#!/usr/bin/env node

// node_modules/typescript-language-server/lib/cli.mjs
import fs$2, { promises, statSync, existsSync, readFileSync } from "node:fs";
import require$$0 from "node:events";
import require$$1 from "node:child_process";
import * as path from "node:path";
import path__default, { extname, resolve } from "node:path";
import process$1 from "node:process";
import require$$0$3, { promisify as promisify$1 } from "node:util";
import require$$0$1, { promisify } from "util";
import require$$1$1 from "path";
import require$$2 from "os";
import crypto from "crypto";
import require$$4 from "net";
import require$$0$2 from "url";
import require$$2$1 from "fs";
import require$$3 from "child_process";
import require$$0$4 from "constants";
import require$$0$5 from "stream";
import require$$5 from "assert";
import os from "node:os";
import fsPromises from "node:fs/promises";
import stream from "node:stream";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
var commonjsGlobal = typeof globalThis !== "undefined" ? globalThis : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : {};
function getDefaultExportFromCjs(x) {
  return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, "default") ? x["default"] : x;
}
var commander$1 = {};
var argument = {};
var error = {};
var hasRequiredError;
function requireError() {
  if (hasRequiredError) return error;
  hasRequiredError = 1;
  class CommanderError2 extends Error {
    constructor(exitCode, code, message) {
      super(message);
      Error.captureStackTrace(this, this.constructor);
      this.name = this.constructor.name;
      this.code = code;
      this.exitCode = exitCode;
      this.nestedError = void 0;
    }
  }
  class InvalidArgumentError2 extends CommanderError2 {
    constructor(message) {
      super(1, "commander.invalidArgument", message);
      Error.captureStackTrace(this, this.constructor);
      this.name = this.constructor.name;
    }
  }
  error.CommanderError = CommanderError2;
  error.InvalidArgumentError = InvalidArgumentError2;
  return error;
}
var hasRequiredArgument;
function requireArgument() {
  if (hasRequiredArgument) return argument;
  hasRequiredArgument = 1;
  const { InvalidArgumentError: InvalidArgumentError2 } = requireError();
  class Argument2 {
    constructor(name, description) {
      this.description = description || "";
      this.variadic = false;
      this.parseArg = void 0;
      this.defaultValue = void 0;
      this.defaultValueDescription = void 0;
      this.argChoices = void 0;
      switch (name[0]) {
        case "<":
          this.required = true;
          this._name = name.slice(1, -1);
          break;
        case "[":
          this.required = false;
          this._name = name.slice(1, -1);
          break;
        default:
          this.required = true;
          this._name = name;
          break;
      }
      if (this._name.endsWith("...")) {
        this.variadic = true;
        this._name = this._name.slice(0, -3);
      }
    }
    name() {
      return this._name;
    }
    _collectValue(value, previous) {
      if (previous === this.defaultValue || !Array.isArray(previous)) {
        return [value];
      }
      previous.push(value);
      return previous;
    }
    default(value, description) {
      this.defaultValue = value;
      this.defaultValueDescription = description;
      return this;
    }
    argParser(fn) {
      this.parseArg = fn;
      return this;
    }
    choices(values) {
      this.argChoices = values.slice();
      this.parseArg = (arg, previous) => {
        if (!this.argChoices.includes(arg)) {
          throw new InvalidArgumentError2(`Allowed choices are ${this.argChoices.join(", ")}.`);
        }
        if (this.variadic) {
          return this._collectValue(arg, previous);
        }
        return arg;
      };
      return this;
    }
    argRequired() {
      this.required = true;
      return this;
    }
    argOptional() {
      this.required = false;
      return this;
    }
  }
  function humanReadableArgName(arg) {
    const nameOutput = arg.name() + (arg.variadic === true ? "..." : "");
    return arg.required ? "<" + nameOutput + ">" : "[" + nameOutput + "]";
  }
  argument.Argument = Argument2;
  argument.humanReadableArgName = humanReadableArgName;
  return argument;
}
var command = {};
var help = {};
var hasRequiredHelp;
function requireHelp() {
  if (hasRequiredHelp) return help;
  hasRequiredHelp = 1;
  const { humanReadableArgName } = requireArgument();
  class Help2 {
    constructor() {
      this.helpWidth = void 0;
      this.minWidthToWrap = 40;
      this.sortSubcommands = false;
      this.sortOptions = false;
      this.showGlobalOptions = false;
    }
    prepareContext(contextOptions) {
      this.helpWidth = this.helpWidth ?? contextOptions.helpWidth ?? 80;
    }
    visibleCommands(cmd) {
      const visibleCommands = cmd.commands.filter((cmd2) => !cmd2._hidden);
      const helpCommand = cmd._getHelpCommand();
      if (helpCommand && !helpCommand._hidden) {
        visibleCommands.push(helpCommand);
      }
      if (this.sortSubcommands) {
        visibleCommands.sort((a, b) => a.name().localeCompare(b.name()));
      }
      return visibleCommands;
    }
    compareOptions(a, b) {
      const getSortKey = (option2) => option2.short ? option2.short.replace(/^-/, "") : option2.long.replace(/^--/, "");
      return getSortKey(a).localeCompare(getSortKey(b));
    }
    visibleOptions(cmd) {
      const visibleOptions = cmd.options.filter((option2) => !option2.hidden);
      const helpOption = cmd._getHelpOption();
      if (helpOption && !helpOption.hidden) {
        const removeShort = helpOption.short && cmd._findOption(helpOption.short);
        const removeLong = helpOption.long && cmd._findOption(helpOption.long);
        if (!removeShort && !removeLong) {
          visibleOptions.push(helpOption);
        } else if (helpOption.long && !removeLong) {
          visibleOptions.push(cmd.createOption(helpOption.long, helpOption.description));
        } else if (helpOption.short && !removeShort) {
          visibleOptions.push(cmd.createOption(helpOption.short, helpOption.description));
        }
      }
      if (this.sortOptions) {
        visibleOptions.sort(this.compareOptions);
      }
      return visibleOptions;
    }
    visibleGlobalOptions(cmd) {
      if (!this.showGlobalOptions) return [];
      const globalOptions = [];
      for (let ancestorCmd = cmd.parent; ancestorCmd; ancestorCmd = ancestorCmd.parent) {
        const visibleOptions = ancestorCmd.options.filter((option2) => !option2.hidden);
        globalOptions.push(...visibleOptions);
      }
      if (this.sortOptions) {
        globalOptions.sort(this.compareOptions);
      }
      return globalOptions;
    }
    visibleArguments(cmd) {
      if (cmd._argsDescription) {
        cmd.registeredArguments.forEach((argument2) => {
          argument2.description = argument2.description || cmd._argsDescription[argument2.name()] || "";
        });
      }
      if (cmd.registeredArguments.find((argument2) => argument2.description)) {
        return cmd.registeredArguments;
      }
      return [];
    }
    subcommandTerm(cmd) {
      const args = cmd.registeredArguments.map((arg) => humanReadableArgName(arg)).join(" ");
      return cmd._name + (cmd._aliases[0] ? "|" + cmd._aliases[0] : "") + (cmd.options.length ? " [options]" : "") + (args ? " " + args : "");
    }
    optionTerm(option2) {
      return option2.flags;
    }
    argumentTerm(argument2) {
      return argument2.name();
    }
    longestSubcommandTermLength(cmd, helper) {
      return helper.visibleCommands(cmd).reduce((max, command2) => Math.max(max, this.displayWidth(helper.styleSubcommandTerm(helper.subcommandTerm(command2)))), 0);
    }
    longestOptionTermLength(cmd, helper) {
      return helper.visibleOptions(cmd).reduce((max, option2) => Math.max(max, this.displayWidth(helper.styleOptionTerm(helper.optionTerm(option2)))), 0);
    }
    longestGlobalOptionTermLength(cmd, helper) {
      return helper.visibleGlobalOptions(cmd).reduce((max, option2) => Math.max(max, this.displayWidth(helper.styleOptionTerm(helper.optionTerm(option2)))), 0);
    }
    longestArgumentTermLength(cmd, helper) {
      return helper.visibleArguments(cmd).reduce((max, argument2) => Math.max(max, this.displayWidth(helper.styleArgumentTerm(helper.argumentTerm(argument2)))), 0);
    }
    commandUsage(cmd) {
      let cmdName = cmd._name;
      if (cmd._aliases[0]) {
        cmdName = cmdName + "|" + cmd._aliases[0];
      }
      let ancestorCmdNames = "";
      for (let ancestorCmd = cmd.parent; ancestorCmd; ancestorCmd = ancestorCmd.parent) {
        ancestorCmdNames = ancestorCmd.name() + " " + ancestorCmdNames;
      }
      return ancestorCmdNames + cmdName + " " + cmd.usage();
    }
    commandDescription(cmd) {
      return cmd.description();
    }
    subcommandDescription(cmd) {
      return cmd.summary() || cmd.description();
    }
    optionDescription(option2) {
      const extraInfo = [];
      if (option2.argChoices) {
        extraInfo.push(`choices: ${option2.argChoices.map((choice) => JSON.stringify(choice)).join(", ")}`);
      }
      if (option2.defaultValue !== void 0) {
        const showDefault = option2.required || option2.optional || option2.isBoolean() && typeof option2.defaultValue === "boolean";
        if (showDefault) {
          extraInfo.push(`default: ${option2.defaultValueDescription || JSON.stringify(option2.defaultValue)}`);
        }
      }
      if (option2.presetArg !== void 0 && option2.optional) {
        extraInfo.push(`preset: ${JSON.stringify(option2.presetArg)}`);
      }
      if (option2.envVar !== void 0) {
        extraInfo.push(`env: ${option2.envVar}`);
      }
      if (extraInfo.length > 0) {
        const extraDescription = `(${extraInfo.join(", ")})`;
        if (option2.description) {
          return `${option2.description} ${extraDescription}`;
        }
        return extraDescription;
      }
      return option2.description;
    }
    argumentDescription(argument2) {
      const extraInfo = [];
      if (argument2.argChoices) {
        extraInfo.push(`choices: ${argument2.argChoices.map((choice) => JSON.stringify(choice)).join(", ")}`);
      }
      if (argument2.defaultValue !== void 0) {
        extraInfo.push(`default: ${argument2.defaultValueDescription || JSON.stringify(argument2.defaultValue)}`);
      }
      if (extraInfo.length > 0) {
        const extraDescription = `(${extraInfo.join(", ")})`;
        if (argument2.description) {
          return `${argument2.description} ${extraDescription}`;
        }
        return extraDescription;
      }
      return argument2.description;
    }
    formatItemList(heading, items, helper) {
      if (items.length === 0) return [];
      return [helper.styleTitle(heading), ...items, ""];
    }
    groupItems(unsortedItems, visibleItems, getGroup) {
      const result = /* @__PURE__ */ new Map();
      unsortedItems.forEach((item) => {
        const group = getGroup(item);
        if (!result.has(group)) result.set(group, []);
      });
      visibleItems.forEach((item) => {
        const group = getGroup(item);
        if (!result.has(group)) {
          result.set(group, []);
        }
        result.get(group).push(item);
      });
      return result;
    }
    formatHelp(cmd, helper) {
      const termWidth = helper.padWidth(cmd, helper);
      const helpWidth = helper.helpWidth ?? 80;
      function callFormatItem(term, description) {
        return helper.formatItem(term, termWidth, description, helper);
      }
      let output = [`${helper.styleTitle("Usage:")} ${helper.styleUsage(helper.commandUsage(cmd))}`, ""];
      const commandDescription = helper.commandDescription(cmd);
      if (commandDescription.length > 0) {
        output = output.concat([helper.boxWrap(helper.styleCommandDescription(commandDescription), helpWidth), ""]);
      }
      const argumentList = helper.visibleArguments(cmd).map((argument2) => callFormatItem(helper.styleArgumentTerm(helper.argumentTerm(argument2)), helper.styleArgumentDescription(helper.argumentDescription(argument2))));
      output = output.concat(this.formatItemList("Arguments:", argumentList, helper));
      const optionGroups = this.groupItems(cmd.options, helper.visibleOptions(cmd), (option2) => option2.helpGroupHeading ?? "Options:");
      optionGroups.forEach((options2, group) => {
        const optionList = options2.map((option2) => callFormatItem(helper.styleOptionTerm(helper.optionTerm(option2)), helper.styleOptionDescription(helper.optionDescription(option2))));
        output = output.concat(this.formatItemList(group, optionList, helper));
      });
      if (helper.showGlobalOptions) {
        const globalOptionList = helper.visibleGlobalOptions(cmd).map((option2) => callFormatItem(helper.styleOptionTerm(helper.optionTerm(option2)), helper.styleOptionDescription(helper.optionDescription(option2))));
        output = output.concat(this.formatItemList("Global Options:", globalOptionList, helper));
      }
      const commandGroups = this.groupItems(cmd.commands, helper.visibleCommands(cmd), (sub) => sub.helpGroup() || "Commands:");
      commandGroups.forEach((commands, group) => {
        const commandList = commands.map((sub) => callFormatItem(helper.styleSubcommandTerm(helper.subcommandTerm(sub)), helper.styleSubcommandDescription(helper.subcommandDescription(sub))));
        output = output.concat(this.formatItemList(group, commandList, helper));
      });
      return output.join("\n");
    }
    displayWidth(str) {
      return stripColor(str).length;
    }
    styleTitle(str) {
      return str;
    }
    styleUsage(str) {
      return str.split(" ").map((word) => {
        if (word === "[options]") return this.styleOptionText(word);
        if (word === "[command]") return this.styleSubcommandText(word);
        if (word[0] === "[" || word[0] === "<") return this.styleArgumentText(word);
        return this.styleCommandText(word);
      }).join(" ");
    }
    styleCommandDescription(str) {
      return this.styleDescriptionText(str);
    }
    styleOptionDescription(str) {
      return this.styleDescriptionText(str);
    }
    styleSubcommandDescription(str) {
      return this.styleDescriptionText(str);
    }
    styleArgumentDescription(str) {
      return this.styleDescriptionText(str);
    }
    styleDescriptionText(str) {
      return str;
    }
    styleOptionTerm(str) {
      return this.styleOptionText(str);
    }
    styleSubcommandTerm(str) {
      return str.split(" ").map((word) => {
        if (word === "[options]") return this.styleOptionText(word);
        if (word[0] === "[" || word[0] === "<") return this.styleArgumentText(word);
        return this.styleSubcommandText(word);
      }).join(" ");
    }
    styleArgumentTerm(str) {
      return this.styleArgumentText(str);
    }
    styleOptionText(str) {
      return str;
    }
    styleArgumentText(str) {
      return str;
    }
    styleSubcommandText(str) {
      return str;
    }
    styleCommandText(str) {
      return str;
    }
    padWidth(cmd, helper) {
      return Math.max(helper.longestOptionTermLength(cmd, helper), helper.longestGlobalOptionTermLength(cmd, helper), helper.longestSubcommandTermLength(cmd, helper), helper.longestArgumentTermLength(cmd, helper));
    }
    preformatted(str) {
      return /\n[^\S\r\n]/.test(str);
    }
    formatItem(term, termWidth, description, helper) {
      const itemIndent = 2;
      const itemIndentStr = " ".repeat(itemIndent);
      if (!description) return itemIndentStr + term;
      const paddedTerm = term.padEnd(termWidth + term.length - helper.displayWidth(term));
      const spacerWidth = 2;
      const helpWidth = this.helpWidth ?? 80;
      const remainingWidth = helpWidth - termWidth - spacerWidth - itemIndent;
      let formattedDescription;
      if (remainingWidth < this.minWidthToWrap || helper.preformatted(description)) {
        formattedDescription = description;
      } else {
        const wrappedDescription = helper.boxWrap(description, remainingWidth);
        formattedDescription = wrappedDescription.replace(/\n/g, "\n" + " ".repeat(termWidth + spacerWidth));
      }
      return itemIndentStr + paddedTerm + " ".repeat(spacerWidth) + formattedDescription.replace(/\n/g, `
${itemIndentStr}`);
    }
    boxWrap(str, width) {
      if (width < this.minWidthToWrap) return str;
      const rawLines = str.split(/\r\n|\n/);
      const chunkPattern = /[\s]*[^\s]+/g;
      const wrappedLines = [];
      rawLines.forEach((line) => {
        const chunks = line.match(chunkPattern);
        if (chunks === null) {
          wrappedLines.push("");
          return;
        }
        let sumChunks = [chunks.shift()];
        let sumWidth = this.displayWidth(sumChunks[0]);
        chunks.forEach((chunk) => {
          const visibleWidth = this.displayWidth(chunk);
          if (sumWidth + visibleWidth <= width) {
            sumChunks.push(chunk);
            sumWidth += visibleWidth;
            return;
          }
          wrappedLines.push(sumChunks.join(""));
          const nextChunk = chunk.trimStart();
          sumChunks = [nextChunk];
          sumWidth = this.displayWidth(nextChunk);
        });
        wrappedLines.push(sumChunks.join(""));
      });
      return wrappedLines.join("\n");
    }
  }
  function stripColor(str) {
    const sgrPattern = /\x1b\[\d*(;\d*)*m/g;
    return str.replace(sgrPattern, "");
  }
  help.Help = Help2;
  help.stripColor = stripColor;
  return help;
}
var option = {};
var hasRequiredOption;
function requireOption() {
  if (hasRequiredOption) return option;
  hasRequiredOption = 1;
  const { InvalidArgumentError: InvalidArgumentError2 } = requireError();
  class Option2 {
    constructor(flags, description) {
      this.flags = flags;
      this.description = description || "";
      this.required = flags.includes("<");
      this.optional = flags.includes("[");
      this.variadic = /\w\.\.\.[>\]]$/.test(flags);
      this.mandatory = false;
      const optionFlags = splitOptionFlags(flags);
      this.short = optionFlags.shortFlag;
      this.long = optionFlags.longFlag;
      this.negate = false;
      if (this.long) {
        this.negate = this.long.startsWith("--no-");
      }
      this.defaultValue = void 0;
      this.defaultValueDescription = void 0;
      this.presetArg = void 0;
      this.envVar = void 0;
      this.parseArg = void 0;
      this.hidden = false;
      this.argChoices = void 0;
      this.conflictsWith = [];
      this.implied = void 0;
      this.helpGroupHeading = void 0;
    }
    default(value, description) {
      this.defaultValue = value;
      this.defaultValueDescription = description;
      return this;
    }
    preset(arg) {
      this.presetArg = arg;
      return this;
    }
    conflicts(names) {
      this.conflictsWith = this.conflictsWith.concat(names);
      return this;
    }
    implies(impliedOptionValues) {
      let newImplied = impliedOptionValues;
      if (typeof impliedOptionValues === "string") {
        newImplied = {
          [impliedOptionValues]: true
        };
      }
      this.implied = Object.assign(this.implied || {}, newImplied);
      return this;
    }
    env(name) {
      this.envVar = name;
      return this;
    }
    argParser(fn) {
      this.parseArg = fn;
      return this;
    }
    makeOptionMandatory(mandatory = true) {
      this.mandatory = !!mandatory;
      return this;
    }
    hideHelp(hide = true) {
      this.hidden = !!hide;
      return this;
    }
    _collectValue(value, previous) {
      if (previous === this.defaultValue || !Array.isArray(previous)) {
        return [value];
      }
      previous.push(value);
      return previous;
    }
    choices(values) {
      this.argChoices = values.slice();
      this.parseArg = (arg, previous) => {
        if (!this.argChoices.includes(arg)) {
          throw new InvalidArgumentError2(`Allowed choices are ${this.argChoices.join(", ")}.`);
        }
        if (this.variadic) {
          return this._collectValue(arg, previous);
        }
        return arg;
      };
      return this;
    }
    name() {
      if (this.long) {
        return this.long.replace(/^--/, "");
      }
      return this.short.replace(/^-/, "");
    }
    attributeName() {
      if (this.negate) {
        return camelcase(this.name().replace(/^no-/, ""));
      }
      return camelcase(this.name());
    }
    helpGroup(heading) {
      this.helpGroupHeading = heading;
      return this;
    }
    is(arg) {
      return this.short === arg || this.long === arg;
    }
    isBoolean() {
      return !this.required && !this.optional && !this.negate;
    }
  }
  class DualOptions {
    constructor(options2) {
      this.positiveOptions = /* @__PURE__ */ new Map();
      this.negativeOptions = /* @__PURE__ */ new Map();
      this.dualOptions = /* @__PURE__ */ new Set();
      options2.forEach((option2) => {
        if (option2.negate) {
          this.negativeOptions.set(option2.attributeName(), option2);
        } else {
          this.positiveOptions.set(option2.attributeName(), option2);
        }
      });
      this.negativeOptions.forEach((value, key) => {
        if (this.positiveOptions.has(key)) {
          this.dualOptions.add(key);
        }
      });
    }
    valueFromOption(value, option2) {
      const optionKey = option2.attributeName();
      if (!this.dualOptions.has(optionKey)) return true;
      const preset = this.negativeOptions.get(optionKey).presetArg;
      const negativeValue = preset !== void 0 ? preset : false;
      return option2.negate === (negativeValue === value);
    }
  }
  function camelcase(str) {
    return str.split("-").reduce((str2, word) => str2 + word[0].toUpperCase() + word.slice(1));
  }
  function splitOptionFlags(flags) {
    let shortFlag;
    let longFlag;
    const shortFlagExp = /^-[^-]$/;
    const longFlagExp = /^--[^-]/;
    const flagParts = flags.split(/[ |,]+/).concat("guard");
    if (shortFlagExp.test(flagParts[0])) shortFlag = flagParts.shift();
    if (longFlagExp.test(flagParts[0])) longFlag = flagParts.shift();
    if (!shortFlag && shortFlagExp.test(flagParts[0])) shortFlag = flagParts.shift();
    if (!shortFlag && longFlagExp.test(flagParts[0])) {
      shortFlag = longFlag;
      longFlag = flagParts.shift();
    }
    if (flagParts[0].startsWith("-")) {
      const unsupportedFlag = flagParts[0];
      const baseError = `option creation failed due to '${unsupportedFlag}' in option flags '${flags}'`;
      if (/^-[^-][^-]/.test(unsupportedFlag)) throw new Error(`${baseError}
- a short flag is a single dash and a single character
  - either use a single dash and a single character (for a short flag)
  - or use a double dash for a long option (and can have two, like '--ws, --workspace')`);
      if (shortFlagExp.test(unsupportedFlag)) throw new Error(`${baseError}
- too many short flags`);
      if (longFlagExp.test(unsupportedFlag)) throw new Error(`${baseError}
- too many long flags`);
      throw new Error(`${baseError}
- unrecognised flag format`);
    }
    if (shortFlag === void 0 && longFlag === void 0) throw new Error(`option creation failed due to no flags found in '${flags}'.`);
    return {
      shortFlag,
      longFlag
    };
  }
  option.Option = Option2;
  option.DualOptions = DualOptions;
  return option;
}
var suggestSimilar = {};
var hasRequiredSuggestSimilar;
function requireSuggestSimilar() {
  if (hasRequiredSuggestSimilar) return suggestSimilar;
  hasRequiredSuggestSimilar = 1;
  const maxDistance = 3;
  function editDistance(a, b) {
    if (Math.abs(a.length - b.length) > maxDistance) return Math.max(a.length, b.length);
    const d = [];
    for (let i = 0; i <= a.length; i++) {
      d[i] = [i];
    }
    for (let j = 0; j <= b.length; j++) {
      d[0][j] = j;
    }
    for (let j = 1; j <= b.length; j++) {
      for (let i = 1; i <= a.length; i++) {
        let cost = 1;
        if (a[i - 1] === b[j - 1]) {
          cost = 0;
        } else {
          cost = 1;
        }
        d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost);
        if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) {
          d[i][j] = Math.min(d[i][j], d[i - 2][j - 2] + 1);
        }
      }
    }
    return d[a.length][b.length];
  }
  function suggestSimilar$1(word, candidates) {
    if (!candidates || candidates.length === 0) return "";
    candidates = Array.from(new Set(candidates));
    const searchingOptions = word.startsWith("--");
    if (searchingOptions) {
      word = word.slice(2);
      candidates = candidates.map((candidate) => candidate.slice(2));
    }
    let similar = [];
    let bestDistance = maxDistance;
    const minSimilarity = 0.4;
    candidates.forEach((candidate) => {
      if (candidate.length <= 1) return;
      const distance = editDistance(word, candidate);
      const length = Math.max(word.length, candidate.length);
      const similarity = (length - distance) / length;
      if (similarity > minSimilarity) {
        if (distance < bestDistance) {
          bestDistance = distance;
          similar = [candidate];
        } else if (distance === bestDistance) {
          similar.push(candidate);
        }
      }
    });
    similar.sort((a, b) => a.localeCompare(b));
    if (searchingOptions) {
      similar = similar.map((candidate) => `--${candidate}`);
    }
    if (similar.length > 1) {
      return `
(Did you mean one of ${similar.join(", ")}?)`;
    }
    if (similar.length === 1) {
      return `
(Did you mean ${similar[0]}?)`;
    }
    return "";
  }
  suggestSimilar.suggestSimilar = suggestSimilar$1;
  return suggestSimilar;
}
var hasRequiredCommand;
function requireCommand() {
  if (hasRequiredCommand) return command;
  hasRequiredCommand = 1;
  const EventEmitter = require$$0.EventEmitter;
  const childProcess = require$$1;
  const path2 = path__default;
  const fs2 = fs$2;
  const process2 = process$1;
  const { Argument: Argument2, humanReadableArgName } = requireArgument();
  const { CommanderError: CommanderError2 } = requireError();
  const { Help: Help2, stripColor } = requireHelp();
  const { Option: Option2, DualOptions } = requireOption();
  const { suggestSimilar: suggestSimilar2 } = requireSuggestSimilar();
  class Command2 extends EventEmitter {
    constructor(name) {
      super();
      this.commands = [];
      this.options = [];
      this.parent = null;
      this._allowUnknownOption = false;
      this._allowExcessArguments = false;
      this.registeredArguments = [];
      this._args = this.registeredArguments;
      this.args = [];
      this.rawArgs = [];
      this.processedArgs = [];
      this._scriptPath = null;
      this._name = name || "";
      this._optionValues = {};
      this._optionValueSources = {};
      this._storeOptionsAsProperties = false;
      this._actionHandler = null;
      this._executableHandler = false;
      this._executableFile = null;
      this._executableDir = null;
      this._defaultCommandName = null;
      this._exitCallback = null;
      this._aliases = [];
      this._combineFlagAndOptionalValue = true;
      this._description = "";
      this._summary = "";
      this._argsDescription = void 0;
      this._enablePositionalOptions = false;
      this._passThroughOptions = false;
      this._lifeCycleHooks = {};
      this._showHelpAfterError = false;
      this._showSuggestionAfterError = true;
      this._savedState = null;
      this._outputConfiguration = {
        writeOut: (str) => process2.stdout.write(str),
        writeErr: (str) => process2.stderr.write(str),
        outputError: (str, write) => write(str),
        getOutHelpWidth: () => process2.stdout.isTTY ? process2.stdout.columns : void 0,
        getErrHelpWidth: () => process2.stderr.isTTY ? process2.stderr.columns : void 0,
        getOutHasColors: () => useColor() ?? (process2.stdout.isTTY && process2.stdout.hasColors?.()),
        getErrHasColors: () => useColor() ?? (process2.stderr.isTTY && process2.stderr.hasColors?.()),
        stripColor: (str) => stripColor(str)
      };
      this._hidden = false;
      this._helpOption = void 0;
      this._addImplicitHelpCommand = void 0;
      this._helpCommand = void 0;
      this._helpConfiguration = {};
      this._helpGroupHeading = void 0;
      this._defaultCommandGroup = void 0;
      this._defaultOptionGroup = void 0;
    }
    copyInheritedSettings(sourceCommand) {
      this._outputConfiguration = sourceCommand._outputConfiguration;
      this._helpOption = sourceCommand._helpOption;
      this._helpCommand = sourceCommand._helpCommand;
      this._helpConfiguration = sourceCommand._helpConfiguration;
      this._exitCallback = sourceCommand._exitCallback;
      this._storeOptionsAsProperties = sourceCommand._storeOptionsAsProperties;
      this._combineFlagAndOptionalValue = sourceCommand._combineFlagAndOptionalValue;
      this._allowExcessArguments = sourceCommand._allowExcessArguments;
      this._enablePositionalOptions = sourceCommand._enablePositionalOptions;
      this._showHelpAfterError = sourceCommand._showHelpAfterError;
      this._showSuggestionAfterError = sourceCommand._showSuggestionAfterError;
      return this;
    }
    _getCommandAndAncestors() {
      const result = [];
      for (let command2 = this; command2; command2 = command2.parent) {
        result.push(command2);
      }
      return result;
    }
    command(nameAndArgs, actionOptsOrExecDesc, execOpts) {
      let desc = actionOptsOrExecDesc;
      let opts = execOpts;
      if (typeof desc === "object" && desc !== null) {
        opts = desc;
        desc = null;
      }
      opts = opts || {};
      const [, name, args] = nameAndArgs.match(/([^ ]+) *(.*)/);
      const cmd = this.createCommand(name);
      if (desc) {
        cmd.description(desc);
        cmd._executableHandler = true;
      }
      if (opts.isDefault) this._defaultCommandName = cmd._name;
      cmd._hidden = !!(opts.noHelp || opts.hidden);
      cmd._executableFile = opts.executableFile || null;
      if (args) cmd.arguments(args);
      this._registerCommand(cmd);
      cmd.parent = this;
      cmd.copyInheritedSettings(this);
      if (desc) return this;
      return cmd;
    }
    createCommand(name) {
      return new Command2(name);
    }
    createHelp() {
      return Object.assign(new Help2(), this.configureHelp());
    }
    configureHelp(configuration2) {
      if (configuration2 === void 0) return this._helpConfiguration;
      this._helpConfiguration = configuration2;
      return this;
    }
    configureOutput(configuration2) {
      if (configuration2 === void 0) return this._outputConfiguration;
      this._outputConfiguration = {
        ...this._outputConfiguration,
        ...configuration2
      };
      return this;
    }
    showHelpAfterError(displayHelp = true) {
      if (typeof displayHelp !== "string") displayHelp = !!displayHelp;
      this._showHelpAfterError = displayHelp;
      return this;
    }
    showSuggestionAfterError(displaySuggestion = true) {
      this._showSuggestionAfterError = !!displaySuggestion;
      return this;
    }
    addCommand(cmd, opts) {
      if (!cmd._name) {
        throw new Error(`Command passed to .addCommand() must have a name
- specify the name in Command constructor or using .name()`);
      }
      opts = opts || {};
      if (opts.isDefault) this._defaultCommandName = cmd._name;
      if (opts.noHelp || opts.hidden) cmd._hidden = true;
      this._registerCommand(cmd);
      cmd.parent = this;
      cmd._checkForBrokenPassThrough();
      return this;
    }
    createArgument(name, description) {
      return new Argument2(name, description);
    }
    argument(name, description, parseArg, defaultValue) {
      const argument2 = this.createArgument(name, description);
      if (typeof parseArg === "function") {
        argument2.default(defaultValue).argParser(parseArg);
      } else {
        argument2.default(parseArg);
      }
      this.addArgument(argument2);
      return this;
    }
    arguments(names) {
      names.trim().split(/ +/).forEach((detail) => {
        this.argument(detail);
      });
      return this;
    }
    addArgument(argument2) {
      const previousArgument = this.registeredArguments.slice(-1)[0];
      if (previousArgument?.variadic) {
        throw new Error(`only the last argument can be variadic '${previousArgument.name()}'`);
      }
      if (argument2.required && argument2.defaultValue !== void 0 && argument2.parseArg === void 0) {
        throw new Error(`a default value for a required argument is never used: '${argument2.name()}'`);
      }
      this.registeredArguments.push(argument2);
      return this;
    }
    helpCommand(enableOrNameAndArgs, description) {
      if (typeof enableOrNameAndArgs === "boolean") {
        this._addImplicitHelpCommand = enableOrNameAndArgs;
        if (enableOrNameAndArgs && this._defaultCommandGroup) {
          this._initCommandGroup(this._getHelpCommand());
        }
        return this;
      }
      const nameAndArgs = enableOrNameAndArgs ?? "help [command]";
      const [, helpName, helpArgs] = nameAndArgs.match(/([^ ]+) *(.*)/);
      const helpDescription = description ?? "display help for command";
      const helpCommand = this.createCommand(helpName);
      helpCommand.helpOption(false);
      if (helpArgs) helpCommand.arguments(helpArgs);
      if (helpDescription) helpCommand.description(helpDescription);
      this._addImplicitHelpCommand = true;
      this._helpCommand = helpCommand;
      if (enableOrNameAndArgs || description) this._initCommandGroup(helpCommand);
      return this;
    }
    addHelpCommand(helpCommand, deprecatedDescription) {
      if (typeof helpCommand !== "object") {
        this.helpCommand(helpCommand, deprecatedDescription);
        return this;
      }
      this._addImplicitHelpCommand = true;
      this._helpCommand = helpCommand;
      this._initCommandGroup(helpCommand);
      return this;
    }
    _getHelpCommand() {
      const hasImplicitHelpCommand = this._addImplicitHelpCommand ?? (this.commands.length && !this._actionHandler && !this._findCommand("help"));
      if (hasImplicitHelpCommand) {
        if (this._helpCommand === void 0) {
          this.helpCommand(void 0, void 0);
        }
        return this._helpCommand;
      }
      return null;
    }
    hook(event, listener) {
      const allowedValues = ["preSubcommand", "preAction", "postAction"];
      if (!allowedValues.includes(event)) {
        throw new Error(`Unexpected value for event passed to hook : '${event}'.
Expecting one of '${allowedValues.join("', '")}'`);
      }
      if (this._lifeCycleHooks[event]) {
        this._lifeCycleHooks[event].push(listener);
      } else {
        this._lifeCycleHooks[event] = [listener];
      }
      return this;
    }
    exitOverride(fn) {
      if (fn) {
        this._exitCallback = fn;
      } else {
        this._exitCallback = (err) => {
          if (err.code !== "commander.executeSubCommandAsync") {
            throw err;
          }
        };
      }
      return this;
    }
    _exit(exitCode, code, message) {
      if (this._exitCallback) {
        this._exitCallback(new CommanderError2(exitCode, code, message));
      }
      process2.exit(exitCode);
    }
    action(fn) {
      const listener = (args) => {
        const expectedArgsCount = this.registeredArguments.length;
        const actionArgs = args.slice(0, expectedArgsCount);
        if (this._storeOptionsAsProperties) {
          actionArgs[expectedArgsCount] = this;
        } else {
          actionArgs[expectedArgsCount] = this.opts();
        }
        actionArgs.push(this);
        return fn.apply(this, actionArgs);
      };
      this._actionHandler = listener;
      return this;
    }
    createOption(flags, description) {
      return new Option2(flags, description);
    }
    _callParseArg(target, value, previous, invalidArgumentMessage) {
      try {
        return target.parseArg(value, previous);
      } catch (err) {
        if (err.code === "commander.invalidArgument") {
          const message = `${invalidArgumentMessage} ${err.message}`;
          this.error(message, {
            exitCode: err.exitCode,
            code: err.code
          });
        }
        throw err;
      }
    }
    _registerOption(option2) {
      const matchingOption = option2.short && this._findOption(option2.short) || option2.long && this._findOption(option2.long);
      if (matchingOption) {
        const matchingFlag = option2.long && this._findOption(option2.long) ? option2.long : option2.short;
        throw new Error(`Cannot add option '${option2.flags}'${this._name && ` to command '${this._name}'`} due to conflicting flag '${matchingFlag}'
-  already used by option '${matchingOption.flags}'`);
      }
      this._initOptionGroup(option2);
      this.options.push(option2);
    }
    _registerCommand(command2) {
      const knownBy = (cmd) => [cmd.name()].concat(cmd.aliases());
      const alreadyUsed = knownBy(command2).find((name) => this._findCommand(name));
      if (alreadyUsed) {
        const existingCmd = knownBy(this._findCommand(alreadyUsed)).join("|");
        const newCmd = knownBy(command2).join("|");
        throw new Error(`cannot add command '${newCmd}' as already have command '${existingCmd}'`);
      }
      this._initCommandGroup(command2);
      this.commands.push(command2);
    }
    addOption(option2) {
      this._registerOption(option2);
      const oname = option2.name();
      const name = option2.attributeName();
      if (option2.negate) {
        const positiveLongFlag = option2.long.replace(/^--no-/, "--");
        if (!this._findOption(positiveLongFlag)) {
          this.setOptionValueWithSource(name, option2.defaultValue === void 0 ? true : option2.defaultValue, "default");
        }
      } else if (option2.defaultValue !== void 0) {
        this.setOptionValueWithSource(name, option2.defaultValue, "default");
      }
      const handleOptionValue = (val, invalidValueMessage, valueSource) => {
        if (val == null && option2.presetArg !== void 0) {
          val = option2.presetArg;
        }
        const oldValue = this.getOptionValue(name);
        if (val !== null && option2.parseArg) {
          val = this._callParseArg(option2, val, oldValue, invalidValueMessage);
        } else if (val !== null && option2.variadic) {
          val = option2._collectValue(val, oldValue);
        }
        if (val == null) {
          if (option2.negate) {
            val = false;
          } else if (option2.isBoolean() || option2.optional) {
            val = true;
          } else {
            val = "";
          }
        }
        this.setOptionValueWithSource(name, val, valueSource);
      };
      this.on("option:" + oname, (val) => {
        const invalidValueMessage = `error: option '${option2.flags}' argument '${val}' is invalid.`;
        handleOptionValue(val, invalidValueMessage, "cli");
      });
      if (option2.envVar) {
        this.on("optionEnv:" + oname, (val) => {
          const invalidValueMessage = `error: option '${option2.flags}' value '${val}' from env '${option2.envVar}' is invalid.`;
          handleOptionValue(val, invalidValueMessage, "env");
        });
      }
      return this;
    }
    _optionEx(config, flags, description, fn, defaultValue) {
      if (typeof flags === "object" && flags instanceof Option2) {
        throw new Error("To add an Option object use addOption() instead of option() or requiredOption()");
      }
      const option2 = this.createOption(flags, description);
      option2.makeOptionMandatory(!!config.mandatory);
      if (typeof fn === "function") {
        option2.default(defaultValue).argParser(fn);
      } else if (fn instanceof RegExp) {
        const regex = fn;
        fn = (val, def) => {
          const m = regex.exec(val);
          return m ? m[0] : def;
        };
        option2.default(defaultValue).argParser(fn);
      } else {
        option2.default(fn);
      }
      return this.addOption(option2);
    }
    option(flags, description, parseArg, defaultValue) {
      return this._optionEx({}, flags, description, parseArg, defaultValue);
    }
    requiredOption(flags, description, parseArg, defaultValue) {
      return this._optionEx({
        mandatory: true
      }, flags, description, parseArg, defaultValue);
    }
    combineFlagAndOptionalValue(combine = true) {
      this._combineFlagAndOptionalValue = !!combine;
      return this;
    }
    allowUnknownOption(allowUnknown = true) {
      this._allowUnknownOption = !!allowUnknown;
      return this;
    }
    allowExcessArguments(allowExcess = true) {
      this._allowExcessArguments = !!allowExcess;
      return this;
    }
    enablePositionalOptions(positional = true) {
      this._enablePositionalOptions = !!positional;
      return this;
    }
    passThroughOptions(passThrough = true) {
      this._passThroughOptions = !!passThrough;
      this._checkForBrokenPassThrough();
      return this;
    }
    _checkForBrokenPassThrough() {
      if (this.parent && this._passThroughOptions && !this.parent._enablePositionalOptions) {
        throw new Error(`passThroughOptions cannot be used for '${this._name}' without turning on enablePositionalOptions for parent command(s)`);
      }
    }
    storeOptionsAsProperties(storeAsProperties = true) {
      if (this.options.length) {
        throw new Error("call .storeOptionsAsProperties() before adding options");
      }
      if (Object.keys(this._optionValues).length) {
        throw new Error("call .storeOptionsAsProperties() before setting option values");
      }
      this._storeOptionsAsProperties = !!storeAsProperties;
      return this;
    }
    getOptionValue(key) {
      if (this._storeOptionsAsProperties) {
        return this[key];
      }
      return this._optionValues[key];
    }
    setOptionValue(key, value) {
      return this.setOptionValueWithSource(key, value, void 0);
    }
    setOptionValueWithSource(key, value, source) {
      if (this._storeOptionsAsProperties) {
        this[key] = value;
      } else {
        this._optionValues[key] = value;
      }
      this._optionValueSources[key] = source;
      return this;
    }
    getOptionValueSource(key) {
      return this._optionValueSources[key];
    }
    getOptionValueSourceWithGlobals(key) {
      let source;
      this._getCommandAndAncestors().forEach((cmd) => {
        if (cmd.getOptionValueSource(key) !== void 0) {
          source = cmd.getOptionValueSource(key);
        }
      });
      return source;
    }
    _prepareUserArgs(argv, parseOptions) {
      if (argv !== void 0 && !Array.isArray(argv)) {
        throw new Error("first parameter to parse must be array or undefined");
      }
      parseOptions = parseOptions || {};
      if (argv === void 0 && parseOptions.from === void 0) {
        if (process2.versions?.electron) {
          parseOptions.from = "electron";
        }
        const execArgv = process2.execArgv ?? [];
        if (execArgv.includes("-e") || execArgv.includes("--eval") || execArgv.includes("-p") || execArgv.includes("--print")) {
          parseOptions.from = "eval";
        }
      }
      if (argv === void 0) {
        argv = process2.argv;
      }
      this.rawArgs = argv.slice();
      let userArgs;
      switch (parseOptions.from) {
        case void 0:
        case "node":
          this._scriptPath = argv[1];
          userArgs = argv.slice(2);
          break;
        case "electron":
          if (process2.defaultApp) {
            this._scriptPath = argv[1];
            userArgs = argv.slice(2);
          } else {
            userArgs = argv.slice(1);
          }
          break;
        case "user":
          userArgs = argv.slice(0);
          break;
        case "eval":
          userArgs = argv.slice(1);
          break;
        default:
          throw new Error(`unexpected parse option { from: '${parseOptions.from}' }`);
      }
      if (!this._name && this._scriptPath) this.nameFromFilename(this._scriptPath);
      this._name = this._name || "program";
      return userArgs;
    }
    parse(argv, parseOptions) {
      this._prepareForParse();
      const userArgs = this._prepareUserArgs(argv, parseOptions);
      this._parseCommand([], userArgs);
      return this;
    }
    async parseAsync(argv, parseOptions) {
      this._prepareForParse();
      const userArgs = this._prepareUserArgs(argv, parseOptions);
      await this._parseCommand([], userArgs);
      return this;
    }
    _prepareForParse() {
      if (this._savedState === null) {
        this.saveStateBeforeParse();
      } else {
        this.restoreStateBeforeParse();
      }
    }
    saveStateBeforeParse() {
      this._savedState = {
        _name: this._name,
        _optionValues: {
          ...this._optionValues
        },
        _optionValueSources: {
          ...this._optionValueSources
        }
      };
    }
    restoreStateBeforeParse() {
      if (this._storeOptionsAsProperties) throw new Error(`Can not call parse again when storeOptionsAsProperties is true.
- either make a new Command for each call to parse, or stop storing options as properties`);
      this._name = this._savedState._name;
      this._scriptPath = null;
      this.rawArgs = [];
      this._optionValues = {
        ...this._savedState._optionValues
      };
      this._optionValueSources = {
        ...this._savedState._optionValueSources
      };
      this.args = [];
      this.processedArgs = [];
    }
    _checkForMissingExecutable(executableFile, executableDir, subcommandName) {
      if (fs2.existsSync(executableFile)) return;
      const executableDirMessage = executableDir ? `searched for local subcommand relative to directory '${executableDir}'` : "no directory for search for local subcommand, use .executableDir() to supply a custom directory";
      const executableMissing = `'${executableFile}' does not exist
 - if '${subcommandName}' is not meant to be an executable command, remove description parameter from '.command()' and use '.description()' instead
 - if the default executable name is not suitable, use the executableFile option to supply a custom name or path
 - ${executableDirMessage}`;
      throw new Error(executableMissing);
    }
    _executeSubCommand(subcommand, args) {
      args = args.slice();
      let launchWithNode = false;
      const sourceExt = [".js", ".ts", ".tsx", ".mjs", ".cjs"];
      function findFile(baseDir, baseName) {
        const localBin = path2.resolve(baseDir, baseName);
        if (fs2.existsSync(localBin)) return localBin;
        if (sourceExt.includes(path2.extname(baseName))) return void 0;
        const foundExt = sourceExt.find((ext) => fs2.existsSync(`${localBin}${ext}`));
        if (foundExt) return `${localBin}${foundExt}`;
        return void 0;
      }
      this._checkForMissingMandatoryOptions();
      this._checkForConflictingOptions();
      let executableFile = subcommand._executableFile || `${this._name}-${subcommand._name}`;
      let executableDir = this._executableDir || "";
      if (this._scriptPath) {
        let resolvedScriptPath;
        try {
          resolvedScriptPath = fs2.realpathSync(this._scriptPath);
        } catch {
          resolvedScriptPath = this._scriptPath;
        }
        executableDir = path2.resolve(path2.dirname(resolvedScriptPath), executableDir);
      }
      if (executableDir) {
        let localFile = findFile(executableDir, executableFile);
        if (!localFile && !subcommand._executableFile && this._scriptPath) {
          const legacyName = path2.basename(this._scriptPath, path2.extname(this._scriptPath));
          if (legacyName !== this._name) {
            localFile = findFile(executableDir, `${legacyName}-${subcommand._name}`);
          }
        }
        executableFile = localFile || executableFile;
      }
      launchWithNode = sourceExt.includes(path2.extname(executableFile));
      let proc;
      if (process2.platform !== "win32") {
        if (launchWithNode) {
          args.unshift(executableFile);
          args = incrementNodeInspectorPort(process2.execArgv).concat(args);
          proc = childProcess.spawn(process2.argv[0], args, {
            stdio: "inherit"
          });
        } else {
          proc = childProcess.spawn(executableFile, args, {
            stdio: "inherit"
          });
        }
      } else {
        this._checkForMissingExecutable(executableFile, executableDir, subcommand._name);
        args.unshift(executableFile);
        args = incrementNodeInspectorPort(process2.execArgv).concat(args);
        proc = childProcess.spawn(process2.execPath, args, {
          stdio: "inherit"
        });
      }
      if (!proc.killed) {
        const signals = ["SIGUSR1", "SIGUSR2", "SIGTERM", "SIGINT", "SIGHUP"];
        signals.forEach((signal) => {
          process2.on(signal, () => {
            if (proc.killed === false && proc.exitCode === null) {
              proc.kill(signal);
            }
          });
        });
      }
      const exitCallback = this._exitCallback;
      proc.on("close", (code) => {
        code = code ?? 1;
        if (!exitCallback) {
          process2.exit(code);
        } else {
          exitCallback(new CommanderError2(code, "commander.executeSubCommandAsync", "(close)"));
        }
      });
      proc.on("error", (err) => {
        if (err.code === "ENOENT") {
          this._checkForMissingExecutable(executableFile, executableDir, subcommand._name);
        } else if (err.code === "EACCES") {
          throw new Error(`'${executableFile}' not executable`);
        }
        if (!exitCallback) {
          process2.exit(1);
        } else {
          const wrappedError = new CommanderError2(1, "commander.executeSubCommandAsync", "(error)");
          wrappedError.nestedError = err;
          exitCallback(wrappedError);
        }
      });
      this.runningCommand = proc;
    }
    _dispatchSubcommand(commandName, operands, unknown) {
      const subCommand = this._findCommand(commandName);
      if (!subCommand) this.help({
        error: true
      });
      subCommand._prepareForParse();
      let promiseChain;
      promiseChain = this._chainOrCallSubCommandHook(promiseChain, subCommand, "preSubcommand");
      promiseChain = this._chainOrCall(promiseChain, () => {
        if (subCommand._executableHandler) {
          this._executeSubCommand(subCommand, operands.concat(unknown));
        } else {
          return subCommand._parseCommand(operands, unknown);
        }
      });
      return promiseChain;
    }
    _dispatchHelpCommand(subcommandName) {
      if (!subcommandName) {
        this.help();
      }
      const subCommand = this._findCommand(subcommandName);
      if (subCommand && !subCommand._executableHandler) {
        subCommand.help();
      }
      return this._dispatchSubcommand(subcommandName, [], [this._getHelpOption()?.long ?? this._getHelpOption()?.short ?? "--help"]);
    }
    _checkNumberOfArguments() {
      this.registeredArguments.forEach((arg, i) => {
        if (arg.required && this.args[i] == null) {
          this.missingArgument(arg.name());
        }
      });
      if (this.registeredArguments.length > 0 && this.registeredArguments[this.registeredArguments.length - 1].variadic) {
        return;
      }
      if (this.args.length > this.registeredArguments.length) {
        this._excessArguments(this.args);
      }
    }
    _processArguments() {
      const myParseArg = (argument2, value, previous) => {
        let parsedValue = value;
        if (value !== null && argument2.parseArg) {
          const invalidValueMessage = `error: command-argument value '${value}' is invalid for argument '${argument2.name()}'.`;
          parsedValue = this._callParseArg(argument2, value, previous, invalidValueMessage);
        }
        return parsedValue;
      };
      this._checkNumberOfArguments();
      const processedArgs = [];
      this.registeredArguments.forEach((declaredArg, index) => {
        let value = declaredArg.defaultValue;
        if (declaredArg.variadic) {
          if (index < this.args.length) {
            value = this.args.slice(index);
            if (declaredArg.parseArg) {
              value = value.reduce((processed, v) => myParseArg(declaredArg, v, processed), declaredArg.defaultValue);
            }
          } else if (value === void 0) {
            value = [];
          }
        } else if (index < this.args.length) {
          value = this.args[index];
          if (declaredArg.parseArg) {
            value = myParseArg(declaredArg, value, declaredArg.defaultValue);
          }
        }
        processedArgs[index] = value;
      });
      this.processedArgs = processedArgs;
    }
    _chainOrCall(promise, fn) {
      if (promise?.then && typeof promise.then === "function") {
        return promise.then(() => fn());
      }
      return fn();
    }
    _chainOrCallHooks(promise, event) {
      let result = promise;
      const hooks = [];
      this._getCommandAndAncestors().reverse().filter((cmd) => cmd._lifeCycleHooks[event] !== void 0).forEach((hookedCommand) => {
        hookedCommand._lifeCycleHooks[event].forEach((callback) => {
          hooks.push({
            hookedCommand,
            callback
          });
        });
      });
      if (event === "postAction") {
        hooks.reverse();
      }
      hooks.forEach((hookDetail) => {
        result = this._chainOrCall(result, () => hookDetail.callback(hookDetail.hookedCommand, this));
      });
      return result;
    }
    _chainOrCallSubCommandHook(promise, subCommand, event) {
      let result = promise;
      if (this._lifeCycleHooks[event] !== void 0) {
        this._lifeCycleHooks[event].forEach((hook) => {
          result = this._chainOrCall(result, () => hook(this, subCommand));
        });
      }
      return result;
    }
    _parseCommand(operands, unknown) {
      const parsed = this.parseOptions(unknown);
      this._parseOptionsEnv();
      this._parseOptionsImplied();
      operands = operands.concat(parsed.operands);
      unknown = parsed.unknown;
      this.args = operands.concat(unknown);
      if (operands && this._findCommand(operands[0])) {
        return this._dispatchSubcommand(operands[0], operands.slice(1), unknown);
      }
      if (this._getHelpCommand() && operands[0] === this._getHelpCommand().name()) {
        return this._dispatchHelpCommand(operands[1]);
      }
      if (this._defaultCommandName) {
        this._outputHelpIfRequested(unknown);
        return this._dispatchSubcommand(this._defaultCommandName, operands, unknown);
      }
      if (this.commands.length && this.args.length === 0 && !this._actionHandler && !this._defaultCommandName) {
        this.help({
          error: true
        });
      }
      this._outputHelpIfRequested(parsed.unknown);
      this._checkForMissingMandatoryOptions();
      this._checkForConflictingOptions();
      const checkForUnknownOptions = () => {
        if (parsed.unknown.length > 0) {
          this.unknownOption(parsed.unknown[0]);
        }
      };
      const commandEvent = `command:${this.name()}`;
      if (this._actionHandler) {
        checkForUnknownOptions();
        this._processArguments();
        let promiseChain;
        promiseChain = this._chainOrCallHooks(promiseChain, "preAction");
        promiseChain = this._chainOrCall(promiseChain, () => this._actionHandler(this.processedArgs));
        if (this.parent) {
          promiseChain = this._chainOrCall(promiseChain, () => {
            this.parent.emit(commandEvent, operands, unknown);
          });
        }
        promiseChain = this._chainOrCallHooks(promiseChain, "postAction");
        return promiseChain;
      }
      if (this.parent?.listenerCount(commandEvent)) {
        checkForUnknownOptions();
        this._processArguments();
        this.parent.emit(commandEvent, operands, unknown);
      } else if (operands.length) {
        if (this._findCommand("*")) {
          return this._dispatchSubcommand("*", operands, unknown);
        }
        if (this.listenerCount("command:*")) {
          this.emit("command:*", operands, unknown);
        } else if (this.commands.length) {
          this.unknownCommand();
        } else {
          checkForUnknownOptions();
          this._processArguments();
        }
      } else if (this.commands.length) {
        checkForUnknownOptions();
        this.help({
          error: true
        });
      } else {
        checkForUnknownOptions();
        this._processArguments();
      }
    }
    _findCommand(name) {
      if (!name) return void 0;
      return this.commands.find((cmd) => cmd._name === name || cmd._aliases.includes(name));
    }
    _findOption(arg) {
      return this.options.find((option2) => option2.is(arg));
    }
    _checkForMissingMandatoryOptions() {
      this._getCommandAndAncestors().forEach((cmd) => {
        cmd.options.forEach((anOption) => {
          if (anOption.mandatory && cmd.getOptionValue(anOption.attributeName()) === void 0) {
            cmd.missingMandatoryOptionValue(anOption);
          }
        });
      });
    }
    _checkForConflictingLocalOptions() {
      const definedNonDefaultOptions = this.options.filter((option2) => {
        const optionKey = option2.attributeName();
        if (this.getOptionValue(optionKey) === void 0) {
          return false;
        }
        return this.getOptionValueSource(optionKey) !== "default";
      });
      const optionsWithConflicting = definedNonDefaultOptions.filter((option2) => option2.conflictsWith.length > 0);
      optionsWithConflicting.forEach((option2) => {
        const conflictingAndDefined = definedNonDefaultOptions.find((defined) => option2.conflictsWith.includes(defined.attributeName()));
        if (conflictingAndDefined) {
          this._conflictingOption(option2, conflictingAndDefined);
        }
      });
    }
    _checkForConflictingOptions() {
      this._getCommandAndAncestors().forEach((cmd) => {
        cmd._checkForConflictingLocalOptions();
      });
    }
    parseOptions(args) {
      const operands = [];
      const unknown = [];
      let dest = operands;
      function maybeOption(arg) {
        return arg.length > 1 && arg[0] === "-";
      }
      const negativeNumberArg = (arg) => {
        if (!/^-(\d+|\d*\.\d+)(e[+-]?\d+)?$/.test(arg)) return false;
        return !this._getCommandAndAncestors().some((cmd) => cmd.options.map((opt) => opt.short).some((short) => /^-\d$/.test(short)));
      };
      let activeVariadicOption = null;
      let activeGroup = null;
      let i = 0;
      while (i < args.length || activeGroup) {
        const arg = activeGroup ?? args[i++];
        activeGroup = null;
        if (arg === "--") {
          if (dest === unknown) dest.push(arg);
          dest.push(...args.slice(i));
          break;
        }
        if (activeVariadicOption && (!maybeOption(arg) || negativeNumberArg(arg))) {
          this.emit(`option:${activeVariadicOption.name()}`, arg);
          continue;
        }
        activeVariadicOption = null;
        if (maybeOption(arg)) {
          const option2 = this._findOption(arg);
          if (option2) {
            if (option2.required) {
              const value = args[i++];
              if (value === void 0) this.optionMissingArgument(option2);
              this.emit(`option:${option2.name()}`, value);
            } else if (option2.optional) {
              let value = null;
              if (i < args.length && (!maybeOption(args[i]) || negativeNumberArg(args[i]))) {
                value = args[i++];
              }
              this.emit(`option:${option2.name()}`, value);
            } else {
              this.emit(`option:${option2.name()}`);
            }
            activeVariadicOption = option2.variadic ? option2 : null;
            continue;
          }
        }
        if (arg.length > 2 && arg[0] === "-" && arg[1] !== "-") {
          const option2 = this._findOption(`-${arg[1]}`);
          if (option2) {
            if (option2.required || option2.optional && this._combineFlagAndOptionalValue) {
              this.emit(`option:${option2.name()}`, arg.slice(2));
            } else {
              this.emit(`option:${option2.name()}`);
              activeGroup = `-${arg.slice(2)}`;
            }
            continue;
          }
        }
        if (/^--[^=]+=/.test(arg)) {
          const index = arg.indexOf("=");
          const option2 = this._findOption(arg.slice(0, index));
          if (option2 && (option2.required || option2.optional)) {
            this.emit(`option:${option2.name()}`, arg.slice(index + 1));
            continue;
          }
        }
        if (dest === operands && maybeOption(arg) && !(this.commands.length === 0 && negativeNumberArg(arg))) {
          dest = unknown;
        }
        if ((this._enablePositionalOptions || this._passThroughOptions) && operands.length === 0 && unknown.length === 0) {
          if (this._findCommand(arg)) {
            operands.push(arg);
            unknown.push(...args.slice(i));
            break;
          } else if (this._getHelpCommand() && arg === this._getHelpCommand().name()) {
            operands.push(arg, ...args.slice(i));
            break;
          } else if (this._defaultCommandName) {
            unknown.push(arg, ...args.slice(i));
            break;
          }
        }
        if (this._passThroughOptions) {
          dest.push(arg, ...args.slice(i));
          break;
        }
        dest.push(arg);
      }
      return {
        operands,
        unknown
      };
    }
    opts() {
      if (this._storeOptionsAsProperties) {
        const result = {};
        const len = this.options.length;
        for (let i = 0; i < len; i++) {
          const key = this.options[i].attributeName();
          result[key] = key === this._versionOptionName ? this._version : this[key];
        }
        return result;
      }
      return this._optionValues;
    }
    optsWithGlobals() {
      return this._getCommandAndAncestors().reduce((combinedOptions, cmd) => Object.assign(combinedOptions, cmd.opts()), {});
    }
    error(message, errorOptions) {
      this._outputConfiguration.outputError(`${message}
`, this._outputConfiguration.writeErr);
      if (typeof this._showHelpAfterError === "string") {
        this._outputConfiguration.writeErr(`${this._showHelpAfterError}
`);
      } else if (this._showHelpAfterError) {
        this._outputConfiguration.writeErr("\n");
        this.outputHelp({
          error: true
        });
      }
      const config = errorOptions || {};
      const exitCode = config.exitCode || 1;
      const code = config.code || "commander.error";
      this._exit(exitCode, code, message);
    }
    _parseOptionsEnv() {
      this.options.forEach((option2) => {
        if (option2.envVar && option2.envVar in process2.env) {
          const optionKey = option2.attributeName();
          if (this.getOptionValue(optionKey) === void 0 || ["default", "config", "env"].includes(this.getOptionValueSource(optionKey))) {
            if (option2.required || option2.optional) {
              this.emit(`optionEnv:${option2.name()}`, process2.env[option2.envVar]);
            } else {
              this.emit(`optionEnv:${option2.name()}`);
            }
          }
        }
      });
    }
    _parseOptionsImplied() {
      const dualHelper = new DualOptions(this.options);
      const hasCustomOptionValue = (optionKey) => this.getOptionValue(optionKey) !== void 0 && !["default", "implied"].includes(this.getOptionValueSource(optionKey));
      this.options.filter((option2) => option2.implied !== void 0 && hasCustomOptionValue(option2.attributeName()) && dualHelper.valueFromOption(this.getOptionValue(option2.attributeName()), option2)).forEach((option2) => {
        Object.keys(option2.implied).filter((impliedKey) => !hasCustomOptionValue(impliedKey)).forEach((impliedKey) => {
          this.setOptionValueWithSource(impliedKey, option2.implied[impliedKey], "implied");
        });
      });
    }
    missingArgument(name) {
      const message = `error: missing required argument '${name}'`;
      this.error(message, {
        code: "commander.missingArgument"
      });
    }
    optionMissingArgument(option2) {
      const message = `error: option '${option2.flags}' argument missing`;
      this.error(message, {
        code: "commander.optionMissingArgument"
      });
    }
    missingMandatoryOptionValue(option2) {
      const message = `error: required option '${option2.flags}' not specified`;
      this.error(message, {
        code: "commander.missingMandatoryOptionValue"
      });
    }
    _conflictingOption(option2, conflictingOption) {
      const findBestOptionFromValue = (option3) => {
        const optionKey = option3.attributeName();
        const optionValue = this.getOptionValue(optionKey);
        const negativeOption = this.options.find((target) => target.negate && optionKey === target.attributeName());
        const positiveOption = this.options.find((target) => !target.negate && optionKey === target.attributeName());
        if (negativeOption && (negativeOption.presetArg === void 0 && optionValue === false || negativeOption.presetArg !== void 0 && optionValue === negativeOption.presetArg)) {
          return negativeOption;
        }
        return positiveOption || option3;
      };
      const getErrorMessage = (option3) => {
        const bestOption = findBestOptionFromValue(option3);
        const optionKey = bestOption.attributeName();
        const source = this.getOptionValueSource(optionKey);
        if (source === "env") {
          return `environment variable '${bestOption.envVar}'`;
        }
        return `option '${bestOption.flags}'`;
      };
      const message = `error: ${getErrorMessage(option2)} cannot be used with ${getErrorMessage(conflictingOption)}`;
      this.error(message, {
        code: "commander.conflictingOption"
      });
    }
    unknownOption(flag) {
      if (this._allowUnknownOption) return;
      let suggestion = "";
      if (flag.startsWith("--") && this._showSuggestionAfterError) {
        let candidateFlags = [];
        let command2 = this;
        do {
          const moreFlags = command2.createHelp().visibleOptions(command2).filter((option2) => option2.long).map((option2) => option2.long);
          candidateFlags = candidateFlags.concat(moreFlags);
          command2 = command2.parent;
        } while (command2 && !command2._enablePositionalOptions);
        suggestion = suggestSimilar2(flag, candidateFlags);
      }
      const message = `error: unknown option '${flag}'${suggestion}`;
      this.error(message, {
        code: "commander.unknownOption"
      });
    }
    _excessArguments(receivedArgs) {
      if (this._allowExcessArguments) return;
      const expected = this.registeredArguments.length;
      const s = expected === 1 ? "" : "s";
      const forSubcommand = this.parent ? ` for '${this.name()}'` : "";
      const message = `error: too many arguments${forSubcommand}. Expected ${expected} argument${s} but got ${receivedArgs.length}.`;
      this.error(message, {
        code: "commander.excessArguments"
      });
    }
    unknownCommand() {
      const unknownName = this.args[0];
      let suggestion = "";
      if (this._showSuggestionAfterError) {
        const candidateNames = [];
        this.createHelp().visibleCommands(this).forEach((command2) => {
          candidateNames.push(command2.name());
          if (command2.alias()) candidateNames.push(command2.alias());
        });
        suggestion = suggestSimilar2(unknownName, candidateNames);
      }
      const message = `error: unknown command '${unknownName}'${suggestion}`;
      this.error(message, {
        code: "commander.unknownCommand"
      });
    }
    version(str, flags, description) {
      if (str === void 0) return this._version;
      this._version = str;
      flags = flags || "-V, --version";
      description = description || "output the version number";
      const versionOption = this.createOption(flags, description);
      this._versionOptionName = versionOption.attributeName();
      this._registerOption(versionOption);
      this.on("option:" + versionOption.name(), () => {
        this._outputConfiguration.writeOut(`${str}
`);
        this._exit(0, "commander.version", str);
      });
      return this;
    }
    description(str, argsDescription) {
      if (str === void 0 && argsDescription === void 0) return this._description;
      this._description = str;
      if (argsDescription) {
        this._argsDescription = argsDescription;
      }
      return this;
    }
    summary(str) {
      if (str === void 0) return this._summary;
      this._summary = str;
      return this;
    }
    alias(alias) {
      if (alias === void 0) return this._aliases[0];
      let command2 = this;
      if (this.commands.length !== 0 && this.commands[this.commands.length - 1]._executableHandler) {
        command2 = this.commands[this.commands.length - 1];
      }
      if (alias === command2._name) throw new Error("Command alias can't be the same as its name");
      const matchingCommand = this.parent?._findCommand(alias);
      if (matchingCommand) {
        const existingCmd = [matchingCommand.name()].concat(matchingCommand.aliases()).join("|");
        throw new Error(`cannot add alias '${alias}' to command '${this.name()}' as already have command '${existingCmd}'`);
      }
      command2._aliases.push(alias);
      return this;
    }
    aliases(aliases) {
      if (aliases === void 0) return this._aliases;
      aliases.forEach((alias) => this.alias(alias));
      return this;
    }
    usage(str) {
      if (str === void 0) {
        if (this._usage) return this._usage;
        const args = this.registeredArguments.map((arg) => humanReadableArgName(arg));
        return [].concat(this.options.length || this._helpOption !== null ? "[options]" : [], this.commands.length ? "[command]" : [], this.registeredArguments.length ? args : []).join(" ");
      }
      this._usage = str;
      return this;
    }
    name(str) {
      if (str === void 0) return this._name;
      this._name = str;
      return this;
    }
    helpGroup(heading) {
      if (heading === void 0) return this._helpGroupHeading ?? "";
      this._helpGroupHeading = heading;
      return this;
    }
    commandsGroup(heading) {
      if (heading === void 0) return this._defaultCommandGroup ?? "";
      this._defaultCommandGroup = heading;
      return this;
    }
    optionsGroup(heading) {
      if (heading === void 0) return this._defaultOptionGroup ?? "";
      this._defaultOptionGroup = heading;
      return this;
    }
    _initOptionGroup(option2) {
      if (this._defaultOptionGroup && !option2.helpGroupHeading) option2.helpGroup(this._defaultOptionGroup);
    }
    _initCommandGroup(cmd) {
      if (this._defaultCommandGroup && !cmd.helpGroup()) cmd.helpGroup(this._defaultCommandGroup);
    }
    nameFromFilename(filename) {
      this._name = path2.basename(filename, path2.extname(filename));
      return this;
    }
    executableDir(path3) {
      if (path3 === void 0) return this._executableDir;
      this._executableDir = path3;
      return this;
    }
    helpInformation(contextOptions) {
      const helper = this.createHelp();
      const context = this._getOutputContext(contextOptions);
      helper.prepareContext({
        error: context.error,
        helpWidth: context.helpWidth,
        outputHasColors: context.hasColors
      });
      const text = helper.formatHelp(this, helper);
      if (context.hasColors) return text;
      return this._outputConfiguration.stripColor(text);
    }
    _getOutputContext(contextOptions) {
      contextOptions = contextOptions || {};
      const error2 = !!contextOptions.error;
      let baseWrite;
      let hasColors;
      let helpWidth;
      if (error2) {
        baseWrite = (str) => this._outputConfiguration.writeErr(str);
        hasColors = this._outputConfiguration.getErrHasColors();
        helpWidth = this._outputConfiguration.getErrHelpWidth();
      } else {
        baseWrite = (str) => this._outputConfiguration.writeOut(str);
        hasColors = this._outputConfiguration.getOutHasColors();
        helpWidth = this._outputConfiguration.getOutHelpWidth();
      }
      const write = (str) => {
        if (!hasColors) str = this._outputConfiguration.stripColor(str);
        return baseWrite(str);
      };
      return {
        error: error2,
        write,
        hasColors,
        helpWidth
      };
    }
    outputHelp(contextOptions) {
      let deprecatedCallback;
      if (typeof contextOptions === "function") {
        deprecatedCallback = contextOptions;
        contextOptions = void 0;
      }
      const outputContext = this._getOutputContext(contextOptions);
      const eventContext = {
        error: outputContext.error,
        write: outputContext.write,
        command: this
      };
      this._getCommandAndAncestors().reverse().forEach((command2) => command2.emit("beforeAllHelp", eventContext));
      this.emit("beforeHelp", eventContext);
      let helpInformation = this.helpInformation({
        error: outputContext.error
      });
      if (deprecatedCallback) {
        helpInformation = deprecatedCallback(helpInformation);
        if (typeof helpInformation !== "string" && !Buffer.isBuffer(helpInformation)) {
          throw new Error("outputHelp callback must return a string or a Buffer");
        }
      }
      outputContext.write(helpInformation);
      if (this._getHelpOption()?.long) {
        this.emit(this._getHelpOption().long);
      }
      this.emit("afterHelp", eventContext);
      this._getCommandAndAncestors().forEach((command2) => command2.emit("afterAllHelp", eventContext));
    }
    helpOption(flags, description) {
      if (typeof flags === "boolean") {
        if (flags) {
          if (this._helpOption === null) this._helpOption = void 0;
          if (this._defaultOptionGroup) {
            this._initOptionGroup(this._getHelpOption());
          }
        } else {
          this._helpOption = null;
        }
        return this;
      }
      this._helpOption = this.createOption(flags ?? "-h, --help", description ?? "display help for command");
      if (flags || description) this._initOptionGroup(this._helpOption);
      return this;
    }
    _getHelpOption() {
      if (this._helpOption === void 0) {
        this.helpOption(void 0, void 0);
      }
      return this._helpOption;
    }
    addHelpOption(option2) {
      this._helpOption = option2;
      this._initOptionGroup(option2);
      return this;
    }
    help(contextOptions) {
      this.outputHelp(contextOptions);
      let exitCode = Number(process2.exitCode ?? 0);
      if (exitCode === 0 && contextOptions && typeof contextOptions !== "function" && contextOptions.error) {
        exitCode = 1;
      }
      this._exit(exitCode, "commander.help", "(outputHelp)");
    }
    addHelpText(position, text) {
      const allowedValues = ["beforeAll", "before", "after", "afterAll"];
      if (!allowedValues.includes(position)) {
        throw new Error(`Unexpected value for position to addHelpText.
Expecting one of '${allowedValues.join("', '")}'`);
      }
      const helpEvent = `${position}Help`;
      this.on(helpEvent, (context) => {
        let helpStr;
        if (typeof text === "function") {
          helpStr = text({
            error: context.error,
            command: context.command
          });
        } else {
          helpStr = text;
        }
        if (helpStr) {
          context.write(`${helpStr}
`);
        }
      });
      return this;
    }
    _outputHelpIfRequested(args) {
      const helpOption = this._getHelpOption();
      const helpRequested = helpOption && args.find((arg) => helpOption.is(arg));
      if (helpRequested) {
        this.outputHelp();
        this._exit(0, "commander.helpDisplayed", "(outputHelp)");
      }
    }
  }
  function incrementNodeInspectorPort(args) {
    return args.map((arg) => {
      if (!arg.startsWith("--inspect")) {
        return arg;
      }
      let debugOption;
      let debugHost = "127.0.0.1";
      let debugPort = "9229";
      let match;
      if ((match = arg.match(/^(--inspect(-brk)?)$/)) !== null) {
        debugOption = match[1];
      } else if ((match = arg.match(/^(--inspect(-brk|-port)?)=([^:]+)$/)) !== null) {
        debugOption = match[1];
        if (/^\d+$/.test(match[3])) {
          debugPort = match[3];
        } else {
          debugHost = match[3];
        }
      } else if ((match = arg.match(/^(--inspect(-brk|-port)?)=([^:]+):(\d+)$/)) !== null) {
        debugOption = match[1];
        debugHost = match[3];
        debugPort = match[4];
      }
      if (debugOption && debugPort !== "0") {
        return `${debugOption}=${debugHost}:${parseInt(debugPort) + 1}`;
      }
      return arg;
    });
  }
  function useColor() {
    if (process2.env.NO_COLOR || process2.env.FORCE_COLOR === "0" || process2.env.FORCE_COLOR === "false") return false;
    if (process2.env.FORCE_COLOR || process2.env.CLICOLOR_FORCE !== void 0) return true;
    return void 0;
  }
  command.Command = Command2;
  command.useColor = useColor;
  return command;
}
var hasRequiredCommander;
function requireCommander() {
  if (hasRequiredCommander) return commander$1;
  hasRequiredCommander = 1;
  const { Argument: Argument2 } = requireArgument();
  const { Command: Command2 } = requireCommand();
  const { CommanderError: CommanderError2, InvalidArgumentError: InvalidArgumentError2 } = requireError();
  const { Help: Help2 } = requireHelp();
  const { Option: Option2 } = requireOption();
  commander$1.program = new Command2();
  commander$1.createCommand = (name) => new Command2(name);
  commander$1.createOption = (flags, description) => new Option2(flags, description);
  commander$1.createArgument = (name, description) => new Argument2(name, description);
  commander$1.Command = Command2;
  commander$1.Option = Option2;
  commander$1.Argument = Argument2;
  commander$1.Help = Help2;
  commander$1.CommanderError = CommanderError2;
  commander$1.InvalidArgumentError = InvalidArgumentError2;
  commander$1.InvalidOptionArgumentError = InvalidArgumentError2;
  return commander$1;
}
var commanderExports = requireCommander();
var commander = getDefaultExportFromCjs(commanderExports);
var { program: program$1, createCommand, createArgument, createOption, CommanderError, InvalidArgumentError, InvalidOptionArgumentError, Command, Argument, Option, Help } = commander;
var main$3 = {};
var is$2 = {};
var hasRequiredIs$2;
function requireIs$2() {
  if (hasRequiredIs$2) return is$2;
  hasRequiredIs$2 = 1;
  Object.defineProperty(is$2, "__esModule", {
    value: true
  });
  is$2.thenable = is$2.typedArray = is$2.stringArray = is$2.array = is$2.func = is$2.error = is$2.number = is$2.string = is$2.boolean = void 0;
  function boolean(value) {
    return value === true || value === false;
  }
  is$2.boolean = boolean;
  function string(value) {
    return typeof value === "string" || value instanceof String;
  }
  is$2.string = string;
  function number(value) {
    return typeof value === "number" || value instanceof Number;
  }
  is$2.number = number;
  function error2(value) {
    return value instanceof Error;
  }
  is$2.error = error2;
  function func(value) {
    return typeof value === "function";
  }
  is$2.func = func;
  function array(value) {
    return Array.isArray(value);
  }
  is$2.array = array;
  function stringArray(value) {
    return array(value) && value.every((elem) => string(elem));
  }
  is$2.stringArray = stringArray;
  function typedArray(value, check) {
    return Array.isArray(value) && value.every(check);
  }
  is$2.typedArray = typedArray;
  function thenable(value) {
    return value && func(value.then);
  }
  is$2.thenable = thenable;
  return is$2;
}
var server = {};
var main$2 = {};
var main$1 = {};
var ril = {};
var api$2 = {};
var messages$1 = {};
var is$1 = {};
var hasRequiredIs$1;
function requireIs$1() {
  if (hasRequiredIs$1) return is$1;
  hasRequiredIs$1 = 1;
  Object.defineProperty(is$1, "__esModule", {
    value: true
  });
  is$1.stringArray = is$1.array = is$1.func = is$1.error = is$1.number = is$1.string = is$1.boolean = void 0;
  function boolean(value) {
    return value === true || value === false;
  }
  is$1.boolean = boolean;
  function string(value) {
    return typeof value === "string" || value instanceof String;
  }
  is$1.string = string;
  function number(value) {
    return typeof value === "number" || value instanceof Number;
  }
  is$1.number = number;
  function error2(value) {
    return value instanceof Error;
  }
  is$1.error = error2;
  function func(value) {
    return typeof value === "function";
  }
  is$1.func = func;
  function array(value) {
    return Array.isArray(value);
  }
  is$1.array = array;
  function stringArray(value) {
    return array(value) && value.every((elem) => string(elem));
  }
  is$1.stringArray = stringArray;
  return is$1;
}
var hasRequiredMessages$1;
function requireMessages$1() {
  if (hasRequiredMessages$1) return messages$1;
  hasRequiredMessages$1 = 1;
  Object.defineProperty(messages$1, "__esModule", {
    value: true
  });
  messages$1.Message = messages$1.NotificationType9 = messages$1.NotificationType8 = messages$1.NotificationType7 = messages$1.NotificationType6 = messages$1.NotificationType5 = messages$1.NotificationType4 = messages$1.NotificationType3 = messages$1.NotificationType2 = messages$1.NotificationType1 = messages$1.NotificationType0 = messages$1.NotificationType = messages$1.RequestType9 = messages$1.RequestType8 = messages$1.RequestType7 = messages$1.RequestType6 = messages$1.RequestType5 = messages$1.RequestType4 = messages$1.RequestType3 = messages$1.RequestType2 = messages$1.RequestType1 = messages$1.RequestType = messages$1.RequestType0 = messages$1.AbstractMessageSignature = messages$1.ParameterStructures = messages$1.ResponseError = messages$1.ErrorCodes = void 0;
  const is2 = requireIs$1();
  var ErrorCodes;
  (function(ErrorCodes2) {
    ErrorCodes2.ParseError = -32700;
    ErrorCodes2.InvalidRequest = -32600;
    ErrorCodes2.MethodNotFound = -32601;
    ErrorCodes2.InvalidParams = -32602;
    ErrorCodes2.InternalError = -32603;
    ErrorCodes2.jsonrpcReservedErrorRangeStart = -32099;
    ErrorCodes2.serverErrorStart = -32099;
    ErrorCodes2.MessageWriteError = -32099;
    ErrorCodes2.MessageReadError = -32098;
    ErrorCodes2.PendingResponseRejected = -32097;
    ErrorCodes2.ConnectionInactive = -32096;
    ErrorCodes2.ServerNotInitialized = -32002;
    ErrorCodes2.UnknownErrorCode = -32001;
    ErrorCodes2.jsonrpcReservedErrorRangeEnd = -32e3;
    ErrorCodes2.serverErrorEnd = -32e3;
  })(ErrorCodes || (messages$1.ErrorCodes = ErrorCodes = {}));
  class ResponseError extends Error {
    constructor(code, message, data) {
      super(message);
      this.code = is2.number(code) ? code : ErrorCodes.UnknownErrorCode;
      this.data = data;
      Object.setPrototypeOf(this, ResponseError.prototype);
    }
    toJson() {
      const result = {
        code: this.code,
        message: this.message
      };
      if (this.data !== void 0) {
        result.data = this.data;
      }
      return result;
    }
  }
  messages$1.ResponseError = ResponseError;
  class ParameterStructures {
    constructor(kind) {
      this.kind = kind;
    }
    static is(value) {
      return value === ParameterStructures.auto || value === ParameterStructures.byName || value === ParameterStructures.byPosition;
    }
    toString() {
      return this.kind;
    }
  }
  messages$1.ParameterStructures = ParameterStructures;
  ParameterStructures.auto = new ParameterStructures("auto");
  ParameterStructures.byPosition = new ParameterStructures("byPosition");
  ParameterStructures.byName = new ParameterStructures("byName");
  class AbstractMessageSignature {
    constructor(method, numberOfParams) {
      this.method = method;
      this.numberOfParams = numberOfParams;
    }
    get parameterStructures() {
      return ParameterStructures.auto;
    }
  }
  messages$1.AbstractMessageSignature = AbstractMessageSignature;
  class RequestType0 extends AbstractMessageSignature {
    constructor(method) {
      super(method, 0);
    }
  }
  messages$1.RequestType0 = RequestType0;
  class RequestType extends AbstractMessageSignature {
    constructor(method, _parameterStructures = ParameterStructures.auto) {
      super(method, 1);
      this._parameterStructures = _parameterStructures;
    }
    get parameterStructures() {
      return this._parameterStructures;
    }
  }
  messages$1.RequestType = RequestType;
  class RequestType1 extends AbstractMessageSignature {
    constructor(method, _parameterStructures = ParameterStructures.auto) {
      super(method, 1);
      this._parameterStructures = _parameterStructures;
    }
    get parameterStructures() {
      return this._parameterStructures;
    }
  }
  messages$1.RequestType1 = RequestType1;
  class RequestType2 extends AbstractMessageSignature {
    constructor(method) {
      super(method, 2);
    }
  }
  messages$1.RequestType2 = RequestType2;
  class RequestType3 extends AbstractMessageSignature {
    constructor(method) {
      super(method, 3);
    }
  }
  messages$1.RequestType3 = RequestType3;
  class RequestType4 extends AbstractMessageSignature {
    constructor(method) {
      super(method, 4);
    }
  }
  messages$1.RequestType4 = RequestType4;
  class RequestType5 extends AbstractMessageSignature {
    constructor(method) {
      super(method, 5);
    }
  }
  messages$1.RequestType5 = RequestType5;
  class RequestType6 extends AbstractMessageSignature {
    constructor(method) {
      super(method, 6);
    }
  }
  messages$1.RequestType6 = RequestType6;
  class RequestType7 extends AbstractMessageSignature {
    constructor(method) {
      super(method, 7);
    }
  }
  messages$1.RequestType7 = RequestType7;
  class RequestType8 extends AbstractMessageSignature {
    constructor(method) {
      super(method, 8);
    }
  }
  messages$1.RequestType8 = RequestType8;
  class RequestType9 extends AbstractMessageSignature {
    constructor(method) {
      super(method, 9);
    }
  }
  messages$1.RequestType9 = RequestType9;
  class NotificationType extends AbstractMessageSignature {
    constructor(method, _parameterStructures = ParameterStructures.auto) {
      super(method, 1);
      this._parameterStructures = _parameterStructures;
    }
    get parameterStructures() {
      return this._parameterStructures;
    }
  }
  messages$1.NotificationType = NotificationType;
  class NotificationType0 extends AbstractMessageSignature {
    constructor(method) {
      super(method, 0);
    }
  }
  messages$1.NotificationType0 = NotificationType0;
  class NotificationType1 extends AbstractMessageSignature {
    constructor(method, _parameterStructures = ParameterStructures.auto) {
      super(method, 1);
      this._parameterStructures = _parameterStructures;
    }
    get parameterStructures() {
      return this._parameterStructures;
    }
  }
  messages$1.NotificationType1 = NotificationType1;
  class NotificationType2 extends AbstractMessageSignature {
    constructor(method) {
      super(method, 2);
    }
  }
  messages$1.NotificationType2 = NotificationType2;
  class NotificationType3 extends AbstractMessageSignature {
    constructor(method) {
      super(method, 3);
    }
  }
  messages$1.NotificationType3 = NotificationType3;
  class NotificationType4 extends AbstractMessageSignature {
    constructor(method) {
      super(method, 4);
    }
  }
  messages$1.NotificationType4 = NotificationType4;
  class NotificationType5 extends AbstractMessageSignature {
    constructor(method) {
      super(method, 5);
    }
  }
  messages$1.NotificationType5 = NotificationType5;
  class NotificationType6 extends AbstractMessageSignature {
    constructor(method) {
      super(method, 6);
    }
  }
  messages$1.NotificationType6 = NotificationType6;
  class NotificationType7 extends AbstractMessageSignature {
    constructor(method) {
      super(method, 7);
    }
  }
  messages$1.NotificationType7 = NotificationType7;
  class NotificationType8 extends AbstractMessageSignature {
    constructor(method) {
      super(method, 8);
    }
  }
  messages$1.NotificationType8 = NotificationType8;
  class NotificationType9 extends AbstractMessageSignature {
    constructor(method) {
      super(method, 9);
    }
  }
  messages$1.NotificationType9 = NotificationType9;
  var Message;
  (function(Message2) {
    function isRequest(message) {
      const candidate = message;
      return candidate && is2.string(candidate.method) && (is2.string(candidate.id) || is2.number(candidate.id));
    }
    Message2.isRequest = isRequest;
    function isNotification(message) {
      const candidate = message;
      return candidate && is2.string(candidate.method) && message.id === void 0;
    }
    Message2.isNotification = isNotification;
    function isResponse(message) {
      const candidate = message;
      return candidate && (candidate.result !== void 0 || !!candidate.error) && (is2.string(candidate.id) || is2.number(candidate.id) || candidate.id === null);
    }
    Message2.isResponse = isResponse;
  })(Message || (messages$1.Message = Message = {}));
  return messages$1;
}
var linkedMap = {};
var hasRequiredLinkedMap;
function requireLinkedMap() {
  if (hasRequiredLinkedMap) return linkedMap;
  hasRequiredLinkedMap = 1;
  var _a;
  Object.defineProperty(linkedMap, "__esModule", {
    value: true
  });
  linkedMap.LRUCache = linkedMap.LinkedMap = linkedMap.Touch = void 0;
  var Touch;
  (function(Touch2) {
    Touch2.None = 0;
    Touch2.First = 1;
    Touch2.AsOld = Touch2.First;
    Touch2.Last = 2;
    Touch2.AsNew = Touch2.Last;
  })(Touch || (linkedMap.Touch = Touch = {}));
  class LinkedMap {
    constructor() {
      this[_a] = "LinkedMap";
      this._map = /* @__PURE__ */ new Map();
      this._head = void 0;
      this._tail = void 0;
      this._size = 0;
      this._state = 0;
    }
    clear() {
      this._map.clear();
      this._head = void 0;
      this._tail = void 0;
      this._size = 0;
      this._state++;
    }
    isEmpty() {
      return !this._head && !this._tail;
    }
    get size() {
      return this._size;
    }
    get first() {
      return this._head?.value;
    }
    get last() {
      return this._tail?.value;
    }
    has(key) {
      return this._map.has(key);
    }
    get(key, touch = Touch.None) {
      const item = this._map.get(key);
      if (!item) {
        return void 0;
      }
      if (touch !== Touch.None) {
        this.touch(item, touch);
      }
      return item.value;
    }
    set(key, value, touch = Touch.None) {
      let item = this._map.get(key);
      if (item) {
        item.value = value;
        if (touch !== Touch.None) {
          this.touch(item, touch);
        }
      } else {
        item = {
          key,
          value,
          next: void 0,
          previous: void 0
        };
        switch (touch) {
          case Touch.None:
            this.addItemLast(item);
            break;
          case Touch.First:
            this.addItemFirst(item);
            break;
          case Touch.Last:
            this.addItemLast(item);
            break;
          default:
            this.addItemLast(item);
            break;
        }
        this._map.set(key, item);
        this._size++;
      }
      return this;
    }
    delete(key) {
      return !!this.remove(key);
    }
    remove(key) {
      const item = this._map.get(key);
      if (!item) {
        return void 0;
      }
      this._map.delete(key);
      this.removeItem(item);
      this._size--;
      return item.value;
    }
    shift() {
      if (!this._head && !this._tail) {
        return void 0;
      }
      if (!this._head || !this._tail) {
        throw new Error("Invalid list");
      }
      const item = this._head;
      this._map.delete(item.key);
      this.removeItem(item);
      this._size--;
      return item.value;
    }
    forEach(callbackfn, thisArg) {
      const state = this._state;
      let current = this._head;
      while (current) {
        if (thisArg) {
          callbackfn.bind(thisArg)(current.value, current.key, this);
        } else {
          callbackfn(current.value, current.key, this);
        }
        if (this._state !== state) {
          throw new Error(`LinkedMap got modified during iteration.`);
        }
        current = current.next;
      }
    }
    keys() {
      const state = this._state;
      let current = this._head;
      const iterator = {
        [Symbol.iterator]: () => iterator,
        next: () => {
          if (this._state !== state) {
            throw new Error(`LinkedMap got modified during iteration.`);
          }
          if (current) {
            const result = {
              value: current.key,
              done: false
            };
            current = current.next;
            return result;
          } else {
            return {
              value: void 0,
              done: true
            };
          }
        }
      };
      return iterator;
    }
    values() {
      const state = this._state;
      let current = this._head;
      const iterator = {
        [Symbol.iterator]: () => iterator,
        next: () => {
          if (this._state !== state) {
            throw new Error(`LinkedMap got modified during iteration.`);
          }
          if (current) {
            const result = {
              value: current.value,
              done: false
            };
            current = current.next;
            return result;
          } else {
            return {
              value: void 0,
              done: true
            };
          }
        }
      };
      return iterator;
    }
    entries() {
      const state = this._state;
      let current = this._head;
      const iterator = {
        [Symbol.iterator]: () => iterator,
        next: () => {
          if (this._state !== state) {
            throw new Error(`LinkedMap got modified during iteration.`);
          }
          if (current) {
            const result = {
              value: [current.key, current.value],
              done: false
            };
            current = current.next;
            return result;
          } else {
            return {
              value: void 0,
              done: true
            };
          }
        }
      };
      return iterator;
    }
    [(_a = Symbol.toStringTag, Symbol.iterator)]() {
      return this.entries();
    }
    trimOld(newSize) {
      if (newSize >= this.size) {
        return;
      }
      if (newSize === 0) {
        this.clear();
        return;
      }
      let current = this._head;
      let currentSize = this.size;
      while (current && currentSize > newSize) {
        this._map.delete(current.key);
        current = current.next;
        currentSize--;
      }
      this._head = current;
      this._size = currentSize;
      if (current) {
        current.previous = void 0;
      }
      this._state++;
    }
    addItemFirst(item) {
      if (!this._head && !this._tail) {
        this._tail = item;
      } else if (!this._head) {
        throw new Error("Invalid list");
      } else {
        item.next = this._head;
        this._head.previous = item;
      }
      this._head = item;
      this._state++;
    }
    addItemLast(item) {
      if (!this._head && !this._tail) {
        this._head = item;
      } else if (!this._tail) {
        throw new Error("Invalid list");
      } else {
        item.previous = this._tail;
        this._tail.next = item;
      }
      this._tail = item;
      this._state++;
    }
    removeItem(item) {
      if (item === this._head && item === this._tail) {
        this._head = void 0;
        this._tail = void 0;
      } else if (item === this._head) {
        if (!item.next) {
          throw new Error("Invalid list");
        }
        item.next.previous = void 0;
        this._head = item.next;
      } else if (item === this._tail) {
        if (!item.previous) {
          throw new Error("Invalid list");
        }
        item.previous.next = void 0;
        this._tail = item.previous;
      } else {
        const next = item.next;
        const previous = item.previous;
        if (!next || !previous) {
          throw new Error("Invalid list");
        }
        next.previous = previous;
        previous.next = next;
      }
      item.next = void 0;
      item.previous = void 0;
      this._state++;
    }
    touch(item, touch) {
      if (!this._head || !this._tail) {
        throw new Error("Invalid list");
      }
      if (touch !== Touch.First && touch !== Touch.Last) {
        return;
      }
      if (touch === Touch.First) {
        if (item === this._head) {
          return;
        }
        const next = item.next;
        const previous = item.previous;
        if (item === this._tail) {
          previous.next = void 0;
          this._tail = previous;
        } else {
          next.previous = previous;
          previous.next = next;
        }
        item.previous = void 0;
        item.next = this._head;
        this._head.previous = item;
        this._head = item;
        this._state++;
      } else if (touch === Touch.Last) {
        if (item === this._tail) {
          return;
        }
        const next = item.next;
        const previous = item.previous;
        if (item === this._head) {
          next.previous = void 0;
          this._head = next;
        } else {
          next.previous = previous;
          previous.next = next;
        }
        item.next = void 0;
        item.previous = this._tail;
        this._tail.next = item;
        this._tail = item;
        this._state++;
      }
    }
    toJSON() {
      const data = [];
      this.forEach((value, key) => {
        data.push([key, value]);
      });
      return data;
    }
    fromJSON(data) {
      this.clear();
      for (const [key, value] of data) {
        this.set(key, value);
      }
    }
  }
  linkedMap.LinkedMap = LinkedMap;
  class LRUCache extends LinkedMap {
    constructor(limit, ratio = 1) {
      super();
      this._limit = limit;
      this._ratio = Math.min(Math.max(0, ratio), 1);
    }
    get limit() {
      return this._limit;
    }
    set limit(limit) {
      this._limit = limit;
      this.checkTrim();
    }
    get ratio() {
      return this._ratio;
    }
    set ratio(ratio) {
      this._ratio = Math.min(Math.max(0, ratio), 1);
      this.checkTrim();
    }
    get(key, touch = Touch.AsNew) {
      return super.get(key, touch);
    }
    peek(key) {
      return super.get(key, Touch.None);
    }
    set(key, value) {
      super.set(key, value, Touch.Last);
      this.checkTrim();
      return this;
    }
    checkTrim() {
      if (this.size > this._limit) {
        this.trimOld(Math.round(this._limit * this._ratio));
      }
    }
  }
  linkedMap.LRUCache = LRUCache;
  return linkedMap;
}
var disposable = {};
var hasRequiredDisposable;
function requireDisposable() {
  if (hasRequiredDisposable) return disposable;
  hasRequiredDisposable = 1;
  Object.defineProperty(disposable, "__esModule", {
    value: true
  });
  disposable.Disposable = void 0;
  var Disposable;
  (function(Disposable2) {
    function create(func) {
      return {
        dispose: func
      };
    }
    Disposable2.create = create;
  })(Disposable || (disposable.Disposable = Disposable = {}));
  return disposable;
}
var events = {};
var ral = {};
var hasRequiredRal;
function requireRal() {
  if (hasRequiredRal) return ral;
  hasRequiredRal = 1;
  Object.defineProperty(ral, "__esModule", {
    value: true
  });
  let _ral;
  function RAL() {
    if (_ral === void 0) {
      throw new Error(`No runtime abstraction layer installed`);
    }
    return _ral;
  }
  (function(RAL2) {
    function install(ral2) {
      if (ral2 === void 0) {
        throw new Error(`No runtime abstraction layer provided`);
      }
      _ral = ral2;
    }
    RAL2.install = install;
  })(RAL || (RAL = {}));
  ral.default = RAL;
  return ral;
}
var hasRequiredEvents;
function requireEvents() {
  if (hasRequiredEvents) return events;
  hasRequiredEvents = 1;
  Object.defineProperty(events, "__esModule", {
    value: true
  });
  events.Emitter = events.Event = void 0;
  const ral_1 = requireRal();
  var Event;
  (function(Event2) {
    const _disposable = {
      dispose() {
      }
    };
    Event2.None = function() {
      return _disposable;
    };
  })(Event || (events.Event = Event = {}));
  class CallbackList {
    add(callback, context = null, bucket) {
      if (!this._callbacks) {
        this._callbacks = [];
        this._contexts = [];
      }
      this._callbacks.push(callback);
      this._contexts.push(context);
      if (Array.isArray(bucket)) {
        bucket.push({
          dispose: () => this.remove(callback, context)
        });
      }
    }
    remove(callback, context = null) {
      if (!this._callbacks) {
        return;
      }
      let foundCallbackWithDifferentContext = false;
      for (let i = 0, len = this._callbacks.length; i < len; i++) {
        if (this._callbacks[i] === callback) {
          if (this._contexts[i] === context) {
            this._callbacks.splice(i, 1);
            this._contexts.splice(i, 1);
            return;
          } else {
            foundCallbackWithDifferentContext = true;
          }
        }
      }
      if (foundCallbackWithDifferentContext) {
        throw new Error("When adding a listener with a context, you should remove it with the same context");
      }
    }
    invoke(...args) {
      if (!this._callbacks) {
        return [];
      }
      const ret = [], callbacks = this._callbacks.slice(0), contexts = this._contexts.slice(0);
      for (let i = 0, len = callbacks.length; i < len; i++) {
        try {
          ret.push(callbacks[i].apply(contexts[i], args));
        } catch (e) {
          (0, ral_1.default)().console.error(e);
        }
      }
      return ret;
    }
    isEmpty() {
      return !this._callbacks || this._callbacks.length === 0;
    }
    dispose() {
      this._callbacks = void 0;
      this._contexts = void 0;
    }
  }
  class Emitter {
    constructor(_options) {
      this._options = _options;
    }
    get event() {
      if (!this._event) {
        this._event = (listener, thisArgs, disposables) => {
          if (!this._callbacks) {
            this._callbacks = new CallbackList();
          }
          if (this._options && this._options.onFirstListenerAdd && this._callbacks.isEmpty()) {
            this._options.onFirstListenerAdd(this);
          }
          this._callbacks.add(listener, thisArgs);
          const result = {
            dispose: () => {
              if (!this._callbacks) {
                return;
              }
              this._callbacks.remove(listener, thisArgs);
              result.dispose = Emitter._noop;
              if (this._options && this._options.onLastListenerRemove && this._callbacks.isEmpty()) {
                this._options.onLastListenerRemove(this);
              }
            }
          };
          if (Array.isArray(disposables)) {
            disposables.push(result);
          }
          return result;
        };
      }
      return this._event;
    }
    fire(event) {
      if (this._callbacks) {
        this._callbacks.invoke.call(this._callbacks, event);
      }
    }
    dispose() {
      if (this._callbacks) {
        this._callbacks.dispose();
        this._callbacks = void 0;
      }
    }
  }
  events.Emitter = Emitter;
  Emitter._noop = function() {
  };
  return events;
}
var cancellation = {};
var hasRequiredCancellation;
function requireCancellation() {
  if (hasRequiredCancellation) return cancellation;
  hasRequiredCancellation = 1;
  Object.defineProperty(cancellation, "__esModule", {
    value: true
  });
  cancellation.CancellationTokenSource = cancellation.CancellationToken = void 0;
  const ral_1 = requireRal();
  const Is = requireIs$1();
  const events_1 = requireEvents();
  var CancellationToken;
  (function(CancellationToken2) {
    CancellationToken2.None = Object.freeze({
      isCancellationRequested: false,
      onCancellationRequested: events_1.Event.None
    });
    CancellationToken2.Cancelled = Object.freeze({
      isCancellationRequested: true,
      onCancellationRequested: events_1.Event.None
    });
    function is2(value) {
      const candidate = value;
      return candidate && (candidate === CancellationToken2.None || candidate === CancellationToken2.Cancelled || Is.boolean(candidate.isCancellationRequested) && !!candidate.onCancellationRequested);
    }
    CancellationToken2.is = is2;
  })(CancellationToken || (cancellation.CancellationToken = CancellationToken = {}));
  const shortcutEvent = Object.freeze(function(callback, context) {
    const handle = (0, ral_1.default)().timer.setTimeout(callback.bind(context), 0);
    return {
      dispose() {
        handle.dispose();
      }
    };
  });
  class MutableToken {
    constructor() {
      this._isCancelled = false;
    }
    cancel() {
      if (!this._isCancelled) {
        this._isCancelled = true;
        if (this._emitter) {
          this._emitter.fire(void 0);
          this.dispose();
        }
      }
    }
    get isCancellationRequested() {
      return this._isCancelled;
    }
    get onCancellationRequested() {
      if (this._isCancelled) {
        return shortcutEvent;
      }
      if (!this._emitter) {
        this._emitter = new events_1.Emitter();
      }
      return this._emitter.event;
    }
    dispose() {
      if (this._emitter) {
        this._emitter.dispose();
        this._emitter = void 0;
      }
    }
  }
  class CancellationTokenSource {
    get token() {
      if (!this._token) {
        this._token = new MutableToken();
      }
      return this._token;
    }
    cancel() {
      if (!this._token) {
        this._token = CancellationToken.Cancelled;
      } else {
        this._token.cancel();
      }
    }
    dispose() {
      if (!this._token) {
        this._token = CancellationToken.None;
      } else if (this._token instanceof MutableToken) {
        this._token.dispose();
      }
    }
  }
  cancellation.CancellationTokenSource = CancellationTokenSource;
  return cancellation;
}
var sharedArrayCancellation = {};
var hasRequiredSharedArrayCancellation;
function requireSharedArrayCancellation() {
  if (hasRequiredSharedArrayCancellation) return sharedArrayCancellation;
  hasRequiredSharedArrayCancellation = 1;
  Object.defineProperty(sharedArrayCancellation, "__esModule", {
    value: true
  });
  sharedArrayCancellation.SharedArrayReceiverStrategy = sharedArrayCancellation.SharedArraySenderStrategy = void 0;
  const cancellation_1 = requireCancellation();
  var CancellationState;
  (function(CancellationState2) {
    CancellationState2.Continue = 0;
    CancellationState2.Cancelled = 1;
  })(CancellationState || (CancellationState = {}));
  class SharedArraySenderStrategy {
    constructor() {
      this.buffers = /* @__PURE__ */ new Map();
    }
    enableCancellation(request) {
      if (request.id === null) {
        return;
      }
      const buffer2 = new SharedArrayBuffer(4);
      const data = new Int32Array(buffer2, 0, 1);
      data[0] = CancellationState.Continue;
      this.buffers.set(request.id, buffer2);
      request.$cancellationData = buffer2;
    }
    async sendCancellation(_conn, id) {
      const buffer2 = this.buffers.get(id);
      if (buffer2 === void 0) {
        return;
      }
      const data = new Int32Array(buffer2, 0, 1);
      Atomics.store(data, 0, CancellationState.Cancelled);
    }
    cleanup(id) {
      this.buffers.delete(id);
    }
    dispose() {
      this.buffers.clear();
    }
  }
  sharedArrayCancellation.SharedArraySenderStrategy = SharedArraySenderStrategy;
  class SharedArrayBufferCancellationToken {
    constructor(buffer2) {
      this.data = new Int32Array(buffer2, 0, 1);
    }
    get isCancellationRequested() {
      return Atomics.load(this.data, 0) === CancellationState.Cancelled;
    }
    get onCancellationRequested() {
      throw new Error(`Cancellation over SharedArrayBuffer doesn't support cancellation events`);
    }
  }
  class SharedArrayBufferCancellationTokenSource {
    constructor(buffer2) {
      this.token = new SharedArrayBufferCancellationToken(buffer2);
    }
    cancel() {
    }
    dispose() {
    }
  }
  class SharedArrayReceiverStrategy {
    constructor() {
      this.kind = "request";
    }
    createCancellationTokenSource(request) {
      const buffer2 = request.$cancellationData;
      if (buffer2 === void 0) {
        return new cancellation_1.CancellationTokenSource();
      }
      return new SharedArrayBufferCancellationTokenSource(buffer2);
    }
  }
  sharedArrayCancellation.SharedArrayReceiverStrategy = SharedArrayReceiverStrategy;
  return sharedArrayCancellation;
}
var messageReader = {};
var semaphore = {};
var hasRequiredSemaphore;
function requireSemaphore() {
  if (hasRequiredSemaphore) return semaphore;
  hasRequiredSemaphore = 1;
  Object.defineProperty(semaphore, "__esModule", {
    value: true
  });
  semaphore.Semaphore = void 0;
  const ral_1 = requireRal();
  class Semaphore {
    constructor(capacity = 1) {
      if (capacity <= 0) {
        throw new Error("Capacity must be greater than 0");
      }
      this._capacity = capacity;
      this._active = 0;
      this._waiting = [];
    }
    lock(thunk) {
      return new Promise((resolve2, reject) => {
        this._waiting.push({
          thunk,
          resolve: resolve2,
          reject
        });
        this.runNext();
      });
    }
    get active() {
      return this._active;
    }
    runNext() {
      if (this._waiting.length === 0 || this._active === this._capacity) {
        return;
      }
      (0, ral_1.default)().timer.setImmediate(() => this.doRunNext());
    }
    doRunNext() {
      if (this._waiting.length === 0 || this._active === this._capacity) {
        return;
      }
      const next = this._waiting.shift();
      this._active++;
      if (this._active > this._capacity) {
        throw new Error(`To many thunks active`);
      }
      try {
        const result = next.thunk();
        if (result instanceof Promise) {
          result.then((value) => {
            this._active--;
            next.resolve(value);
            this.runNext();
          }, (err) => {
            this._active--;
            next.reject(err);
            this.runNext();
          });
        } else {
          this._active--;
          next.resolve(result);
          this.runNext();
        }
      } catch (err) {
        this._active--;
        next.reject(err);
        this.runNext();
      }
    }
  }
  semaphore.Semaphore = Semaphore;
  return semaphore;
}
var hasRequiredMessageReader;
function requireMessageReader() {
  if (hasRequiredMessageReader) return messageReader;
  hasRequiredMessageReader = 1;
  Object.defineProperty(messageReader, "__esModule", {
    value: true
  });
  messageReader.ReadableStreamMessageReader = messageReader.AbstractMessageReader = messageReader.MessageReader = void 0;
  const ral_1 = requireRal();
  const Is = requireIs$1();
  const events_1 = requireEvents();
  const semaphore_1 = requireSemaphore();
  var MessageReader;
  (function(MessageReader2) {
    function is2(value) {
      let candidate = value;
      return candidate && Is.func(candidate.listen) && Is.func(candidate.dispose) && Is.func(candidate.onError) && Is.func(candidate.onClose) && Is.func(candidate.onPartialMessage);
    }
    MessageReader2.is = is2;
  })(MessageReader || (messageReader.MessageReader = MessageReader = {}));
  class AbstractMessageReader {
    constructor() {
      this.errorEmitter = new events_1.Emitter();
      this.closeEmitter = new events_1.Emitter();
      this.partialMessageEmitter = new events_1.Emitter();
    }
    dispose() {
      this.errorEmitter.dispose();
      this.closeEmitter.dispose();
    }
    get onError() {
      return this.errorEmitter.event;
    }
    fireError(error2) {
      this.errorEmitter.fire(this.asError(error2));
    }
    get onClose() {
      return this.closeEmitter.event;
    }
    fireClose() {
      this.closeEmitter.fire(void 0);
    }
    get onPartialMessage() {
      return this.partialMessageEmitter.event;
    }
    firePartialMessage(info) {
      this.partialMessageEmitter.fire(info);
    }
    asError(error2) {
      if (error2 instanceof Error) {
        return error2;
      } else {
        return new Error(`Reader received error. Reason: ${Is.string(error2.message) ? error2.message : "unknown"}`);
      }
    }
  }
  messageReader.AbstractMessageReader = AbstractMessageReader;
  var ResolvedMessageReaderOptions;
  (function(ResolvedMessageReaderOptions2) {
    function fromOptions(options2) {
      let charset;
      let contentDecoder;
      const contentDecoders = /* @__PURE__ */ new Map();
      let contentTypeDecoder;
      const contentTypeDecoders = /* @__PURE__ */ new Map();
      if (options2 === void 0 || typeof options2 === "string") {
        charset = options2 ?? "utf-8";
      } else {
        charset = options2.charset ?? "utf-8";
        if (options2.contentDecoder !== void 0) {
          contentDecoder = options2.contentDecoder;
          contentDecoders.set(contentDecoder.name, contentDecoder);
        }
        if (options2.contentDecoders !== void 0) {
          for (const decoder of options2.contentDecoders) {
            contentDecoders.set(decoder.name, decoder);
          }
        }
        if (options2.contentTypeDecoder !== void 0) {
          contentTypeDecoder = options2.contentTypeDecoder;
          contentTypeDecoders.set(contentTypeDecoder.name, contentTypeDecoder);
        }
        if (options2.contentTypeDecoders !== void 0) {
          for (const decoder of options2.contentTypeDecoders) {
            contentTypeDecoders.set(decoder.name, decoder);
          }
        }
      }
      if (contentTypeDecoder === void 0) {
        contentTypeDecoder = (0, ral_1.default)().applicationJson.decoder;
        contentTypeDecoders.set(contentTypeDecoder.name, contentTypeDecoder);
      }
      return {
        charset,
        contentDecoder,
        contentDecoders,
        contentTypeDecoder,
        contentTypeDecoders
      };
    }
    ResolvedMessageReaderOptions2.fromOptions = fromOptions;
  })(ResolvedMessageReaderOptions || (ResolvedMessageReaderOptions = {}));
  class ReadableStreamMessageReader extends AbstractMessageReader {
    constructor(readable, options2) {
      super();
      this.readable = readable;
      this.options = ResolvedMessageReaderOptions.fromOptions(options2);
      this.buffer = (0, ral_1.default)().messageBuffer.create(this.options.charset);
      this._partialMessageTimeout = 1e4;
      this.nextMessageLength = -1;
      this.messageToken = 0;
      this.readSemaphore = new semaphore_1.Semaphore(1);
    }
    set partialMessageTimeout(timeout) {
      this._partialMessageTimeout = timeout;
    }
    get partialMessageTimeout() {
      return this._partialMessageTimeout;
    }
    listen(callback) {
      this.nextMessageLength = -1;
      this.messageToken = 0;
      this.partialMessageTimer = void 0;
      this.callback = callback;
      const result = this.readable.onData((data) => {
        this.onData(data);
      });
      this.readable.onError((error2) => this.fireError(error2));
      this.readable.onClose(() => this.fireClose());
      return result;
    }
    onData(data) {
      try {
        this.buffer.append(data);
        while (true) {
          if (this.nextMessageLength === -1) {
            const headers = this.buffer.tryReadHeaders(true);
            if (!headers) {
              return;
            }
            const contentLength2 = headers.get("content-length");
            if (!contentLength2) {
              this.fireError(new Error(`Header must provide a Content-Length property.
${JSON.stringify(Object.fromEntries(headers))}`));
              return;
            }
            const length = parseInt(contentLength2);
            if (isNaN(length)) {
              this.fireError(new Error(`Content-Length value must be a number. Got ${contentLength2}`));
              return;
            }
            this.nextMessageLength = length;
          }
          const body = this.buffer.tryReadBody(this.nextMessageLength);
          if (body === void 0) {
            this.setPartialMessageTimer();
            return;
          }
          this.clearPartialMessageTimer();
          this.nextMessageLength = -1;
          this.readSemaphore.lock(async () => {
            const bytes = this.options.contentDecoder !== void 0 ? await this.options.contentDecoder.decode(body) : body;
            const message = await this.options.contentTypeDecoder.decode(bytes, this.options);
            this.callback(message);
          }).catch((error2) => {
            this.fireError(error2);
          });
        }
      } catch (error2) {
        this.fireError(error2);
      }
    }
    clearPartialMessageTimer() {
      if (this.partialMessageTimer) {
        this.partialMessageTimer.dispose();
        this.partialMessageTimer = void 0;
      }
    }
    setPartialMessageTimer() {
      this.clearPartialMessageTimer();
      if (this._partialMessageTimeout <= 0) {
        return;
      }
      this.partialMessageTimer = (0, ral_1.default)().timer.setTimeout((token, timeout) => {
        this.partialMessageTimer = void 0;
        if (token === this.messageToken) {
          this.firePartialMessage({
            messageToken: token,
            waitingTime: timeout
          });
          this.setPartialMessageTimer();
        }
      }, this._partialMessageTimeout, this.messageToken, this._partialMessageTimeout);
    }
  }
  messageReader.ReadableStreamMessageReader = ReadableStreamMessageReader;
  return messageReader;
}
var messageWriter = {};
var hasRequiredMessageWriter;
function requireMessageWriter() {
  if (hasRequiredMessageWriter) return messageWriter;
  hasRequiredMessageWriter = 1;
  Object.defineProperty(messageWriter, "__esModule", {
    value: true
  });
  messageWriter.WriteableStreamMessageWriter = messageWriter.AbstractMessageWriter = messageWriter.MessageWriter = void 0;
  const ral_1 = requireRal();
  const Is = requireIs$1();
  const semaphore_1 = requireSemaphore();
  const events_1 = requireEvents();
  const ContentLength = "Content-Length: ";
  const CRLF = "\r\n";
  var MessageWriter;
  (function(MessageWriter2) {
    function is2(value) {
      let candidate = value;
      return candidate && Is.func(candidate.dispose) && Is.func(candidate.onClose) && Is.func(candidate.onError) && Is.func(candidate.write);
    }
    MessageWriter2.is = is2;
  })(MessageWriter || (messageWriter.MessageWriter = MessageWriter = {}));
  class AbstractMessageWriter {
    constructor() {
      this.errorEmitter = new events_1.Emitter();
      this.closeEmitter = new events_1.Emitter();
    }
    dispose() {
      this.errorEmitter.dispose();
      this.closeEmitter.dispose();
    }
    get onError() {
      return this.errorEmitter.event;
    }
    fireError(error2, message, count) {
      this.errorEmitter.fire([this.asError(error2), message, count]);
    }
    get onClose() {
      return this.closeEmitter.event;
    }
    fireClose() {
      this.closeEmitter.fire(void 0);
    }
    asError(error2) {
      if (error2 instanceof Error) {
        return error2;
      } else {
        return new Error(`Writer received error. Reason: ${Is.string(error2.message) ? error2.message : "unknown"}`);
      }
    }
  }
  messageWriter.AbstractMessageWriter = AbstractMessageWriter;
  var ResolvedMessageWriterOptions;
  (function(ResolvedMessageWriterOptions2) {
    function fromOptions(options2) {
      if (options2 === void 0 || typeof options2 === "string") {
        return {
          charset: options2 ?? "utf-8",
          contentTypeEncoder: (0, ral_1.default)().applicationJson.encoder
        };
      } else {
        return {
          charset: options2.charset ?? "utf-8",
          contentEncoder: options2.contentEncoder,
          contentTypeEncoder: options2.contentTypeEncoder ?? (0, ral_1.default)().applicationJson.encoder
        };
      }
    }
    ResolvedMessageWriterOptions2.fromOptions = fromOptions;
  })(ResolvedMessageWriterOptions || (ResolvedMessageWriterOptions = {}));
  class WriteableStreamMessageWriter extends AbstractMessageWriter {
    constructor(writable, options2) {
      super();
      this.writable = writable;
      this.options = ResolvedMessageWriterOptions.fromOptions(options2);
      this.errorCount = 0;
      this.writeSemaphore = new semaphore_1.Semaphore(1);
      this.writable.onError((error2) => this.fireError(error2));
      this.writable.onClose(() => this.fireClose());
    }
    async write(msg) {
      return this.writeSemaphore.lock(async () => {
        const payload = this.options.contentTypeEncoder.encode(msg, this.options).then((buffer2) => {
          if (this.options.contentEncoder !== void 0) {
            return this.options.contentEncoder.encode(buffer2);
          } else {
            return buffer2;
          }
        });
        return payload.then((buffer2) => {
          const headers = [];
          headers.push(ContentLength, buffer2.byteLength.toString(), CRLF);
          headers.push(CRLF);
          return this.doWrite(msg, headers, buffer2);
        }, (error2) => {
          this.fireError(error2);
          throw error2;
        });
      });
    }
    async doWrite(msg, headers, data) {
      try {
        await this.writable.write(headers.join(""), "ascii");
        return this.writable.write(data);
      } catch (error2) {
        this.handleError(error2, msg);
        return Promise.reject(error2);
      }
    }
    handleError(error2, msg) {
      this.errorCount++;
      this.fireError(error2, msg, this.errorCount);
    }
    end() {
      this.writable.end();
    }
  }
  messageWriter.WriteableStreamMessageWriter = WriteableStreamMessageWriter;
  return messageWriter;
}
var messageBuffer = {};
var hasRequiredMessageBuffer;
function requireMessageBuffer() {
  if (hasRequiredMessageBuffer) return messageBuffer;
  hasRequiredMessageBuffer = 1;
  Object.defineProperty(messageBuffer, "__esModule", {
    value: true
  });
  messageBuffer.AbstractMessageBuffer = void 0;
  const CR = 13;
  const LF = 10;
  const CRLF = "\r\n";
  class AbstractMessageBuffer {
    constructor(encoding = "utf-8") {
      this._encoding = encoding;
      this._chunks = [];
      this._totalLength = 0;
    }
    get encoding() {
      return this._encoding;
    }
    append(chunk) {
      const toAppend = typeof chunk === "string" ? this.fromString(chunk, this._encoding) : chunk;
      this._chunks.push(toAppend);
      this._totalLength += toAppend.byteLength;
    }
    tryReadHeaders(lowerCaseKeys = false) {
      if (this._chunks.length === 0) {
        return void 0;
      }
      let state = 0;
      let chunkIndex = 0;
      let offset = 0;
      let chunkBytesRead = 0;
      row: while (chunkIndex < this._chunks.length) {
        const chunk = this._chunks[chunkIndex];
        offset = 0;
        while (offset < chunk.length) {
          const value = chunk[offset];
          switch (value) {
            case CR:
              switch (state) {
                case 0:
                  state = 1;
                  break;
                case 2:
                  state = 3;
                  break;
                default:
                  state = 0;
              }
              break;
            case LF:
              switch (state) {
                case 1:
                  state = 2;
                  break;
                case 3:
                  state = 4;
                  offset++;
                  break row;
                default:
                  state = 0;
              }
              break;
            default:
              state = 0;
          }
          offset++;
        }
        chunkBytesRead += chunk.byteLength;
        chunkIndex++;
      }
      if (state !== 4) {
        return void 0;
      }
      const buffer2 = this._read(chunkBytesRead + offset);
      const result = /* @__PURE__ */ new Map();
      const headers = this.toString(buffer2, "ascii").split(CRLF);
      if (headers.length < 2) {
        return result;
      }
      for (let i = 0; i < headers.length - 2; i++) {
        const header = headers[i];
        const index = header.indexOf(":");
        if (index === -1) {
          throw new Error(`Message header must separate key and value using ':'
${header}`);
        }
        const key = header.substr(0, index);
        const value = header.substr(index + 1).trim();
        result.set(lowerCaseKeys ? key.toLowerCase() : key, value);
      }
      return result;
    }
    tryReadBody(length) {
      if (this._totalLength < length) {
        return void 0;
      }
      return this._read(length);
    }
    get numberOfBytes() {
      return this._totalLength;
    }
    _read(byteCount) {
      if (byteCount === 0) {
        return this.emptyBuffer();
      }
      if (byteCount > this._totalLength) {
        throw new Error(`Cannot read so many bytes!`);
      }
      if (this._chunks[0].byteLength === byteCount) {
        const chunk = this._chunks[0];
        this._chunks.shift();
        this._totalLength -= byteCount;
        return this.asNative(chunk);
      }
      if (this._chunks[0].byteLength > byteCount) {
        const chunk = this._chunks[0];
        const result2 = this.asNative(chunk, byteCount);
        this._chunks[0] = chunk.slice(byteCount);
        this._totalLength -= byteCount;
        return result2;
      }
      const result = this.allocNative(byteCount);
      let resultOffset = 0;
      let chunkIndex = 0;
      while (byteCount > 0) {
        const chunk = this._chunks[chunkIndex];
        if (chunk.byteLength > byteCount) {
          const chunkPart = chunk.slice(0, byteCount);
          result.set(chunkPart, resultOffset);
          resultOffset += byteCount;
          this._chunks[chunkIndex] = chunk.slice(byteCount);
          this._totalLength -= byteCount;
          byteCount -= byteCount;
        } else {
          result.set(chunk, resultOffset);
          resultOffset += chunk.byteLength;
          this._chunks.shift();
          this._totalLength -= chunk.byteLength;
          byteCount -= chunk.byteLength;
        }
      }
      return result;
    }
  }
  messageBuffer.AbstractMessageBuffer = AbstractMessageBuffer;
  return messageBuffer;
}
var connection$1 = {};
var hasRequiredConnection$1;
function requireConnection$1() {
  if (hasRequiredConnection$1) return connection$1;
  hasRequiredConnection$1 = 1;
  (function(exports) {
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.createMessageConnection = exports.ConnectionOptions = exports.MessageStrategy = exports.CancellationStrategy = exports.CancellationSenderStrategy = exports.CancellationReceiverStrategy = exports.RequestCancellationReceiverStrategy = exports.IdCancellationReceiverStrategy = exports.ConnectionStrategy = exports.ConnectionError = exports.ConnectionErrors = exports.LogTraceNotification = exports.SetTraceNotification = exports.TraceFormat = exports.TraceValues = exports.Trace = exports.NullLogger = exports.ProgressType = exports.ProgressToken = void 0;
    const ral_1 = requireRal();
    const Is = requireIs$1();
    const messages_1 = requireMessages$1();
    const linkedMap_1 = requireLinkedMap();
    const events_1 = requireEvents();
    const cancellation_1 = requireCancellation();
    var CancelNotification;
    (function(CancelNotification2) {
      CancelNotification2.type = new messages_1.NotificationType("$/cancelRequest");
    })(CancelNotification || (CancelNotification = {}));
    var ProgressToken;
    (function(ProgressToken2) {
      function is2(value) {
        return typeof value === "string" || typeof value === "number";
      }
      ProgressToken2.is = is2;
    })(ProgressToken || (exports.ProgressToken = ProgressToken = {}));
    var ProgressNotification;
    (function(ProgressNotification2) {
      ProgressNotification2.type = new messages_1.NotificationType("$/progress");
    })(ProgressNotification || (ProgressNotification = {}));
    class ProgressType {
      constructor() {
      }
    }
    exports.ProgressType = ProgressType;
    var StarRequestHandler;
    (function(StarRequestHandler2) {
      function is2(value) {
        return Is.func(value);
      }
      StarRequestHandler2.is = is2;
    })(StarRequestHandler || (StarRequestHandler = {}));
    exports.NullLogger = Object.freeze({
      error: () => {
      },
      warn: () => {
      },
      info: () => {
      },
      log: () => {
      }
    });
    var Trace2;
    (function(Trace3) {
      Trace3[Trace3["Off"] = 0] = "Off";
      Trace3[Trace3["Messages"] = 1] = "Messages";
      Trace3[Trace3["Compact"] = 2] = "Compact";
      Trace3[Trace3["Verbose"] = 3] = "Verbose";
    })(Trace2 || (exports.Trace = Trace2 = {}));
    var TraceValues;
    (function(TraceValues2) {
      TraceValues2.Off = "off";
      TraceValues2.Messages = "messages";
      TraceValues2.Compact = "compact";
      TraceValues2.Verbose = "verbose";
    })(TraceValues || (exports.TraceValues = TraceValues = {}));
    (function(Trace3) {
      function fromString(value) {
        if (!Is.string(value)) {
          return Trace3.Off;
        }
        value = value.toLowerCase();
        switch (value) {
          case "off":
            return Trace3.Off;
          case "messages":
            return Trace3.Messages;
          case "compact":
            return Trace3.Compact;
          case "verbose":
            return Trace3.Verbose;
          default:
            return Trace3.Off;
        }
      }
      Trace3.fromString = fromString;
      function toString(value) {
        switch (value) {
          case Trace3.Off:
            return "off";
          case Trace3.Messages:
            return "messages";
          case Trace3.Compact:
            return "compact";
          case Trace3.Verbose:
            return "verbose";
          default:
            return "off";
        }
      }
      Trace3.toString = toString;
    })(Trace2 || (exports.Trace = Trace2 = {}));
    var TraceFormat;
    (function(TraceFormat2) {
      TraceFormat2["Text"] = "text";
      TraceFormat2["JSON"] = "json";
    })(TraceFormat || (exports.TraceFormat = TraceFormat = {}));
    (function(TraceFormat2) {
      function fromString(value) {
        if (!Is.string(value)) {
          return TraceFormat2.Text;
        }
        value = value.toLowerCase();
        if (value === "json") {
          return TraceFormat2.JSON;
        } else {
          return TraceFormat2.Text;
        }
      }
      TraceFormat2.fromString = fromString;
    })(TraceFormat || (exports.TraceFormat = TraceFormat = {}));
    var SetTraceNotification;
    (function(SetTraceNotification2) {
      SetTraceNotification2.type = new messages_1.NotificationType("$/setTrace");
    })(SetTraceNotification || (exports.SetTraceNotification = SetTraceNotification = {}));
    var LogTraceNotification;
    (function(LogTraceNotification2) {
      LogTraceNotification2.type = new messages_1.NotificationType("$/logTrace");
    })(LogTraceNotification || (exports.LogTraceNotification = LogTraceNotification = {}));
    var ConnectionErrors;
    (function(ConnectionErrors2) {
      ConnectionErrors2[ConnectionErrors2["Closed"] = 1] = "Closed";
      ConnectionErrors2[ConnectionErrors2["Disposed"] = 2] = "Disposed";
      ConnectionErrors2[ConnectionErrors2["AlreadyListening"] = 3] = "AlreadyListening";
    })(ConnectionErrors || (exports.ConnectionErrors = ConnectionErrors = {}));
    class ConnectionError extends Error {
      constructor(code, message) {
        super(message);
        this.code = code;
        Object.setPrototypeOf(this, ConnectionError.prototype);
      }
    }
    exports.ConnectionError = ConnectionError;
    var ConnectionStrategy;
    (function(ConnectionStrategy2) {
      function is2(value) {
        const candidate = value;
        return candidate && Is.func(candidate.cancelUndispatched);
      }
      ConnectionStrategy2.is = is2;
    })(ConnectionStrategy || (exports.ConnectionStrategy = ConnectionStrategy = {}));
    var IdCancellationReceiverStrategy;
    (function(IdCancellationReceiverStrategy2) {
      function is2(value) {
        const candidate = value;
        return candidate && (candidate.kind === void 0 || candidate.kind === "id") && Is.func(candidate.createCancellationTokenSource) && (candidate.dispose === void 0 || Is.func(candidate.dispose));
      }
      IdCancellationReceiverStrategy2.is = is2;
    })(IdCancellationReceiverStrategy || (exports.IdCancellationReceiverStrategy = IdCancellationReceiverStrategy = {}));
    var RequestCancellationReceiverStrategy;
    (function(RequestCancellationReceiverStrategy2) {
      function is2(value) {
        const candidate = value;
        return candidate && candidate.kind === "request" && Is.func(candidate.createCancellationTokenSource) && (candidate.dispose === void 0 || Is.func(candidate.dispose));
      }
      RequestCancellationReceiverStrategy2.is = is2;
    })(RequestCancellationReceiverStrategy || (exports.RequestCancellationReceiverStrategy = RequestCancellationReceiverStrategy = {}));
    var CancellationReceiverStrategy;
    (function(CancellationReceiverStrategy2) {
      CancellationReceiverStrategy2.Message = Object.freeze({
        createCancellationTokenSource(_) {
          return new cancellation_1.CancellationTokenSource();
        }
      });
      function is2(value) {
        return IdCancellationReceiverStrategy.is(value) || RequestCancellationReceiverStrategy.is(value);
      }
      CancellationReceiverStrategy2.is = is2;
    })(CancellationReceiverStrategy || (exports.CancellationReceiverStrategy = CancellationReceiverStrategy = {}));
    var CancellationSenderStrategy;
    (function(CancellationSenderStrategy2) {
      CancellationSenderStrategy2.Message = Object.freeze({
        sendCancellation(conn, id) {
          return conn.sendNotification(CancelNotification.type, {
            id
          });
        },
        cleanup(_) {
        }
      });
      function is2(value) {
        const candidate = value;
        return candidate && Is.func(candidate.sendCancellation) && Is.func(candidate.cleanup);
      }
      CancellationSenderStrategy2.is = is2;
    })(CancellationSenderStrategy || (exports.CancellationSenderStrategy = CancellationSenderStrategy = {}));
    var CancellationStrategy;
    (function(CancellationStrategy2) {
      CancellationStrategy2.Message = Object.freeze({
        receiver: CancellationReceiverStrategy.Message,
        sender: CancellationSenderStrategy.Message
      });
      function is2(value) {
        const candidate = value;
        return candidate && CancellationReceiverStrategy.is(candidate.receiver) && CancellationSenderStrategy.is(candidate.sender);
      }
      CancellationStrategy2.is = is2;
    })(CancellationStrategy || (exports.CancellationStrategy = CancellationStrategy = {}));
    var MessageStrategy;
    (function(MessageStrategy2) {
      function is2(value) {
        const candidate = value;
        return candidate && Is.func(candidate.handleMessage);
      }
      MessageStrategy2.is = is2;
    })(MessageStrategy || (exports.MessageStrategy = MessageStrategy = {}));
    var ConnectionOptions;
    (function(ConnectionOptions2) {
      function is2(value) {
        const candidate = value;
        return candidate && (CancellationStrategy.is(candidate.cancellationStrategy) || ConnectionStrategy.is(candidate.connectionStrategy) || MessageStrategy.is(candidate.messageStrategy));
      }
      ConnectionOptions2.is = is2;
    })(ConnectionOptions || (exports.ConnectionOptions = ConnectionOptions = {}));
    var ConnectionState;
    (function(ConnectionState2) {
      ConnectionState2[ConnectionState2["New"] = 1] = "New";
      ConnectionState2[ConnectionState2["Listening"] = 2] = "Listening";
      ConnectionState2[ConnectionState2["Closed"] = 3] = "Closed";
      ConnectionState2[ConnectionState2["Disposed"] = 4] = "Disposed";
    })(ConnectionState || (ConnectionState = {}));
    function createMessageConnection(messageReader2, messageWriter2, _logger, options2) {
      const logger = _logger !== void 0 ? _logger : exports.NullLogger;
      let sequenceNumber = 0;
      let notificationSequenceNumber = 0;
      let unknownResponseSequenceNumber = 0;
      const version2 = "2.0";
      let starRequestHandler = void 0;
      const requestHandlers = /* @__PURE__ */ new Map();
      let starNotificationHandler = void 0;
      const notificationHandlers = /* @__PURE__ */ new Map();
      const progressHandlers = /* @__PURE__ */ new Map();
      let timer;
      let messageQueue = new linkedMap_1.LinkedMap();
      let responsePromises = /* @__PURE__ */ new Map();
      let knownCanceledRequests = /* @__PURE__ */ new Set();
      let requestTokens = /* @__PURE__ */ new Map();
      let trace = Trace2.Off;
      let traceFormat = TraceFormat.Text;
      let tracer;
      let state = ConnectionState.New;
      const errorEmitter = new events_1.Emitter();
      const closeEmitter = new events_1.Emitter();
      const unhandledNotificationEmitter = new events_1.Emitter();
      const unhandledProgressEmitter = new events_1.Emitter();
      const disposeEmitter = new events_1.Emitter();
      const cancellationStrategy = options2 && options2.cancellationStrategy ? options2.cancellationStrategy : CancellationStrategy.Message;
      function createRequestQueueKey(id) {
        if (id === null) {
          throw new Error(`Can't send requests with id null since the response can't be correlated.`);
        }
        return "req-" + id.toString();
      }
      function createResponseQueueKey(id) {
        if (id === null) {
          return "res-unknown-" + (++unknownResponseSequenceNumber).toString();
        } else {
          return "res-" + id.toString();
        }
      }
      function createNotificationQueueKey() {
        return "not-" + (++notificationSequenceNumber).toString();
      }
      function addMessageToQueue(queue, message) {
        if (messages_1.Message.isRequest(message)) {
          queue.set(createRequestQueueKey(message.id), message);
        } else if (messages_1.Message.isResponse(message)) {
          queue.set(createResponseQueueKey(message.id), message);
        } else {
          queue.set(createNotificationQueueKey(), message);
        }
      }
      function cancelUndispatched(_message) {
        return void 0;
      }
      function isListening() {
        return state === ConnectionState.Listening;
      }
      function isClosed() {
        return state === ConnectionState.Closed;
      }
      function isDisposed() {
        return state === ConnectionState.Disposed;
      }
      function closeHandler() {
        if (state === ConnectionState.New || state === ConnectionState.Listening) {
          state = ConnectionState.Closed;
          closeEmitter.fire(void 0);
        }
      }
      function readErrorHandler(error2) {
        errorEmitter.fire([error2, void 0, void 0]);
      }
      function writeErrorHandler(data) {
        errorEmitter.fire(data);
      }
      messageReader2.onClose(closeHandler);
      messageReader2.onError(readErrorHandler);
      messageWriter2.onClose(closeHandler);
      messageWriter2.onError(writeErrorHandler);
      function triggerMessageQueue() {
        if (timer || messageQueue.size === 0) {
          return;
        }
        timer = (0, ral_1.default)().timer.setImmediate(() => {
          timer = void 0;
          processMessageQueue();
        });
      }
      function handleMessage(message) {
        if (messages_1.Message.isRequest(message)) {
          handleRequest(message);
        } else if (messages_1.Message.isNotification(message)) {
          handleNotification(message);
        } else if (messages_1.Message.isResponse(message)) {
          handleResponse(message);
        } else {
          handleInvalidMessage(message);
        }
      }
      function processMessageQueue() {
        if (messageQueue.size === 0) {
          return;
        }
        const message = messageQueue.shift();
        try {
          const messageStrategy = options2?.messageStrategy;
          if (MessageStrategy.is(messageStrategy)) {
            messageStrategy.handleMessage(message, handleMessage);
          } else {
            handleMessage(message);
          }
        } finally {
          triggerMessageQueue();
        }
      }
      const callback = (message) => {
        try {
          if (messages_1.Message.isNotification(message) && message.method === CancelNotification.type.method) {
            const cancelId = message.params.id;
            const key = createRequestQueueKey(cancelId);
            const toCancel = messageQueue.get(key);
            if (messages_1.Message.isRequest(toCancel)) {
              const strategy = options2?.connectionStrategy;
              const response = strategy && strategy.cancelUndispatched ? strategy.cancelUndispatched(toCancel, cancelUndispatched) : cancelUndispatched(toCancel);
              if (response && (response.error !== void 0 || response.result !== void 0)) {
                messageQueue.delete(key);
                requestTokens.delete(cancelId);
                response.id = toCancel.id;
                traceSendingResponse(response, message.method, Date.now());
                messageWriter2.write(response).catch(() => logger.error(`Sending response for canceled message failed.`));
                return;
              }
            }
            const cancellationToken = requestTokens.get(cancelId);
            if (cancellationToken !== void 0) {
              cancellationToken.cancel();
              traceReceivedNotification(message);
              return;
            } else {
              knownCanceledRequests.add(cancelId);
            }
          }
          addMessageToQueue(messageQueue, message);
        } finally {
          triggerMessageQueue();
        }
      };
      function handleRequest(requestMessage) {
        if (isDisposed()) {
          return;
        }
        function reply(resultOrError, method, startTime2) {
          const message = {
            jsonrpc: version2,
            id: requestMessage.id
          };
          if (resultOrError instanceof messages_1.ResponseError) {
            message.error = resultOrError.toJson();
          } else {
            message.result = resultOrError === void 0 ? null : resultOrError;
          }
          traceSendingResponse(message, method, startTime2);
          messageWriter2.write(message).catch(() => logger.error(`Sending response failed.`));
        }
        function replyError(error2, method, startTime2) {
          const message = {
            jsonrpc: version2,
            id: requestMessage.id,
            error: error2.toJson()
          };
          traceSendingResponse(message, method, startTime2);
          messageWriter2.write(message).catch(() => logger.error(`Sending response failed.`));
        }
        function replySuccess(result, method, startTime2) {
          if (result === void 0) {
            result = null;
          }
          const message = {
            jsonrpc: version2,
            id: requestMessage.id,
            result
          };
          traceSendingResponse(message, method, startTime2);
          messageWriter2.write(message).catch(() => logger.error(`Sending response failed.`));
        }
        traceReceivedRequest(requestMessage);
        const element = requestHandlers.get(requestMessage.method);
        let type;
        let requestHandler;
        if (element) {
          type = element.type;
          requestHandler = element.handler;
        }
        const startTime = Date.now();
        if (requestHandler || starRequestHandler) {
          const tokenKey = requestMessage.id ?? String(Date.now());
          const cancellationSource = IdCancellationReceiverStrategy.is(cancellationStrategy.receiver) ? cancellationStrategy.receiver.createCancellationTokenSource(tokenKey) : cancellationStrategy.receiver.createCancellationTokenSource(requestMessage);
          if (requestMessage.id !== null && knownCanceledRequests.has(requestMessage.id)) {
            cancellationSource.cancel();
          }
          if (requestMessage.id !== null) {
            requestTokens.set(tokenKey, cancellationSource);
          }
          try {
            let handlerResult;
            if (requestHandler) {
              if (requestMessage.params === void 0) {
                if (type !== void 0 && type.numberOfParams !== 0) {
                  replyError(new messages_1.ResponseError(messages_1.ErrorCodes.InvalidParams, `Request ${requestMessage.method} defines ${type.numberOfParams} params but received none.`), requestMessage.method, startTime);
                  return;
                }
                handlerResult = requestHandler(cancellationSource.token);
              } else if (Array.isArray(requestMessage.params)) {
                if (type !== void 0 && type.parameterStructures === messages_1.ParameterStructures.byName) {
                  replyError(new messages_1.ResponseError(messages_1.ErrorCodes.InvalidParams, `Request ${requestMessage.method} defines parameters by name but received parameters by position`), requestMessage.method, startTime);
                  return;
                }
                handlerResult = requestHandler(...requestMessage.params, cancellationSource.token);
              } else {
                if (type !== void 0 && type.parameterStructures === messages_1.ParameterStructures.byPosition) {
                  replyError(new messages_1.ResponseError(messages_1.ErrorCodes.InvalidParams, `Request ${requestMessage.method} defines parameters by position but received parameters by name`), requestMessage.method, startTime);
                  return;
                }
                handlerResult = requestHandler(requestMessage.params, cancellationSource.token);
              }
            } else if (starRequestHandler) {
              handlerResult = starRequestHandler(requestMessage.method, requestMessage.params, cancellationSource.token);
            }
            const promise = handlerResult;
            if (!handlerResult) {
              requestTokens.delete(tokenKey);
              replySuccess(handlerResult, requestMessage.method, startTime);
            } else if (promise.then) {
              promise.then((resultOrError) => {
                requestTokens.delete(tokenKey);
                reply(resultOrError, requestMessage.method, startTime);
              }, (error2) => {
                requestTokens.delete(tokenKey);
                if (error2 instanceof messages_1.ResponseError) {
                  replyError(error2, requestMessage.method, startTime);
                } else if (error2 && Is.string(error2.message)) {
                  replyError(new messages_1.ResponseError(messages_1.ErrorCodes.InternalError, `Request ${requestMessage.method} failed with message: ${error2.message}`), requestMessage.method, startTime);
                } else {
                  replyError(new messages_1.ResponseError(messages_1.ErrorCodes.InternalError, `Request ${requestMessage.method} failed unexpectedly without providing any details.`), requestMessage.method, startTime);
                }
              });
            } else {
              requestTokens.delete(tokenKey);
              reply(handlerResult, requestMessage.method, startTime);
            }
          } catch (error2) {
            requestTokens.delete(tokenKey);
            if (error2 instanceof messages_1.ResponseError) {
              reply(error2, requestMessage.method, startTime);
            } else if (error2 && Is.string(error2.message)) {
              replyError(new messages_1.ResponseError(messages_1.ErrorCodes.InternalError, `Request ${requestMessage.method} failed with message: ${error2.message}`), requestMessage.method, startTime);
            } else {
              replyError(new messages_1.ResponseError(messages_1.ErrorCodes.InternalError, `Request ${requestMessage.method} failed unexpectedly without providing any details.`), requestMessage.method, startTime);
            }
          }
        } else {
          replyError(new messages_1.ResponseError(messages_1.ErrorCodes.MethodNotFound, `Unhandled method ${requestMessage.method}`), requestMessage.method, startTime);
        }
      }
      function handleResponse(responseMessage) {
        if (isDisposed()) {
          return;
        }
        if (responseMessage.id === null) {
          if (responseMessage.error) {
            logger.error(`Received response message without id: Error is: 
${JSON.stringify(responseMessage.error, void 0, 4)}`);
          } else {
            logger.error(`Received response message without id. No further error information provided.`);
          }
        } else {
          const key = responseMessage.id;
          const responsePromise = responsePromises.get(key);
          traceReceivedResponse(responseMessage, responsePromise);
          if (responsePromise !== void 0) {
            responsePromises.delete(key);
            try {
              if (responseMessage.error) {
                const error2 = responseMessage.error;
                responsePromise.reject(new messages_1.ResponseError(error2.code, error2.message, error2.data));
              } else if (responseMessage.result !== void 0) {
                responsePromise.resolve(responseMessage.result);
              } else {
                throw new Error("Should never happen.");
              }
            } catch (error2) {
              if (error2.message) {
                logger.error(`Response handler '${responsePromise.method}' failed with message: ${error2.message}`);
              } else {
                logger.error(`Response handler '${responsePromise.method}' failed unexpectedly.`);
              }
            }
          }
        }
      }
      function handleNotification(message) {
        if (isDisposed()) {
          return;
        }
        let type = void 0;
        let notificationHandler;
        if (message.method === CancelNotification.type.method) {
          const cancelId = message.params.id;
          knownCanceledRequests.delete(cancelId);
          traceReceivedNotification(message);
          return;
        } else {
          const element = notificationHandlers.get(message.method);
          if (element) {
            notificationHandler = element.handler;
            type = element.type;
          }
        }
        if (notificationHandler || starNotificationHandler) {
          try {
            traceReceivedNotification(message);
            if (notificationHandler) {
              if (message.params === void 0) {
                if (type !== void 0) {
                  if (type.numberOfParams !== 0 && type.parameterStructures !== messages_1.ParameterStructures.byName) {
                    logger.error(`Notification ${message.method} defines ${type.numberOfParams} params but received none.`);
                  }
                }
                notificationHandler();
              } else if (Array.isArray(message.params)) {
                const params = message.params;
                if (message.method === ProgressNotification.type.method && params.length === 2 && ProgressToken.is(params[0])) {
                  notificationHandler({
                    token: params[0],
                    value: params[1]
                  });
                } else {
                  if (type !== void 0) {
                    if (type.parameterStructures === messages_1.ParameterStructures.byName) {
                      logger.error(`Notification ${message.method} defines parameters by name but received parameters by position`);
                    }
                    if (type.numberOfParams !== message.params.length) {
                      logger.error(`Notification ${message.method} defines ${type.numberOfParams} params but received ${params.length} arguments`);
                    }
                  }
                  notificationHandler(...params);
                }
              } else {
                if (type !== void 0 && type.parameterStructures === messages_1.ParameterStructures.byPosition) {
                  logger.error(`Notification ${message.method} defines parameters by position but received parameters by name`);
                }
                notificationHandler(message.params);
              }
            } else if (starNotificationHandler) {
              starNotificationHandler(message.method, message.params);
            }
          } catch (error2) {
            if (error2.message) {
              logger.error(`Notification handler '${message.method}' failed with message: ${error2.message}`);
            } else {
              logger.error(`Notification handler '${message.method}' failed unexpectedly.`);
            }
          }
        } else {
          unhandledNotificationEmitter.fire(message);
        }
      }
      function handleInvalidMessage(message) {
        if (!message) {
          logger.error("Received empty message.");
          return;
        }
        logger.error(`Received message which is neither a response nor a notification message:
${JSON.stringify(message, null, 4)}`);
        const responseMessage = message;
        if (Is.string(responseMessage.id) || Is.number(responseMessage.id)) {
          const key = responseMessage.id;
          const responseHandler = responsePromises.get(key);
          if (responseHandler) {
            responseHandler.reject(new Error("The received response has neither a result nor an error property."));
          }
        }
      }
      function stringifyTrace(params) {
        if (params === void 0 || params === null) {
          return void 0;
        }
        switch (trace) {
          case Trace2.Verbose:
            return JSON.stringify(params, null, 4);
          case Trace2.Compact:
            return JSON.stringify(params);
          default:
            return void 0;
        }
      }
      function traceSendingRequest(message) {
        if (trace === Trace2.Off || !tracer) {
          return;
        }
        if (traceFormat === TraceFormat.Text) {
          let data = void 0;
          if ((trace === Trace2.Verbose || trace === Trace2.Compact) && message.params) {
            data = `Params: ${stringifyTrace(message.params)}

`;
          }
          tracer.log(`Sending request '${message.method} - (${message.id})'.`, data);
        } else {
          logLSPMessage("send-request", message);
        }
      }
      function traceSendingNotification(message) {
        if (trace === Trace2.Off || !tracer) {
          return;
        }
        if (traceFormat === TraceFormat.Text) {
          let data = void 0;
          if (trace === Trace2.Verbose || trace === Trace2.Compact) {
            if (message.params) {
              data = `Params: ${stringifyTrace(message.params)}

`;
            } else {
              data = "No parameters provided.\n\n";
            }
          }
          tracer.log(`Sending notification '${message.method}'.`, data);
        } else {
          logLSPMessage("send-notification", message);
        }
      }
      function traceSendingResponse(message, method, startTime) {
        if (trace === Trace2.Off || !tracer) {
          return;
        }
        if (traceFormat === TraceFormat.Text) {
          let data = void 0;
          if (trace === Trace2.Verbose || trace === Trace2.Compact) {
            if (message.error && message.error.data) {
              data = `Error data: ${stringifyTrace(message.error.data)}

`;
            } else {
              if (message.result) {
                data = `Result: ${stringifyTrace(message.result)}

`;
              } else if (message.error === void 0) {
                data = "No result returned.\n\n";
              }
            }
          }
          tracer.log(`Sending response '${method} - (${message.id})'. Processing request took ${Date.now() - startTime}ms`, data);
        } else {
          logLSPMessage("send-response", message);
        }
      }
      function traceReceivedRequest(message) {
        if (trace === Trace2.Off || !tracer) {
          return;
        }
        if (traceFormat === TraceFormat.Text) {
          let data = void 0;
          if ((trace === Trace2.Verbose || trace === Trace2.Compact) && message.params) {
            data = `Params: ${stringifyTrace(message.params)}

`;
          }
          tracer.log(`Received request '${message.method} - (${message.id})'.`, data);
        } else {
          logLSPMessage("receive-request", message);
        }
      }
      function traceReceivedNotification(message) {
        if (trace === Trace2.Off || !tracer || message.method === LogTraceNotification.type.method) {
          return;
        }
        if (traceFormat === TraceFormat.Text) {
          let data = void 0;
          if (trace === Trace2.Verbose || trace === Trace2.Compact) {
            if (message.params) {
              data = `Params: ${stringifyTrace(message.params)}

`;
            } else {
              data = "No parameters provided.\n\n";
            }
          }
          tracer.log(`Received notification '${message.method}'.`, data);
        } else {
          logLSPMessage("receive-notification", message);
        }
      }
      function traceReceivedResponse(message, responsePromise) {
        if (trace === Trace2.Off || !tracer) {
          return;
        }
        if (traceFormat === TraceFormat.Text) {
          let data = void 0;
          if (trace === Trace2.Verbose || trace === Trace2.Compact) {
            if (message.error && message.error.data) {
              data = `Error data: ${stringifyTrace(message.error.data)}

`;
            } else {
              if (message.result) {
                data = `Result: ${stringifyTrace(message.result)}

`;
              } else if (message.error === void 0) {
                data = "No result returned.\n\n";
              }
            }
          }
          if (responsePromise) {
            const error2 = message.error ? ` Request failed: ${message.error.message} (${message.error.code}).` : "";
            tracer.log(`Received response '${responsePromise.method} - (${message.id})' in ${Date.now() - responsePromise.timerStart}ms.${error2}`, data);
          } else {
            tracer.log(`Received response ${message.id} without active response promise.`, data);
          }
        } else {
          logLSPMessage("receive-response", message);
        }
      }
      function logLSPMessage(type, message) {
        if (!tracer || trace === Trace2.Off) {
          return;
        }
        const lspMessage = {
          isLSPMessage: true,
          type,
          message,
          timestamp: Date.now()
        };
        tracer.log(lspMessage);
      }
      function throwIfClosedOrDisposed() {
        if (isClosed()) {
          throw new ConnectionError(ConnectionErrors.Closed, "Connection is closed.");
        }
        if (isDisposed()) {
          throw new ConnectionError(ConnectionErrors.Disposed, "Connection is disposed.");
        }
      }
      function throwIfListening() {
        if (isListening()) {
          throw new ConnectionError(ConnectionErrors.AlreadyListening, "Connection is already listening");
        }
      }
      function throwIfNotListening() {
        if (!isListening()) {
          throw new Error("Call listen() first.");
        }
      }
      function undefinedToNull(param) {
        if (param === void 0) {
          return null;
        } else {
          return param;
        }
      }
      function nullToUndefined(param) {
        if (param === null) {
          return void 0;
        } else {
          return param;
        }
      }
      function isNamedParam(param) {
        return param !== void 0 && param !== null && !Array.isArray(param) && typeof param === "object";
      }
      function computeSingleParam(parameterStructures, param) {
        switch (parameterStructures) {
          case messages_1.ParameterStructures.auto:
            if (isNamedParam(param)) {
              return nullToUndefined(param);
            } else {
              return [undefinedToNull(param)];
            }
          case messages_1.ParameterStructures.byName:
            if (!isNamedParam(param)) {
              throw new Error(`Received parameters by name but param is not an object literal.`);
            }
            return nullToUndefined(param);
          case messages_1.ParameterStructures.byPosition:
            return [undefinedToNull(param)];
          default:
            throw new Error(`Unknown parameter structure ${parameterStructures.toString()}`);
        }
      }
      function computeMessageParams(type, params) {
        let result;
        const numberOfParams = type.numberOfParams;
        switch (numberOfParams) {
          case 0:
            result = void 0;
            break;
          case 1:
            result = computeSingleParam(type.parameterStructures, params[0]);
            break;
          default:
            result = [];
            for (let i = 0; i < params.length && i < numberOfParams; i++) {
              result.push(undefinedToNull(params[i]));
            }
            if (params.length < numberOfParams) {
              for (let i = params.length; i < numberOfParams; i++) {
                result.push(null);
              }
            }
            break;
        }
        return result;
      }
      const connection2 = {
        sendNotification: (type, ...args) => {
          throwIfClosedOrDisposed();
          let method;
          let messageParams;
          if (Is.string(type)) {
            method = type;
            const first = args[0];
            let paramStart = 0;
            let parameterStructures = messages_1.ParameterStructures.auto;
            if (messages_1.ParameterStructures.is(first)) {
              paramStart = 1;
              parameterStructures = first;
            }
            let paramEnd = args.length;
            const numberOfParams = paramEnd - paramStart;
            switch (numberOfParams) {
              case 0:
                messageParams = void 0;
                break;
              case 1:
                messageParams = computeSingleParam(parameterStructures, args[paramStart]);
                break;
              default:
                if (parameterStructures === messages_1.ParameterStructures.byName) {
                  throw new Error(`Received ${numberOfParams} parameters for 'by Name' notification parameter structure.`);
                }
                messageParams = args.slice(paramStart, paramEnd).map((value) => undefinedToNull(value));
                break;
            }
          } else {
            const params = args;
            method = type.method;
            messageParams = computeMessageParams(type, params);
          }
          const notificationMessage = {
            jsonrpc: version2,
            method,
            params: messageParams
          };
          traceSendingNotification(notificationMessage);
          return messageWriter2.write(notificationMessage).catch((error2) => {
            logger.error(`Sending notification failed.`);
            throw error2;
          });
        },
        onNotification: (type, handler) => {
          throwIfClosedOrDisposed();
          let method;
          if (Is.func(type)) {
            starNotificationHandler = type;
          } else if (handler) {
            if (Is.string(type)) {
              method = type;
              notificationHandlers.set(type, {
                type: void 0,
                handler
              });
            } else {
              method = type.method;
              notificationHandlers.set(type.method, {
                type,
                handler
              });
            }
          }
          return {
            dispose: () => {
              if (method !== void 0) {
                notificationHandlers.delete(method);
              } else {
                starNotificationHandler = void 0;
              }
            }
          };
        },
        onProgress: (_type, token, handler) => {
          if (progressHandlers.has(token)) {
            throw new Error(`Progress handler for token ${token} already registered`);
          }
          progressHandlers.set(token, handler);
          return {
            dispose: () => {
              progressHandlers.delete(token);
            }
          };
        },
        sendProgress: (_type, token, value) => connection2.sendNotification(ProgressNotification.type, {
          token,
          value
        }),
        onUnhandledProgress: unhandledProgressEmitter.event,
        sendRequest: (type, ...args) => {
          throwIfClosedOrDisposed();
          throwIfNotListening();
          let method;
          let messageParams;
          let token = void 0;
          if (Is.string(type)) {
            method = type;
            const first = args[0];
            const last = args[args.length - 1];
            let paramStart = 0;
            let parameterStructures = messages_1.ParameterStructures.auto;
            if (messages_1.ParameterStructures.is(first)) {
              paramStart = 1;
              parameterStructures = first;
            }
            let paramEnd = args.length;
            if (cancellation_1.CancellationToken.is(last)) {
              paramEnd = paramEnd - 1;
              token = last;
            }
            const numberOfParams = paramEnd - paramStart;
            switch (numberOfParams) {
              case 0:
                messageParams = void 0;
                break;
              case 1:
                messageParams = computeSingleParam(parameterStructures, args[paramStart]);
                break;
              default:
                if (parameterStructures === messages_1.ParameterStructures.byName) {
                  throw new Error(`Received ${numberOfParams} parameters for 'by Name' request parameter structure.`);
                }
                messageParams = args.slice(paramStart, paramEnd).map((value) => undefinedToNull(value));
                break;
            }
          } else {
            const params = args;
            method = type.method;
            messageParams = computeMessageParams(type, params);
            const numberOfParams = type.numberOfParams;
            token = cancellation_1.CancellationToken.is(params[numberOfParams]) ? params[numberOfParams] : void 0;
          }
          const id = sequenceNumber++;
          let disposable2;
          if (token) {
            disposable2 = token.onCancellationRequested(() => {
              const p = cancellationStrategy.sender.sendCancellation(connection2, id);
              if (p === void 0) {
                logger.log(`Received no promise from cancellation strategy when cancelling id ${id}`);
                return Promise.resolve();
              } else {
                return p.catch(() => {
                  logger.log(`Sending cancellation messages for id ${id} failed`);
                });
              }
            });
          }
          const requestMessage = {
            jsonrpc: version2,
            id,
            method,
            params: messageParams
          };
          traceSendingRequest(requestMessage);
          if (typeof cancellationStrategy.sender.enableCancellation === "function") {
            cancellationStrategy.sender.enableCancellation(requestMessage);
          }
          return new Promise(async (resolve2, reject) => {
            const resolveWithCleanup = (r) => {
              resolve2(r);
              cancellationStrategy.sender.cleanup(id);
              disposable2?.dispose();
            };
            const rejectWithCleanup = (r) => {
              reject(r);
              cancellationStrategy.sender.cleanup(id);
              disposable2?.dispose();
            };
            const responsePromise = {
              method,
              timerStart: Date.now(),
              resolve: resolveWithCleanup,
              reject: rejectWithCleanup
            };
            try {
              responsePromises.set(id, responsePromise);
              await messageWriter2.write(requestMessage);
            } catch (error2) {
              responsePromises.delete(id);
              responsePromise.reject(new messages_1.ResponseError(messages_1.ErrorCodes.MessageWriteError, error2.message ? error2.message : "Unknown reason"));
              logger.error(`Sending request failed.`);
              throw error2;
            }
          });
        },
        onRequest: (type, handler) => {
          throwIfClosedOrDisposed();
          let method = null;
          if (StarRequestHandler.is(type)) {
            method = void 0;
            starRequestHandler = type;
          } else if (Is.string(type)) {
            method = null;
            if (handler !== void 0) {
              method = type;
              requestHandlers.set(type, {
                handler,
                type: void 0
              });
            }
          } else {
            if (handler !== void 0) {
              method = type.method;
              requestHandlers.set(type.method, {
                type,
                handler
              });
            }
          }
          return {
            dispose: () => {
              if (method === null) {
                return;
              }
              if (method !== void 0) {
                requestHandlers.delete(method);
              } else {
                starRequestHandler = void 0;
              }
            }
          };
        },
        hasPendingResponse: () => responsePromises.size > 0,
        trace: async (_value, _tracer, sendNotificationOrTraceOptions) => {
          let _sendNotification = false;
          let _traceFormat = TraceFormat.Text;
          if (sendNotificationOrTraceOptions !== void 0) {
            if (Is.boolean(sendNotificationOrTraceOptions)) {
              _sendNotification = sendNotificationOrTraceOptions;
            } else {
              _sendNotification = sendNotificationOrTraceOptions.sendNotification || false;
              _traceFormat = sendNotificationOrTraceOptions.traceFormat || TraceFormat.Text;
            }
          }
          trace = _value;
          traceFormat = _traceFormat;
          if (trace === Trace2.Off) {
            tracer = void 0;
          } else {
            tracer = _tracer;
          }
          if (_sendNotification && !isClosed() && !isDisposed()) {
            await connection2.sendNotification(SetTraceNotification.type, {
              value: Trace2.toString(_value)
            });
          }
        },
        onError: errorEmitter.event,
        onClose: closeEmitter.event,
        onUnhandledNotification: unhandledNotificationEmitter.event,
        onDispose: disposeEmitter.event,
        end: () => {
          messageWriter2.end();
        },
        dispose: () => {
          if (isDisposed()) {
            return;
          }
          state = ConnectionState.Disposed;
          disposeEmitter.fire(void 0);
          const error2 = new messages_1.ResponseError(messages_1.ErrorCodes.PendingResponseRejected, "Pending response rejected since connection got disposed");
          for (const promise of responsePromises.values()) {
            promise.reject(error2);
          }
          responsePromises = /* @__PURE__ */ new Map();
          requestTokens = /* @__PURE__ */ new Map();
          knownCanceledRequests = /* @__PURE__ */ new Set();
          messageQueue = new linkedMap_1.LinkedMap();
          if (Is.func(messageWriter2.dispose)) {
            messageWriter2.dispose();
          }
          if (Is.func(messageReader2.dispose)) {
            messageReader2.dispose();
          }
        },
        listen: () => {
          throwIfClosedOrDisposed();
          throwIfListening();
          state = ConnectionState.Listening;
          messageReader2.listen(callback);
        },
        inspect: () => {
          (0, ral_1.default)().console.log("inspect");
        }
      };
      connection2.onNotification(LogTraceNotification.type, (params) => {
        if (trace === Trace2.Off || !tracer) {
          return;
        }
        const verbose = trace === Trace2.Verbose || trace === Trace2.Compact;
        tracer.log(params.message, verbose ? params.verbose : void 0);
      });
      connection2.onNotification(ProgressNotification.type, (params) => {
        const handler = progressHandlers.get(params.token);
        if (handler) {
          handler(params.value);
        } else {
          unhandledProgressEmitter.fire(params);
        }
      });
      return connection2;
    }
    exports.createMessageConnection = createMessageConnection;
  })(connection$1);
  return connection$1;
}
var hasRequiredApi$2;
function requireApi$2() {
  if (hasRequiredApi$2) return api$2;
  hasRequiredApi$2 = 1;
  (function(exports) {
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.ProgressType = exports.ProgressToken = exports.createMessageConnection = exports.NullLogger = exports.ConnectionOptions = exports.ConnectionStrategy = exports.AbstractMessageBuffer = exports.WriteableStreamMessageWriter = exports.AbstractMessageWriter = exports.MessageWriter = exports.ReadableStreamMessageReader = exports.AbstractMessageReader = exports.MessageReader = exports.SharedArrayReceiverStrategy = exports.SharedArraySenderStrategy = exports.CancellationToken = exports.CancellationTokenSource = exports.Emitter = exports.Event = exports.Disposable = exports.LRUCache = exports.Touch = exports.LinkedMap = exports.ParameterStructures = exports.NotificationType9 = exports.NotificationType8 = exports.NotificationType7 = exports.NotificationType6 = exports.NotificationType5 = exports.NotificationType4 = exports.NotificationType3 = exports.NotificationType2 = exports.NotificationType1 = exports.NotificationType0 = exports.NotificationType = exports.ErrorCodes = exports.ResponseError = exports.RequestType9 = exports.RequestType8 = exports.RequestType7 = exports.RequestType6 = exports.RequestType5 = exports.RequestType4 = exports.RequestType3 = exports.RequestType2 = exports.RequestType1 = exports.RequestType0 = exports.RequestType = exports.Message = exports.RAL = void 0;
    exports.MessageStrategy = exports.CancellationStrategy = exports.CancellationSenderStrategy = exports.CancellationReceiverStrategy = exports.ConnectionError = exports.ConnectionErrors = exports.LogTraceNotification = exports.SetTraceNotification = exports.TraceFormat = exports.TraceValues = exports.Trace = void 0;
    const messages_1 = requireMessages$1();
    Object.defineProperty(exports, "Message", {
      enumerable: true,
      get: function() {
        return messages_1.Message;
      }
    });
    Object.defineProperty(exports, "RequestType", {
      enumerable: true,
      get: function() {
        return messages_1.RequestType;
      }
    });
    Object.defineProperty(exports, "RequestType0", {
      enumerable: true,
      get: function() {
        return messages_1.RequestType0;
      }
    });
    Object.defineProperty(exports, "RequestType1", {
      enumerable: true,
      get: function() {
        return messages_1.RequestType1;
      }
    });
    Object.defineProperty(exports, "RequestType2", {
      enumerable: true,
      get: function() {
        return messages_1.RequestType2;
      }
    });
    Object.defineProperty(exports, "RequestType3", {
      enumerable: true,
      get: function() {
        return messages_1.RequestType3;
      }
    });
    Object.defineProperty(exports, "RequestType4", {
      enumerable: true,
      get: function() {
        return messages_1.RequestType4;
      }
    });
    Object.defineProperty(exports, "RequestType5", {
      enumerable: true,
      get: function() {
        return messages_1.RequestType5;
      }
    });
    Object.defineProperty(exports, "RequestType6", {
      enumerable: true,
      get: function() {
        return messages_1.RequestType6;
      }
    });
    Object.defineProperty(exports, "RequestType7", {
      enumerable: true,
      get: function() {
        return messages_1.RequestType7;
      }
    });
    Object.defineProperty(exports, "RequestType8", {
      enumerable: true,
      get: function() {
        return messages_1.RequestType8;
      }
    });
    Object.defineProperty(exports, "RequestType9", {
      enumerable: true,
      get: function() {
        return messages_1.RequestType9;
      }
    });
    Object.defineProperty(exports, "ResponseError", {
      enumerable: true,
      get: function() {
        return messages_1.ResponseError;
      }
    });
    Object.defineProperty(exports, "ErrorCodes", {
      enumerable: true,
      get: function() {
        return messages_1.ErrorCodes;
      }
    });
    Object.defineProperty(exports, "NotificationType", {
      enumerable: true,
      get: function() {
        return messages_1.NotificationType;
      }
    });
    Object.defineProperty(exports, "NotificationType0", {
      enumerable: true,
      get: function() {
        return messages_1.NotificationType0;
      }
    });
    Object.defineProperty(exports, "NotificationType1", {
      enumerable: true,
      get: function() {
        return messages_1.NotificationType1;
      }
    });
    Object.defineProperty(exports, "NotificationType2", {
      enumerable: true,
      get: function() {
        return messages_1.NotificationType2;
      }
    });
    Object.defineProperty(exports, "NotificationType3", {
      enumerable: true,
      get: function() {
        return messages_1.NotificationType3;
      }
    });
    Object.defineProperty(exports, "NotificationType4", {
      enumerable: true,
      get: function() {
        return messages_1.NotificationType4;
      }
    });
    Object.defineProperty(exports, "NotificationType5", {
      enumerable: true,
      get: function() {
        return messages_1.NotificationType5;
      }
    });
    Object.defineProperty(exports, "NotificationType6", {
      enumerable: true,
      get: function() {
        return messages_1.NotificationType6;
      }
    });
    Object.defineProperty(exports, "NotificationType7", {
      enumerable: true,
      get: function() {
        return messages_1.NotificationType7;
      }
    });
    Object.defineProperty(exports, "NotificationType8", {
      enumerable: true,
      get: function() {
        return messages_1.NotificationType8;
      }
    });
    Object.defineProperty(exports, "NotificationType9", {
      enumerable: true,
      get: function() {
        return messages_1.NotificationType9;
      }
    });
    Object.defineProperty(exports, "ParameterStructures", {
      enumerable: true,
      get: function() {
        return messages_1.ParameterStructures;
      }
    });
    const linkedMap_1 = requireLinkedMap();
    Object.defineProperty(exports, "LinkedMap", {
      enumerable: true,
      get: function() {
        return linkedMap_1.LinkedMap;
      }
    });
    Object.defineProperty(exports, "LRUCache", {
      enumerable: true,
      get: function() {
        return linkedMap_1.LRUCache;
      }
    });
    Object.defineProperty(exports, "Touch", {
      enumerable: true,
      get: function() {
        return linkedMap_1.Touch;
      }
    });
    const disposable_1 = requireDisposable();
    Object.defineProperty(exports, "Disposable", {
      enumerable: true,
      get: function() {
        return disposable_1.Disposable;
      }
    });
    const events_1 = requireEvents();
    Object.defineProperty(exports, "Event", {
      enumerable: true,
      get: function() {
        return events_1.Event;
      }
    });
    Object.defineProperty(exports, "Emitter", {
      enumerable: true,
      get: function() {
        return events_1.Emitter;
      }
    });
    const cancellation_1 = requireCancellation();
    Object.defineProperty(exports, "CancellationTokenSource", {
      enumerable: true,
      get: function() {
        return cancellation_1.CancellationTokenSource;
      }
    });
    Object.defineProperty(exports, "CancellationToken", {
      enumerable: true,
      get: function() {
        return cancellation_1.CancellationToken;
      }
    });
    const sharedArrayCancellation_1 = requireSharedArrayCancellation();
    Object.defineProperty(exports, "SharedArraySenderStrategy", {
      enumerable: true,
      get: function() {
        return sharedArrayCancellation_1.SharedArraySenderStrategy;
      }
    });
    Object.defineProperty(exports, "SharedArrayReceiverStrategy", {
      enumerable: true,
      get: function() {
        return sharedArrayCancellation_1.SharedArrayReceiverStrategy;
      }
    });
    const messageReader_1 = requireMessageReader();
    Object.defineProperty(exports, "MessageReader", {
      enumerable: true,
      get: function() {
        return messageReader_1.MessageReader;
      }
    });
    Object.defineProperty(exports, "AbstractMessageReader", {
      enumerable: true,
      get: function() {
        return messageReader_1.AbstractMessageReader;
      }
    });
    Object.defineProperty(exports, "ReadableStreamMessageReader", {
      enumerable: true,
      get: function() {
        return messageReader_1.ReadableStreamMessageReader;
      }
    });
    const messageWriter_1 = requireMessageWriter();
    Object.defineProperty(exports, "MessageWriter", {
      enumerable: true,
      get: function() {
        return messageWriter_1.MessageWriter;
      }
    });
    Object.defineProperty(exports, "AbstractMessageWriter", {
      enumerable: true,
      get: function() {
        return messageWriter_1.AbstractMessageWriter;
      }
    });
    Object.defineProperty(exports, "WriteableStreamMessageWriter", {
      enumerable: true,
      get: function() {
        return messageWriter_1.WriteableStreamMessageWriter;
      }
    });
    const messageBuffer_1 = requireMessageBuffer();
    Object.defineProperty(exports, "AbstractMessageBuffer", {
      enumerable: true,
      get: function() {
        return messageBuffer_1.AbstractMessageBuffer;
      }
    });
    const connection_1 = requireConnection$1();
    Object.defineProperty(exports, "ConnectionStrategy", {
      enumerable: true,
      get: function() {
        return connection_1.ConnectionStrategy;
      }
    });
    Object.defineProperty(exports, "ConnectionOptions", {
      enumerable: true,
      get: function() {
        return connection_1.ConnectionOptions;
      }
    });
    Object.defineProperty(exports, "NullLogger", {
      enumerable: true,
      get: function() {
        return connection_1.NullLogger;
      }
    });
    Object.defineProperty(exports, "createMessageConnection", {
      enumerable: true,
      get: function() {
        return connection_1.createMessageConnection;
      }
    });
    Object.defineProperty(exports, "ProgressToken", {
      enumerable: true,
      get: function() {
        return connection_1.ProgressToken;
      }
    });
    Object.defineProperty(exports, "ProgressType", {
      enumerable: true,
      get: function() {
        return connection_1.ProgressType;
      }
    });
    Object.defineProperty(exports, "Trace", {
      enumerable: true,
      get: function() {
        return connection_1.Trace;
      }
    });
    Object.defineProperty(exports, "TraceValues", {
      enumerable: true,
      get: function() {
        return connection_1.TraceValues;
      }
    });
    Object.defineProperty(exports, "TraceFormat", {
      enumerable: true,
      get: function() {
        return connection_1.TraceFormat;
      }
    });
    Object.defineProperty(exports, "SetTraceNotification", {
      enumerable: true,
      get: function() {
        return connection_1.SetTraceNotification;
      }
    });
    Object.defineProperty(exports, "LogTraceNotification", {
      enumerable: true,
      get: function() {
        return connection_1.LogTraceNotification;
      }
    });
    Object.defineProperty(exports, "ConnectionErrors", {
      enumerable: true,
      get: function() {
        return connection_1.ConnectionErrors;
      }
    });
    Object.defineProperty(exports, "ConnectionError", {
      enumerable: true,
      get: function() {
        return connection_1.ConnectionError;
      }
    });
    Object.defineProperty(exports, "CancellationReceiverStrategy", {
      enumerable: true,
      get: function() {
        return connection_1.CancellationReceiverStrategy;
      }
    });
    Object.defineProperty(exports, "CancellationSenderStrategy", {
      enumerable: true,
      get: function() {
        return connection_1.CancellationSenderStrategy;
      }
    });
    Object.defineProperty(exports, "CancellationStrategy", {
      enumerable: true,
      get: function() {
        return connection_1.CancellationStrategy;
      }
    });
    Object.defineProperty(exports, "MessageStrategy", {
      enumerable: true,
      get: function() {
        return connection_1.MessageStrategy;
      }
    });
    const ral_1 = requireRal();
    exports.RAL = ral_1.default;
  })(api$2);
  return api$2;
}
var hasRequiredRil;
function requireRil() {
  if (hasRequiredRil) return ril;
  hasRequiredRil = 1;
  Object.defineProperty(ril, "__esModule", {
    value: true
  });
  const util_1 = require$$0$1;
  const api_1 = requireApi$2();
  class MessageBuffer extends api_1.AbstractMessageBuffer {
    constructor(encoding = "utf-8") {
      super(encoding);
    }
    emptyBuffer() {
      return MessageBuffer.emptyBuffer;
    }
    fromString(value, encoding) {
      return Buffer.from(value, encoding);
    }
    toString(value, encoding) {
      if (value instanceof Buffer) {
        return value.toString(encoding);
      } else {
        return new util_1.TextDecoder(encoding).decode(value);
      }
    }
    asNative(buffer2, length) {
      if (length === void 0) {
        return buffer2 instanceof Buffer ? buffer2 : Buffer.from(buffer2);
      } else {
        return buffer2 instanceof Buffer ? buffer2.slice(0, length) : Buffer.from(buffer2, 0, length);
      }
    }
    allocNative(length) {
      return Buffer.allocUnsafe(length);
    }
  }
  MessageBuffer.emptyBuffer = Buffer.allocUnsafe(0);
  class ReadableStreamWrapper {
    constructor(stream2) {
      this.stream = stream2;
    }
    onClose(listener) {
      this.stream.on("close", listener);
      return api_1.Disposable.create(() => this.stream.off("close", listener));
    }
    onError(listener) {
      this.stream.on("error", listener);
      return api_1.Disposable.create(() => this.stream.off("error", listener));
    }
    onEnd(listener) {
      this.stream.on("end", listener);
      return api_1.Disposable.create(() => this.stream.off("end", listener));
    }
    onData(listener) {
      this.stream.on("data", listener);
      return api_1.Disposable.create(() => this.stream.off("data", listener));
    }
  }
  class WritableStreamWrapper {
    constructor(stream2) {
      this.stream = stream2;
    }
    onClose(listener) {
      this.stream.on("close", listener);
      return api_1.Disposable.create(() => this.stream.off("close", listener));
    }
    onError(listener) {
      this.stream.on("error", listener);
      return api_1.Disposable.create(() => this.stream.off("error", listener));
    }
    onEnd(listener) {
      this.stream.on("end", listener);
      return api_1.Disposable.create(() => this.stream.off("end", listener));
    }
    write(data, encoding) {
      return new Promise((resolve2, reject) => {
        const callback = (error2) => {
          if (error2 === void 0 || error2 === null) {
            resolve2();
          } else {
            reject(error2);
          }
        };
        if (typeof data === "string") {
          this.stream.write(data, encoding, callback);
        } else {
          this.stream.write(data, callback);
        }
      });
    }
    end() {
      this.stream.end();
    }
  }
  const _ril = Object.freeze({
    messageBuffer: Object.freeze({
      create: (encoding) => new MessageBuffer(encoding)
    }),
    applicationJson: Object.freeze({
      encoder: Object.freeze({
        name: "application/json",
        encode: (msg, options2) => {
          try {
            return Promise.resolve(Buffer.from(JSON.stringify(msg, void 0, 0), options2.charset));
          } catch (err) {
            return Promise.reject(err);
          }
        }
      }),
      decoder: Object.freeze({
        name: "application/json",
        decode: (buffer2, options2) => {
          try {
            if (buffer2 instanceof Buffer) {
              return Promise.resolve(JSON.parse(buffer2.toString(options2.charset)));
            } else {
              return Promise.resolve(JSON.parse(new util_1.TextDecoder(options2.charset).decode(buffer2)));
            }
          } catch (err) {
            return Promise.reject(err);
          }
        }
      })
    }),
    stream: Object.freeze({
      asReadableStream: (stream2) => new ReadableStreamWrapper(stream2),
      asWritableStream: (stream2) => new WritableStreamWrapper(stream2)
    }),
    console,
    timer: Object.freeze({
      setTimeout(callback, ms, ...args) {
        const handle = setTimeout(callback, ms, ...args);
        return {
          dispose: () => clearTimeout(handle)
        };
      },
      setImmediate(callback, ...args) {
        const handle = setImmediate(callback, ...args);
        return {
          dispose: () => clearImmediate(handle)
        };
      },
      setInterval(callback, ms, ...args) {
        const handle = setInterval(callback, ms, ...args);
        return {
          dispose: () => clearInterval(handle)
        };
      }
    })
  });
  function RIL() {
    return _ril;
  }
  (function(RIL2) {
    function install() {
      api_1.RAL.install(_ril);
    }
    RIL2.install = install;
  })(RIL || (RIL = {}));
  ril.default = RIL;
  return ril;
}
var hasRequiredMain$3;
function requireMain$3() {
  if (hasRequiredMain$3) return main$1;
  hasRequiredMain$3 = 1;
  (function(exports) {
    var __createBinding = main$1 && main$1.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
          enumerable: true,
          get: function() {
            return m[k];
          }
        };
      }
      Object.defineProperty(o, k2, desc);
    } : function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = main$1 && main$1.__exportStar || function(m, exports2) {
      for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports2, p)) __createBinding(exports2, m, p);
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.createMessageConnection = exports.createServerSocketTransport = exports.createClientSocketTransport = exports.createServerPipeTransport = exports.createClientPipeTransport = exports.generateRandomPipeName = exports.StreamMessageWriter = exports.StreamMessageReader = exports.SocketMessageWriter = exports.SocketMessageReader = exports.PortMessageWriter = exports.PortMessageReader = exports.IPCMessageWriter = exports.IPCMessageReader = void 0;
    const ril_1 = requireRil();
    ril_1.default.install();
    const path2 = require$$1$1;
    const os2 = require$$2;
    const crypto_1 = crypto;
    const net_1 = require$$4;
    const api_1 = requireApi$2();
    __exportStar(requireApi$2(), exports);
    class IPCMessageReader extends api_1.AbstractMessageReader {
      constructor(process2) {
        super();
        this.process = process2;
        let eventEmitter = this.process;
        eventEmitter.on("error", (error2) => this.fireError(error2));
        eventEmitter.on("close", () => this.fireClose());
      }
      listen(callback) {
        this.process.on("message", callback);
        return api_1.Disposable.create(() => this.process.off("message", callback));
      }
    }
    exports.IPCMessageReader = IPCMessageReader;
    class IPCMessageWriter extends api_1.AbstractMessageWriter {
      constructor(process2) {
        super();
        this.process = process2;
        this.errorCount = 0;
        const eventEmitter = this.process;
        eventEmitter.on("error", (error2) => this.fireError(error2));
        eventEmitter.on("close", () => this.fireClose);
      }
      write(msg) {
        try {
          if (typeof this.process.send === "function") {
            this.process.send(msg, void 0, void 0, (error2) => {
              if (error2) {
                this.errorCount++;
                this.handleError(error2, msg);
              } else {
                this.errorCount = 0;
              }
            });
          }
          return Promise.resolve();
        } catch (error2) {
          this.handleError(error2, msg);
          return Promise.reject(error2);
        }
      }
      handleError(error2, msg) {
        this.errorCount++;
        this.fireError(error2, msg, this.errorCount);
      }
      end() {
      }
    }
    exports.IPCMessageWriter = IPCMessageWriter;
    class PortMessageReader extends api_1.AbstractMessageReader {
      constructor(port) {
        super();
        this.onData = new api_1.Emitter();
        port.on("close", () => this.fireClose);
        port.on("error", (error2) => this.fireError(error2));
        port.on("message", (message) => {
          this.onData.fire(message);
        });
      }
      listen(callback) {
        return this.onData.event(callback);
      }
    }
    exports.PortMessageReader = PortMessageReader;
    class PortMessageWriter extends api_1.AbstractMessageWriter {
      constructor(port) {
        super();
        this.port = port;
        this.errorCount = 0;
        port.on("close", () => this.fireClose());
        port.on("error", (error2) => this.fireError(error2));
      }
      write(msg) {
        try {
          this.port.postMessage(msg);
          return Promise.resolve();
        } catch (error2) {
          this.handleError(error2, msg);
          return Promise.reject(error2);
        }
      }
      handleError(error2, msg) {
        this.errorCount++;
        this.fireError(error2, msg, this.errorCount);
      }
      end() {
      }
    }
    exports.PortMessageWriter = PortMessageWriter;
    class SocketMessageReader extends api_1.ReadableStreamMessageReader {
      constructor(socket, encoding = "utf-8") {
        super((0, ril_1.default)().stream.asReadableStream(socket), encoding);
      }
    }
    exports.SocketMessageReader = SocketMessageReader;
    class SocketMessageWriter extends api_1.WriteableStreamMessageWriter {
      constructor(socket, options2) {
        super((0, ril_1.default)().stream.asWritableStream(socket), options2);
        this.socket = socket;
      }
      dispose() {
        super.dispose();
        this.socket.destroy();
      }
    }
    exports.SocketMessageWriter = SocketMessageWriter;
    class StreamMessageReader extends api_1.ReadableStreamMessageReader {
      constructor(readable, encoding) {
        super((0, ril_1.default)().stream.asReadableStream(readable), encoding);
      }
    }
    exports.StreamMessageReader = StreamMessageReader;
    class StreamMessageWriter extends api_1.WriteableStreamMessageWriter {
      constructor(writable, options2) {
        super((0, ril_1.default)().stream.asWritableStream(writable), options2);
      }
    }
    exports.StreamMessageWriter = StreamMessageWriter;
    const XDG_RUNTIME_DIR = process.env["XDG_RUNTIME_DIR"];
    const safeIpcPathLengths = /* @__PURE__ */ new Map([["linux", 107], ["darwin", 103]]);
    function generateRandomPipeName() {
      const randomSuffix = (0, crypto_1.randomBytes)(21).toString("hex");
      if (process.platform === "win32") {
        return `\\\\.\\pipe\\vscode-jsonrpc-${randomSuffix}-sock`;
      }
      let result;
      if (XDG_RUNTIME_DIR) {
        result = path2.join(XDG_RUNTIME_DIR, `vscode-ipc-${randomSuffix}.sock`);
      } else {
        result = path2.join(os2.tmpdir(), `vscode-${randomSuffix}.sock`);
      }
      const limit = safeIpcPathLengths.get(process.platform);
      if (limit !== void 0 && result.length > limit) {
        (0, ril_1.default)().console.warn(`WARNING: IPC handle "${result}" is longer than ${limit} characters.`);
      }
      return result;
    }
    exports.generateRandomPipeName = generateRandomPipeName;
    function createClientPipeTransport(pipeName, encoding = "utf-8") {
      let connectResolve;
      const connected = new Promise((resolve2, _reject) => {
        connectResolve = resolve2;
      });
      return new Promise((resolve2, reject) => {
        let server2 = (0, net_1.createServer)((socket) => {
          server2.close();
          connectResolve([new SocketMessageReader(socket, encoding), new SocketMessageWriter(socket, encoding)]);
        });
        server2.on("error", reject);
        server2.listen(pipeName, () => {
          server2.removeListener("error", reject);
          resolve2({
            onConnected: () => connected
          });
        });
      });
    }
    exports.createClientPipeTransport = createClientPipeTransport;
    function createServerPipeTransport(pipeName, encoding = "utf-8") {
      const socket = (0, net_1.createConnection)(pipeName);
      return [new SocketMessageReader(socket, encoding), new SocketMessageWriter(socket, encoding)];
    }
    exports.createServerPipeTransport = createServerPipeTransport;
    function createClientSocketTransport(port, encoding = "utf-8") {
      let connectResolve;
      const connected = new Promise((resolve2, _reject) => {
        connectResolve = resolve2;
      });
      return new Promise((resolve2, reject) => {
        const server2 = (0, net_1.createServer)((socket) => {
          server2.close();
          connectResolve([new SocketMessageReader(socket, encoding), new SocketMessageWriter(socket, encoding)]);
        });
        server2.on("error", reject);
        server2.listen(port, "127.0.0.1", () => {
          server2.removeListener("error", reject);
          resolve2({
            onConnected: () => connected
          });
        });
      });
    }
    exports.createClientSocketTransport = createClientSocketTransport;
    function createServerSocketTransport(port, encoding = "utf-8") {
      const socket = (0, net_1.createConnection)(port, "127.0.0.1");
      return [new SocketMessageReader(socket, encoding), new SocketMessageWriter(socket, encoding)];
    }
    exports.createServerSocketTransport = createServerSocketTransport;
    function isReadableStream(value) {
      const candidate = value;
      return candidate.read !== void 0 && candidate.addListener !== void 0;
    }
    function isWritableStream(value) {
      const candidate = value;
      return candidate.write !== void 0 && candidate.addListener !== void 0;
    }
    function createMessageConnection(input, output, logger, options2) {
      if (!logger) {
        logger = api_1.NullLogger;
      }
      const reader = isReadableStream(input) ? new StreamMessageReader(input) : input;
      const writer = isWritableStream(output) ? new StreamMessageWriter(output) : output;
      if (api_1.ConnectionStrategy.is(options2)) {
        options2 = {
          connectionStrategy: options2
        };
      }
      return (0, api_1.createMessageConnection)(reader, writer, logger, options2);
    }
    exports.createMessageConnection = createMessageConnection;
  })(main$1);
  return main$1;
}
var node$2;
var hasRequiredNode$2;
function requireNode$2() {
  if (hasRequiredNode$2) return node$2;
  hasRequiredNode$2 = 1;
  node$2 = requireMain$3();
  return node$2;
}
var api$1 = {};
function commonjsRequire(path2) {
  throw new Error('Could not dynamically require "' + path2 + '". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.');
}
var main = {
  exports: {}
};
var hasRequiredMain$2;
function requireMain$2() {
  if (hasRequiredMain$2) return main.exports;
  hasRequiredMain$2 = 1;
  (function(module, exports) {
    (function(factory) {
      {
        var v = factory(commonjsRequire, exports);
        if (v !== void 0) module.exports = v;
      }
    })(function(require2, exports2) {
      Object.defineProperty(exports2, "__esModule", {
        value: true
      });
      exports2.TextDocument = exports2.EOL = exports2.WorkspaceFolder = exports2.InlineCompletionContext = exports2.SelectedCompletionInfo = exports2.InlineCompletionTriggerKind = exports2.InlineCompletionList = exports2.InlineCompletionItem = exports2.StringValue = exports2.InlayHint = exports2.InlayHintLabelPart = exports2.InlayHintKind = exports2.InlineValueContext = exports2.InlineValueEvaluatableExpression = exports2.InlineValueVariableLookup = exports2.InlineValueText = exports2.SemanticTokens = exports2.SemanticTokenModifiers = exports2.SemanticTokenTypes = exports2.SelectionRange = exports2.DocumentLink = exports2.FormattingOptions = exports2.CodeLens = exports2.CodeAction = exports2.CodeActionContext = exports2.CodeActionTriggerKind = exports2.CodeActionKind = exports2.DocumentSymbol = exports2.WorkspaceSymbol = exports2.SymbolInformation = exports2.SymbolTag = exports2.SymbolKind = exports2.DocumentHighlight = exports2.DocumentHighlightKind = exports2.SignatureInformation = exports2.ParameterInformation = exports2.Hover = exports2.MarkedString = exports2.CompletionList = exports2.CompletionItem = exports2.CompletionItemLabelDetails = exports2.InsertTextMode = exports2.InsertReplaceEdit = exports2.CompletionItemTag = exports2.InsertTextFormat = exports2.CompletionItemKind = exports2.MarkupContent = exports2.MarkupKind = exports2.TextDocumentItem = exports2.OptionalVersionedTextDocumentIdentifier = exports2.VersionedTextDocumentIdentifier = exports2.TextDocumentIdentifier = exports2.WorkspaceChange = exports2.WorkspaceEdit = exports2.DeleteFile = exports2.RenameFile = exports2.CreateFile = exports2.TextDocumentEdit = exports2.AnnotatedTextEdit = exports2.ChangeAnnotationIdentifier = exports2.ChangeAnnotation = exports2.TextEdit = exports2.Command = exports2.Diagnostic = exports2.CodeDescription = exports2.DiagnosticTag = exports2.DiagnosticSeverity = exports2.DiagnosticRelatedInformation = exports2.FoldingRange = exports2.FoldingRangeKind = exports2.ColorPresentation = exports2.ColorInformation = exports2.Color = exports2.LocationLink = exports2.Location = exports2.Range = exports2.Position = exports2.uinteger = exports2.integer = exports2.URI = exports2.DocumentUri = void 0;
      var DocumentUri;
      (function(DocumentUri2) {
        function is2(value) {
          return typeof value === "string";
        }
        DocumentUri2.is = is2;
      })(DocumentUri || (exports2.DocumentUri = DocumentUri = {}));
      var URI2;
      (function(URI3) {
        function is2(value) {
          return typeof value === "string";
        }
        URI3.is = is2;
      })(URI2 || (exports2.URI = URI2 = {}));
      var integer;
      (function(integer2) {
        integer2.MIN_VALUE = -2147483648;
        integer2.MAX_VALUE = 2147483647;
        function is2(value) {
          return typeof value === "number" && integer2.MIN_VALUE <= value && value <= integer2.MAX_VALUE;
        }
        integer2.is = is2;
      })(integer || (exports2.integer = integer = {}));
      var uinteger;
      (function(uinteger2) {
        uinteger2.MIN_VALUE = 0;
        uinteger2.MAX_VALUE = 2147483647;
        function is2(value) {
          return typeof value === "number" && uinteger2.MIN_VALUE <= value && value <= uinteger2.MAX_VALUE;
        }
        uinteger2.is = is2;
      })(uinteger || (exports2.uinteger = uinteger = {}));
      var Position2;
      (function(Position3) {
        function create(line, character) {
          if (line === Number.MAX_VALUE) {
            line = uinteger.MAX_VALUE;
          }
          if (character === Number.MAX_VALUE) {
            character = uinteger.MAX_VALUE;
          }
          return {
            line,
            character
          };
        }
        Position3.create = create;
        function is2(value) {
          var candidate = value;
          return Is.objectLiteral(candidate) && Is.uinteger(candidate.line) && Is.uinteger(candidate.character);
        }
        Position3.is = is2;
      })(Position2 || (exports2.Position = Position2 = {}));
      var Range2;
      (function(Range3) {
        function create(one, two, three, four) {
          if (Is.uinteger(one) && Is.uinteger(two) && Is.uinteger(three) && Is.uinteger(four)) {
            return {
              start: Position2.create(one, two),
              end: Position2.create(three, four)
            };
          } else if (Position2.is(one) && Position2.is(two)) {
            return {
              start: one,
              end: two
            };
          } else {
            throw new Error("Range#create called with invalid arguments[".concat(one, ", ").concat(two, ", ").concat(three, ", ").concat(four, "]"));
          }
        }
        Range3.create = create;
        function is2(value) {
          var candidate = value;
          return Is.objectLiteral(candidate) && Position2.is(candidate.start) && Position2.is(candidate.end);
        }
        Range3.is = is2;
      })(Range2 || (exports2.Range = Range2 = {}));
      var Location2;
      (function(Location3) {
        function create(uri, range2) {
          return {
            uri,
            range: range2
          };
        }
        Location3.create = create;
        function is2(value) {
          var candidate = value;
          return Is.objectLiteral(candidate) && Range2.is(candidate.range) && (Is.string(candidate.uri) || Is.undefined(candidate.uri));
        }
        Location3.is = is2;
      })(Location2 || (exports2.Location = Location2 = {}));
      var LocationLink;
      (function(LocationLink2) {
        function create(targetUri, targetRange, targetSelectionRange, originSelectionRange) {
          return {
            targetUri,
            targetRange,
            targetSelectionRange,
            originSelectionRange
          };
        }
        LocationLink2.create = create;
        function is2(value) {
          var candidate = value;
          return Is.objectLiteral(candidate) && Range2.is(candidate.targetRange) && Is.string(candidate.targetUri) && Range2.is(candidate.targetSelectionRange) && (Range2.is(candidate.originSelectionRange) || Is.undefined(candidate.originSelectionRange));
        }
        LocationLink2.is = is2;
      })(LocationLink || (exports2.LocationLink = LocationLink = {}));
      var Color;
      (function(Color2) {
        function create(red, green, blue, alpha) {
          return {
            red,
            green,
            blue,
            alpha
          };
        }
        Color2.create = create;
        function is2(value) {
          var candidate = value;
          return Is.objectLiteral(candidate) && Is.numberRange(candidate.red, 0, 1) && Is.numberRange(candidate.green, 0, 1) && Is.numberRange(candidate.blue, 0, 1) && Is.numberRange(candidate.alpha, 0, 1);
        }
        Color2.is = is2;
      })(Color || (exports2.Color = Color = {}));
      var ColorInformation;
      (function(ColorInformation2) {
        function create(range2, color) {
          return {
            range: range2,
            color
          };
        }
        ColorInformation2.create = create;
        function is2(value) {
          var candidate = value;
          return Is.objectLiteral(candidate) && Range2.is(candidate.range) && Color.is(candidate.color);
        }
        ColorInformation2.is = is2;
      })(ColorInformation || (exports2.ColorInformation = ColorInformation = {}));
      var ColorPresentation;
      (function(ColorPresentation2) {
        function create(label, textEdit, additionalTextEdits) {
          return {
            label,
            textEdit,
            additionalTextEdits
          };
        }
        ColorPresentation2.create = create;
        function is2(value) {
          var candidate = value;
          return Is.objectLiteral(candidate) && Is.string(candidate.label) && (Is.undefined(candidate.textEdit) || TextEdit.is(candidate)) && (Is.undefined(candidate.additionalTextEdits) || Is.typedArray(candidate.additionalTextEdits, TextEdit.is));
        }
        ColorPresentation2.is = is2;
      })(ColorPresentation || (exports2.ColorPresentation = ColorPresentation = {}));
      var FoldingRangeKind;
      (function(FoldingRangeKind2) {
        FoldingRangeKind2.Comment = "comment";
        FoldingRangeKind2.Imports = "imports";
        FoldingRangeKind2.Region = "region";
      })(FoldingRangeKind || (exports2.FoldingRangeKind = FoldingRangeKind = {}));
      var FoldingRange;
      (function(FoldingRange2) {
        function create(startLine, endLine, startCharacter, endCharacter, kind, collapsedText) {
          var result = {
            startLine,
            endLine
          };
          if (Is.defined(startCharacter)) {
            result.startCharacter = startCharacter;
          }
          if (Is.defined(endCharacter)) {
            result.endCharacter = endCharacter;
          }
          if (Is.defined(kind)) {
            result.kind = kind;
          }
          if (Is.defined(collapsedText)) {
            result.collapsedText = collapsedText;
          }
          return result;
        }
        FoldingRange2.create = create;
        function is2(value) {
          var candidate = value;
          return Is.objectLiteral(candidate) && Is.uinteger(candidate.startLine) && Is.uinteger(candidate.startLine) && (Is.undefined(candidate.startCharacter) || Is.uinteger(candidate.startCharacter)) && (Is.undefined(candidate.endCharacter) || Is.uinteger(candidate.endCharacter)) && (Is.undefined(candidate.kind) || Is.string(candidate.kind));
        }
        FoldingRange2.is = is2;
      })(FoldingRange || (exports2.FoldingRange = FoldingRange = {}));
      var DiagnosticRelatedInformation;
      (function(DiagnosticRelatedInformation2) {
        function create(location, message) {
          return {
            location,
            message
          };
        }
        DiagnosticRelatedInformation2.create = create;
        function is2(value) {
          var candidate = value;
          return Is.defined(candidate) && Location2.is(candidate.location) && Is.string(candidate.message);
        }
        DiagnosticRelatedInformation2.is = is2;
      })(DiagnosticRelatedInformation || (exports2.DiagnosticRelatedInformation = DiagnosticRelatedInformation = {}));
      var DiagnosticSeverity;
      (function(DiagnosticSeverity2) {
        DiagnosticSeverity2.Error = 1;
        DiagnosticSeverity2.Warning = 2;
        DiagnosticSeverity2.Information = 3;
        DiagnosticSeverity2.Hint = 4;
      })(DiagnosticSeverity || (exports2.DiagnosticSeverity = DiagnosticSeverity = {}));
      var DiagnosticTag;
      (function(DiagnosticTag2) {
        DiagnosticTag2.Unnecessary = 1;
        DiagnosticTag2.Deprecated = 2;
      })(DiagnosticTag || (exports2.DiagnosticTag = DiagnosticTag = {}));
      var CodeDescription;
      (function(CodeDescription2) {
        function is2(value) {
          var candidate = value;
          return Is.objectLiteral(candidate) && Is.string(candidate.href);
        }
        CodeDescription2.is = is2;
      })(CodeDescription || (exports2.CodeDescription = CodeDescription = {}));
      var Diagnostic;
      (function(Diagnostic2) {
        function create(range2, message, severity, code, source, relatedInformation) {
          var result = {
            range: range2,
            message
          };
          if (Is.defined(severity)) {
            result.severity = severity;
          }
          if (Is.defined(code)) {
            result.code = code;
          }
          if (Is.defined(source)) {
            result.source = source;
          }
          if (Is.defined(relatedInformation)) {
            result.relatedInformation = relatedInformation;
          }
          return result;
        }
        Diagnostic2.create = create;
        function is2(value) {
          var _a;
          var candidate = value;
          return Is.defined(candidate) && Range2.is(candidate.range) && Is.string(candidate.message) && (Is.number(candidate.severity) || Is.undefined(candidate.severity)) && (Is.integer(candidate.code) || Is.string(candidate.code) || Is.undefined(candidate.code)) && (Is.undefined(candidate.codeDescription) || Is.string((_a = candidate.codeDescription) === null || _a === void 0 ? void 0 : _a.href)) && (Is.string(candidate.source) || Is.undefined(candidate.source)) && (Is.undefined(candidate.relatedInformation) || Is.typedArray(candidate.relatedInformation, DiagnosticRelatedInformation.is));
        }
        Diagnostic2.is = is2;
      })(Diagnostic || (exports2.Diagnostic = Diagnostic = {}));
      var Command2;
      (function(Command3) {
        function create(title, command2) {
          var args = [];
          for (var _i = 2; _i < arguments.length; _i++) {
            args[_i - 2] = arguments[_i];
          }
          var result = {
            title,
            command: command2
          };
          if (Is.defined(args) && args.length > 0) {
            result.arguments = args;
          }
          return result;
        }
        Command3.create = create;
        function is2(value) {
          var candidate = value;
          return Is.defined(candidate) && Is.string(candidate.title) && Is.string(candidate.command);
        }
        Command3.is = is2;
      })(Command2 || (exports2.Command = Command2 = {}));
      var TextEdit;
      (function(TextEdit2) {
        function replace(range2, newText) {
          return {
            range: range2,
            newText
          };
        }
        TextEdit2.replace = replace;
        function insert(position, newText) {
          return {
            range: {
              start: position,
              end: position
            },
            newText
          };
        }
        TextEdit2.insert = insert;
        function del(range2) {
          return {
            range: range2,
            newText: ""
          };
        }
        TextEdit2.del = del;
        function is2(value) {
          var candidate = value;
          return Is.objectLiteral(candidate) && Is.string(candidate.newText) && Range2.is(candidate.range);
        }
        TextEdit2.is = is2;
      })(TextEdit || (exports2.TextEdit = TextEdit = {}));
      var ChangeAnnotation;
      (function(ChangeAnnotation2) {
        function create(label, needsConfirmation, description) {
          var result = {
            label
          };
          if (needsConfirmation !== void 0) {
            result.needsConfirmation = needsConfirmation;
          }
          if (description !== void 0) {
            result.description = description;
          }
          return result;
        }
        ChangeAnnotation2.create = create;
        function is2(value) {
          var candidate = value;
          return Is.objectLiteral(candidate) && Is.string(candidate.label) && (Is.boolean(candidate.needsConfirmation) || candidate.needsConfirmation === void 0) && (Is.string(candidate.description) || candidate.description === void 0);
        }
        ChangeAnnotation2.is = is2;
      })(ChangeAnnotation || (exports2.ChangeAnnotation = ChangeAnnotation = {}));
      var ChangeAnnotationIdentifier;
      (function(ChangeAnnotationIdentifier2) {
        function is2(value) {
          var candidate = value;
          return Is.string(candidate);
        }
        ChangeAnnotationIdentifier2.is = is2;
      })(ChangeAnnotationIdentifier || (exports2.ChangeAnnotationIdentifier = ChangeAnnotationIdentifier = {}));
      var AnnotatedTextEdit;
      (function(AnnotatedTextEdit2) {
        function replace(range2, newText, annotation) {
          return {
            range: range2,
            newText,
            annotationId: annotation
          };
        }
        AnnotatedTextEdit2.replace = replace;
        function insert(position, newText, annotation) {
          return {
            range: {
              start: position,
              end: position
            },
            newText,
            annotationId: annotation
          };
        }
        AnnotatedTextEdit2.insert = insert;
        function del(range2, annotation) {
          return {
            range: range2,
            newText: "",
            annotationId: annotation
          };
        }
        AnnotatedTextEdit2.del = del;
        function is2(value) {
          var candidate = value;
          return TextEdit.is(candidate) && (ChangeAnnotation.is(candidate.annotationId) || ChangeAnnotationIdentifier.is(candidate.annotationId));
        }
        AnnotatedTextEdit2.is = is2;
      })(AnnotatedTextEdit || (exports2.AnnotatedTextEdit = AnnotatedTextEdit = {}));
      var TextDocumentEdit;
      (function(TextDocumentEdit2) {
        function create(textDocument, edits) {
          return {
            textDocument,
            edits
          };
        }
        TextDocumentEdit2.create = create;
        function is2(value) {
          var candidate = value;
          return Is.defined(candidate) && OptionalVersionedTextDocumentIdentifier.is(candidate.textDocument) && Array.isArray(candidate.edits);
        }
        TextDocumentEdit2.is = is2;
      })(TextDocumentEdit || (exports2.TextDocumentEdit = TextDocumentEdit = {}));
      var CreateFile;
      (function(CreateFile2) {
        function create(uri, options2, annotation) {
          var result = {
            kind: "create",
            uri
          };
          if (options2 !== void 0 && (options2.overwrite !== void 0 || options2.ignoreIfExists !== void 0)) {
            result.options = options2;
          }
          if (annotation !== void 0) {
            result.annotationId = annotation;
          }
          return result;
        }
        CreateFile2.create = create;
        function is2(value) {
          var candidate = value;
          return candidate && candidate.kind === "create" && Is.string(candidate.uri) && (candidate.options === void 0 || (candidate.options.overwrite === void 0 || Is.boolean(candidate.options.overwrite)) && (candidate.options.ignoreIfExists === void 0 || Is.boolean(candidate.options.ignoreIfExists))) && (candidate.annotationId === void 0 || ChangeAnnotationIdentifier.is(candidate.annotationId));
        }
        CreateFile2.is = is2;
      })(CreateFile || (exports2.CreateFile = CreateFile = {}));
      var RenameFile;
      (function(RenameFile2) {
        function create(oldUri, newUri, options2, annotation) {
          var result = {
            kind: "rename",
            oldUri,
            newUri
          };
          if (options2 !== void 0 && (options2.overwrite !== void 0 || options2.ignoreIfExists !== void 0)) {
            result.options = options2;
          }
          if (annotation !== void 0) {
            result.annotationId = annotation;
          }
          return result;
        }
        RenameFile2.create = create;
        function is2(value) {
          var candidate = value;
          return candidate && candidate.kind === "rename" && Is.string(candidate.oldUri) && Is.string(candidate.newUri) && (candidate.options === void 0 || (candidate.options.overwrite === void 0 || Is.boolean(candidate.options.overwrite)) && (candidate.options.ignoreIfExists === void 0 || Is.boolean(candidate.options.ignoreIfExists))) && (candidate.annotationId === void 0 || ChangeAnnotationIdentifier.is(candidate.annotationId));
        }
        RenameFile2.is = is2;
      })(RenameFile || (exports2.RenameFile = RenameFile = {}));
      var DeleteFile;
      (function(DeleteFile2) {
        function create(uri, options2, annotation) {
          var result = {
            kind: "delete",
            uri
          };
          if (options2 !== void 0 && (options2.recursive !== void 0 || options2.ignoreIfNotExists !== void 0)) {
            result.options = options2;
          }
          if (annotation !== void 0) {
            result.annotationId = annotation;
          }
          return result;
        }
        DeleteFile2.create = create;
        function is2(value) {
          var candidate = value;
          return candidate && candidate.kind === "delete" && Is.string(candidate.uri) && (candidate.options === void 0 || (candidate.options.recursive === void 0 || Is.boolean(candidate.options.recursive)) && (candidate.options.ignoreIfNotExists === void 0 || Is.boolean(candidate.options.ignoreIfNotExists))) && (candidate.annotationId === void 0 || ChangeAnnotationIdentifier.is(candidate.annotationId));
        }
        DeleteFile2.is = is2;
      })(DeleteFile || (exports2.DeleteFile = DeleteFile = {}));
      var WorkspaceEdit;
      (function(WorkspaceEdit2) {
        function is2(value) {
          var candidate = value;
          return candidate && (candidate.changes !== void 0 || candidate.documentChanges !== void 0) && (candidate.documentChanges === void 0 || candidate.documentChanges.every(function(change) {
            if (Is.string(change.kind)) {
              return CreateFile.is(change) || RenameFile.is(change) || DeleteFile.is(change);
            } else {
              return TextDocumentEdit.is(change);
            }
          }));
        }
        WorkspaceEdit2.is = is2;
      })(WorkspaceEdit || (exports2.WorkspaceEdit = WorkspaceEdit = {}));
      var TextEditChangeImpl = (function() {
        function TextEditChangeImpl2(edits, changeAnnotations) {
          this.edits = edits;
          this.changeAnnotations = changeAnnotations;
        }
        TextEditChangeImpl2.prototype.insert = function(position, newText, annotation) {
          var edit;
          var id;
          if (annotation === void 0) {
            edit = TextEdit.insert(position, newText);
          } else if (ChangeAnnotationIdentifier.is(annotation)) {
            id = annotation;
            edit = AnnotatedTextEdit.insert(position, newText, annotation);
          } else {
            this.assertChangeAnnotations(this.changeAnnotations);
            id = this.changeAnnotations.manage(annotation);
            edit = AnnotatedTextEdit.insert(position, newText, id);
          }
          this.edits.push(edit);
          if (id !== void 0) {
            return id;
          }
        };
        TextEditChangeImpl2.prototype.replace = function(range2, newText, annotation) {
          var edit;
          var id;
          if (annotation === void 0) {
            edit = TextEdit.replace(range2, newText);
          } else if (ChangeAnnotationIdentifier.is(annotation)) {
            id = annotation;
            edit = AnnotatedTextEdit.replace(range2, newText, annotation);
          } else {
            this.assertChangeAnnotations(this.changeAnnotations);
            id = this.changeAnnotations.manage(annotation);
            edit = AnnotatedTextEdit.replace(range2, newText, id);
          }
          this.edits.push(edit);
          if (id !== void 0) {
            return id;
          }
        };
        TextEditChangeImpl2.prototype.delete = function(range2, annotation) {
          var edit;
          var id;
          if (annotation === void 0) {
            edit = TextEdit.del(range2);
          } else if (ChangeAnnotationIdentifier.is(annotation)) {
            id = annotation;
            edit = AnnotatedTextEdit.del(range2, annotation);
          } else {
            this.assertChangeAnnotations(this.changeAnnotations);
            id = this.changeAnnotations.manage(annotation);
            edit = AnnotatedTextEdit.del(range2, id);
          }
          this.edits.push(edit);
          if (id !== void 0) {
            return id;
          }
        };
        TextEditChangeImpl2.prototype.add = function(edit) {
          this.edits.push(edit);
        };
        TextEditChangeImpl2.prototype.all = function() {
          return this.edits;
        };
        TextEditChangeImpl2.prototype.clear = function() {
          this.edits.splice(0, this.edits.length);
        };
        TextEditChangeImpl2.prototype.assertChangeAnnotations = function(value) {
          if (value === void 0) {
            throw new Error("Text edit change is not configured to manage change annotations.");
          }
        };
        return TextEditChangeImpl2;
      })();
      var ChangeAnnotations = (function() {
        function ChangeAnnotations2(annotations) {
          this._annotations = annotations === void 0 ? /* @__PURE__ */ Object.create(null) : annotations;
          this._counter = 0;
          this._size = 0;
        }
        ChangeAnnotations2.prototype.all = function() {
          return this._annotations;
        };
        Object.defineProperty(ChangeAnnotations2.prototype, "size", {
          get: function() {
            return this._size;
          },
          enumerable: false,
          configurable: true
        });
        ChangeAnnotations2.prototype.manage = function(idOrAnnotation, annotation) {
          var id;
          if (ChangeAnnotationIdentifier.is(idOrAnnotation)) {
            id = idOrAnnotation;
          } else {
            id = this.nextId();
            annotation = idOrAnnotation;
          }
          if (this._annotations[id] !== void 0) {
            throw new Error("Id ".concat(id, " is already in use."));
          }
          if (annotation === void 0) {
            throw new Error("No annotation provided for id ".concat(id));
          }
          this._annotations[id] = annotation;
          this._size++;
          return id;
        };
        ChangeAnnotations2.prototype.nextId = function() {
          this._counter++;
          return this._counter.toString();
        };
        return ChangeAnnotations2;
      })();
      var WorkspaceChange = (function() {
        function WorkspaceChange2(workspaceEdit) {
          var _this = this;
          this._textEditChanges = /* @__PURE__ */ Object.create(null);
          if (workspaceEdit !== void 0) {
            this._workspaceEdit = workspaceEdit;
            if (workspaceEdit.documentChanges) {
              this._changeAnnotations = new ChangeAnnotations(workspaceEdit.changeAnnotations);
              workspaceEdit.changeAnnotations = this._changeAnnotations.all();
              workspaceEdit.documentChanges.forEach(function(change) {
                if (TextDocumentEdit.is(change)) {
                  var textEditChange = new TextEditChangeImpl(change.edits, _this._changeAnnotations);
                  _this._textEditChanges[change.textDocument.uri] = textEditChange;
                }
              });
            } else if (workspaceEdit.changes) {
              Object.keys(workspaceEdit.changes).forEach(function(key) {
                var textEditChange = new TextEditChangeImpl(workspaceEdit.changes[key]);
                _this._textEditChanges[key] = textEditChange;
              });
            }
          } else {
            this._workspaceEdit = {};
          }
        }
        Object.defineProperty(WorkspaceChange2.prototype, "edit", {
          get: function() {
            this.initDocumentChanges();
            if (this._changeAnnotations !== void 0) {
              if (this._changeAnnotations.size === 0) {
                this._workspaceEdit.changeAnnotations = void 0;
              } else {
                this._workspaceEdit.changeAnnotations = this._changeAnnotations.all();
              }
            }
            return this._workspaceEdit;
          },
          enumerable: false,
          configurable: true
        });
        WorkspaceChange2.prototype.getTextEditChange = function(key) {
          if (OptionalVersionedTextDocumentIdentifier.is(key)) {
            this.initDocumentChanges();
            if (this._workspaceEdit.documentChanges === void 0) {
              throw new Error("Workspace edit is not configured for document changes.");
            }
            var textDocument = {
              uri: key.uri,
              version: key.version
            };
            var result = this._textEditChanges[textDocument.uri];
            if (!result) {
              var edits = [];
              var textDocumentEdit = {
                textDocument,
                edits
              };
              this._workspaceEdit.documentChanges.push(textDocumentEdit);
              result = new TextEditChangeImpl(edits, this._changeAnnotations);
              this._textEditChanges[textDocument.uri] = result;
            }
            return result;
          } else {
            this.initChanges();
            if (this._workspaceEdit.changes === void 0) {
              throw new Error("Workspace edit is not configured for normal text edit changes.");
            }
            var result = this._textEditChanges[key];
            if (!result) {
              var edits = [];
              this._workspaceEdit.changes[key] = edits;
              result = new TextEditChangeImpl(edits);
              this._textEditChanges[key] = result;
            }
            return result;
          }
        };
        WorkspaceChange2.prototype.initDocumentChanges = function() {
          if (this._workspaceEdit.documentChanges === void 0 && this._workspaceEdit.changes === void 0) {
            this._changeAnnotations = new ChangeAnnotations();
            this._workspaceEdit.documentChanges = [];
            this._workspaceEdit.changeAnnotations = this._changeAnnotations.all();
          }
        };
        WorkspaceChange2.prototype.initChanges = function() {
          if (this._workspaceEdit.documentChanges === void 0 && this._workspaceEdit.changes === void 0) {
            this._workspaceEdit.changes = /* @__PURE__ */ Object.create(null);
          }
        };
        WorkspaceChange2.prototype.createFile = function(uri, optionsOrAnnotation, options2) {
          this.initDocumentChanges();
          if (this._workspaceEdit.documentChanges === void 0) {
            throw new Error("Workspace edit is not configured for document changes.");
          }
          var annotation;
          if (ChangeAnnotation.is(optionsOrAnnotation) || ChangeAnnotationIdentifier.is(optionsOrAnnotation)) {
            annotation = optionsOrAnnotation;
          } else {
            options2 = optionsOrAnnotation;
          }
          var operation;
          var id;
          if (annotation === void 0) {
            operation = CreateFile.create(uri, options2);
          } else {
            id = ChangeAnnotationIdentifier.is(annotation) ? annotation : this._changeAnnotations.manage(annotation);
            operation = CreateFile.create(uri, options2, id);
          }
          this._workspaceEdit.documentChanges.push(operation);
          if (id !== void 0) {
            return id;
          }
        };
        WorkspaceChange2.prototype.renameFile = function(oldUri, newUri, optionsOrAnnotation, options2) {
          this.initDocumentChanges();
          if (this._workspaceEdit.documentChanges === void 0) {
            throw new Error("Workspace edit is not configured for document changes.");
          }
          var annotation;
          if (ChangeAnnotation.is(optionsOrAnnotation) || ChangeAnnotationIdentifier.is(optionsOrAnnotation)) {
            annotation = optionsOrAnnotation;
          } else {
            options2 = optionsOrAnnotation;
          }
          var operation;
          var id;
          if (annotation === void 0) {
            operation = RenameFile.create(oldUri, newUri, options2);
          } else {
            id = ChangeAnnotationIdentifier.is(annotation) ? annotation : this._changeAnnotations.manage(annotation);
            operation = RenameFile.create(oldUri, newUri, options2, id);
          }
          this._workspaceEdit.documentChanges.push(operation);
          if (id !== void 0) {
            return id;
          }
        };
        WorkspaceChange2.prototype.deleteFile = function(uri, optionsOrAnnotation, options2) {
          this.initDocumentChanges();
          if (this._workspaceEdit.documentChanges === void 0) {
            throw new Error("Workspace edit is not configured for document changes.");
          }
          var annotation;
          if (ChangeAnnotation.is(optionsOrAnnotation) || ChangeAnnotationIdentifier.is(optionsOrAnnotation)) {
            annotation = optionsOrAnnotation;
          } else {
            options2 = optionsOrAnnotation;
          }
          var operation;
          var id;
          if (annotation === void 0) {
            operation = DeleteFile.create(uri, options2);
          } else {
            id = ChangeAnnotationIdentifier.is(annotation) ? annotation : this._changeAnnotations.manage(annotation);
            operation = DeleteFile.create(uri, options2, id);
          }
          this._workspaceEdit.documentChanges.push(operation);
          if (id !== void 0) {
            return id;
          }
        };
        return WorkspaceChange2;
      })();
      exports2.WorkspaceChange = WorkspaceChange;
      var TextDocumentIdentifier;
      (function(TextDocumentIdentifier2) {
        function create(uri) {
          return {
            uri
          };
        }
        TextDocumentIdentifier2.create = create;
        function is2(value) {
          var candidate = value;
          return Is.defined(candidate) && Is.string(candidate.uri);
        }
        TextDocumentIdentifier2.is = is2;
      })(TextDocumentIdentifier || (exports2.TextDocumentIdentifier = TextDocumentIdentifier = {}));
      var VersionedTextDocumentIdentifier;
      (function(VersionedTextDocumentIdentifier2) {
        function create(uri, version2) {
          return {
            uri,
            version: version2
          };
        }
        VersionedTextDocumentIdentifier2.create = create;
        function is2(value) {
          var candidate = value;
          return Is.defined(candidate) && Is.string(candidate.uri) && Is.integer(candidate.version);
        }
        VersionedTextDocumentIdentifier2.is = is2;
      })(VersionedTextDocumentIdentifier || (exports2.VersionedTextDocumentIdentifier = VersionedTextDocumentIdentifier = {}));
      var OptionalVersionedTextDocumentIdentifier;
      (function(OptionalVersionedTextDocumentIdentifier2) {
        function create(uri, version2) {
          return {
            uri,
            version: version2
          };
        }
        OptionalVersionedTextDocumentIdentifier2.create = create;
        function is2(value) {
          var candidate = value;
          return Is.defined(candidate) && Is.string(candidate.uri) && (candidate.version === null || Is.integer(candidate.version));
        }
        OptionalVersionedTextDocumentIdentifier2.is = is2;
      })(OptionalVersionedTextDocumentIdentifier || (exports2.OptionalVersionedTextDocumentIdentifier = OptionalVersionedTextDocumentIdentifier = {}));
      var TextDocumentItem;
      (function(TextDocumentItem2) {
        function create(uri, languageId, version2, text) {
          return {
            uri,
            languageId,
            version: version2,
            text
          };
        }
        TextDocumentItem2.create = create;
        function is2(value) {
          var candidate = value;
          return Is.defined(candidate) && Is.string(candidate.uri) && Is.string(candidate.languageId) && Is.integer(candidate.version) && Is.string(candidate.text);
        }
        TextDocumentItem2.is = is2;
      })(TextDocumentItem || (exports2.TextDocumentItem = TextDocumentItem = {}));
      var MarkupKind;
      (function(MarkupKind2) {
        MarkupKind2.PlainText = "plaintext";
        MarkupKind2.Markdown = "markdown";
        function is2(value) {
          var candidate = value;
          return candidate === MarkupKind2.PlainText || candidate === MarkupKind2.Markdown;
        }
        MarkupKind2.is = is2;
      })(MarkupKind || (exports2.MarkupKind = MarkupKind = {}));
      var MarkupContent;
      (function(MarkupContent2) {
        function is2(value) {
          var candidate = value;
          return Is.objectLiteral(value) && MarkupKind.is(candidate.kind) && Is.string(candidate.value);
        }
        MarkupContent2.is = is2;
      })(MarkupContent || (exports2.MarkupContent = MarkupContent = {}));
      var CompletionItemKind;
      (function(CompletionItemKind2) {
        CompletionItemKind2.Text = 1;
        CompletionItemKind2.Method = 2;
        CompletionItemKind2.Function = 3;
        CompletionItemKind2.Constructor = 4;
        CompletionItemKind2.Field = 5;
        CompletionItemKind2.Variable = 6;
        CompletionItemKind2.Class = 7;
        CompletionItemKind2.Interface = 8;
        CompletionItemKind2.Module = 9;
        CompletionItemKind2.Property = 10;
        CompletionItemKind2.Unit = 11;
        CompletionItemKind2.Value = 12;
        CompletionItemKind2.Enum = 13;
        CompletionItemKind2.Keyword = 14;
        CompletionItemKind2.Snippet = 15;
        CompletionItemKind2.Color = 16;
        CompletionItemKind2.File = 17;
        CompletionItemKind2.Reference = 18;
        CompletionItemKind2.Folder = 19;
        CompletionItemKind2.EnumMember = 20;
        CompletionItemKind2.Constant = 21;
        CompletionItemKind2.Struct = 22;
        CompletionItemKind2.Event = 23;
        CompletionItemKind2.Operator = 24;
        CompletionItemKind2.TypeParameter = 25;
      })(CompletionItemKind || (exports2.CompletionItemKind = CompletionItemKind = {}));
      var InsertTextFormat;
      (function(InsertTextFormat2) {
        InsertTextFormat2.PlainText = 1;
        InsertTextFormat2.Snippet = 2;
      })(InsertTextFormat || (exports2.InsertTextFormat = InsertTextFormat = {}));
      var CompletionItemTag;
      (function(CompletionItemTag2) {
        CompletionItemTag2.Deprecated = 1;
      })(CompletionItemTag || (exports2.CompletionItemTag = CompletionItemTag = {}));
      var InsertReplaceEdit;
      (function(InsertReplaceEdit2) {
        function create(newText, insert, replace) {
          return {
            newText,
            insert,
            replace
          };
        }
        InsertReplaceEdit2.create = create;
        function is2(value) {
          var candidate = value;
          return candidate && Is.string(candidate.newText) && Range2.is(candidate.insert) && Range2.is(candidate.replace);
        }
        InsertReplaceEdit2.is = is2;
      })(InsertReplaceEdit || (exports2.InsertReplaceEdit = InsertReplaceEdit = {}));
      var InsertTextMode;
      (function(InsertTextMode2) {
        InsertTextMode2.asIs = 1;
        InsertTextMode2.adjustIndentation = 2;
      })(InsertTextMode || (exports2.InsertTextMode = InsertTextMode = {}));
      var CompletionItemLabelDetails;
      (function(CompletionItemLabelDetails2) {
        function is2(value) {
          var candidate = value;
          return candidate && (Is.string(candidate.detail) || candidate.detail === void 0) && (Is.string(candidate.description) || candidate.description === void 0);
        }
        CompletionItemLabelDetails2.is = is2;
      })(CompletionItemLabelDetails || (exports2.CompletionItemLabelDetails = CompletionItemLabelDetails = {}));
      var CompletionItem;
      (function(CompletionItem2) {
        function create(label) {
          return {
            label
          };
        }
        CompletionItem2.create = create;
      })(CompletionItem || (exports2.CompletionItem = CompletionItem = {}));
      var CompletionList;
      (function(CompletionList2) {
        function create(items, isIncomplete) {
          return {
            items: items ? items : [],
            isIncomplete: !!isIncomplete
          };
        }
        CompletionList2.create = create;
      })(CompletionList || (exports2.CompletionList = CompletionList = {}));
      var MarkedString;
      (function(MarkedString2) {
        function fromPlainText(plainText) {
          return plainText.replace(/[\\`*_{}[\]()#+\-.!]/g, "\\$&");
        }
        MarkedString2.fromPlainText = fromPlainText;
        function is2(value) {
          var candidate = value;
          return Is.string(candidate) || Is.objectLiteral(candidate) && Is.string(candidate.language) && Is.string(candidate.value);
        }
        MarkedString2.is = is2;
      })(MarkedString || (exports2.MarkedString = MarkedString = {}));
      var Hover;
      (function(Hover2) {
        function is2(value) {
          var candidate = value;
          return !!candidate && Is.objectLiteral(candidate) && (MarkupContent.is(candidate.contents) || MarkedString.is(candidate.contents) || Is.typedArray(candidate.contents, MarkedString.is)) && (value.range === void 0 || Range2.is(value.range));
        }
        Hover2.is = is2;
      })(Hover || (exports2.Hover = Hover = {}));
      var ParameterInformation;
      (function(ParameterInformation2) {
        function create(label, documentation) {
          return documentation ? {
            label,
            documentation
          } : {
            label
          };
        }
        ParameterInformation2.create = create;
      })(ParameterInformation || (exports2.ParameterInformation = ParameterInformation = {}));
      var SignatureInformation;
      (function(SignatureInformation2) {
        function create(label, documentation) {
          var parameters = [];
          for (var _i = 2; _i < arguments.length; _i++) {
            parameters[_i - 2] = arguments[_i];
          }
          var result = {
            label
          };
          if (Is.defined(documentation)) {
            result.documentation = documentation;
          }
          if (Is.defined(parameters)) {
            result.parameters = parameters;
          } else {
            result.parameters = [];
          }
          return result;
        }
        SignatureInformation2.create = create;
      })(SignatureInformation || (exports2.SignatureInformation = SignatureInformation = {}));
      var DocumentHighlightKind;
      (function(DocumentHighlightKind2) {
        DocumentHighlightKind2.Text = 1;
        DocumentHighlightKind2.Read = 2;
        DocumentHighlightKind2.Write = 3;
      })(DocumentHighlightKind || (exports2.DocumentHighlightKind = DocumentHighlightKind = {}));
      var DocumentHighlight;
      (function(DocumentHighlight2) {
        function create(range2, kind) {
          var result = {
            range: range2
          };
          if (Is.number(kind)) {
            result.kind = kind;
          }
          return result;
        }
        DocumentHighlight2.create = create;
      })(DocumentHighlight || (exports2.DocumentHighlight = DocumentHighlight = {}));
      var SymbolKind;
      (function(SymbolKind2) {
        SymbolKind2.File = 1;
        SymbolKind2.Module = 2;
        SymbolKind2.Namespace = 3;
        SymbolKind2.Package = 4;
        SymbolKind2.Class = 5;
        SymbolKind2.Method = 6;
        SymbolKind2.Property = 7;
        SymbolKind2.Field = 8;
        SymbolKind2.Constructor = 9;
        SymbolKind2.Enum = 10;
        SymbolKind2.Interface = 11;
        SymbolKind2.Function = 12;
        SymbolKind2.Variable = 13;
        SymbolKind2.Constant = 14;
        SymbolKind2.String = 15;
        SymbolKind2.Number = 16;
        SymbolKind2.Boolean = 17;
        SymbolKind2.Array = 18;
        SymbolKind2.Object = 19;
        SymbolKind2.Key = 20;
        SymbolKind2.Null = 21;
        SymbolKind2.EnumMember = 22;
        SymbolKind2.Struct = 23;
        SymbolKind2.Event = 24;
        SymbolKind2.Operator = 25;
        SymbolKind2.TypeParameter = 26;
      })(SymbolKind || (exports2.SymbolKind = SymbolKind = {}));
      var SymbolTag;
      (function(SymbolTag2) {
        SymbolTag2.Deprecated = 1;
      })(SymbolTag || (exports2.SymbolTag = SymbolTag = {}));
      var SymbolInformation;
      (function(SymbolInformation2) {
        function create(name, kind, range2, uri, containerName) {
          var result = {
            name,
            kind,
            location: {
              uri,
              range: range2
            }
          };
          if (containerName) {
            result.containerName = containerName;
          }
          return result;
        }
        SymbolInformation2.create = create;
      })(SymbolInformation || (exports2.SymbolInformation = SymbolInformation = {}));
      var WorkspaceSymbol;
      (function(WorkspaceSymbol2) {
        function create(name, kind, uri, range2) {
          return range2 !== void 0 ? {
            name,
            kind,
            location: {
              uri,
              range: range2
            }
          } : {
            name,
            kind,
            location: {
              uri
            }
          };
        }
        WorkspaceSymbol2.create = create;
      })(WorkspaceSymbol || (exports2.WorkspaceSymbol = WorkspaceSymbol = {}));
      var DocumentSymbol;
      (function(DocumentSymbol2) {
        function create(name, detail, kind, range2, selectionRange, children) {
          var result = {
            name,
            detail,
            kind,
            range: range2,
            selectionRange
          };
          if (children !== void 0) {
            result.children = children;
          }
          return result;
        }
        DocumentSymbol2.create = create;
        function is2(value) {
          var candidate = value;
          return candidate && Is.string(candidate.name) && Is.number(candidate.kind) && Range2.is(candidate.range) && Range2.is(candidate.selectionRange) && (candidate.detail === void 0 || Is.string(candidate.detail)) && (candidate.deprecated === void 0 || Is.boolean(candidate.deprecated)) && (candidate.children === void 0 || Array.isArray(candidate.children)) && (candidate.tags === void 0 || Array.isArray(candidate.tags));
        }
        DocumentSymbol2.is = is2;
      })(DocumentSymbol || (exports2.DocumentSymbol = DocumentSymbol = {}));
      var CodeActionKind2;
      (function(CodeActionKind3) {
        CodeActionKind3.Empty = "";
        CodeActionKind3.QuickFix = "quickfix";
        CodeActionKind3.Refactor = "refactor";
        CodeActionKind3.RefactorExtract = "refactor.extract";
        CodeActionKind3.RefactorInline = "refactor.inline";
        CodeActionKind3.RefactorRewrite = "refactor.rewrite";
        CodeActionKind3.Source = "source";
        CodeActionKind3.SourceOrganizeImports = "source.organizeImports";
        CodeActionKind3.SourceFixAll = "source.fixAll";
      })(CodeActionKind2 || (exports2.CodeActionKind = CodeActionKind2 = {}));
      var CodeActionTriggerKind;
      (function(CodeActionTriggerKind2) {
        CodeActionTriggerKind2.Invoked = 1;
        CodeActionTriggerKind2.Automatic = 2;
      })(CodeActionTriggerKind || (exports2.CodeActionTriggerKind = CodeActionTriggerKind = {}));
      var CodeActionContext;
      (function(CodeActionContext2) {
        function create(diagnostics, only, triggerKind) {
          var result = {
            diagnostics
          };
          if (only !== void 0 && only !== null) {
            result.only = only;
          }
          if (triggerKind !== void 0 && triggerKind !== null) {
            result.triggerKind = triggerKind;
          }
          return result;
        }
        CodeActionContext2.create = create;
        function is2(value) {
          var candidate = value;
          return Is.defined(candidate) && Is.typedArray(candidate.diagnostics, Diagnostic.is) && (candidate.only === void 0 || Is.typedArray(candidate.only, Is.string)) && (candidate.triggerKind === void 0 || candidate.triggerKind === CodeActionTriggerKind.Invoked || candidate.triggerKind === CodeActionTriggerKind.Automatic);
        }
        CodeActionContext2.is = is2;
      })(CodeActionContext || (exports2.CodeActionContext = CodeActionContext = {}));
      var CodeAction;
      (function(CodeAction2) {
        function create(title, kindOrCommandOrEdit, kind) {
          var result = {
            title
          };
          var checkKind = true;
          if (typeof kindOrCommandOrEdit === "string") {
            checkKind = false;
            result.kind = kindOrCommandOrEdit;
          } else if (Command2.is(kindOrCommandOrEdit)) {
            result.command = kindOrCommandOrEdit;
          } else {
            result.edit = kindOrCommandOrEdit;
          }
          if (checkKind && kind !== void 0) {
            result.kind = kind;
          }
          return result;
        }
        CodeAction2.create = create;
        function is2(value) {
          var candidate = value;
          return candidate && Is.string(candidate.title) && (candidate.diagnostics === void 0 || Is.typedArray(candidate.diagnostics, Diagnostic.is)) && (candidate.kind === void 0 || Is.string(candidate.kind)) && (candidate.edit !== void 0 || candidate.command !== void 0) && (candidate.command === void 0 || Command2.is(candidate.command)) && (candidate.isPreferred === void 0 || Is.boolean(candidate.isPreferred)) && (candidate.edit === void 0 || WorkspaceEdit.is(candidate.edit));
        }
        CodeAction2.is = is2;
      })(CodeAction || (exports2.CodeAction = CodeAction = {}));
      var CodeLens;
      (function(CodeLens2) {
        function create(range2, data) {
          var result = {
            range: range2
          };
          if (Is.defined(data)) {
            result.data = data;
          }
          return result;
        }
        CodeLens2.create = create;
        function is2(value) {
          var candidate = value;
          return Is.defined(candidate) && Range2.is(candidate.range) && (Is.undefined(candidate.command) || Command2.is(candidate.command));
        }
        CodeLens2.is = is2;
      })(CodeLens || (exports2.CodeLens = CodeLens = {}));
      var FormattingOptions;
      (function(FormattingOptions2) {
        function create(tabSize, insertSpaces) {
          return {
            tabSize,
            insertSpaces
          };
        }
        FormattingOptions2.create = create;
        function is2(value) {
          var candidate = value;
          return Is.defined(candidate) && Is.uinteger(candidate.tabSize) && Is.boolean(candidate.insertSpaces);
        }
        FormattingOptions2.is = is2;
      })(FormattingOptions || (exports2.FormattingOptions = FormattingOptions = {}));
      var DocumentLink;
      (function(DocumentLink2) {
        function create(range2, target, data) {
          return {
            range: range2,
            target,
            data
          };
        }
        DocumentLink2.create = create;
        function is2(value) {
          var candidate = value;
          return Is.defined(candidate) && Range2.is(candidate.range) && (Is.undefined(candidate.target) || Is.string(candidate.target));
        }
        DocumentLink2.is = is2;
      })(DocumentLink || (exports2.DocumentLink = DocumentLink = {}));
      var SelectionRange;
      (function(SelectionRange2) {
        function create(range2, parent) {
          return {
            range: range2,
            parent
          };
        }
        SelectionRange2.create = create;
        function is2(value) {
          var candidate = value;
          return Is.objectLiteral(candidate) && Range2.is(candidate.range) && (candidate.parent === void 0 || SelectionRange2.is(candidate.parent));
        }
        SelectionRange2.is = is2;
      })(SelectionRange || (exports2.SelectionRange = SelectionRange = {}));
      var SemanticTokenTypes;
      (function(SemanticTokenTypes2) {
        SemanticTokenTypes2["namespace"] = "namespace";
        SemanticTokenTypes2["type"] = "type";
        SemanticTokenTypes2["class"] = "class";
        SemanticTokenTypes2["enum"] = "enum";
        SemanticTokenTypes2["interface"] = "interface";
        SemanticTokenTypes2["struct"] = "struct";
        SemanticTokenTypes2["typeParameter"] = "typeParameter";
        SemanticTokenTypes2["parameter"] = "parameter";
        SemanticTokenTypes2["variable"] = "variable";
        SemanticTokenTypes2["property"] = "property";
        SemanticTokenTypes2["enumMember"] = "enumMember";
        SemanticTokenTypes2["event"] = "event";
        SemanticTokenTypes2["function"] = "function";
        SemanticTokenTypes2["method"] = "method";
        SemanticTokenTypes2["macro"] = "macro";
        SemanticTokenTypes2["keyword"] = "keyword";
        SemanticTokenTypes2["modifier"] = "modifier";
        SemanticTokenTypes2["comment"] = "comment";
        SemanticTokenTypes2["string"] = "string";
        SemanticTokenTypes2["number"] = "number";
        SemanticTokenTypes2["regexp"] = "regexp";
        SemanticTokenTypes2["operator"] = "operator";
        SemanticTokenTypes2["decorator"] = "decorator";
      })(SemanticTokenTypes || (exports2.SemanticTokenTypes = SemanticTokenTypes = {}));
      var SemanticTokenModifiers;
      (function(SemanticTokenModifiers2) {
        SemanticTokenModifiers2["declaration"] = "declaration";
        SemanticTokenModifiers2["definition"] = "definition";
        SemanticTokenModifiers2["readonly"] = "readonly";
        SemanticTokenModifiers2["static"] = "static";
        SemanticTokenModifiers2["deprecated"] = "deprecated";
        SemanticTokenModifiers2["abstract"] = "abstract";
        SemanticTokenModifiers2["async"] = "async";
        SemanticTokenModifiers2["modification"] = "modification";
        SemanticTokenModifiers2["documentation"] = "documentation";
        SemanticTokenModifiers2["defaultLibrary"] = "defaultLibrary";
      })(SemanticTokenModifiers || (exports2.SemanticTokenModifiers = SemanticTokenModifiers = {}));
      var SemanticTokens;
      (function(SemanticTokens2) {
        function is2(value) {
          var candidate = value;
          return Is.objectLiteral(candidate) && (candidate.resultId === void 0 || typeof candidate.resultId === "string") && Array.isArray(candidate.data) && (candidate.data.length === 0 || typeof candidate.data[0] === "number");
        }
        SemanticTokens2.is = is2;
      })(SemanticTokens || (exports2.SemanticTokens = SemanticTokens = {}));
      var InlineValueText;
      (function(InlineValueText2) {
        function create(range2, text) {
          return {
            range: range2,
            text
          };
        }
        InlineValueText2.create = create;
        function is2(value) {
          var candidate = value;
          return candidate !== void 0 && candidate !== null && Range2.is(candidate.range) && Is.string(candidate.text);
        }
        InlineValueText2.is = is2;
      })(InlineValueText || (exports2.InlineValueText = InlineValueText = {}));
      var InlineValueVariableLookup;
      (function(InlineValueVariableLookup2) {
        function create(range2, variableName, caseSensitiveLookup) {
          return {
            range: range2,
            variableName,
            caseSensitiveLookup
          };
        }
        InlineValueVariableLookup2.create = create;
        function is2(value) {
          var candidate = value;
          return candidate !== void 0 && candidate !== null && Range2.is(candidate.range) && Is.boolean(candidate.caseSensitiveLookup) && (Is.string(candidate.variableName) || candidate.variableName === void 0);
        }
        InlineValueVariableLookup2.is = is2;
      })(InlineValueVariableLookup || (exports2.InlineValueVariableLookup = InlineValueVariableLookup = {}));
      var InlineValueEvaluatableExpression;
      (function(InlineValueEvaluatableExpression2) {
        function create(range2, expression) {
          return {
            range: range2,
            expression
          };
        }
        InlineValueEvaluatableExpression2.create = create;
        function is2(value) {
          var candidate = value;
          return candidate !== void 0 && candidate !== null && Range2.is(candidate.range) && (Is.string(candidate.expression) || candidate.expression === void 0);
        }
        InlineValueEvaluatableExpression2.is = is2;
      })(InlineValueEvaluatableExpression || (exports2.InlineValueEvaluatableExpression = InlineValueEvaluatableExpression = {}));
      var InlineValueContext;
      (function(InlineValueContext2) {
        function create(frameId, stoppedLocation) {
          return {
            frameId,
            stoppedLocation
          };
        }
        InlineValueContext2.create = create;
        function is2(value) {
          var candidate = value;
          return Is.defined(candidate) && Range2.is(value.stoppedLocation);
        }
        InlineValueContext2.is = is2;
      })(InlineValueContext || (exports2.InlineValueContext = InlineValueContext = {}));
      var InlayHintKind;
      (function(InlayHintKind2) {
        InlayHintKind2.Type = 1;
        InlayHintKind2.Parameter = 2;
        function is2(value) {
          return value === 1 || value === 2;
        }
        InlayHintKind2.is = is2;
      })(InlayHintKind || (exports2.InlayHintKind = InlayHintKind = {}));
      var InlayHintLabelPart;
      (function(InlayHintLabelPart2) {
        function create(value) {
          return {
            value
          };
        }
        InlayHintLabelPart2.create = create;
        function is2(value) {
          var candidate = value;
          return Is.objectLiteral(candidate) && (candidate.tooltip === void 0 || Is.string(candidate.tooltip) || MarkupContent.is(candidate.tooltip)) && (candidate.location === void 0 || Location2.is(candidate.location)) && (candidate.command === void 0 || Command2.is(candidate.command));
        }
        InlayHintLabelPart2.is = is2;
      })(InlayHintLabelPart || (exports2.InlayHintLabelPart = InlayHintLabelPart = {}));
      var InlayHint;
      (function(InlayHint2) {
        function create(position, label, kind) {
          var result = {
            position,
            label
          };
          if (kind !== void 0) {
            result.kind = kind;
          }
          return result;
        }
        InlayHint2.create = create;
        function is2(value) {
          var candidate = value;
          return Is.objectLiteral(candidate) && Position2.is(candidate.position) && (Is.string(candidate.label) || Is.typedArray(candidate.label, InlayHintLabelPart.is)) && (candidate.kind === void 0 || InlayHintKind.is(candidate.kind)) && candidate.textEdits === void 0 || Is.typedArray(candidate.textEdits, TextEdit.is) && (candidate.tooltip === void 0 || Is.string(candidate.tooltip) || MarkupContent.is(candidate.tooltip)) && (candidate.paddingLeft === void 0 || Is.boolean(candidate.paddingLeft)) && (candidate.paddingRight === void 0 || Is.boolean(candidate.paddingRight));
        }
        InlayHint2.is = is2;
      })(InlayHint || (exports2.InlayHint = InlayHint = {}));
      var StringValue;
      (function(StringValue2) {
        function createSnippet(value) {
          return {
            kind: "snippet",
            value
          };
        }
        StringValue2.createSnippet = createSnippet;
      })(StringValue || (exports2.StringValue = StringValue = {}));
      var InlineCompletionItem;
      (function(InlineCompletionItem2) {
        function create(insertText, filterText, range2, command2) {
          return {
            insertText,
            filterText,
            range: range2,
            command: command2
          };
        }
        InlineCompletionItem2.create = create;
      })(InlineCompletionItem || (exports2.InlineCompletionItem = InlineCompletionItem = {}));
      var InlineCompletionList;
      (function(InlineCompletionList2) {
        function create(items) {
          return {
            items
          };
        }
        InlineCompletionList2.create = create;
      })(InlineCompletionList || (exports2.InlineCompletionList = InlineCompletionList = {}));
      var InlineCompletionTriggerKind;
      (function(InlineCompletionTriggerKind2) {
        InlineCompletionTriggerKind2.Invoked = 0;
        InlineCompletionTriggerKind2.Automatic = 1;
      })(InlineCompletionTriggerKind || (exports2.InlineCompletionTriggerKind = InlineCompletionTriggerKind = {}));
      var SelectedCompletionInfo;
      (function(SelectedCompletionInfo2) {
        function create(range2, text) {
          return {
            range: range2,
            text
          };
        }
        SelectedCompletionInfo2.create = create;
      })(SelectedCompletionInfo || (exports2.SelectedCompletionInfo = SelectedCompletionInfo = {}));
      var InlineCompletionContext;
      (function(InlineCompletionContext2) {
        function create(triggerKind, selectedCompletionInfo) {
          return {
            triggerKind,
            selectedCompletionInfo
          };
        }
        InlineCompletionContext2.create = create;
      })(InlineCompletionContext || (exports2.InlineCompletionContext = InlineCompletionContext = {}));
      var WorkspaceFolder;
      (function(WorkspaceFolder2) {
        function is2(value) {
          var candidate = value;
          return Is.objectLiteral(candidate) && URI2.is(candidate.uri) && Is.string(candidate.name);
        }
        WorkspaceFolder2.is = is2;
      })(WorkspaceFolder || (exports2.WorkspaceFolder = WorkspaceFolder = {}));
      exports2.EOL = ["\n", "\r\n", "\r"];
      var TextDocument2;
      (function(TextDocument3) {
        function create(uri, languageId, version2, content) {
          return new FullTextDocument2(uri, languageId, version2, content);
        }
        TextDocument3.create = create;
        function is2(value) {
          var candidate = value;
          return Is.defined(candidate) && Is.string(candidate.uri) && (Is.undefined(candidate.languageId) || Is.string(candidate.languageId)) && Is.uinteger(candidate.lineCount) && Is.func(candidate.getText) && Is.func(candidate.positionAt) && Is.func(candidate.offsetAt) ? true : false;
        }
        TextDocument3.is = is2;
        function applyEdits(document, edits) {
          var text = document.getText();
          var sortedEdits = mergeSort2(edits, function(a, b) {
            var diff = a.range.start.line - b.range.start.line;
            if (diff === 0) {
              return a.range.start.character - b.range.start.character;
            }
            return diff;
          });
          var lastModifiedOffset = text.length;
          for (var i = sortedEdits.length - 1; i >= 0; i--) {
            var e = sortedEdits[i];
            var startOffset = document.offsetAt(e.range.start);
            var endOffset = document.offsetAt(e.range.end);
            if (endOffset <= lastModifiedOffset) {
              text = text.substring(0, startOffset) + e.newText + text.substring(endOffset, text.length);
            } else {
              throw new Error("Overlapping edit");
            }
            lastModifiedOffset = startOffset;
          }
          return text;
        }
        TextDocument3.applyEdits = applyEdits;
        function mergeSort2(data, compare) {
          if (data.length <= 1) {
            return data;
          }
          var p = data.length / 2 | 0;
          var left = data.slice(0, p);
          var right = data.slice(p);
          mergeSort2(left, compare);
          mergeSort2(right, compare);
          var leftIdx = 0;
          var rightIdx = 0;
          var i = 0;
          while (leftIdx < left.length && rightIdx < right.length) {
            var ret = compare(left[leftIdx], right[rightIdx]);
            if (ret <= 0) {
              data[i++] = left[leftIdx++];
            } else {
              data[i++] = right[rightIdx++];
            }
          }
          while (leftIdx < left.length) {
            data[i++] = left[leftIdx++];
          }
          while (rightIdx < right.length) {
            data[i++] = right[rightIdx++];
          }
          return data;
        }
      })(TextDocument2 || (exports2.TextDocument = TextDocument2 = {}));
      var FullTextDocument2 = (function() {
        function FullTextDocument3(uri, languageId, version2, content) {
          this._uri = uri;
          this._languageId = languageId;
          this._version = version2;
          this._content = content;
          this._lineOffsets = void 0;
        }
        Object.defineProperty(FullTextDocument3.prototype, "uri", {
          get: function() {
            return this._uri;
          },
          enumerable: false,
          configurable: true
        });
        Object.defineProperty(FullTextDocument3.prototype, "languageId", {
          get: function() {
            return this._languageId;
          },
          enumerable: false,
          configurable: true
        });
        Object.defineProperty(FullTextDocument3.prototype, "version", {
          get: function() {
            return this._version;
          },
          enumerable: false,
          configurable: true
        });
        FullTextDocument3.prototype.getText = function(range2) {
          if (range2) {
            var start = this.offsetAt(range2.start);
            var end = this.offsetAt(range2.end);
            return this._content.substring(start, end);
          }
          return this._content;
        };
        FullTextDocument3.prototype.update = function(event, version2) {
          this._content = event.text;
          this._version = version2;
          this._lineOffsets = void 0;
        };
        FullTextDocument3.prototype.getLineOffsets = function() {
          if (this._lineOffsets === void 0) {
            var lineOffsets = [];
            var text = this._content;
            var isLineStart = true;
            for (var i = 0; i < text.length; i++) {
              if (isLineStart) {
                lineOffsets.push(i);
                isLineStart = false;
              }
              var ch = text.charAt(i);
              isLineStart = ch === "\r" || ch === "\n";
              if (ch === "\r" && i + 1 < text.length && text.charAt(i + 1) === "\n") {
                i++;
              }
            }
            if (isLineStart && text.length > 0) {
              lineOffsets.push(text.length);
            }
            this._lineOffsets = lineOffsets;
          }
          return this._lineOffsets;
        };
        FullTextDocument3.prototype.positionAt = function(offset) {
          offset = Math.max(Math.min(offset, this._content.length), 0);
          var lineOffsets = this.getLineOffsets();
          var low = 0, high = lineOffsets.length;
          if (high === 0) {
            return Position2.create(0, offset);
          }
          while (low < high) {
            var mid = Math.floor((low + high) / 2);
            if (lineOffsets[mid] > offset) {
              high = mid;
            } else {
              low = mid + 1;
            }
          }
          var line = low - 1;
          return Position2.create(line, offset - lineOffsets[line]);
        };
        FullTextDocument3.prototype.offsetAt = function(position) {
          var lineOffsets = this.getLineOffsets();
          if (position.line >= lineOffsets.length) {
            return this._content.length;
          } else if (position.line < 0) {
            return 0;
          }
          var lineOffset = lineOffsets[position.line];
          var nextLineOffset = position.line + 1 < lineOffsets.length ? lineOffsets[position.line + 1] : this._content.length;
          return Math.max(Math.min(lineOffset + position.character, nextLineOffset), lineOffset);
        };
        Object.defineProperty(FullTextDocument3.prototype, "lineCount", {
          get: function() {
            return this.getLineOffsets().length;
          },
          enumerable: false,
          configurable: true
        });
        return FullTextDocument3;
      })();
      var Is;
      (function(Is2) {
        var toString = Object.prototype.toString;
        function defined(value) {
          return typeof value !== "undefined";
        }
        Is2.defined = defined;
        function undefined$1(value) {
          return typeof value === "undefined";
        }
        Is2.undefined = undefined$1;
        function boolean(value) {
          return value === true || value === false;
        }
        Is2.boolean = boolean;
        function string(value) {
          return toString.call(value) === "[object String]";
        }
        Is2.string = string;
        function number(value) {
          return toString.call(value) === "[object Number]";
        }
        Is2.number = number;
        function numberRange(value, min, max) {
          return toString.call(value) === "[object Number]" && min <= value && value <= max;
        }
        Is2.numberRange = numberRange;
        function integer2(value) {
          return toString.call(value) === "[object Number]" && -2147483648 <= value && value <= 2147483647;
        }
        Is2.integer = integer2;
        function uinteger2(value) {
          return toString.call(value) === "[object Number]" && 0 <= value && value <= 2147483647;
        }
        Is2.uinteger = uinteger2;
        function func(value) {
          return toString.call(value) === "[object Function]";
        }
        Is2.func = func;
        function objectLiteral(value) {
          return value !== null && typeof value === "object";
        }
        Is2.objectLiteral = objectLiteral;
        function typedArray(value, check) {
          return Array.isArray(value) && value.every(check);
        }
        Is2.typedArray = typedArray;
      })(Is || (Is = {}));
    });
  })(main, main.exports);
  return main.exports;
}
var messages = {};
var hasRequiredMessages;
function requireMessages() {
  if (hasRequiredMessages) return messages;
  hasRequiredMessages = 1;
  Object.defineProperty(messages, "__esModule", {
    value: true
  });
  messages.ProtocolNotificationType = messages.ProtocolNotificationType0 = messages.ProtocolRequestType = messages.ProtocolRequestType0 = messages.RegistrationType = messages.MessageDirection = void 0;
  const vscode_jsonrpc_1 = requireMain$3();
  var MessageDirection;
  (function(MessageDirection2) {
    MessageDirection2["clientToServer"] = "clientToServer";
    MessageDirection2["serverToClient"] = "serverToClient";
    MessageDirection2["both"] = "both";
  })(MessageDirection || (messages.MessageDirection = MessageDirection = {}));
  class RegistrationType {
    constructor(method) {
      this.method = method;
    }
  }
  messages.RegistrationType = RegistrationType;
  class ProtocolRequestType0 extends vscode_jsonrpc_1.RequestType0 {
    constructor(method) {
      super(method);
    }
  }
  messages.ProtocolRequestType0 = ProtocolRequestType0;
  class ProtocolRequestType extends vscode_jsonrpc_1.RequestType {
    constructor(method) {
      super(method, vscode_jsonrpc_1.ParameterStructures.byName);
    }
  }
  messages.ProtocolRequestType = ProtocolRequestType;
  class ProtocolNotificationType0 extends vscode_jsonrpc_1.NotificationType0 {
    constructor(method) {
      super(method);
    }
  }
  messages.ProtocolNotificationType0 = ProtocolNotificationType0;
  class ProtocolNotificationType extends vscode_jsonrpc_1.NotificationType {
    constructor(method) {
      super(method, vscode_jsonrpc_1.ParameterStructures.byName);
    }
  }
  messages.ProtocolNotificationType = ProtocolNotificationType;
  return messages;
}
var protocol = {};
var is = {};
var hasRequiredIs;
function requireIs() {
  if (hasRequiredIs) return is;
  hasRequiredIs = 1;
  Object.defineProperty(is, "__esModule", {
    value: true
  });
  is.objectLiteral = is.typedArray = is.stringArray = is.array = is.func = is.error = is.number = is.string = is.boolean = void 0;
  function boolean(value) {
    return value === true || value === false;
  }
  is.boolean = boolean;
  function string(value) {
    return typeof value === "string" || value instanceof String;
  }
  is.string = string;
  function number(value) {
    return typeof value === "number" || value instanceof Number;
  }
  is.number = number;
  function error2(value) {
    return value instanceof Error;
  }
  is.error = error2;
  function func(value) {
    return typeof value === "function";
  }
  is.func = func;
  function array(value) {
    return Array.isArray(value);
  }
  is.array = array;
  function stringArray(value) {
    return array(value) && value.every((elem) => string(elem));
  }
  is.stringArray = stringArray;
  function typedArray(value, check) {
    return Array.isArray(value) && value.every(check);
  }
  is.typedArray = typedArray;
  function objectLiteral(value) {
    return value !== null && typeof value === "object";
  }
  is.objectLiteral = objectLiteral;
  return is;
}
var protocol_implementation = {};
var hasRequiredProtocol_implementation;
function requireProtocol_implementation() {
  if (hasRequiredProtocol_implementation) return protocol_implementation;
  hasRequiredProtocol_implementation = 1;
  Object.defineProperty(protocol_implementation, "__esModule", {
    value: true
  });
  protocol_implementation.ImplementationRequest = void 0;
  const messages_1 = requireMessages();
  var ImplementationRequest;
  (function(ImplementationRequest2) {
    ImplementationRequest2.method = "textDocument/implementation";
    ImplementationRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
    ImplementationRequest2.type = new messages_1.ProtocolRequestType(ImplementationRequest2.method);
  })(ImplementationRequest || (protocol_implementation.ImplementationRequest = ImplementationRequest = {}));
  return protocol_implementation;
}
var protocol_typeDefinition = {};
var hasRequiredProtocol_typeDefinition;
function requireProtocol_typeDefinition() {
  if (hasRequiredProtocol_typeDefinition) return protocol_typeDefinition;
  hasRequiredProtocol_typeDefinition = 1;
  Object.defineProperty(protocol_typeDefinition, "__esModule", {
    value: true
  });
  protocol_typeDefinition.TypeDefinitionRequest = void 0;
  const messages_1 = requireMessages();
  var TypeDefinitionRequest;
  (function(TypeDefinitionRequest2) {
    TypeDefinitionRequest2.method = "textDocument/typeDefinition";
    TypeDefinitionRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
    TypeDefinitionRequest2.type = new messages_1.ProtocolRequestType(TypeDefinitionRequest2.method);
  })(TypeDefinitionRequest || (protocol_typeDefinition.TypeDefinitionRequest = TypeDefinitionRequest = {}));
  return protocol_typeDefinition;
}
var protocol_workspaceFolder = {};
var hasRequiredProtocol_workspaceFolder;
function requireProtocol_workspaceFolder() {
  if (hasRequiredProtocol_workspaceFolder) return protocol_workspaceFolder;
  hasRequiredProtocol_workspaceFolder = 1;
  Object.defineProperty(protocol_workspaceFolder, "__esModule", {
    value: true
  });
  protocol_workspaceFolder.DidChangeWorkspaceFoldersNotification = protocol_workspaceFolder.WorkspaceFoldersRequest = void 0;
  const messages_1 = requireMessages();
  var WorkspaceFoldersRequest;
  (function(WorkspaceFoldersRequest2) {
    WorkspaceFoldersRequest2.method = "workspace/workspaceFolders";
    WorkspaceFoldersRequest2.messageDirection = messages_1.MessageDirection.serverToClient;
    WorkspaceFoldersRequest2.type = new messages_1.ProtocolRequestType0(WorkspaceFoldersRequest2.method);
  })(WorkspaceFoldersRequest || (protocol_workspaceFolder.WorkspaceFoldersRequest = WorkspaceFoldersRequest = {}));
  var DidChangeWorkspaceFoldersNotification;
  (function(DidChangeWorkspaceFoldersNotification2) {
    DidChangeWorkspaceFoldersNotification2.method = "workspace/didChangeWorkspaceFolders";
    DidChangeWorkspaceFoldersNotification2.messageDirection = messages_1.MessageDirection.clientToServer;
    DidChangeWorkspaceFoldersNotification2.type = new messages_1.ProtocolNotificationType(DidChangeWorkspaceFoldersNotification2.method);
  })(DidChangeWorkspaceFoldersNotification || (protocol_workspaceFolder.DidChangeWorkspaceFoldersNotification = DidChangeWorkspaceFoldersNotification = {}));
  return protocol_workspaceFolder;
}
var protocol_configuration = {};
var hasRequiredProtocol_configuration;
function requireProtocol_configuration() {
  if (hasRequiredProtocol_configuration) return protocol_configuration;
  hasRequiredProtocol_configuration = 1;
  Object.defineProperty(protocol_configuration, "__esModule", {
    value: true
  });
  protocol_configuration.ConfigurationRequest = void 0;
  const messages_1 = requireMessages();
  var ConfigurationRequest;
  (function(ConfigurationRequest2) {
    ConfigurationRequest2.method = "workspace/configuration";
    ConfigurationRequest2.messageDirection = messages_1.MessageDirection.serverToClient;
    ConfigurationRequest2.type = new messages_1.ProtocolRequestType(ConfigurationRequest2.method);
  })(ConfigurationRequest || (protocol_configuration.ConfigurationRequest = ConfigurationRequest = {}));
  return protocol_configuration;
}
var protocol_colorProvider = {};
var hasRequiredProtocol_colorProvider;
function requireProtocol_colorProvider() {
  if (hasRequiredProtocol_colorProvider) return protocol_colorProvider;
  hasRequiredProtocol_colorProvider = 1;
  Object.defineProperty(protocol_colorProvider, "__esModule", {
    value: true
  });
  protocol_colorProvider.ColorPresentationRequest = protocol_colorProvider.DocumentColorRequest = void 0;
  const messages_1 = requireMessages();
  var DocumentColorRequest;
  (function(DocumentColorRequest2) {
    DocumentColorRequest2.method = "textDocument/documentColor";
    DocumentColorRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
    DocumentColorRequest2.type = new messages_1.ProtocolRequestType(DocumentColorRequest2.method);
  })(DocumentColorRequest || (protocol_colorProvider.DocumentColorRequest = DocumentColorRequest = {}));
  var ColorPresentationRequest;
  (function(ColorPresentationRequest2) {
    ColorPresentationRequest2.method = "textDocument/colorPresentation";
    ColorPresentationRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
    ColorPresentationRequest2.type = new messages_1.ProtocolRequestType(ColorPresentationRequest2.method);
  })(ColorPresentationRequest || (protocol_colorProvider.ColorPresentationRequest = ColorPresentationRequest = {}));
  return protocol_colorProvider;
}
var protocol_foldingRange = {};
var hasRequiredProtocol_foldingRange;
function requireProtocol_foldingRange() {
  if (hasRequiredProtocol_foldingRange) return protocol_foldingRange;
  hasRequiredProtocol_foldingRange = 1;
  Object.defineProperty(protocol_foldingRange, "__esModule", {
    value: true
  });
  protocol_foldingRange.FoldingRangeRefreshRequest = protocol_foldingRange.FoldingRangeRequest = void 0;
  const messages_1 = requireMessages();
  var FoldingRangeRequest;
  (function(FoldingRangeRequest2) {
    FoldingRangeRequest2.method = "textDocument/foldingRange";
    FoldingRangeRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
    FoldingRangeRequest2.type = new messages_1.ProtocolRequestType(FoldingRangeRequest2.method);
  })(FoldingRangeRequest || (protocol_foldingRange.FoldingRangeRequest = FoldingRangeRequest = {}));
  var FoldingRangeRefreshRequest;
  (function(FoldingRangeRefreshRequest2) {
    FoldingRangeRefreshRequest2.method = `workspace/foldingRange/refresh`;
    FoldingRangeRefreshRequest2.messageDirection = messages_1.MessageDirection.serverToClient;
    FoldingRangeRefreshRequest2.type = new messages_1.ProtocolRequestType0(FoldingRangeRefreshRequest2.method);
  })(FoldingRangeRefreshRequest || (protocol_foldingRange.FoldingRangeRefreshRequest = FoldingRangeRefreshRequest = {}));
  return protocol_foldingRange;
}
var protocol_declaration = {};
var hasRequiredProtocol_declaration;
function requireProtocol_declaration() {
  if (hasRequiredProtocol_declaration) return protocol_declaration;
  hasRequiredProtocol_declaration = 1;
  Object.defineProperty(protocol_declaration, "__esModule", {
    value: true
  });
  protocol_declaration.DeclarationRequest = void 0;
  const messages_1 = requireMessages();
  var DeclarationRequest;
  (function(DeclarationRequest2) {
    DeclarationRequest2.method = "textDocument/declaration";
    DeclarationRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
    DeclarationRequest2.type = new messages_1.ProtocolRequestType(DeclarationRequest2.method);
  })(DeclarationRequest || (protocol_declaration.DeclarationRequest = DeclarationRequest = {}));
  return protocol_declaration;
}
var protocol_selectionRange = {};
var hasRequiredProtocol_selectionRange;
function requireProtocol_selectionRange() {
  if (hasRequiredProtocol_selectionRange) return protocol_selectionRange;
  hasRequiredProtocol_selectionRange = 1;
  Object.defineProperty(protocol_selectionRange, "__esModule", {
    value: true
  });
  protocol_selectionRange.SelectionRangeRequest = void 0;
  const messages_1 = requireMessages();
  var SelectionRangeRequest;
  (function(SelectionRangeRequest2) {
    SelectionRangeRequest2.method = "textDocument/selectionRange";
    SelectionRangeRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
    SelectionRangeRequest2.type = new messages_1.ProtocolRequestType(SelectionRangeRequest2.method);
  })(SelectionRangeRequest || (protocol_selectionRange.SelectionRangeRequest = SelectionRangeRequest = {}));
  return protocol_selectionRange;
}
var protocol_progress = {};
var hasRequiredProtocol_progress;
function requireProtocol_progress() {
  if (hasRequiredProtocol_progress) return protocol_progress;
  hasRequiredProtocol_progress = 1;
  Object.defineProperty(protocol_progress, "__esModule", {
    value: true
  });
  protocol_progress.WorkDoneProgressCancelNotification = protocol_progress.WorkDoneProgressCreateRequest = protocol_progress.WorkDoneProgress = void 0;
  const vscode_jsonrpc_1 = requireMain$3();
  const messages_1 = requireMessages();
  var WorkDoneProgress;
  (function(WorkDoneProgress2) {
    WorkDoneProgress2.type = new vscode_jsonrpc_1.ProgressType();
    function is2(value) {
      return value === WorkDoneProgress2.type;
    }
    WorkDoneProgress2.is = is2;
  })(WorkDoneProgress || (protocol_progress.WorkDoneProgress = WorkDoneProgress = {}));
  var WorkDoneProgressCreateRequest;
  (function(WorkDoneProgressCreateRequest2) {
    WorkDoneProgressCreateRequest2.method = "window/workDoneProgress/create";
    WorkDoneProgressCreateRequest2.messageDirection = messages_1.MessageDirection.serverToClient;
    WorkDoneProgressCreateRequest2.type = new messages_1.ProtocolRequestType(WorkDoneProgressCreateRequest2.method);
  })(WorkDoneProgressCreateRequest || (protocol_progress.WorkDoneProgressCreateRequest = WorkDoneProgressCreateRequest = {}));
  var WorkDoneProgressCancelNotification;
  (function(WorkDoneProgressCancelNotification2) {
    WorkDoneProgressCancelNotification2.method = "window/workDoneProgress/cancel";
    WorkDoneProgressCancelNotification2.messageDirection = messages_1.MessageDirection.clientToServer;
    WorkDoneProgressCancelNotification2.type = new messages_1.ProtocolNotificationType(WorkDoneProgressCancelNotification2.method);
  })(WorkDoneProgressCancelNotification || (protocol_progress.WorkDoneProgressCancelNotification = WorkDoneProgressCancelNotification = {}));
  return protocol_progress;
}
var protocol_callHierarchy = {};
var hasRequiredProtocol_callHierarchy;
function requireProtocol_callHierarchy() {
  if (hasRequiredProtocol_callHierarchy) return protocol_callHierarchy;
  hasRequiredProtocol_callHierarchy = 1;
  Object.defineProperty(protocol_callHierarchy, "__esModule", {
    value: true
  });
  protocol_callHierarchy.CallHierarchyOutgoingCallsRequest = protocol_callHierarchy.CallHierarchyIncomingCallsRequest = protocol_callHierarchy.CallHierarchyPrepareRequest = void 0;
  const messages_1 = requireMessages();
  var CallHierarchyPrepareRequest;
  (function(CallHierarchyPrepareRequest2) {
    CallHierarchyPrepareRequest2.method = "textDocument/prepareCallHierarchy";
    CallHierarchyPrepareRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
    CallHierarchyPrepareRequest2.type = new messages_1.ProtocolRequestType(CallHierarchyPrepareRequest2.method);
  })(CallHierarchyPrepareRequest || (protocol_callHierarchy.CallHierarchyPrepareRequest = CallHierarchyPrepareRequest = {}));
  var CallHierarchyIncomingCallsRequest;
  (function(CallHierarchyIncomingCallsRequest2) {
    CallHierarchyIncomingCallsRequest2.method = "callHierarchy/incomingCalls";
    CallHierarchyIncomingCallsRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
    CallHierarchyIncomingCallsRequest2.type = new messages_1.ProtocolRequestType(CallHierarchyIncomingCallsRequest2.method);
  })(CallHierarchyIncomingCallsRequest || (protocol_callHierarchy.CallHierarchyIncomingCallsRequest = CallHierarchyIncomingCallsRequest = {}));
  var CallHierarchyOutgoingCallsRequest;
  (function(CallHierarchyOutgoingCallsRequest2) {
    CallHierarchyOutgoingCallsRequest2.method = "callHierarchy/outgoingCalls";
    CallHierarchyOutgoingCallsRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
    CallHierarchyOutgoingCallsRequest2.type = new messages_1.ProtocolRequestType(CallHierarchyOutgoingCallsRequest2.method);
  })(CallHierarchyOutgoingCallsRequest || (protocol_callHierarchy.CallHierarchyOutgoingCallsRequest = CallHierarchyOutgoingCallsRequest = {}));
  return protocol_callHierarchy;
}
var protocol_semanticTokens = {};
var hasRequiredProtocol_semanticTokens;
function requireProtocol_semanticTokens() {
  if (hasRequiredProtocol_semanticTokens) return protocol_semanticTokens;
  hasRequiredProtocol_semanticTokens = 1;
  Object.defineProperty(protocol_semanticTokens, "__esModule", {
    value: true
  });
  protocol_semanticTokens.SemanticTokensRefreshRequest = protocol_semanticTokens.SemanticTokensRangeRequest = protocol_semanticTokens.SemanticTokensDeltaRequest = protocol_semanticTokens.SemanticTokensRequest = protocol_semanticTokens.SemanticTokensRegistrationType = protocol_semanticTokens.TokenFormat = void 0;
  const messages_1 = requireMessages();
  var TokenFormat;
  (function(TokenFormat2) {
    TokenFormat2.Relative = "relative";
  })(TokenFormat || (protocol_semanticTokens.TokenFormat = TokenFormat = {}));
  var SemanticTokensRegistrationType;
  (function(SemanticTokensRegistrationType2) {
    SemanticTokensRegistrationType2.method = "textDocument/semanticTokens";
    SemanticTokensRegistrationType2.type = new messages_1.RegistrationType(SemanticTokensRegistrationType2.method);
  })(SemanticTokensRegistrationType || (protocol_semanticTokens.SemanticTokensRegistrationType = SemanticTokensRegistrationType = {}));
  var SemanticTokensRequest;
  (function(SemanticTokensRequest2) {
    SemanticTokensRequest2.method = "textDocument/semanticTokens/full";
    SemanticTokensRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
    SemanticTokensRequest2.type = new messages_1.ProtocolRequestType(SemanticTokensRequest2.method);
    SemanticTokensRequest2.registrationMethod = SemanticTokensRegistrationType.method;
  })(SemanticTokensRequest || (protocol_semanticTokens.SemanticTokensRequest = SemanticTokensRequest = {}));
  var SemanticTokensDeltaRequest;
  (function(SemanticTokensDeltaRequest2) {
    SemanticTokensDeltaRequest2.method = "textDocument/semanticTokens/full/delta";
    SemanticTokensDeltaRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
    SemanticTokensDeltaRequest2.type = new messages_1.ProtocolRequestType(SemanticTokensDeltaRequest2.method);
    SemanticTokensDeltaRequest2.registrationMethod = SemanticTokensRegistrationType.method;
  })(SemanticTokensDeltaRequest || (protocol_semanticTokens.SemanticTokensDeltaRequest = SemanticTokensDeltaRequest = {}));
  var SemanticTokensRangeRequest;
  (function(SemanticTokensRangeRequest2) {
    SemanticTokensRangeRequest2.method = "textDocument/semanticTokens/range";
    SemanticTokensRangeRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
    SemanticTokensRangeRequest2.type = new messages_1.ProtocolRequestType(SemanticTokensRangeRequest2.method);
    SemanticTokensRangeRequest2.registrationMethod = SemanticTokensRegistrationType.method;
  })(SemanticTokensRangeRequest || (protocol_semanticTokens.SemanticTokensRangeRequest = SemanticTokensRangeRequest = {}));
  var SemanticTokensRefreshRequest;
  (function(SemanticTokensRefreshRequest2) {
    SemanticTokensRefreshRequest2.method = `workspace/semanticTokens/refresh`;
    SemanticTokensRefreshRequest2.messageDirection = messages_1.MessageDirection.serverToClient;
    SemanticTokensRefreshRequest2.type = new messages_1.ProtocolRequestType0(SemanticTokensRefreshRequest2.method);
  })(SemanticTokensRefreshRequest || (protocol_semanticTokens.SemanticTokensRefreshRequest = SemanticTokensRefreshRequest = {}));
  return protocol_semanticTokens;
}
var protocol_showDocument = {};
var hasRequiredProtocol_showDocument;
function requireProtocol_showDocument() {
  if (hasRequiredProtocol_showDocument) return protocol_showDocument;
  hasRequiredProtocol_showDocument = 1;
  Object.defineProperty(protocol_showDocument, "__esModule", {
    value: true
  });
  protocol_showDocument.ShowDocumentRequest = void 0;
  const messages_1 = requireMessages();
  var ShowDocumentRequest;
  (function(ShowDocumentRequest2) {
    ShowDocumentRequest2.method = "window/showDocument";
    ShowDocumentRequest2.messageDirection = messages_1.MessageDirection.serverToClient;
    ShowDocumentRequest2.type = new messages_1.ProtocolRequestType(ShowDocumentRequest2.method);
  })(ShowDocumentRequest || (protocol_showDocument.ShowDocumentRequest = ShowDocumentRequest = {}));
  return protocol_showDocument;
}
var protocol_linkedEditingRange = {};
var hasRequiredProtocol_linkedEditingRange;
function requireProtocol_linkedEditingRange() {
  if (hasRequiredProtocol_linkedEditingRange) return protocol_linkedEditingRange;
  hasRequiredProtocol_linkedEditingRange = 1;
  Object.defineProperty(protocol_linkedEditingRange, "__esModule", {
    value: true
  });
  protocol_linkedEditingRange.LinkedEditingRangeRequest = void 0;
  const messages_1 = requireMessages();
  var LinkedEditingRangeRequest;
  (function(LinkedEditingRangeRequest2) {
    LinkedEditingRangeRequest2.method = "textDocument/linkedEditingRange";
    LinkedEditingRangeRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
    LinkedEditingRangeRequest2.type = new messages_1.ProtocolRequestType(LinkedEditingRangeRequest2.method);
  })(LinkedEditingRangeRequest || (protocol_linkedEditingRange.LinkedEditingRangeRequest = LinkedEditingRangeRequest = {}));
  return protocol_linkedEditingRange;
}
var protocol_fileOperations = {};
var hasRequiredProtocol_fileOperations;
function requireProtocol_fileOperations() {
  if (hasRequiredProtocol_fileOperations) return protocol_fileOperations;
  hasRequiredProtocol_fileOperations = 1;
  Object.defineProperty(protocol_fileOperations, "__esModule", {
    value: true
  });
  protocol_fileOperations.WillDeleteFilesRequest = protocol_fileOperations.DidDeleteFilesNotification = protocol_fileOperations.DidRenameFilesNotification = protocol_fileOperations.WillRenameFilesRequest = protocol_fileOperations.DidCreateFilesNotification = protocol_fileOperations.WillCreateFilesRequest = protocol_fileOperations.FileOperationPatternKind = void 0;
  const messages_1 = requireMessages();
  var FileOperationPatternKind;
  (function(FileOperationPatternKind2) {
    FileOperationPatternKind2.file = "file";
    FileOperationPatternKind2.folder = "folder";
  })(FileOperationPatternKind || (protocol_fileOperations.FileOperationPatternKind = FileOperationPatternKind = {}));
  var WillCreateFilesRequest;
  (function(WillCreateFilesRequest2) {
    WillCreateFilesRequest2.method = "workspace/willCreateFiles";
    WillCreateFilesRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
    WillCreateFilesRequest2.type = new messages_1.ProtocolRequestType(WillCreateFilesRequest2.method);
  })(WillCreateFilesRequest || (protocol_fileOperations.WillCreateFilesRequest = WillCreateFilesRequest = {}));
  var DidCreateFilesNotification;
  (function(DidCreateFilesNotification2) {
    DidCreateFilesNotification2.method = "workspace/didCreateFiles";
    DidCreateFilesNotification2.messageDirection = messages_1.MessageDirection.clientToServer;
    DidCreateFilesNotification2.type = new messages_1.ProtocolNotificationType(DidCreateFilesNotification2.method);
  })(DidCreateFilesNotification || (protocol_fileOperations.DidCreateFilesNotification = DidCreateFilesNotification = {}));
  var WillRenameFilesRequest;
  (function(WillRenameFilesRequest2) {
    WillRenameFilesRequest2.method = "workspace/willRenameFiles";
    WillRenameFilesRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
    WillRenameFilesRequest2.type = new messages_1.ProtocolRequestType(WillRenameFilesRequest2.method);
  })(WillRenameFilesRequest || (protocol_fileOperations.WillRenameFilesRequest = WillRenameFilesRequest = {}));
  var DidRenameFilesNotification;
  (function(DidRenameFilesNotification2) {
    DidRenameFilesNotification2.method = "workspace/didRenameFiles";
    DidRenameFilesNotification2.messageDirection = messages_1.MessageDirection.clientToServer;
    DidRenameFilesNotification2.type = new messages_1.ProtocolNotificationType(DidRenameFilesNotification2.method);
  })(DidRenameFilesNotification || (protocol_fileOperations.DidRenameFilesNotification = DidRenameFilesNotification = {}));
  var DidDeleteFilesNotification;
  (function(DidDeleteFilesNotification2) {
    DidDeleteFilesNotification2.method = "workspace/didDeleteFiles";
    DidDeleteFilesNotification2.messageDirection = messages_1.MessageDirection.clientToServer;
    DidDeleteFilesNotification2.type = new messages_1.ProtocolNotificationType(DidDeleteFilesNotification2.method);
  })(DidDeleteFilesNotification || (protocol_fileOperations.DidDeleteFilesNotification = DidDeleteFilesNotification = {}));
  var WillDeleteFilesRequest;
  (function(WillDeleteFilesRequest2) {
    WillDeleteFilesRequest2.method = "workspace/willDeleteFiles";
    WillDeleteFilesRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
    WillDeleteFilesRequest2.type = new messages_1.ProtocolRequestType(WillDeleteFilesRequest2.method);
  })(WillDeleteFilesRequest || (protocol_fileOperations.WillDeleteFilesRequest = WillDeleteFilesRequest = {}));
  return protocol_fileOperations;
}
var protocol_moniker = {};
var hasRequiredProtocol_moniker;
function requireProtocol_moniker() {
  if (hasRequiredProtocol_moniker) return protocol_moniker;
  hasRequiredProtocol_moniker = 1;
  Object.defineProperty(protocol_moniker, "__esModule", {
    value: true
  });
  protocol_moniker.MonikerRequest = protocol_moniker.MonikerKind = protocol_moniker.UniquenessLevel = void 0;
  const messages_1 = requireMessages();
  var UniquenessLevel;
  (function(UniquenessLevel2) {
    UniquenessLevel2.document = "document";
    UniquenessLevel2.project = "project";
    UniquenessLevel2.group = "group";
    UniquenessLevel2.scheme = "scheme";
    UniquenessLevel2.global = "global";
  })(UniquenessLevel || (protocol_moniker.UniquenessLevel = UniquenessLevel = {}));
  var MonikerKind;
  (function(MonikerKind2) {
    MonikerKind2.$import = "import";
    MonikerKind2.$export = "export";
    MonikerKind2.local = "local";
  })(MonikerKind || (protocol_moniker.MonikerKind = MonikerKind = {}));
  var MonikerRequest;
  (function(MonikerRequest2) {
    MonikerRequest2.method = "textDocument/moniker";
    MonikerRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
    MonikerRequest2.type = new messages_1.ProtocolRequestType(MonikerRequest2.method);
  })(MonikerRequest || (protocol_moniker.MonikerRequest = MonikerRequest = {}));
  return protocol_moniker;
}
var protocol_typeHierarchy = {};
var hasRequiredProtocol_typeHierarchy;
function requireProtocol_typeHierarchy() {
  if (hasRequiredProtocol_typeHierarchy) return protocol_typeHierarchy;
  hasRequiredProtocol_typeHierarchy = 1;
  Object.defineProperty(protocol_typeHierarchy, "__esModule", {
    value: true
  });
  protocol_typeHierarchy.TypeHierarchySubtypesRequest = protocol_typeHierarchy.TypeHierarchySupertypesRequest = protocol_typeHierarchy.TypeHierarchyPrepareRequest = void 0;
  const messages_1 = requireMessages();
  var TypeHierarchyPrepareRequest;
  (function(TypeHierarchyPrepareRequest2) {
    TypeHierarchyPrepareRequest2.method = "textDocument/prepareTypeHierarchy";
    TypeHierarchyPrepareRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
    TypeHierarchyPrepareRequest2.type = new messages_1.ProtocolRequestType(TypeHierarchyPrepareRequest2.method);
  })(TypeHierarchyPrepareRequest || (protocol_typeHierarchy.TypeHierarchyPrepareRequest = TypeHierarchyPrepareRequest = {}));
  var TypeHierarchySupertypesRequest;
  (function(TypeHierarchySupertypesRequest2) {
    TypeHierarchySupertypesRequest2.method = "typeHierarchy/supertypes";
    TypeHierarchySupertypesRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
    TypeHierarchySupertypesRequest2.type = new messages_1.ProtocolRequestType(TypeHierarchySupertypesRequest2.method);
  })(TypeHierarchySupertypesRequest || (protocol_typeHierarchy.TypeHierarchySupertypesRequest = TypeHierarchySupertypesRequest = {}));
  var TypeHierarchySubtypesRequest;
  (function(TypeHierarchySubtypesRequest2) {
    TypeHierarchySubtypesRequest2.method = "typeHierarchy/subtypes";
    TypeHierarchySubtypesRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
    TypeHierarchySubtypesRequest2.type = new messages_1.ProtocolRequestType(TypeHierarchySubtypesRequest2.method);
  })(TypeHierarchySubtypesRequest || (protocol_typeHierarchy.TypeHierarchySubtypesRequest = TypeHierarchySubtypesRequest = {}));
  return protocol_typeHierarchy;
}
var protocol_inlineValue = {};
var hasRequiredProtocol_inlineValue;
function requireProtocol_inlineValue() {
  if (hasRequiredProtocol_inlineValue) return protocol_inlineValue;
  hasRequiredProtocol_inlineValue = 1;
  Object.defineProperty(protocol_inlineValue, "__esModule", {
    value: true
  });
  protocol_inlineValue.InlineValueRefreshRequest = protocol_inlineValue.InlineValueRequest = void 0;
  const messages_1 = requireMessages();
  var InlineValueRequest;
  (function(InlineValueRequest2) {
    InlineValueRequest2.method = "textDocument/inlineValue";
    InlineValueRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
    InlineValueRequest2.type = new messages_1.ProtocolRequestType(InlineValueRequest2.method);
  })(InlineValueRequest || (protocol_inlineValue.InlineValueRequest = InlineValueRequest = {}));
  var InlineValueRefreshRequest;
  (function(InlineValueRefreshRequest2) {
    InlineValueRefreshRequest2.method = `workspace/inlineValue/refresh`;
    InlineValueRefreshRequest2.messageDirection = messages_1.MessageDirection.serverToClient;
    InlineValueRefreshRequest2.type = new messages_1.ProtocolRequestType0(InlineValueRefreshRequest2.method);
  })(InlineValueRefreshRequest || (protocol_inlineValue.InlineValueRefreshRequest = InlineValueRefreshRequest = {}));
  return protocol_inlineValue;
}
var protocol_inlayHint = {};
var hasRequiredProtocol_inlayHint;
function requireProtocol_inlayHint() {
  if (hasRequiredProtocol_inlayHint) return protocol_inlayHint;
  hasRequiredProtocol_inlayHint = 1;
  Object.defineProperty(protocol_inlayHint, "__esModule", {
    value: true
  });
  protocol_inlayHint.InlayHintRefreshRequest = protocol_inlayHint.InlayHintResolveRequest = protocol_inlayHint.InlayHintRequest = void 0;
  const messages_1 = requireMessages();
  var InlayHintRequest;
  (function(InlayHintRequest2) {
    InlayHintRequest2.method = "textDocument/inlayHint";
    InlayHintRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
    InlayHintRequest2.type = new messages_1.ProtocolRequestType(InlayHintRequest2.method);
  })(InlayHintRequest || (protocol_inlayHint.InlayHintRequest = InlayHintRequest = {}));
  var InlayHintResolveRequest;
  (function(InlayHintResolveRequest2) {
    InlayHintResolveRequest2.method = "inlayHint/resolve";
    InlayHintResolveRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
    InlayHintResolveRequest2.type = new messages_1.ProtocolRequestType(InlayHintResolveRequest2.method);
  })(InlayHintResolveRequest || (protocol_inlayHint.InlayHintResolveRequest = InlayHintResolveRequest = {}));
  var InlayHintRefreshRequest;
  (function(InlayHintRefreshRequest2) {
    InlayHintRefreshRequest2.method = `workspace/inlayHint/refresh`;
    InlayHintRefreshRequest2.messageDirection = messages_1.MessageDirection.serverToClient;
    InlayHintRefreshRequest2.type = new messages_1.ProtocolRequestType0(InlayHintRefreshRequest2.method);
  })(InlayHintRefreshRequest || (protocol_inlayHint.InlayHintRefreshRequest = InlayHintRefreshRequest = {}));
  return protocol_inlayHint;
}
var protocol_diagnostic = {};
var hasRequiredProtocol_diagnostic;
function requireProtocol_diagnostic() {
  if (hasRequiredProtocol_diagnostic) return protocol_diagnostic;
  hasRequiredProtocol_diagnostic = 1;
  Object.defineProperty(protocol_diagnostic, "__esModule", {
    value: true
  });
  protocol_diagnostic.DiagnosticRefreshRequest = protocol_diagnostic.WorkspaceDiagnosticRequest = protocol_diagnostic.DocumentDiagnosticRequest = protocol_diagnostic.DocumentDiagnosticReportKind = protocol_diagnostic.DiagnosticServerCancellationData = void 0;
  const vscode_jsonrpc_1 = requireMain$3();
  const Is = requireIs();
  const messages_1 = requireMessages();
  var DiagnosticServerCancellationData;
  (function(DiagnosticServerCancellationData2) {
    function is2(value) {
      const candidate = value;
      return candidate && Is.boolean(candidate.retriggerRequest);
    }
    DiagnosticServerCancellationData2.is = is2;
  })(DiagnosticServerCancellationData || (protocol_diagnostic.DiagnosticServerCancellationData = DiagnosticServerCancellationData = {}));
  var DocumentDiagnosticReportKind;
  (function(DocumentDiagnosticReportKind2) {
    DocumentDiagnosticReportKind2.Full = "full";
    DocumentDiagnosticReportKind2.Unchanged = "unchanged";
  })(DocumentDiagnosticReportKind || (protocol_diagnostic.DocumentDiagnosticReportKind = DocumentDiagnosticReportKind = {}));
  var DocumentDiagnosticRequest;
  (function(DocumentDiagnosticRequest2) {
    DocumentDiagnosticRequest2.method = "textDocument/diagnostic";
    DocumentDiagnosticRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
    DocumentDiagnosticRequest2.type = new messages_1.ProtocolRequestType(DocumentDiagnosticRequest2.method);
    DocumentDiagnosticRequest2.partialResult = new vscode_jsonrpc_1.ProgressType();
  })(DocumentDiagnosticRequest || (protocol_diagnostic.DocumentDiagnosticRequest = DocumentDiagnosticRequest = {}));
  var WorkspaceDiagnosticRequest;
  (function(WorkspaceDiagnosticRequest2) {
    WorkspaceDiagnosticRequest2.method = "workspace/diagnostic";
    WorkspaceDiagnosticRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
    WorkspaceDiagnosticRequest2.type = new messages_1.ProtocolRequestType(WorkspaceDiagnosticRequest2.method);
    WorkspaceDiagnosticRequest2.partialResult = new vscode_jsonrpc_1.ProgressType();
  })(WorkspaceDiagnosticRequest || (protocol_diagnostic.WorkspaceDiagnosticRequest = WorkspaceDiagnosticRequest = {}));
  var DiagnosticRefreshRequest;
  (function(DiagnosticRefreshRequest2) {
    DiagnosticRefreshRequest2.method = `workspace/diagnostic/refresh`;
    DiagnosticRefreshRequest2.messageDirection = messages_1.MessageDirection.serverToClient;
    DiagnosticRefreshRequest2.type = new messages_1.ProtocolRequestType0(DiagnosticRefreshRequest2.method);
  })(DiagnosticRefreshRequest || (protocol_diagnostic.DiagnosticRefreshRequest = DiagnosticRefreshRequest = {}));
  return protocol_diagnostic;
}
var protocol_notebook = {};
var hasRequiredProtocol_notebook;
function requireProtocol_notebook() {
  if (hasRequiredProtocol_notebook) return protocol_notebook;
  hasRequiredProtocol_notebook = 1;
  Object.defineProperty(protocol_notebook, "__esModule", {
    value: true
  });
  protocol_notebook.DidCloseNotebookDocumentNotification = protocol_notebook.DidSaveNotebookDocumentNotification = protocol_notebook.DidChangeNotebookDocumentNotification = protocol_notebook.NotebookCellArrayChange = protocol_notebook.DidOpenNotebookDocumentNotification = protocol_notebook.NotebookDocumentSyncRegistrationType = protocol_notebook.NotebookDocument = protocol_notebook.NotebookCell = protocol_notebook.ExecutionSummary = protocol_notebook.NotebookCellKind = void 0;
  const vscode_languageserver_types_1 = requireMain$2();
  const Is = requireIs();
  const messages_1 = requireMessages();
  var NotebookCellKind;
  (function(NotebookCellKind2) {
    NotebookCellKind2.Markup = 1;
    NotebookCellKind2.Code = 2;
    function is2(value) {
      return value === 1 || value === 2;
    }
    NotebookCellKind2.is = is2;
  })(NotebookCellKind || (protocol_notebook.NotebookCellKind = NotebookCellKind = {}));
  var ExecutionSummary;
  (function(ExecutionSummary2) {
    function create(executionOrder, success) {
      const result = {
        executionOrder
      };
      if (success === true || success === false) {
        result.success = success;
      }
      return result;
    }
    ExecutionSummary2.create = create;
    function is2(value) {
      const candidate = value;
      return Is.objectLiteral(candidate) && vscode_languageserver_types_1.uinteger.is(candidate.executionOrder) && (candidate.success === void 0 || Is.boolean(candidate.success));
    }
    ExecutionSummary2.is = is2;
    function equals2(one, other) {
      if (one === other) {
        return true;
      }
      if (one === null || one === void 0 || other === null || other === void 0) {
        return false;
      }
      return one.executionOrder === other.executionOrder && one.success === other.success;
    }
    ExecutionSummary2.equals = equals2;
  })(ExecutionSummary || (protocol_notebook.ExecutionSummary = ExecutionSummary = {}));
  var NotebookCell;
  (function(NotebookCell2) {
    function create(kind, document) {
      return {
        kind,
        document
      };
    }
    NotebookCell2.create = create;
    function is2(value) {
      const candidate = value;
      return Is.objectLiteral(candidate) && NotebookCellKind.is(candidate.kind) && vscode_languageserver_types_1.DocumentUri.is(candidate.document) && (candidate.metadata === void 0 || Is.objectLiteral(candidate.metadata));
    }
    NotebookCell2.is = is2;
    function diff(one, two) {
      const result = /* @__PURE__ */ new Set();
      if (one.document !== two.document) {
        result.add("document");
      }
      if (one.kind !== two.kind) {
        result.add("kind");
      }
      if (one.executionSummary !== two.executionSummary) {
        result.add("executionSummary");
      }
      if ((one.metadata !== void 0 || two.metadata !== void 0) && !equalsMetadata(one.metadata, two.metadata)) {
        result.add("metadata");
      }
      if ((one.executionSummary !== void 0 || two.executionSummary !== void 0) && !ExecutionSummary.equals(one.executionSummary, two.executionSummary)) {
        result.add("executionSummary");
      }
      return result;
    }
    NotebookCell2.diff = diff;
    function equalsMetadata(one, other) {
      if (one === other) {
        return true;
      }
      if (one === null || one === void 0 || other === null || other === void 0) {
        return false;
      }
      if (typeof one !== typeof other) {
        return false;
      }
      if (typeof one !== "object") {
        return false;
      }
      const oneArray = Array.isArray(one);
      const otherArray = Array.isArray(other);
      if (oneArray !== otherArray) {
        return false;
      }
      if (oneArray && otherArray) {
        if (one.length !== other.length) {
          return false;
        }
        for (let i = 0; i < one.length; i++) {
          if (!equalsMetadata(one[i], other[i])) {
            return false;
          }
        }
      }
      if (Is.objectLiteral(one) && Is.objectLiteral(other)) {
        const oneKeys = Object.keys(one);
        const otherKeys = Object.keys(other);
        if (oneKeys.length !== otherKeys.length) {
          return false;
        }
        oneKeys.sort();
        otherKeys.sort();
        if (!equalsMetadata(oneKeys, otherKeys)) {
          return false;
        }
        for (let i = 0; i < oneKeys.length; i++) {
          const prop = oneKeys[i];
          if (!equalsMetadata(one[prop], other[prop])) {
            return false;
          }
        }
      }
      return true;
    }
  })(NotebookCell || (protocol_notebook.NotebookCell = NotebookCell = {}));
  var NotebookDocument;
  (function(NotebookDocument2) {
    function create(uri, notebookType, version2, cells) {
      return {
        uri,
        notebookType,
        version: version2,
        cells
      };
    }
    NotebookDocument2.create = create;
    function is2(value) {
      const candidate = value;
      return Is.objectLiteral(candidate) && Is.string(candidate.uri) && vscode_languageserver_types_1.integer.is(candidate.version) && Is.typedArray(candidate.cells, NotebookCell.is);
    }
    NotebookDocument2.is = is2;
  })(NotebookDocument || (protocol_notebook.NotebookDocument = NotebookDocument = {}));
  var NotebookDocumentSyncRegistrationType;
  (function(NotebookDocumentSyncRegistrationType2) {
    NotebookDocumentSyncRegistrationType2.method = "notebookDocument/sync";
    NotebookDocumentSyncRegistrationType2.messageDirection = messages_1.MessageDirection.clientToServer;
    NotebookDocumentSyncRegistrationType2.type = new messages_1.RegistrationType(NotebookDocumentSyncRegistrationType2.method);
  })(NotebookDocumentSyncRegistrationType || (protocol_notebook.NotebookDocumentSyncRegistrationType = NotebookDocumentSyncRegistrationType = {}));
  var DidOpenNotebookDocumentNotification;
  (function(DidOpenNotebookDocumentNotification2) {
    DidOpenNotebookDocumentNotification2.method = "notebookDocument/didOpen";
    DidOpenNotebookDocumentNotification2.messageDirection = messages_1.MessageDirection.clientToServer;
    DidOpenNotebookDocumentNotification2.type = new messages_1.ProtocolNotificationType(DidOpenNotebookDocumentNotification2.method);
    DidOpenNotebookDocumentNotification2.registrationMethod = NotebookDocumentSyncRegistrationType.method;
  })(DidOpenNotebookDocumentNotification || (protocol_notebook.DidOpenNotebookDocumentNotification = DidOpenNotebookDocumentNotification = {}));
  var NotebookCellArrayChange;
  (function(NotebookCellArrayChange2) {
    function is2(value) {
      const candidate = value;
      return Is.objectLiteral(candidate) && vscode_languageserver_types_1.uinteger.is(candidate.start) && vscode_languageserver_types_1.uinteger.is(candidate.deleteCount) && (candidate.cells === void 0 || Is.typedArray(candidate.cells, NotebookCell.is));
    }
    NotebookCellArrayChange2.is = is2;
    function create(start, deleteCount, cells) {
      const result = {
        start,
        deleteCount
      };
      if (cells !== void 0) {
        result.cells = cells;
      }
      return result;
    }
    NotebookCellArrayChange2.create = create;
  })(NotebookCellArrayChange || (protocol_notebook.NotebookCellArrayChange = NotebookCellArrayChange = {}));
  var DidChangeNotebookDocumentNotification;
  (function(DidChangeNotebookDocumentNotification2) {
    DidChangeNotebookDocumentNotification2.method = "notebookDocument/didChange";
    DidChangeNotebookDocumentNotification2.messageDirection = messages_1.MessageDirection.clientToServer;
    DidChangeNotebookDocumentNotification2.type = new messages_1.ProtocolNotificationType(DidChangeNotebookDocumentNotification2.method);
    DidChangeNotebookDocumentNotification2.registrationMethod = NotebookDocumentSyncRegistrationType.method;
  })(DidChangeNotebookDocumentNotification || (protocol_notebook.DidChangeNotebookDocumentNotification = DidChangeNotebookDocumentNotification = {}));
  var DidSaveNotebookDocumentNotification;
  (function(DidSaveNotebookDocumentNotification2) {
    DidSaveNotebookDocumentNotification2.method = "notebookDocument/didSave";
    DidSaveNotebookDocumentNotification2.messageDirection = messages_1.MessageDirection.clientToServer;
    DidSaveNotebookDocumentNotification2.type = new messages_1.ProtocolNotificationType(DidSaveNotebookDocumentNotification2.method);
    DidSaveNotebookDocumentNotification2.registrationMethod = NotebookDocumentSyncRegistrationType.method;
  })(DidSaveNotebookDocumentNotification || (protocol_notebook.DidSaveNotebookDocumentNotification = DidSaveNotebookDocumentNotification = {}));
  var DidCloseNotebookDocumentNotification;
  (function(DidCloseNotebookDocumentNotification2) {
    DidCloseNotebookDocumentNotification2.method = "notebookDocument/didClose";
    DidCloseNotebookDocumentNotification2.messageDirection = messages_1.MessageDirection.clientToServer;
    DidCloseNotebookDocumentNotification2.type = new messages_1.ProtocolNotificationType(DidCloseNotebookDocumentNotification2.method);
    DidCloseNotebookDocumentNotification2.registrationMethod = NotebookDocumentSyncRegistrationType.method;
  })(DidCloseNotebookDocumentNotification || (protocol_notebook.DidCloseNotebookDocumentNotification = DidCloseNotebookDocumentNotification = {}));
  return protocol_notebook;
}
var protocol_inlineCompletion = {};
var hasRequiredProtocol_inlineCompletion;
function requireProtocol_inlineCompletion() {
  if (hasRequiredProtocol_inlineCompletion) return protocol_inlineCompletion;
  hasRequiredProtocol_inlineCompletion = 1;
  Object.defineProperty(protocol_inlineCompletion, "__esModule", {
    value: true
  });
  protocol_inlineCompletion.InlineCompletionRequest = void 0;
  const messages_1 = requireMessages();
  var InlineCompletionRequest;
  (function(InlineCompletionRequest2) {
    InlineCompletionRequest2.method = "textDocument/inlineCompletion";
    InlineCompletionRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
    InlineCompletionRequest2.type = new messages_1.ProtocolRequestType(InlineCompletionRequest2.method);
  })(InlineCompletionRequest || (protocol_inlineCompletion.InlineCompletionRequest = InlineCompletionRequest = {}));
  return protocol_inlineCompletion;
}
var hasRequiredProtocol;
function requireProtocol() {
  if (hasRequiredProtocol) return protocol;
  hasRequiredProtocol = 1;
  (function(exports) {
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.WorkspaceSymbolRequest = exports.CodeActionResolveRequest = exports.CodeActionRequest = exports.DocumentSymbolRequest = exports.DocumentHighlightRequest = exports.ReferencesRequest = exports.DefinitionRequest = exports.SignatureHelpRequest = exports.SignatureHelpTriggerKind = exports.HoverRequest = exports.CompletionResolveRequest = exports.CompletionRequest = exports.CompletionTriggerKind = exports.PublishDiagnosticsNotification = exports.WatchKind = exports.RelativePattern = exports.FileChangeType = exports.DidChangeWatchedFilesNotification = exports.WillSaveTextDocumentWaitUntilRequest = exports.WillSaveTextDocumentNotification = exports.TextDocumentSaveReason = exports.DidSaveTextDocumentNotification = exports.DidCloseTextDocumentNotification = exports.DidChangeTextDocumentNotification = exports.TextDocumentContentChangeEvent = exports.DidOpenTextDocumentNotification = exports.TextDocumentSyncKind = exports.TelemetryEventNotification = exports.LogMessageNotification = exports.ShowMessageRequest = exports.ShowMessageNotification = exports.MessageType = exports.DidChangeConfigurationNotification = exports.ExitNotification = exports.ShutdownRequest = exports.InitializedNotification = exports.InitializeErrorCodes = exports.InitializeRequest = exports.WorkDoneProgressOptions = exports.TextDocumentRegistrationOptions = exports.StaticRegistrationOptions = exports.PositionEncodingKind = exports.FailureHandlingKind = exports.ResourceOperationKind = exports.UnregistrationRequest = exports.RegistrationRequest = exports.DocumentSelector = exports.NotebookCellTextDocumentFilter = exports.NotebookDocumentFilter = exports.TextDocumentFilter = void 0;
    exports.MonikerRequest = exports.MonikerKind = exports.UniquenessLevel = exports.WillDeleteFilesRequest = exports.DidDeleteFilesNotification = exports.WillRenameFilesRequest = exports.DidRenameFilesNotification = exports.WillCreateFilesRequest = exports.DidCreateFilesNotification = exports.FileOperationPatternKind = exports.LinkedEditingRangeRequest = exports.ShowDocumentRequest = exports.SemanticTokensRegistrationType = exports.SemanticTokensRefreshRequest = exports.SemanticTokensRangeRequest = exports.SemanticTokensDeltaRequest = exports.SemanticTokensRequest = exports.TokenFormat = exports.CallHierarchyPrepareRequest = exports.CallHierarchyOutgoingCallsRequest = exports.CallHierarchyIncomingCallsRequest = exports.WorkDoneProgressCancelNotification = exports.WorkDoneProgressCreateRequest = exports.WorkDoneProgress = exports.SelectionRangeRequest = exports.DeclarationRequest = exports.FoldingRangeRefreshRequest = exports.FoldingRangeRequest = exports.ColorPresentationRequest = exports.DocumentColorRequest = exports.ConfigurationRequest = exports.DidChangeWorkspaceFoldersNotification = exports.WorkspaceFoldersRequest = exports.TypeDefinitionRequest = exports.ImplementationRequest = exports.ApplyWorkspaceEditRequest = exports.ExecuteCommandRequest = exports.PrepareRenameRequest = exports.RenameRequest = exports.PrepareSupportDefaultBehavior = exports.DocumentOnTypeFormattingRequest = exports.DocumentRangesFormattingRequest = exports.DocumentRangeFormattingRequest = exports.DocumentFormattingRequest = exports.DocumentLinkResolveRequest = exports.DocumentLinkRequest = exports.CodeLensRefreshRequest = exports.CodeLensResolveRequest = exports.CodeLensRequest = exports.WorkspaceSymbolResolveRequest = void 0;
    exports.InlineCompletionRequest = exports.DidCloseNotebookDocumentNotification = exports.DidSaveNotebookDocumentNotification = exports.DidChangeNotebookDocumentNotification = exports.NotebookCellArrayChange = exports.DidOpenNotebookDocumentNotification = exports.NotebookDocumentSyncRegistrationType = exports.NotebookDocument = exports.NotebookCell = exports.ExecutionSummary = exports.NotebookCellKind = exports.DiagnosticRefreshRequest = exports.WorkspaceDiagnosticRequest = exports.DocumentDiagnosticRequest = exports.DocumentDiagnosticReportKind = exports.DiagnosticServerCancellationData = exports.InlayHintRefreshRequest = exports.InlayHintResolveRequest = exports.InlayHintRequest = exports.InlineValueRefreshRequest = exports.InlineValueRequest = exports.TypeHierarchySupertypesRequest = exports.TypeHierarchySubtypesRequest = exports.TypeHierarchyPrepareRequest = void 0;
    const messages_1 = requireMessages();
    const vscode_languageserver_types_1 = requireMain$2();
    const Is = requireIs();
    const protocol_implementation_1 = requireProtocol_implementation();
    Object.defineProperty(exports, "ImplementationRequest", {
      enumerable: true,
      get: function() {
        return protocol_implementation_1.ImplementationRequest;
      }
    });
    const protocol_typeDefinition_1 = requireProtocol_typeDefinition();
    Object.defineProperty(exports, "TypeDefinitionRequest", {
      enumerable: true,
      get: function() {
        return protocol_typeDefinition_1.TypeDefinitionRequest;
      }
    });
    const protocol_workspaceFolder_1 = requireProtocol_workspaceFolder();
    Object.defineProperty(exports, "WorkspaceFoldersRequest", {
      enumerable: true,
      get: function() {
        return protocol_workspaceFolder_1.WorkspaceFoldersRequest;
      }
    });
    Object.defineProperty(exports, "DidChangeWorkspaceFoldersNotification", {
      enumerable: true,
      get: function() {
        return protocol_workspaceFolder_1.DidChangeWorkspaceFoldersNotification;
      }
    });
    const protocol_configuration_1 = requireProtocol_configuration();
    Object.defineProperty(exports, "ConfigurationRequest", {
      enumerable: true,
      get: function() {
        return protocol_configuration_1.ConfigurationRequest;
      }
    });
    const protocol_colorProvider_1 = requireProtocol_colorProvider();
    Object.defineProperty(exports, "DocumentColorRequest", {
      enumerable: true,
      get: function() {
        return protocol_colorProvider_1.DocumentColorRequest;
      }
    });
    Object.defineProperty(exports, "ColorPresentationRequest", {
      enumerable: true,
      get: function() {
        return protocol_colorProvider_1.ColorPresentationRequest;
      }
    });
    const protocol_foldingRange_1 = requireProtocol_foldingRange();
    Object.defineProperty(exports, "FoldingRangeRequest", {
      enumerable: true,
      get: function() {
        return protocol_foldingRange_1.FoldingRangeRequest;
      }
    });
    Object.defineProperty(exports, "FoldingRangeRefreshRequest", {
      enumerable: true,
      get: function() {
        return protocol_foldingRange_1.FoldingRangeRefreshRequest;
      }
    });
    const protocol_declaration_1 = requireProtocol_declaration();
    Object.defineProperty(exports, "DeclarationRequest", {
      enumerable: true,
      get: function() {
        return protocol_declaration_1.DeclarationRequest;
      }
    });
    const protocol_selectionRange_1 = requireProtocol_selectionRange();
    Object.defineProperty(exports, "SelectionRangeRequest", {
      enumerable: true,
      get: function() {
        return protocol_selectionRange_1.SelectionRangeRequest;
      }
    });
    const protocol_progress_1 = requireProtocol_progress();
    Object.defineProperty(exports, "WorkDoneProgress", {
      enumerable: true,
      get: function() {
        return protocol_progress_1.WorkDoneProgress;
      }
    });
    Object.defineProperty(exports, "WorkDoneProgressCreateRequest", {
      enumerable: true,
      get: function() {
        return protocol_progress_1.WorkDoneProgressCreateRequest;
      }
    });
    Object.defineProperty(exports, "WorkDoneProgressCancelNotification", {
      enumerable: true,
      get: function() {
        return protocol_progress_1.WorkDoneProgressCancelNotification;
      }
    });
    const protocol_callHierarchy_1 = requireProtocol_callHierarchy();
    Object.defineProperty(exports, "CallHierarchyIncomingCallsRequest", {
      enumerable: true,
      get: function() {
        return protocol_callHierarchy_1.CallHierarchyIncomingCallsRequest;
      }
    });
    Object.defineProperty(exports, "CallHierarchyOutgoingCallsRequest", {
      enumerable: true,
      get: function() {
        return protocol_callHierarchy_1.CallHierarchyOutgoingCallsRequest;
      }
    });
    Object.defineProperty(exports, "CallHierarchyPrepareRequest", {
      enumerable: true,
      get: function() {
        return protocol_callHierarchy_1.CallHierarchyPrepareRequest;
      }
    });
    const protocol_semanticTokens_1 = requireProtocol_semanticTokens();
    Object.defineProperty(exports, "TokenFormat", {
      enumerable: true,
      get: function() {
        return protocol_semanticTokens_1.TokenFormat;
      }
    });
    Object.defineProperty(exports, "SemanticTokensRequest", {
      enumerable: true,
      get: function() {
        return protocol_semanticTokens_1.SemanticTokensRequest;
      }
    });
    Object.defineProperty(exports, "SemanticTokensDeltaRequest", {
      enumerable: true,
      get: function() {
        return protocol_semanticTokens_1.SemanticTokensDeltaRequest;
      }
    });
    Object.defineProperty(exports, "SemanticTokensRangeRequest", {
      enumerable: true,
      get: function() {
        return protocol_semanticTokens_1.SemanticTokensRangeRequest;
      }
    });
    Object.defineProperty(exports, "SemanticTokensRefreshRequest", {
      enumerable: true,
      get: function() {
        return protocol_semanticTokens_1.SemanticTokensRefreshRequest;
      }
    });
    Object.defineProperty(exports, "SemanticTokensRegistrationType", {
      enumerable: true,
      get: function() {
        return protocol_semanticTokens_1.SemanticTokensRegistrationType;
      }
    });
    const protocol_showDocument_1 = requireProtocol_showDocument();
    Object.defineProperty(exports, "ShowDocumentRequest", {
      enumerable: true,
      get: function() {
        return protocol_showDocument_1.ShowDocumentRequest;
      }
    });
    const protocol_linkedEditingRange_1 = requireProtocol_linkedEditingRange();
    Object.defineProperty(exports, "LinkedEditingRangeRequest", {
      enumerable: true,
      get: function() {
        return protocol_linkedEditingRange_1.LinkedEditingRangeRequest;
      }
    });
    const protocol_fileOperations_1 = requireProtocol_fileOperations();
    Object.defineProperty(exports, "FileOperationPatternKind", {
      enumerable: true,
      get: function() {
        return protocol_fileOperations_1.FileOperationPatternKind;
      }
    });
    Object.defineProperty(exports, "DidCreateFilesNotification", {
      enumerable: true,
      get: function() {
        return protocol_fileOperations_1.DidCreateFilesNotification;
      }
    });
    Object.defineProperty(exports, "WillCreateFilesRequest", {
      enumerable: true,
      get: function() {
        return protocol_fileOperations_1.WillCreateFilesRequest;
      }
    });
    Object.defineProperty(exports, "DidRenameFilesNotification", {
      enumerable: true,
      get: function() {
        return protocol_fileOperations_1.DidRenameFilesNotification;
      }
    });
    Object.defineProperty(exports, "WillRenameFilesRequest", {
      enumerable: true,
      get: function() {
        return protocol_fileOperations_1.WillRenameFilesRequest;
      }
    });
    Object.defineProperty(exports, "DidDeleteFilesNotification", {
      enumerable: true,
      get: function() {
        return protocol_fileOperations_1.DidDeleteFilesNotification;
      }
    });
    Object.defineProperty(exports, "WillDeleteFilesRequest", {
      enumerable: true,
      get: function() {
        return protocol_fileOperations_1.WillDeleteFilesRequest;
      }
    });
    const protocol_moniker_1 = requireProtocol_moniker();
    Object.defineProperty(exports, "UniquenessLevel", {
      enumerable: true,
      get: function() {
        return protocol_moniker_1.UniquenessLevel;
      }
    });
    Object.defineProperty(exports, "MonikerKind", {
      enumerable: true,
      get: function() {
        return protocol_moniker_1.MonikerKind;
      }
    });
    Object.defineProperty(exports, "MonikerRequest", {
      enumerable: true,
      get: function() {
        return protocol_moniker_1.MonikerRequest;
      }
    });
    const protocol_typeHierarchy_1 = requireProtocol_typeHierarchy();
    Object.defineProperty(exports, "TypeHierarchyPrepareRequest", {
      enumerable: true,
      get: function() {
        return protocol_typeHierarchy_1.TypeHierarchyPrepareRequest;
      }
    });
    Object.defineProperty(exports, "TypeHierarchySubtypesRequest", {
      enumerable: true,
      get: function() {
        return protocol_typeHierarchy_1.TypeHierarchySubtypesRequest;
      }
    });
    Object.defineProperty(exports, "TypeHierarchySupertypesRequest", {
      enumerable: true,
      get: function() {
        return protocol_typeHierarchy_1.TypeHierarchySupertypesRequest;
      }
    });
    const protocol_inlineValue_1 = requireProtocol_inlineValue();
    Object.defineProperty(exports, "InlineValueRequest", {
      enumerable: true,
      get: function() {
        return protocol_inlineValue_1.InlineValueRequest;
      }
    });
    Object.defineProperty(exports, "InlineValueRefreshRequest", {
      enumerable: true,
      get: function() {
        return protocol_inlineValue_1.InlineValueRefreshRequest;
      }
    });
    const protocol_inlayHint_1 = requireProtocol_inlayHint();
    Object.defineProperty(exports, "InlayHintRequest", {
      enumerable: true,
      get: function() {
        return protocol_inlayHint_1.InlayHintRequest;
      }
    });
    Object.defineProperty(exports, "InlayHintResolveRequest", {
      enumerable: true,
      get: function() {
        return protocol_inlayHint_1.InlayHintResolveRequest;
      }
    });
    Object.defineProperty(exports, "InlayHintRefreshRequest", {
      enumerable: true,
      get: function() {
        return protocol_inlayHint_1.InlayHintRefreshRequest;
      }
    });
    const protocol_diagnostic_1 = requireProtocol_diagnostic();
    Object.defineProperty(exports, "DiagnosticServerCancellationData", {
      enumerable: true,
      get: function() {
        return protocol_diagnostic_1.DiagnosticServerCancellationData;
      }
    });
    Object.defineProperty(exports, "DocumentDiagnosticReportKind", {
      enumerable: true,
      get: function() {
        return protocol_diagnostic_1.DocumentDiagnosticReportKind;
      }
    });
    Object.defineProperty(exports, "DocumentDiagnosticRequest", {
      enumerable: true,
      get: function() {
        return protocol_diagnostic_1.DocumentDiagnosticRequest;
      }
    });
    Object.defineProperty(exports, "WorkspaceDiagnosticRequest", {
      enumerable: true,
      get: function() {
        return protocol_diagnostic_1.WorkspaceDiagnosticRequest;
      }
    });
    Object.defineProperty(exports, "DiagnosticRefreshRequest", {
      enumerable: true,
      get: function() {
        return protocol_diagnostic_1.DiagnosticRefreshRequest;
      }
    });
    const protocol_notebook_1 = requireProtocol_notebook();
    Object.defineProperty(exports, "NotebookCellKind", {
      enumerable: true,
      get: function() {
        return protocol_notebook_1.NotebookCellKind;
      }
    });
    Object.defineProperty(exports, "ExecutionSummary", {
      enumerable: true,
      get: function() {
        return protocol_notebook_1.ExecutionSummary;
      }
    });
    Object.defineProperty(exports, "NotebookCell", {
      enumerable: true,
      get: function() {
        return protocol_notebook_1.NotebookCell;
      }
    });
    Object.defineProperty(exports, "NotebookDocument", {
      enumerable: true,
      get: function() {
        return protocol_notebook_1.NotebookDocument;
      }
    });
    Object.defineProperty(exports, "NotebookDocumentSyncRegistrationType", {
      enumerable: true,
      get: function() {
        return protocol_notebook_1.NotebookDocumentSyncRegistrationType;
      }
    });
    Object.defineProperty(exports, "DidOpenNotebookDocumentNotification", {
      enumerable: true,
      get: function() {
        return protocol_notebook_1.DidOpenNotebookDocumentNotification;
      }
    });
    Object.defineProperty(exports, "NotebookCellArrayChange", {
      enumerable: true,
      get: function() {
        return protocol_notebook_1.NotebookCellArrayChange;
      }
    });
    Object.defineProperty(exports, "DidChangeNotebookDocumentNotification", {
      enumerable: true,
      get: function() {
        return protocol_notebook_1.DidChangeNotebookDocumentNotification;
      }
    });
    Object.defineProperty(exports, "DidSaveNotebookDocumentNotification", {
      enumerable: true,
      get: function() {
        return protocol_notebook_1.DidSaveNotebookDocumentNotification;
      }
    });
    Object.defineProperty(exports, "DidCloseNotebookDocumentNotification", {
      enumerable: true,
      get: function() {
        return protocol_notebook_1.DidCloseNotebookDocumentNotification;
      }
    });
    const protocol_inlineCompletion_1 = requireProtocol_inlineCompletion();
    Object.defineProperty(exports, "InlineCompletionRequest", {
      enumerable: true,
      get: function() {
        return protocol_inlineCompletion_1.InlineCompletionRequest;
      }
    });
    var TextDocumentFilter;
    (function(TextDocumentFilter2) {
      function is2(value) {
        const candidate = value;
        return Is.string(candidate) || (Is.string(candidate.language) || Is.string(candidate.scheme) || Is.string(candidate.pattern));
      }
      TextDocumentFilter2.is = is2;
    })(TextDocumentFilter || (exports.TextDocumentFilter = TextDocumentFilter = {}));
    var NotebookDocumentFilter;
    (function(NotebookDocumentFilter2) {
      function is2(value) {
        const candidate = value;
        return Is.objectLiteral(candidate) && (Is.string(candidate.notebookType) || Is.string(candidate.scheme) || Is.string(candidate.pattern));
      }
      NotebookDocumentFilter2.is = is2;
    })(NotebookDocumentFilter || (exports.NotebookDocumentFilter = NotebookDocumentFilter = {}));
    var NotebookCellTextDocumentFilter;
    (function(NotebookCellTextDocumentFilter2) {
      function is2(value) {
        const candidate = value;
        return Is.objectLiteral(candidate) && (Is.string(candidate.notebook) || NotebookDocumentFilter.is(candidate.notebook)) && (candidate.language === void 0 || Is.string(candidate.language));
      }
      NotebookCellTextDocumentFilter2.is = is2;
    })(NotebookCellTextDocumentFilter || (exports.NotebookCellTextDocumentFilter = NotebookCellTextDocumentFilter = {}));
    var DocumentSelector;
    (function(DocumentSelector2) {
      function is2(value) {
        if (!Array.isArray(value)) {
          return false;
        }
        for (let elem of value) {
          if (!Is.string(elem) && !TextDocumentFilter.is(elem) && !NotebookCellTextDocumentFilter.is(elem)) {
            return false;
          }
        }
        return true;
      }
      DocumentSelector2.is = is2;
    })(DocumentSelector || (exports.DocumentSelector = DocumentSelector = {}));
    var RegistrationRequest;
    (function(RegistrationRequest2) {
      RegistrationRequest2.method = "client/registerCapability";
      RegistrationRequest2.messageDirection = messages_1.MessageDirection.serverToClient;
      RegistrationRequest2.type = new messages_1.ProtocolRequestType(RegistrationRequest2.method);
    })(RegistrationRequest || (exports.RegistrationRequest = RegistrationRequest = {}));
    var UnregistrationRequest;
    (function(UnregistrationRequest2) {
      UnregistrationRequest2.method = "client/unregisterCapability";
      UnregistrationRequest2.messageDirection = messages_1.MessageDirection.serverToClient;
      UnregistrationRequest2.type = new messages_1.ProtocolRequestType(UnregistrationRequest2.method);
    })(UnregistrationRequest || (exports.UnregistrationRequest = UnregistrationRequest = {}));
    var ResourceOperationKind;
    (function(ResourceOperationKind2) {
      ResourceOperationKind2.Create = "create";
      ResourceOperationKind2.Rename = "rename";
      ResourceOperationKind2.Delete = "delete";
    })(ResourceOperationKind || (exports.ResourceOperationKind = ResourceOperationKind = {}));
    var FailureHandlingKind;
    (function(FailureHandlingKind2) {
      FailureHandlingKind2.Abort = "abort";
      FailureHandlingKind2.Transactional = "transactional";
      FailureHandlingKind2.TextOnlyTransactional = "textOnlyTransactional";
      FailureHandlingKind2.Undo = "undo";
    })(FailureHandlingKind || (exports.FailureHandlingKind = FailureHandlingKind = {}));
    var PositionEncodingKind;
    (function(PositionEncodingKind2) {
      PositionEncodingKind2.UTF8 = "utf-8";
      PositionEncodingKind2.UTF16 = "utf-16";
      PositionEncodingKind2.UTF32 = "utf-32";
    })(PositionEncodingKind || (exports.PositionEncodingKind = PositionEncodingKind = {}));
    var StaticRegistrationOptions;
    (function(StaticRegistrationOptions2) {
      function hasId(value) {
        const candidate = value;
        return candidate && Is.string(candidate.id) && candidate.id.length > 0;
      }
      StaticRegistrationOptions2.hasId = hasId;
    })(StaticRegistrationOptions || (exports.StaticRegistrationOptions = StaticRegistrationOptions = {}));
    var TextDocumentRegistrationOptions;
    (function(TextDocumentRegistrationOptions2) {
      function is2(value) {
        const candidate = value;
        return candidate && (candidate.documentSelector === null || DocumentSelector.is(candidate.documentSelector));
      }
      TextDocumentRegistrationOptions2.is = is2;
    })(TextDocumentRegistrationOptions || (exports.TextDocumentRegistrationOptions = TextDocumentRegistrationOptions = {}));
    var WorkDoneProgressOptions;
    (function(WorkDoneProgressOptions2) {
      function is2(value) {
        const candidate = value;
        return Is.objectLiteral(candidate) && (candidate.workDoneProgress === void 0 || Is.boolean(candidate.workDoneProgress));
      }
      WorkDoneProgressOptions2.is = is2;
      function hasWorkDoneProgress(value) {
        const candidate = value;
        return candidate && Is.boolean(candidate.workDoneProgress);
      }
      WorkDoneProgressOptions2.hasWorkDoneProgress = hasWorkDoneProgress;
    })(WorkDoneProgressOptions || (exports.WorkDoneProgressOptions = WorkDoneProgressOptions = {}));
    var InitializeRequest;
    (function(InitializeRequest2) {
      InitializeRequest2.method = "initialize";
      InitializeRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
      InitializeRequest2.type = new messages_1.ProtocolRequestType(InitializeRequest2.method);
    })(InitializeRequest || (exports.InitializeRequest = InitializeRequest = {}));
    var InitializeErrorCodes;
    (function(InitializeErrorCodes2) {
      InitializeErrorCodes2.unknownProtocolVersion = 1;
    })(InitializeErrorCodes || (exports.InitializeErrorCodes = InitializeErrorCodes = {}));
    var InitializedNotification;
    (function(InitializedNotification2) {
      InitializedNotification2.method = "initialized";
      InitializedNotification2.messageDirection = messages_1.MessageDirection.clientToServer;
      InitializedNotification2.type = new messages_1.ProtocolNotificationType(InitializedNotification2.method);
    })(InitializedNotification || (exports.InitializedNotification = InitializedNotification = {}));
    var ShutdownRequest;
    (function(ShutdownRequest2) {
      ShutdownRequest2.method = "shutdown";
      ShutdownRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
      ShutdownRequest2.type = new messages_1.ProtocolRequestType0(ShutdownRequest2.method);
    })(ShutdownRequest || (exports.ShutdownRequest = ShutdownRequest = {}));
    var ExitNotification;
    (function(ExitNotification2) {
      ExitNotification2.method = "exit";
      ExitNotification2.messageDirection = messages_1.MessageDirection.clientToServer;
      ExitNotification2.type = new messages_1.ProtocolNotificationType0(ExitNotification2.method);
    })(ExitNotification || (exports.ExitNotification = ExitNotification = {}));
    var DidChangeConfigurationNotification;
    (function(DidChangeConfigurationNotification2) {
      DidChangeConfigurationNotification2.method = "workspace/didChangeConfiguration";
      DidChangeConfigurationNotification2.messageDirection = messages_1.MessageDirection.clientToServer;
      DidChangeConfigurationNotification2.type = new messages_1.ProtocolNotificationType(DidChangeConfigurationNotification2.method);
    })(DidChangeConfigurationNotification || (exports.DidChangeConfigurationNotification = DidChangeConfigurationNotification = {}));
    var MessageType;
    (function(MessageType2) {
      MessageType2.Error = 1;
      MessageType2.Warning = 2;
      MessageType2.Info = 3;
      MessageType2.Log = 4;
      MessageType2.Debug = 5;
    })(MessageType || (exports.MessageType = MessageType = {}));
    var ShowMessageNotification;
    (function(ShowMessageNotification2) {
      ShowMessageNotification2.method = "window/showMessage";
      ShowMessageNotification2.messageDirection = messages_1.MessageDirection.serverToClient;
      ShowMessageNotification2.type = new messages_1.ProtocolNotificationType(ShowMessageNotification2.method);
    })(ShowMessageNotification || (exports.ShowMessageNotification = ShowMessageNotification = {}));
    var ShowMessageRequest;
    (function(ShowMessageRequest2) {
      ShowMessageRequest2.method = "window/showMessageRequest";
      ShowMessageRequest2.messageDirection = messages_1.MessageDirection.serverToClient;
      ShowMessageRequest2.type = new messages_1.ProtocolRequestType(ShowMessageRequest2.method);
    })(ShowMessageRequest || (exports.ShowMessageRequest = ShowMessageRequest = {}));
    var LogMessageNotification;
    (function(LogMessageNotification2) {
      LogMessageNotification2.method = "window/logMessage";
      LogMessageNotification2.messageDirection = messages_1.MessageDirection.serverToClient;
      LogMessageNotification2.type = new messages_1.ProtocolNotificationType(LogMessageNotification2.method);
    })(LogMessageNotification || (exports.LogMessageNotification = LogMessageNotification = {}));
    var TelemetryEventNotification;
    (function(TelemetryEventNotification2) {
      TelemetryEventNotification2.method = "telemetry/event";
      TelemetryEventNotification2.messageDirection = messages_1.MessageDirection.serverToClient;
      TelemetryEventNotification2.type = new messages_1.ProtocolNotificationType(TelemetryEventNotification2.method);
    })(TelemetryEventNotification || (exports.TelemetryEventNotification = TelemetryEventNotification = {}));
    var TextDocumentSyncKind;
    (function(TextDocumentSyncKind2) {
      TextDocumentSyncKind2.None = 0;
      TextDocumentSyncKind2.Full = 1;
      TextDocumentSyncKind2.Incremental = 2;
    })(TextDocumentSyncKind || (exports.TextDocumentSyncKind = TextDocumentSyncKind = {}));
    var DidOpenTextDocumentNotification;
    (function(DidOpenTextDocumentNotification2) {
      DidOpenTextDocumentNotification2.method = "textDocument/didOpen";
      DidOpenTextDocumentNotification2.messageDirection = messages_1.MessageDirection.clientToServer;
      DidOpenTextDocumentNotification2.type = new messages_1.ProtocolNotificationType(DidOpenTextDocumentNotification2.method);
    })(DidOpenTextDocumentNotification || (exports.DidOpenTextDocumentNotification = DidOpenTextDocumentNotification = {}));
    var TextDocumentContentChangeEvent;
    (function(TextDocumentContentChangeEvent2) {
      function isIncremental(event) {
        let candidate = event;
        return candidate !== void 0 && candidate !== null && typeof candidate.text === "string" && candidate.range !== void 0 && (candidate.rangeLength === void 0 || typeof candidate.rangeLength === "number");
      }
      TextDocumentContentChangeEvent2.isIncremental = isIncremental;
      function isFull(event) {
        let candidate = event;
        return candidate !== void 0 && candidate !== null && typeof candidate.text === "string" && candidate.range === void 0 && candidate.rangeLength === void 0;
      }
      TextDocumentContentChangeEvent2.isFull = isFull;
    })(TextDocumentContentChangeEvent || (exports.TextDocumentContentChangeEvent = TextDocumentContentChangeEvent = {}));
    var DidChangeTextDocumentNotification;
    (function(DidChangeTextDocumentNotification2) {
      DidChangeTextDocumentNotification2.method = "textDocument/didChange";
      DidChangeTextDocumentNotification2.messageDirection = messages_1.MessageDirection.clientToServer;
      DidChangeTextDocumentNotification2.type = new messages_1.ProtocolNotificationType(DidChangeTextDocumentNotification2.method);
    })(DidChangeTextDocumentNotification || (exports.DidChangeTextDocumentNotification = DidChangeTextDocumentNotification = {}));
    var DidCloseTextDocumentNotification;
    (function(DidCloseTextDocumentNotification2) {
      DidCloseTextDocumentNotification2.method = "textDocument/didClose";
      DidCloseTextDocumentNotification2.messageDirection = messages_1.MessageDirection.clientToServer;
      DidCloseTextDocumentNotification2.type = new messages_1.ProtocolNotificationType(DidCloseTextDocumentNotification2.method);
    })(DidCloseTextDocumentNotification || (exports.DidCloseTextDocumentNotification = DidCloseTextDocumentNotification = {}));
    var DidSaveTextDocumentNotification;
    (function(DidSaveTextDocumentNotification2) {
      DidSaveTextDocumentNotification2.method = "textDocument/didSave";
      DidSaveTextDocumentNotification2.messageDirection = messages_1.MessageDirection.clientToServer;
      DidSaveTextDocumentNotification2.type = new messages_1.ProtocolNotificationType(DidSaveTextDocumentNotification2.method);
    })(DidSaveTextDocumentNotification || (exports.DidSaveTextDocumentNotification = DidSaveTextDocumentNotification = {}));
    var TextDocumentSaveReason;
    (function(TextDocumentSaveReason2) {
      TextDocumentSaveReason2.Manual = 1;
      TextDocumentSaveReason2.AfterDelay = 2;
      TextDocumentSaveReason2.FocusOut = 3;
    })(TextDocumentSaveReason || (exports.TextDocumentSaveReason = TextDocumentSaveReason = {}));
    var WillSaveTextDocumentNotification;
    (function(WillSaveTextDocumentNotification2) {
      WillSaveTextDocumentNotification2.method = "textDocument/willSave";
      WillSaveTextDocumentNotification2.messageDirection = messages_1.MessageDirection.clientToServer;
      WillSaveTextDocumentNotification2.type = new messages_1.ProtocolNotificationType(WillSaveTextDocumentNotification2.method);
    })(WillSaveTextDocumentNotification || (exports.WillSaveTextDocumentNotification = WillSaveTextDocumentNotification = {}));
    var WillSaveTextDocumentWaitUntilRequest;
    (function(WillSaveTextDocumentWaitUntilRequest2) {
      WillSaveTextDocumentWaitUntilRequest2.method = "textDocument/willSaveWaitUntil";
      WillSaveTextDocumentWaitUntilRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
      WillSaveTextDocumentWaitUntilRequest2.type = new messages_1.ProtocolRequestType(WillSaveTextDocumentWaitUntilRequest2.method);
    })(WillSaveTextDocumentWaitUntilRequest || (exports.WillSaveTextDocumentWaitUntilRequest = WillSaveTextDocumentWaitUntilRequest = {}));
    var DidChangeWatchedFilesNotification;
    (function(DidChangeWatchedFilesNotification2) {
      DidChangeWatchedFilesNotification2.method = "workspace/didChangeWatchedFiles";
      DidChangeWatchedFilesNotification2.messageDirection = messages_1.MessageDirection.clientToServer;
      DidChangeWatchedFilesNotification2.type = new messages_1.ProtocolNotificationType(DidChangeWatchedFilesNotification2.method);
    })(DidChangeWatchedFilesNotification || (exports.DidChangeWatchedFilesNotification = DidChangeWatchedFilesNotification = {}));
    var FileChangeType;
    (function(FileChangeType2) {
      FileChangeType2.Created = 1;
      FileChangeType2.Changed = 2;
      FileChangeType2.Deleted = 3;
    })(FileChangeType || (exports.FileChangeType = FileChangeType = {}));
    var RelativePattern;
    (function(RelativePattern2) {
      function is2(value) {
        const candidate = value;
        return Is.objectLiteral(candidate) && (vscode_languageserver_types_1.URI.is(candidate.baseUri) || vscode_languageserver_types_1.WorkspaceFolder.is(candidate.baseUri)) && Is.string(candidate.pattern);
      }
      RelativePattern2.is = is2;
    })(RelativePattern || (exports.RelativePattern = RelativePattern = {}));
    var WatchKind;
    (function(WatchKind2) {
      WatchKind2.Create = 1;
      WatchKind2.Change = 2;
      WatchKind2.Delete = 4;
    })(WatchKind || (exports.WatchKind = WatchKind = {}));
    var PublishDiagnosticsNotification;
    (function(PublishDiagnosticsNotification2) {
      PublishDiagnosticsNotification2.method = "textDocument/publishDiagnostics";
      PublishDiagnosticsNotification2.messageDirection = messages_1.MessageDirection.serverToClient;
      PublishDiagnosticsNotification2.type = new messages_1.ProtocolNotificationType(PublishDiagnosticsNotification2.method);
    })(PublishDiagnosticsNotification || (exports.PublishDiagnosticsNotification = PublishDiagnosticsNotification = {}));
    var CompletionTriggerKind;
    (function(CompletionTriggerKind2) {
      CompletionTriggerKind2.Invoked = 1;
      CompletionTriggerKind2.TriggerCharacter = 2;
      CompletionTriggerKind2.TriggerForIncompleteCompletions = 3;
    })(CompletionTriggerKind || (exports.CompletionTriggerKind = CompletionTriggerKind = {}));
    var CompletionRequest;
    (function(CompletionRequest2) {
      CompletionRequest2.method = "textDocument/completion";
      CompletionRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
      CompletionRequest2.type = new messages_1.ProtocolRequestType(CompletionRequest2.method);
    })(CompletionRequest || (exports.CompletionRequest = CompletionRequest = {}));
    var CompletionResolveRequest;
    (function(CompletionResolveRequest2) {
      CompletionResolveRequest2.method = "completionItem/resolve";
      CompletionResolveRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
      CompletionResolveRequest2.type = new messages_1.ProtocolRequestType(CompletionResolveRequest2.method);
    })(CompletionResolveRequest || (exports.CompletionResolveRequest = CompletionResolveRequest = {}));
    var HoverRequest;
    (function(HoverRequest2) {
      HoverRequest2.method = "textDocument/hover";
      HoverRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
      HoverRequest2.type = new messages_1.ProtocolRequestType(HoverRequest2.method);
    })(HoverRequest || (exports.HoverRequest = HoverRequest = {}));
    var SignatureHelpTriggerKind;
    (function(SignatureHelpTriggerKind2) {
      SignatureHelpTriggerKind2.Invoked = 1;
      SignatureHelpTriggerKind2.TriggerCharacter = 2;
      SignatureHelpTriggerKind2.ContentChange = 3;
    })(SignatureHelpTriggerKind || (exports.SignatureHelpTriggerKind = SignatureHelpTriggerKind = {}));
    var SignatureHelpRequest;
    (function(SignatureHelpRequest2) {
      SignatureHelpRequest2.method = "textDocument/signatureHelp";
      SignatureHelpRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
      SignatureHelpRequest2.type = new messages_1.ProtocolRequestType(SignatureHelpRequest2.method);
    })(SignatureHelpRequest || (exports.SignatureHelpRequest = SignatureHelpRequest = {}));
    var DefinitionRequest;
    (function(DefinitionRequest2) {
      DefinitionRequest2.method = "textDocument/definition";
      DefinitionRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
      DefinitionRequest2.type = new messages_1.ProtocolRequestType(DefinitionRequest2.method);
    })(DefinitionRequest || (exports.DefinitionRequest = DefinitionRequest = {}));
    var ReferencesRequest;
    (function(ReferencesRequest2) {
      ReferencesRequest2.method = "textDocument/references";
      ReferencesRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
      ReferencesRequest2.type = new messages_1.ProtocolRequestType(ReferencesRequest2.method);
    })(ReferencesRequest || (exports.ReferencesRequest = ReferencesRequest = {}));
    var DocumentHighlightRequest;
    (function(DocumentHighlightRequest2) {
      DocumentHighlightRequest2.method = "textDocument/documentHighlight";
      DocumentHighlightRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
      DocumentHighlightRequest2.type = new messages_1.ProtocolRequestType(DocumentHighlightRequest2.method);
    })(DocumentHighlightRequest || (exports.DocumentHighlightRequest = DocumentHighlightRequest = {}));
    var DocumentSymbolRequest;
    (function(DocumentSymbolRequest2) {
      DocumentSymbolRequest2.method = "textDocument/documentSymbol";
      DocumentSymbolRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
      DocumentSymbolRequest2.type = new messages_1.ProtocolRequestType(DocumentSymbolRequest2.method);
    })(DocumentSymbolRequest || (exports.DocumentSymbolRequest = DocumentSymbolRequest = {}));
    var CodeActionRequest;
    (function(CodeActionRequest2) {
      CodeActionRequest2.method = "textDocument/codeAction";
      CodeActionRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
      CodeActionRequest2.type = new messages_1.ProtocolRequestType(CodeActionRequest2.method);
    })(CodeActionRequest || (exports.CodeActionRequest = CodeActionRequest = {}));
    var CodeActionResolveRequest;
    (function(CodeActionResolveRequest2) {
      CodeActionResolveRequest2.method = "codeAction/resolve";
      CodeActionResolveRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
      CodeActionResolveRequest2.type = new messages_1.ProtocolRequestType(CodeActionResolveRequest2.method);
    })(CodeActionResolveRequest || (exports.CodeActionResolveRequest = CodeActionResolveRequest = {}));
    var WorkspaceSymbolRequest;
    (function(WorkspaceSymbolRequest2) {
      WorkspaceSymbolRequest2.method = "workspace/symbol";
      WorkspaceSymbolRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
      WorkspaceSymbolRequest2.type = new messages_1.ProtocolRequestType(WorkspaceSymbolRequest2.method);
    })(WorkspaceSymbolRequest || (exports.WorkspaceSymbolRequest = WorkspaceSymbolRequest = {}));
    var WorkspaceSymbolResolveRequest;
    (function(WorkspaceSymbolResolveRequest2) {
      WorkspaceSymbolResolveRequest2.method = "workspaceSymbol/resolve";
      WorkspaceSymbolResolveRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
      WorkspaceSymbolResolveRequest2.type = new messages_1.ProtocolRequestType(WorkspaceSymbolResolveRequest2.method);
    })(WorkspaceSymbolResolveRequest || (exports.WorkspaceSymbolResolveRequest = WorkspaceSymbolResolveRequest = {}));
    var CodeLensRequest;
    (function(CodeLensRequest2) {
      CodeLensRequest2.method = "textDocument/codeLens";
      CodeLensRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
      CodeLensRequest2.type = new messages_1.ProtocolRequestType(CodeLensRequest2.method);
    })(CodeLensRequest || (exports.CodeLensRequest = CodeLensRequest = {}));
    var CodeLensResolveRequest;
    (function(CodeLensResolveRequest2) {
      CodeLensResolveRequest2.method = "codeLens/resolve";
      CodeLensResolveRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
      CodeLensResolveRequest2.type = new messages_1.ProtocolRequestType(CodeLensResolveRequest2.method);
    })(CodeLensResolveRequest || (exports.CodeLensResolveRequest = CodeLensResolveRequest = {}));
    var CodeLensRefreshRequest;
    (function(CodeLensRefreshRequest2) {
      CodeLensRefreshRequest2.method = `workspace/codeLens/refresh`;
      CodeLensRefreshRequest2.messageDirection = messages_1.MessageDirection.serverToClient;
      CodeLensRefreshRequest2.type = new messages_1.ProtocolRequestType0(CodeLensRefreshRequest2.method);
    })(CodeLensRefreshRequest || (exports.CodeLensRefreshRequest = CodeLensRefreshRequest = {}));
    var DocumentLinkRequest;
    (function(DocumentLinkRequest2) {
      DocumentLinkRequest2.method = "textDocument/documentLink";
      DocumentLinkRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
      DocumentLinkRequest2.type = new messages_1.ProtocolRequestType(DocumentLinkRequest2.method);
    })(DocumentLinkRequest || (exports.DocumentLinkRequest = DocumentLinkRequest = {}));
    var DocumentLinkResolveRequest;
    (function(DocumentLinkResolveRequest2) {
      DocumentLinkResolveRequest2.method = "documentLink/resolve";
      DocumentLinkResolveRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
      DocumentLinkResolveRequest2.type = new messages_1.ProtocolRequestType(DocumentLinkResolveRequest2.method);
    })(DocumentLinkResolveRequest || (exports.DocumentLinkResolveRequest = DocumentLinkResolveRequest = {}));
    var DocumentFormattingRequest;
    (function(DocumentFormattingRequest2) {
      DocumentFormattingRequest2.method = "textDocument/formatting";
      DocumentFormattingRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
      DocumentFormattingRequest2.type = new messages_1.ProtocolRequestType(DocumentFormattingRequest2.method);
    })(DocumentFormattingRequest || (exports.DocumentFormattingRequest = DocumentFormattingRequest = {}));
    var DocumentRangeFormattingRequest;
    (function(DocumentRangeFormattingRequest2) {
      DocumentRangeFormattingRequest2.method = "textDocument/rangeFormatting";
      DocumentRangeFormattingRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
      DocumentRangeFormattingRequest2.type = new messages_1.ProtocolRequestType(DocumentRangeFormattingRequest2.method);
    })(DocumentRangeFormattingRequest || (exports.DocumentRangeFormattingRequest = DocumentRangeFormattingRequest = {}));
    var DocumentRangesFormattingRequest;
    (function(DocumentRangesFormattingRequest2) {
      DocumentRangesFormattingRequest2.method = "textDocument/rangesFormatting";
      DocumentRangesFormattingRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
      DocumentRangesFormattingRequest2.type = new messages_1.ProtocolRequestType(DocumentRangesFormattingRequest2.method);
    })(DocumentRangesFormattingRequest || (exports.DocumentRangesFormattingRequest = DocumentRangesFormattingRequest = {}));
    var DocumentOnTypeFormattingRequest;
    (function(DocumentOnTypeFormattingRequest2) {
      DocumentOnTypeFormattingRequest2.method = "textDocument/onTypeFormatting";
      DocumentOnTypeFormattingRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
      DocumentOnTypeFormattingRequest2.type = new messages_1.ProtocolRequestType(DocumentOnTypeFormattingRequest2.method);
    })(DocumentOnTypeFormattingRequest || (exports.DocumentOnTypeFormattingRequest = DocumentOnTypeFormattingRequest = {}));
    var PrepareSupportDefaultBehavior;
    (function(PrepareSupportDefaultBehavior2) {
      PrepareSupportDefaultBehavior2.Identifier = 1;
    })(PrepareSupportDefaultBehavior || (exports.PrepareSupportDefaultBehavior = PrepareSupportDefaultBehavior = {}));
    var RenameRequest;
    (function(RenameRequest2) {
      RenameRequest2.method = "textDocument/rename";
      RenameRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
      RenameRequest2.type = new messages_1.ProtocolRequestType(RenameRequest2.method);
    })(RenameRequest || (exports.RenameRequest = RenameRequest = {}));
    var PrepareRenameRequest;
    (function(PrepareRenameRequest2) {
      PrepareRenameRequest2.method = "textDocument/prepareRename";
      PrepareRenameRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
      PrepareRenameRequest2.type = new messages_1.ProtocolRequestType(PrepareRenameRequest2.method);
    })(PrepareRenameRequest || (exports.PrepareRenameRequest = PrepareRenameRequest = {}));
    var ExecuteCommandRequest;
    (function(ExecuteCommandRequest2) {
      ExecuteCommandRequest2.method = "workspace/executeCommand";
      ExecuteCommandRequest2.messageDirection = messages_1.MessageDirection.clientToServer;
      ExecuteCommandRequest2.type = new messages_1.ProtocolRequestType(ExecuteCommandRequest2.method);
    })(ExecuteCommandRequest || (exports.ExecuteCommandRequest = ExecuteCommandRequest = {}));
    var ApplyWorkspaceEditRequest;
    (function(ApplyWorkspaceEditRequest2) {
      ApplyWorkspaceEditRequest2.method = "workspace/applyEdit";
      ApplyWorkspaceEditRequest2.messageDirection = messages_1.MessageDirection.serverToClient;
      ApplyWorkspaceEditRequest2.type = new messages_1.ProtocolRequestType("workspace/applyEdit");
    })(ApplyWorkspaceEditRequest || (exports.ApplyWorkspaceEditRequest = ApplyWorkspaceEditRequest = {}));
  })(protocol);
  return protocol;
}
var connection = {};
var hasRequiredConnection;
function requireConnection() {
  if (hasRequiredConnection) return connection;
  hasRequiredConnection = 1;
  Object.defineProperty(connection, "__esModule", {
    value: true
  });
  connection.createProtocolConnection = void 0;
  const vscode_jsonrpc_1 = requireMain$3();
  function createProtocolConnection(input, output, logger, options2) {
    if (vscode_jsonrpc_1.ConnectionStrategy.is(options2)) {
      options2 = {
        connectionStrategy: options2
      };
    }
    return (0, vscode_jsonrpc_1.createMessageConnection)(input, output, logger, options2);
  }
  connection.createProtocolConnection = createProtocolConnection;
  return connection;
}
var hasRequiredApi$1;
function requireApi$1() {
  if (hasRequiredApi$1) return api$1;
  hasRequiredApi$1 = 1;
  (function(exports) {
    var __createBinding = api$1 && api$1.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
          enumerable: true,
          get: function() {
            return m[k];
          }
        };
      }
      Object.defineProperty(o, k2, desc);
    } : function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = api$1 && api$1.__exportStar || function(m, exports2) {
      for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports2, p)) __createBinding(exports2, m, p);
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.LSPErrorCodes = exports.createProtocolConnection = void 0;
    __exportStar(requireMain$3(), exports);
    __exportStar(requireMain$2(), exports);
    __exportStar(requireMessages(), exports);
    __exportStar(requireProtocol(), exports);
    var connection_1 = requireConnection();
    Object.defineProperty(exports, "createProtocolConnection", {
      enumerable: true,
      get: function() {
        return connection_1.createProtocolConnection;
      }
    });
    var LSPErrorCodes;
    (function(LSPErrorCodes2) {
      LSPErrorCodes2.lspReservedErrorRangeStart = -32899;
      LSPErrorCodes2.RequestFailed = -32803;
      LSPErrorCodes2.ServerCancelled = -32802;
      LSPErrorCodes2.ContentModified = -32801;
      LSPErrorCodes2.RequestCancelled = -32800;
      LSPErrorCodes2.lspReservedErrorRangeEnd = -32800;
    })(LSPErrorCodes || (exports.LSPErrorCodes = LSPErrorCodes = {}));
  })(api$1);
  return api$1;
}
var hasRequiredMain$1;
function requireMain$1() {
  if (hasRequiredMain$1) return main$2;
  hasRequiredMain$1 = 1;
  (function(exports) {
    var __createBinding = main$2 && main$2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
          enumerable: true,
          get: function() {
            return m[k];
          }
        };
      }
      Object.defineProperty(o, k2, desc);
    } : function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = main$2 && main$2.__exportStar || function(m, exports2) {
      for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports2, p)) __createBinding(exports2, m, p);
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.createProtocolConnection = void 0;
    const node_1 = requireNode$2();
    __exportStar(requireNode$2(), exports);
    __exportStar(requireApi$1(), exports);
    function createProtocolConnection(input, output, logger, options2) {
      return (0, node_1.createMessageConnection)(input, output, logger, options2);
    }
    exports.createProtocolConnection = createProtocolConnection;
  })(main$2);
  return main$2;
}
var uuid = {};
var hasRequiredUuid;
function requireUuid() {
  if (hasRequiredUuid) return uuid;
  hasRequiredUuid = 1;
  Object.defineProperty(uuid, "__esModule", {
    value: true
  });
  uuid.generateUuid = uuid.parse = uuid.isUUID = uuid.v4 = uuid.empty = void 0;
  class ValueUUID {
    constructor(_value) {
      this._value = _value;
    }
    asHex() {
      return this._value;
    }
    equals(other) {
      return this.asHex() === other.asHex();
    }
  }
  class V4UUID extends ValueUUID {
    static _oneOf(array) {
      return array[Math.floor(array.length * Math.random())];
    }
    static _randomHex() {
      return V4UUID._oneOf(V4UUID._chars);
    }
    constructor() {
      super([V4UUID._randomHex(), V4UUID._randomHex(), V4UUID._randomHex(), V4UUID._randomHex(), V4UUID._randomHex(), V4UUID._randomHex(), V4UUID._randomHex(), V4UUID._randomHex(), "-", V4UUID._randomHex(), V4UUID._randomHex(), V4UUID._randomHex(), V4UUID._randomHex(), "-", "4", V4UUID._randomHex(), V4UUID._randomHex(), V4UUID._randomHex(), "-", V4UUID._oneOf(V4UUID._timeHighBits), V4UUID._randomHex(), V4UUID._randomHex(), V4UUID._randomHex(), "-", V4UUID._randomHex(), V4UUID._randomHex(), V4UUID._randomHex(), V4UUID._randomHex(), V4UUID._randomHex(), V4UUID._randomHex(), V4UUID._randomHex(), V4UUID._randomHex(), V4UUID._randomHex(), V4UUID._randomHex(), V4UUID._randomHex(), V4UUID._randomHex()].join(""));
    }
  }
  V4UUID._chars = ["0", "1", "2", "3", "4", "5", "6", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f"];
  V4UUID._timeHighBits = ["8", "9", "a", "b"];
  uuid.empty = new ValueUUID("00000000-0000-0000-0000-000000000000");
  function v4() {
    return new V4UUID();
  }
  uuid.v4 = v4;
  const _UUIDPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  function isUUID(value) {
    return _UUIDPattern.test(value);
  }
  uuid.isUUID = isUUID;
  function parse(value) {
    if (!isUUID(value)) {
      throw new Error("invalid uuid");
    }
    return new ValueUUID(value);
  }
  uuid.parse = parse;
  function generateUuid() {
    return v4().asHex();
  }
  uuid.generateUuid = generateUuid;
  return uuid;
}
var progress = {};
var hasRequiredProgress;
function requireProgress() {
  if (hasRequiredProgress) return progress;
  hasRequiredProgress = 1;
  Object.defineProperty(progress, "__esModule", {
    value: true
  });
  progress.attachPartialResult = progress.ProgressFeature = progress.attachWorkDone = void 0;
  const vscode_languageserver_protocol_1 = requireMain$1();
  const uuid_1 = requireUuid();
  class WorkDoneProgressReporterImpl {
    constructor(_connection, _token) {
      this._connection = _connection;
      this._token = _token;
      WorkDoneProgressReporterImpl.Instances.set(this._token, this);
    }
    begin(title, percentage, message, cancellable) {
      let param = {
        kind: "begin",
        title,
        percentage,
        message,
        cancellable
      };
      this._connection.sendProgress(vscode_languageserver_protocol_1.WorkDoneProgress.type, this._token, param);
    }
    report(arg0, arg1) {
      let param = {
        kind: "report"
      };
      if (typeof arg0 === "number") {
        param.percentage = arg0;
        if (arg1 !== void 0) {
          param.message = arg1;
        }
      } else {
        param.message = arg0;
      }
      this._connection.sendProgress(vscode_languageserver_protocol_1.WorkDoneProgress.type, this._token, param);
    }
    done() {
      WorkDoneProgressReporterImpl.Instances.delete(this._token);
      this._connection.sendProgress(vscode_languageserver_protocol_1.WorkDoneProgress.type, this._token, {
        kind: "end"
      });
    }
  }
  WorkDoneProgressReporterImpl.Instances = /* @__PURE__ */ new Map();
  class WorkDoneProgressServerReporterImpl extends WorkDoneProgressReporterImpl {
    constructor(connection2, token) {
      super(connection2, token);
      this._source = new vscode_languageserver_protocol_1.CancellationTokenSource();
    }
    get token() {
      return this._source.token;
    }
    done() {
      this._source.dispose();
      super.done();
    }
    cancel() {
      this._source.cancel();
    }
  }
  class NullProgressReporter {
    constructor() {
    }
    begin() {
    }
    report() {
    }
    done() {
    }
  }
  class NullProgressServerReporter extends NullProgressReporter {
    constructor() {
      super();
      this._source = new vscode_languageserver_protocol_1.CancellationTokenSource();
    }
    get token() {
      return this._source.token;
    }
    done() {
      this._source.dispose();
    }
    cancel() {
      this._source.cancel();
    }
  }
  function attachWorkDone(connection2, params) {
    if (params === void 0 || params.workDoneToken === void 0) {
      return new NullProgressReporter();
    }
    const token = params.workDoneToken;
    delete params.workDoneToken;
    return new WorkDoneProgressReporterImpl(connection2, token);
  }
  progress.attachWorkDone = attachWorkDone;
  const ProgressFeature = (Base) => class extends Base {
    constructor() {
      super();
      this._progressSupported = false;
    }
    initialize(capabilities) {
      super.initialize(capabilities);
      if (capabilities?.window?.workDoneProgress === true) {
        this._progressSupported = true;
        this.connection.onNotification(vscode_languageserver_protocol_1.WorkDoneProgressCancelNotification.type, (params) => {
          let progress2 = WorkDoneProgressReporterImpl.Instances.get(params.token);
          if (progress2 instanceof WorkDoneProgressServerReporterImpl || progress2 instanceof NullProgressServerReporter) {
            progress2.cancel();
          }
        });
      }
    }
    attachWorkDoneProgress(token) {
      if (token === void 0) {
        return new NullProgressReporter();
      } else {
        return new WorkDoneProgressReporterImpl(this.connection, token);
      }
    }
    createWorkDoneProgress() {
      if (this._progressSupported) {
        const token = (0, uuid_1.generateUuid)();
        return this.connection.sendRequest(vscode_languageserver_protocol_1.WorkDoneProgressCreateRequest.type, {
          token
        }).then(() => {
          const result = new WorkDoneProgressServerReporterImpl(this.connection, token);
          return result;
        });
      } else {
        return Promise.resolve(new NullProgressServerReporter());
      }
    }
  };
  progress.ProgressFeature = ProgressFeature;
  var ResultProgress;
  (function(ResultProgress2) {
    ResultProgress2.type = new vscode_languageserver_protocol_1.ProgressType();
  })(ResultProgress || (ResultProgress = {}));
  class ResultProgressReporterImpl {
    constructor(_connection, _token) {
      this._connection = _connection;
      this._token = _token;
    }
    report(data) {
      this._connection.sendProgress(ResultProgress.type, this._token, data);
    }
  }
  function attachPartialResult(connection2, params) {
    if (params === void 0 || params.partialResultToken === void 0) {
      return void 0;
    }
    const token = params.partialResultToken;
    delete params.partialResultToken;
    return new ResultProgressReporterImpl(connection2, token);
  }
  progress.attachPartialResult = attachPartialResult;
  return progress;
}
var configuration = {};
var hasRequiredConfiguration;
function requireConfiguration() {
  if (hasRequiredConfiguration) return configuration;
  hasRequiredConfiguration = 1;
  Object.defineProperty(configuration, "__esModule", {
    value: true
  });
  configuration.ConfigurationFeature = void 0;
  const vscode_languageserver_protocol_1 = requireMain$1();
  const Is = requireIs$2();
  const ConfigurationFeature = (Base) => class extends Base {
    getConfiguration(arg) {
      if (!arg) {
        return this._getConfiguration({});
      } else if (Is.string(arg)) {
        return this._getConfiguration({
          section: arg
        });
      } else {
        return this._getConfiguration(arg);
      }
    }
    _getConfiguration(arg) {
      let params = {
        items: Array.isArray(arg) ? arg : [arg]
      };
      return this.connection.sendRequest(vscode_languageserver_protocol_1.ConfigurationRequest.type, params).then((result) => {
        if (Array.isArray(result)) {
          return Array.isArray(arg) ? result : result[0];
        } else {
          return Array.isArray(arg) ? [] : null;
        }
      });
    }
  };
  configuration.ConfigurationFeature = ConfigurationFeature;
  return configuration;
}
var workspaceFolder = {};
var hasRequiredWorkspaceFolder;
function requireWorkspaceFolder() {
  if (hasRequiredWorkspaceFolder) return workspaceFolder;
  hasRequiredWorkspaceFolder = 1;
  Object.defineProperty(workspaceFolder, "__esModule", {
    value: true
  });
  workspaceFolder.WorkspaceFoldersFeature = void 0;
  const vscode_languageserver_protocol_1 = requireMain$1();
  const WorkspaceFoldersFeature = (Base) => class extends Base {
    constructor() {
      super();
      this._notificationIsAutoRegistered = false;
    }
    initialize(capabilities) {
      super.initialize(capabilities);
      let workspaceCapabilities = capabilities.workspace;
      if (workspaceCapabilities && workspaceCapabilities.workspaceFolders) {
        this._onDidChangeWorkspaceFolders = new vscode_languageserver_protocol_1.Emitter();
        this.connection.onNotification(vscode_languageserver_protocol_1.DidChangeWorkspaceFoldersNotification.type, (params) => {
          this._onDidChangeWorkspaceFolders.fire(params.event);
        });
      }
    }
    fillServerCapabilities(capabilities) {
      super.fillServerCapabilities(capabilities);
      const changeNotifications = capabilities.workspace?.workspaceFolders?.changeNotifications;
      this._notificationIsAutoRegistered = changeNotifications === true || typeof changeNotifications === "string";
    }
    getWorkspaceFolders() {
      return this.connection.sendRequest(vscode_languageserver_protocol_1.WorkspaceFoldersRequest.type);
    }
    get onDidChangeWorkspaceFolders() {
      if (!this._onDidChangeWorkspaceFolders) {
        throw new Error("Client doesn't support sending workspace folder change events.");
      }
      if (!this._notificationIsAutoRegistered && !this._unregistration) {
        this._unregistration = this.connection.client.register(vscode_languageserver_protocol_1.DidChangeWorkspaceFoldersNotification.type);
      }
      return this._onDidChangeWorkspaceFolders.event;
    }
  };
  workspaceFolder.WorkspaceFoldersFeature = WorkspaceFoldersFeature;
  return workspaceFolder;
}
var callHierarchy = {};
var hasRequiredCallHierarchy;
function requireCallHierarchy() {
  if (hasRequiredCallHierarchy) return callHierarchy;
  hasRequiredCallHierarchy = 1;
  Object.defineProperty(callHierarchy, "__esModule", {
    value: true
  });
  callHierarchy.CallHierarchyFeature = void 0;
  const vscode_languageserver_protocol_1 = requireMain$1();
  const CallHierarchyFeature = (Base) => class extends Base {
    get callHierarchy() {
      return {
        onPrepare: (handler) => this.connection.onRequest(vscode_languageserver_protocol_1.CallHierarchyPrepareRequest.type, (params, cancel) => handler(params, cancel, this.attachWorkDoneProgress(params), void 0)),
        onIncomingCalls: (handler) => {
          const type = vscode_languageserver_protocol_1.CallHierarchyIncomingCallsRequest.type;
          return this.connection.onRequest(type, (params, cancel) => handler(params, cancel, this.attachWorkDoneProgress(params), this.attachPartialResultProgress(type, params)));
        },
        onOutgoingCalls: (handler) => {
          const type = vscode_languageserver_protocol_1.CallHierarchyOutgoingCallsRequest.type;
          return this.connection.onRequest(type, (params, cancel) => handler(params, cancel, this.attachWorkDoneProgress(params), this.attachPartialResultProgress(type, params)));
        }
      };
    }
  };
  callHierarchy.CallHierarchyFeature = CallHierarchyFeature;
  return callHierarchy;
}
var semanticTokens = {};
var hasRequiredSemanticTokens;
function requireSemanticTokens() {
  if (hasRequiredSemanticTokens) return semanticTokens;
  hasRequiredSemanticTokens = 1;
  Object.defineProperty(semanticTokens, "__esModule", {
    value: true
  });
  semanticTokens.SemanticTokensBuilder = semanticTokens.SemanticTokensDiff = semanticTokens.SemanticTokensFeature = void 0;
  const vscode_languageserver_protocol_1 = requireMain$1();
  const SemanticTokensFeature = (Base) => class extends Base {
    get semanticTokens() {
      return {
        refresh: () => this.connection.sendRequest(vscode_languageserver_protocol_1.SemanticTokensRefreshRequest.type),
        on: (handler) => {
          const type = vscode_languageserver_protocol_1.SemanticTokensRequest.type;
          return this.connection.onRequest(type, (params, cancel) => handler(params, cancel, this.attachWorkDoneProgress(params), this.attachPartialResultProgress(type, params)));
        },
        onDelta: (handler) => {
          const type = vscode_languageserver_protocol_1.SemanticTokensDeltaRequest.type;
          return this.connection.onRequest(type, (params, cancel) => handler(params, cancel, this.attachWorkDoneProgress(params), this.attachPartialResultProgress(type, params)));
        },
        onRange: (handler) => {
          const type = vscode_languageserver_protocol_1.SemanticTokensRangeRequest.type;
          return this.connection.onRequest(type, (params, cancel) => handler(params, cancel, this.attachWorkDoneProgress(params), this.attachPartialResultProgress(type, params)));
        }
      };
    }
  };
  semanticTokens.SemanticTokensFeature = SemanticTokensFeature;
  class SemanticTokensDiff {
    constructor(originalSequence, modifiedSequence) {
      this.originalSequence = originalSequence;
      this.modifiedSequence = modifiedSequence;
    }
    computeDiff() {
      const originalLength = this.originalSequence.length;
      const modifiedLength = this.modifiedSequence.length;
      let startIndex = 0;
      while (startIndex < modifiedLength && startIndex < originalLength && this.originalSequence[startIndex] === this.modifiedSequence[startIndex]) {
        startIndex++;
      }
      if (startIndex < modifiedLength && startIndex < originalLength) {
        let originalEndIndex = originalLength - 1;
        let modifiedEndIndex = modifiedLength - 1;
        while (originalEndIndex >= startIndex && modifiedEndIndex >= startIndex && this.originalSequence[originalEndIndex] === this.modifiedSequence[modifiedEndIndex]) {
          originalEndIndex--;
          modifiedEndIndex--;
        }
        if (originalEndIndex < startIndex || modifiedEndIndex < startIndex) {
          originalEndIndex++;
          modifiedEndIndex++;
        }
        const deleteCount = originalEndIndex - startIndex + 1;
        const newData = this.modifiedSequence.slice(startIndex, modifiedEndIndex + 1);
        if (newData.length === 1 && newData[0] === this.originalSequence[originalEndIndex]) {
          return [{
            start: startIndex,
            deleteCount: deleteCount - 1
          }];
        } else {
          return [{
            start: startIndex,
            deleteCount,
            data: newData
          }];
        }
      } else if (startIndex < modifiedLength) {
        return [{
          start: startIndex,
          deleteCount: 0,
          data: this.modifiedSequence.slice(startIndex)
        }];
      } else if (startIndex < originalLength) {
        return [{
          start: startIndex,
          deleteCount: originalLength - startIndex
        }];
      } else {
        return [];
      }
    }
  }
  semanticTokens.SemanticTokensDiff = SemanticTokensDiff;
  class SemanticTokensBuilder {
    constructor() {
      this._prevData = void 0;
      this.initialize();
    }
    initialize() {
      this._id = Date.now();
      this._prevLine = 0;
      this._prevChar = 0;
      this._data = [];
      this._dataLen = 0;
    }
    push(line, char, length, tokenType, tokenModifiers) {
      let pushLine = line;
      let pushChar = char;
      if (this._dataLen > 0) {
        pushLine -= this._prevLine;
        if (pushLine === 0) {
          pushChar -= this._prevChar;
        }
      }
      this._data[this._dataLen++] = pushLine;
      this._data[this._dataLen++] = pushChar;
      this._data[this._dataLen++] = length;
      this._data[this._dataLen++] = tokenType;
      this._data[this._dataLen++] = tokenModifiers;
      this._prevLine = line;
      this._prevChar = char;
    }
    get id() {
      return this._id.toString();
    }
    previousResult(id) {
      if (this.id === id) {
        this._prevData = this._data;
      }
      this.initialize();
    }
    build() {
      this._prevData = void 0;
      return {
        resultId: this.id,
        data: this._data
      };
    }
    canBuildEdits() {
      return this._prevData !== void 0;
    }
    buildEdits() {
      if (this._prevData !== void 0) {
        return {
          resultId: this.id,
          edits: new SemanticTokensDiff(this._prevData, this._data).computeDiff()
        };
      } else {
        return this.build();
      }
    }
  }
  semanticTokens.SemanticTokensBuilder = SemanticTokensBuilder;
  return semanticTokens;
}
var showDocument = {};
var hasRequiredShowDocument;
function requireShowDocument() {
  if (hasRequiredShowDocument) return showDocument;
  hasRequiredShowDocument = 1;
  Object.defineProperty(showDocument, "__esModule", {
    value: true
  });
  showDocument.ShowDocumentFeature = void 0;
  const vscode_languageserver_protocol_1 = requireMain$1();
  const ShowDocumentFeature = (Base) => class extends Base {
    showDocument(params) {
      return this.connection.sendRequest(vscode_languageserver_protocol_1.ShowDocumentRequest.type, params);
    }
  };
  showDocument.ShowDocumentFeature = ShowDocumentFeature;
  return showDocument;
}
var fileOperations = {};
var hasRequiredFileOperations;
function requireFileOperations() {
  if (hasRequiredFileOperations) return fileOperations;
  hasRequiredFileOperations = 1;
  Object.defineProperty(fileOperations, "__esModule", {
    value: true
  });
  fileOperations.FileOperationsFeature = void 0;
  const vscode_languageserver_protocol_1 = requireMain$1();
  const FileOperationsFeature = (Base) => class extends Base {
    onDidCreateFiles(handler) {
      return this.connection.onNotification(vscode_languageserver_protocol_1.DidCreateFilesNotification.type, (params) => {
        handler(params);
      });
    }
    onDidRenameFiles(handler) {
      return this.connection.onNotification(vscode_languageserver_protocol_1.DidRenameFilesNotification.type, (params) => {
        handler(params);
      });
    }
    onDidDeleteFiles(handler) {
      return this.connection.onNotification(vscode_languageserver_protocol_1.DidDeleteFilesNotification.type, (params) => {
        handler(params);
      });
    }
    onWillCreateFiles(handler) {
      return this.connection.onRequest(vscode_languageserver_protocol_1.WillCreateFilesRequest.type, (params, cancel) => handler(params, cancel));
    }
    onWillRenameFiles(handler) {
      return this.connection.onRequest(vscode_languageserver_protocol_1.WillRenameFilesRequest.type, (params, cancel) => handler(params, cancel));
    }
    onWillDeleteFiles(handler) {
      return this.connection.onRequest(vscode_languageserver_protocol_1.WillDeleteFilesRequest.type, (params, cancel) => handler(params, cancel));
    }
  };
  fileOperations.FileOperationsFeature = FileOperationsFeature;
  return fileOperations;
}
var linkedEditingRange = {};
var hasRequiredLinkedEditingRange;
function requireLinkedEditingRange() {
  if (hasRequiredLinkedEditingRange) return linkedEditingRange;
  hasRequiredLinkedEditingRange = 1;
  Object.defineProperty(linkedEditingRange, "__esModule", {
    value: true
  });
  linkedEditingRange.LinkedEditingRangeFeature = void 0;
  const vscode_languageserver_protocol_1 = requireMain$1();
  const LinkedEditingRangeFeature = (Base) => class extends Base {
    onLinkedEditingRange(handler) {
      return this.connection.onRequest(vscode_languageserver_protocol_1.LinkedEditingRangeRequest.type, (params, cancel) => handler(params, cancel, this.attachWorkDoneProgress(params), void 0));
    }
  };
  linkedEditingRange.LinkedEditingRangeFeature = LinkedEditingRangeFeature;
  return linkedEditingRange;
}
var typeHierarchy = {};
var hasRequiredTypeHierarchy;
function requireTypeHierarchy() {
  if (hasRequiredTypeHierarchy) return typeHierarchy;
  hasRequiredTypeHierarchy = 1;
  Object.defineProperty(typeHierarchy, "__esModule", {
    value: true
  });
  typeHierarchy.TypeHierarchyFeature = void 0;
  const vscode_languageserver_protocol_1 = requireMain$1();
  const TypeHierarchyFeature = (Base) => class extends Base {
    get typeHierarchy() {
      return {
        onPrepare: (handler) => this.connection.onRequest(vscode_languageserver_protocol_1.TypeHierarchyPrepareRequest.type, (params, cancel) => handler(params, cancel, this.attachWorkDoneProgress(params), void 0)),
        onSupertypes: (handler) => {
          const type = vscode_languageserver_protocol_1.TypeHierarchySupertypesRequest.type;
          return this.connection.onRequest(type, (params, cancel) => handler(params, cancel, this.attachWorkDoneProgress(params), this.attachPartialResultProgress(type, params)));
        },
        onSubtypes: (handler) => {
          const type = vscode_languageserver_protocol_1.TypeHierarchySubtypesRequest.type;
          return this.connection.onRequest(type, (params, cancel) => handler(params, cancel, this.attachWorkDoneProgress(params), this.attachPartialResultProgress(type, params)));
        }
      };
    }
  };
  typeHierarchy.TypeHierarchyFeature = TypeHierarchyFeature;
  return typeHierarchy;
}
var inlineValue = {};
var hasRequiredInlineValue;
function requireInlineValue() {
  if (hasRequiredInlineValue) return inlineValue;
  hasRequiredInlineValue = 1;
  Object.defineProperty(inlineValue, "__esModule", {
    value: true
  });
  inlineValue.InlineValueFeature = void 0;
  const vscode_languageserver_protocol_1 = requireMain$1();
  const InlineValueFeature = (Base) => class extends Base {
    get inlineValue() {
      return {
        refresh: () => this.connection.sendRequest(vscode_languageserver_protocol_1.InlineValueRefreshRequest.type),
        on: (handler) => this.connection.onRequest(vscode_languageserver_protocol_1.InlineValueRequest.type, (params, cancel) => handler(params, cancel, this.attachWorkDoneProgress(params)))
      };
    }
  };
  inlineValue.InlineValueFeature = InlineValueFeature;
  return inlineValue;
}
var foldingRange = {};
var hasRequiredFoldingRange;
function requireFoldingRange() {
  if (hasRequiredFoldingRange) return foldingRange;
  hasRequiredFoldingRange = 1;
  Object.defineProperty(foldingRange, "__esModule", {
    value: true
  });
  foldingRange.FoldingRangeFeature = void 0;
  const vscode_languageserver_protocol_1 = requireMain$1();
  const FoldingRangeFeature = (Base) => class extends Base {
    get foldingRange() {
      return {
        refresh: () => this.connection.sendRequest(vscode_languageserver_protocol_1.FoldingRangeRefreshRequest.type),
        on: (handler) => {
          const type = vscode_languageserver_protocol_1.FoldingRangeRequest.type;
          return this.connection.onRequest(type, (params, cancel) => handler(params, cancel, this.attachWorkDoneProgress(params), this.attachPartialResultProgress(type, params)));
        }
      };
    }
  };
  foldingRange.FoldingRangeFeature = FoldingRangeFeature;
  return foldingRange;
}
var inlayHint = {};
var hasRequiredInlayHint;
function requireInlayHint() {
  if (hasRequiredInlayHint) return inlayHint;
  hasRequiredInlayHint = 1;
  Object.defineProperty(inlayHint, "__esModule", {
    value: true
  });
  inlayHint.InlayHintFeature = void 0;
  const vscode_languageserver_protocol_1 = requireMain$1();
  const InlayHintFeature = (Base) => class extends Base {
    get inlayHint() {
      return {
        refresh: () => this.connection.sendRequest(vscode_languageserver_protocol_1.InlayHintRefreshRequest.type),
        on: (handler) => this.connection.onRequest(vscode_languageserver_protocol_1.InlayHintRequest.type, (params, cancel) => handler(params, cancel, this.attachWorkDoneProgress(params))),
        resolve: (handler) => this.connection.onRequest(vscode_languageserver_protocol_1.InlayHintResolveRequest.type, (params, cancel) => handler(params, cancel))
      };
    }
  };
  inlayHint.InlayHintFeature = InlayHintFeature;
  return inlayHint;
}
var diagnostic = {};
var hasRequiredDiagnostic;
function requireDiagnostic() {
  if (hasRequiredDiagnostic) return diagnostic;
  hasRequiredDiagnostic = 1;
  Object.defineProperty(diagnostic, "__esModule", {
    value: true
  });
  diagnostic.DiagnosticFeature = void 0;
  const vscode_languageserver_protocol_1 = requireMain$1();
  const DiagnosticFeature = (Base) => class extends Base {
    get diagnostics() {
      return {
        refresh: () => this.connection.sendRequest(vscode_languageserver_protocol_1.DiagnosticRefreshRequest.type),
        on: (handler) => this.connection.onRequest(vscode_languageserver_protocol_1.DocumentDiagnosticRequest.type, (params, cancel) => handler(params, cancel, this.attachWorkDoneProgress(params), this.attachPartialResultProgress(vscode_languageserver_protocol_1.DocumentDiagnosticRequest.partialResult, params))),
        onWorkspace: (handler) => this.connection.onRequest(vscode_languageserver_protocol_1.WorkspaceDiagnosticRequest.type, (params, cancel) => handler(params, cancel, this.attachWorkDoneProgress(params), this.attachPartialResultProgress(vscode_languageserver_protocol_1.WorkspaceDiagnosticRequest.partialResult, params)))
      };
    }
  };
  diagnostic.DiagnosticFeature = DiagnosticFeature;
  return diagnostic;
}
var notebook = {};
var textDocuments = {};
var hasRequiredTextDocuments;
function requireTextDocuments() {
  if (hasRequiredTextDocuments) return textDocuments;
  hasRequiredTextDocuments = 1;
  Object.defineProperty(textDocuments, "__esModule", {
    value: true
  });
  textDocuments.TextDocuments = void 0;
  const vscode_languageserver_protocol_1 = requireMain$1();
  class TextDocuments {
    constructor(configuration2) {
      this._configuration = configuration2;
      this._syncedDocuments = /* @__PURE__ */ new Map();
      this._onDidChangeContent = new vscode_languageserver_protocol_1.Emitter();
      this._onDidOpen = new vscode_languageserver_protocol_1.Emitter();
      this._onDidClose = new vscode_languageserver_protocol_1.Emitter();
      this._onDidSave = new vscode_languageserver_protocol_1.Emitter();
      this._onWillSave = new vscode_languageserver_protocol_1.Emitter();
    }
    get onDidOpen() {
      return this._onDidOpen.event;
    }
    get onDidChangeContent() {
      return this._onDidChangeContent.event;
    }
    get onWillSave() {
      return this._onWillSave.event;
    }
    onWillSaveWaitUntil(handler) {
      this._willSaveWaitUntil = handler;
    }
    get onDidSave() {
      return this._onDidSave.event;
    }
    get onDidClose() {
      return this._onDidClose.event;
    }
    get(uri) {
      return this._syncedDocuments.get(uri);
    }
    all() {
      return Array.from(this._syncedDocuments.values());
    }
    keys() {
      return Array.from(this._syncedDocuments.keys());
    }
    listen(connection2) {
      connection2.__textDocumentSync = vscode_languageserver_protocol_1.TextDocumentSyncKind.Incremental;
      const disposables = [];
      disposables.push(connection2.onDidOpenTextDocument((event) => {
        const td = event.textDocument;
        const document = this._configuration.create(td.uri, td.languageId, td.version, td.text);
        this._syncedDocuments.set(td.uri, document);
        const toFire = Object.freeze({
          document
        });
        this._onDidOpen.fire(toFire);
        this._onDidChangeContent.fire(toFire);
      }));
      disposables.push(connection2.onDidChangeTextDocument((event) => {
        const td = event.textDocument;
        const changes = event.contentChanges;
        if (changes.length === 0) {
          return;
        }
        const { version: version2 } = td;
        if (version2 === null || version2 === void 0) {
          throw new Error(`Received document change event for ${td.uri} without valid version identifier`);
        }
        let syncedDocument = this._syncedDocuments.get(td.uri);
        if (syncedDocument !== void 0) {
          syncedDocument = this._configuration.update(syncedDocument, changes, version2);
          this._syncedDocuments.set(td.uri, syncedDocument);
          this._onDidChangeContent.fire(Object.freeze({
            document: syncedDocument
          }));
        }
      }));
      disposables.push(connection2.onDidCloseTextDocument((event) => {
        let syncedDocument = this._syncedDocuments.get(event.textDocument.uri);
        if (syncedDocument !== void 0) {
          this._syncedDocuments.delete(event.textDocument.uri);
          this._onDidClose.fire(Object.freeze({
            document: syncedDocument
          }));
        }
      }));
      disposables.push(connection2.onWillSaveTextDocument((event) => {
        let syncedDocument = this._syncedDocuments.get(event.textDocument.uri);
        if (syncedDocument !== void 0) {
          this._onWillSave.fire(Object.freeze({
            document: syncedDocument,
            reason: event.reason
          }));
        }
      }));
      disposables.push(connection2.onWillSaveTextDocumentWaitUntil((event, token) => {
        let syncedDocument = this._syncedDocuments.get(event.textDocument.uri);
        if (syncedDocument !== void 0 && this._willSaveWaitUntil) {
          return this._willSaveWaitUntil(Object.freeze({
            document: syncedDocument,
            reason: event.reason
          }), token);
        } else {
          return [];
        }
      }));
      disposables.push(connection2.onDidSaveTextDocument((event) => {
        let syncedDocument = this._syncedDocuments.get(event.textDocument.uri);
        if (syncedDocument !== void 0) {
          this._onDidSave.fire(Object.freeze({
            document: syncedDocument
          }));
        }
      }));
      return vscode_languageserver_protocol_1.Disposable.create(() => {
        disposables.forEach((disposable2) => disposable2.dispose());
      });
    }
  }
  textDocuments.TextDocuments = TextDocuments;
  return textDocuments;
}
var hasRequiredNotebook;
function requireNotebook() {
  if (hasRequiredNotebook) return notebook;
  hasRequiredNotebook = 1;
  Object.defineProperty(notebook, "__esModule", {
    value: true
  });
  notebook.NotebookDocuments = notebook.NotebookSyncFeature = void 0;
  const vscode_languageserver_protocol_1 = requireMain$1();
  const textDocuments_1 = requireTextDocuments();
  const NotebookSyncFeature = (Base) => class extends Base {
    get synchronization() {
      return {
        onDidOpenNotebookDocument: (handler) => this.connection.onNotification(vscode_languageserver_protocol_1.DidOpenNotebookDocumentNotification.type, (params) => {
          handler(params);
        }),
        onDidChangeNotebookDocument: (handler) => this.connection.onNotification(vscode_languageserver_protocol_1.DidChangeNotebookDocumentNotification.type, (params) => {
          handler(params);
        }),
        onDidSaveNotebookDocument: (handler) => this.connection.onNotification(vscode_languageserver_protocol_1.DidSaveNotebookDocumentNotification.type, (params) => {
          handler(params);
        }),
        onDidCloseNotebookDocument: (handler) => this.connection.onNotification(vscode_languageserver_protocol_1.DidCloseNotebookDocumentNotification.type, (params) => {
          handler(params);
        })
      };
    }
  };
  notebook.NotebookSyncFeature = NotebookSyncFeature;
  class CellTextDocumentConnection {
    onDidOpenTextDocument(handler) {
      this.openHandler = handler;
      return vscode_languageserver_protocol_1.Disposable.create(() => {
        this.openHandler = void 0;
      });
    }
    openTextDocument(params) {
      this.openHandler && this.openHandler(params);
    }
    onDidChangeTextDocument(handler) {
      this.changeHandler = handler;
      return vscode_languageserver_protocol_1.Disposable.create(() => {
        this.changeHandler = handler;
      });
    }
    changeTextDocument(params) {
      this.changeHandler && this.changeHandler(params);
    }
    onDidCloseTextDocument(handler) {
      this.closeHandler = handler;
      return vscode_languageserver_protocol_1.Disposable.create(() => {
        this.closeHandler = void 0;
      });
    }
    closeTextDocument(params) {
      this.closeHandler && this.closeHandler(params);
    }
    onWillSaveTextDocument() {
      return CellTextDocumentConnection.NULL_DISPOSE;
    }
    onWillSaveTextDocumentWaitUntil() {
      return CellTextDocumentConnection.NULL_DISPOSE;
    }
    onDidSaveTextDocument() {
      return CellTextDocumentConnection.NULL_DISPOSE;
    }
  }
  CellTextDocumentConnection.NULL_DISPOSE = Object.freeze({
    dispose: () => {
    }
  });
  class NotebookDocuments {
    constructor(configurationOrTextDocuments) {
      if (configurationOrTextDocuments instanceof textDocuments_1.TextDocuments) {
        this._cellTextDocuments = configurationOrTextDocuments;
      } else {
        this._cellTextDocuments = new textDocuments_1.TextDocuments(configurationOrTextDocuments);
      }
      this.notebookDocuments = /* @__PURE__ */ new Map();
      this.notebookCellMap = /* @__PURE__ */ new Map();
      this._onDidOpen = new vscode_languageserver_protocol_1.Emitter();
      this._onDidChange = new vscode_languageserver_protocol_1.Emitter();
      this._onDidSave = new vscode_languageserver_protocol_1.Emitter();
      this._onDidClose = new vscode_languageserver_protocol_1.Emitter();
    }
    get cellTextDocuments() {
      return this._cellTextDocuments;
    }
    getCellTextDocument(cell) {
      return this._cellTextDocuments.get(cell.document);
    }
    getNotebookDocument(uri) {
      return this.notebookDocuments.get(uri);
    }
    getNotebookCell(uri) {
      const value = this.notebookCellMap.get(uri);
      return value && value[0];
    }
    findNotebookDocumentForCell(cell) {
      const key = typeof cell === "string" ? cell : cell.document;
      const value = this.notebookCellMap.get(key);
      return value && value[1];
    }
    get onDidOpen() {
      return this._onDidOpen.event;
    }
    get onDidSave() {
      return this._onDidSave.event;
    }
    get onDidChange() {
      return this._onDidChange.event;
    }
    get onDidClose() {
      return this._onDidClose.event;
    }
    listen(connection2) {
      const cellTextDocumentConnection = new CellTextDocumentConnection();
      const disposables = [];
      disposables.push(this.cellTextDocuments.listen(cellTextDocumentConnection));
      disposables.push(connection2.notebooks.synchronization.onDidOpenNotebookDocument((params) => {
        this.notebookDocuments.set(params.notebookDocument.uri, params.notebookDocument);
        for (const cellTextDocument of params.cellTextDocuments) {
          cellTextDocumentConnection.openTextDocument({
            textDocument: cellTextDocument
          });
        }
        this.updateCellMap(params.notebookDocument);
        this._onDidOpen.fire(params.notebookDocument);
      }));
      disposables.push(connection2.notebooks.synchronization.onDidChangeNotebookDocument((params) => {
        const notebookDocument = this.notebookDocuments.get(params.notebookDocument.uri);
        if (notebookDocument === void 0) {
          return;
        }
        notebookDocument.version = params.notebookDocument.version;
        const oldMetadata = notebookDocument.metadata;
        let metadataChanged = false;
        const change = params.change;
        if (change.metadata !== void 0) {
          metadataChanged = true;
          notebookDocument.metadata = change.metadata;
        }
        const opened = [];
        const closed = [];
        const data = [];
        const text = [];
        if (change.cells !== void 0) {
          const changedCells = change.cells;
          if (changedCells.structure !== void 0) {
            const array = changedCells.structure.array;
            notebookDocument.cells.splice(array.start, array.deleteCount, ...array.cells !== void 0 ? array.cells : []);
            if (changedCells.structure.didOpen !== void 0) {
              for (const open of changedCells.structure.didOpen) {
                cellTextDocumentConnection.openTextDocument({
                  textDocument: open
                });
                opened.push(open.uri);
              }
            }
            if (changedCells.structure.didClose) {
              for (const close of changedCells.structure.didClose) {
                cellTextDocumentConnection.closeTextDocument({
                  textDocument: close
                });
                closed.push(close.uri);
              }
            }
          }
          if (changedCells.data !== void 0) {
            const cellUpdates = new Map(changedCells.data.map((cell) => [cell.document, cell]));
            for (let i = 0; i <= notebookDocument.cells.length; i++) {
              const change2 = cellUpdates.get(notebookDocument.cells[i].document);
              if (change2 !== void 0) {
                const old = notebookDocument.cells.splice(i, 1, change2);
                data.push({
                  old: old[0],
                  new: change2
                });
                cellUpdates.delete(change2.document);
                if (cellUpdates.size === 0) {
                  break;
                }
              }
            }
          }
          if (changedCells.textContent !== void 0) {
            for (const cellTextDocument of changedCells.textContent) {
              cellTextDocumentConnection.changeTextDocument({
                textDocument: cellTextDocument.document,
                contentChanges: cellTextDocument.changes
              });
              text.push(cellTextDocument.document.uri);
            }
          }
        }
        this.updateCellMap(notebookDocument);
        const changeEvent = {
          notebookDocument
        };
        if (metadataChanged) {
          changeEvent.metadata = {
            old: oldMetadata,
            new: notebookDocument.metadata
          };
        }
        const added = [];
        for (const open of opened) {
          added.push(this.getNotebookCell(open));
        }
        const removed = [];
        for (const close of closed) {
          removed.push(this.getNotebookCell(close));
        }
        const textContent = [];
        for (const change2 of text) {
          textContent.push(this.getNotebookCell(change2));
        }
        if (added.length > 0 || removed.length > 0 || data.length > 0 || textContent.length > 0) {
          changeEvent.cells = {
            added,
            removed,
            changed: {
              data,
              textContent
            }
          };
        }
        if (changeEvent.metadata !== void 0 || changeEvent.cells !== void 0) {
          this._onDidChange.fire(changeEvent);
        }
      }));
      disposables.push(connection2.notebooks.synchronization.onDidSaveNotebookDocument((params) => {
        const notebookDocument = this.notebookDocuments.get(params.notebookDocument.uri);
        if (notebookDocument === void 0) {
          return;
        }
        this._onDidSave.fire(notebookDocument);
      }));
      disposables.push(connection2.notebooks.synchronization.onDidCloseNotebookDocument((params) => {
        const notebookDocument = this.notebookDocuments.get(params.notebookDocument.uri);
        if (notebookDocument === void 0) {
          return;
        }
        this._onDidClose.fire(notebookDocument);
        for (const cellTextDocument of params.cellTextDocuments) {
          cellTextDocumentConnection.closeTextDocument({
            textDocument: cellTextDocument
          });
        }
        this.notebookDocuments.delete(params.notebookDocument.uri);
        for (const cell of notebookDocument.cells) {
          this.notebookCellMap.delete(cell.document);
        }
      }));
      return vscode_languageserver_protocol_1.Disposable.create(() => {
        disposables.forEach((disposable2) => disposable2.dispose());
      });
    }
    updateCellMap(notebookDocument) {
      for (const cell of notebookDocument.cells) {
        this.notebookCellMap.set(cell.document, [cell, notebookDocument]);
      }
    }
  }
  notebook.NotebookDocuments = NotebookDocuments;
  return notebook;
}
var moniker = {};
var hasRequiredMoniker;
function requireMoniker() {
  if (hasRequiredMoniker) return moniker;
  hasRequiredMoniker = 1;
  Object.defineProperty(moniker, "__esModule", {
    value: true
  });
  moniker.MonikerFeature = void 0;
  const vscode_languageserver_protocol_1 = requireMain$1();
  const MonikerFeature = (Base) => class extends Base {
    get moniker() {
      return {
        on: (handler) => {
          const type = vscode_languageserver_protocol_1.MonikerRequest.type;
          return this.connection.onRequest(type, (params, cancel) => handler(params, cancel, this.attachWorkDoneProgress(params), this.attachPartialResultProgress(type, params)));
        }
      };
    }
  };
  moniker.MonikerFeature = MonikerFeature;
  return moniker;
}
var hasRequiredServer;
function requireServer() {
  if (hasRequiredServer) return server;
  hasRequiredServer = 1;
  Object.defineProperty(server, "__esModule", {
    value: true
  });
  server.createConnection = server.combineFeatures = server.combineNotebooksFeatures = server.combineLanguagesFeatures = server.combineWorkspaceFeatures = server.combineWindowFeatures = server.combineClientFeatures = server.combineTracerFeatures = server.combineTelemetryFeatures = server.combineConsoleFeatures = server._NotebooksImpl = server._LanguagesImpl = server.BulkUnregistration = server.BulkRegistration = server.ErrorMessageTracker = void 0;
  const vscode_languageserver_protocol_1 = requireMain$1();
  const Is = requireIs$2();
  const UUID = requireUuid();
  const progress_1 = requireProgress();
  const configuration_1 = requireConfiguration();
  const workspaceFolder_1 = requireWorkspaceFolder();
  const callHierarchy_1 = requireCallHierarchy();
  const semanticTokens_1 = requireSemanticTokens();
  const showDocument_1 = requireShowDocument();
  const fileOperations_1 = requireFileOperations();
  const linkedEditingRange_1 = requireLinkedEditingRange();
  const typeHierarchy_1 = requireTypeHierarchy();
  const inlineValue_1 = requireInlineValue();
  const foldingRange_1 = requireFoldingRange();
  const inlayHint_1 = requireInlayHint();
  const diagnostic_1 = requireDiagnostic();
  const notebook_1 = requireNotebook();
  const moniker_1 = requireMoniker();
  function null2Undefined(value) {
    if (value === null) {
      return void 0;
    }
    return value;
  }
  class ErrorMessageTracker {
    constructor() {
      this._messages = /* @__PURE__ */ Object.create(null);
    }
    add(message) {
      let count = this._messages[message];
      if (!count) {
        count = 0;
      }
      count++;
      this._messages[message] = count;
    }
    sendErrors(connection2) {
      Object.keys(this._messages).forEach((message) => {
        connection2.window.showErrorMessage(message);
      });
    }
  }
  server.ErrorMessageTracker = ErrorMessageTracker;
  class RemoteConsoleImpl {
    constructor() {
    }
    rawAttach(connection2) {
      this._rawConnection = connection2;
    }
    attach(connection2) {
      this._connection = connection2;
    }
    get connection() {
      if (!this._connection) {
        throw new Error("Remote is not attached to a connection yet.");
      }
      return this._connection;
    }
    fillServerCapabilities(_capabilities) {
    }
    initialize(_capabilities) {
    }
    error(message) {
      this.send(vscode_languageserver_protocol_1.MessageType.Error, message);
    }
    warn(message) {
      this.send(vscode_languageserver_protocol_1.MessageType.Warning, message);
    }
    info(message) {
      this.send(vscode_languageserver_protocol_1.MessageType.Info, message);
    }
    log(message) {
      this.send(vscode_languageserver_protocol_1.MessageType.Log, message);
    }
    debug(message) {
      this.send(vscode_languageserver_protocol_1.MessageType.Debug, message);
    }
    send(type, message) {
      if (this._rawConnection) {
        this._rawConnection.sendNotification(vscode_languageserver_protocol_1.LogMessageNotification.type, {
          type,
          message
        }).catch(() => {
          (0, vscode_languageserver_protocol_1.RAL)().console.error(`Sending log message failed`);
        });
      }
    }
  }
  class _RemoteWindowImpl {
    constructor() {
    }
    attach(connection2) {
      this._connection = connection2;
    }
    get connection() {
      if (!this._connection) {
        throw new Error("Remote is not attached to a connection yet.");
      }
      return this._connection;
    }
    initialize(_capabilities) {
    }
    fillServerCapabilities(_capabilities) {
    }
    showErrorMessage(message, ...actions) {
      let params = {
        type: vscode_languageserver_protocol_1.MessageType.Error,
        message,
        actions
      };
      return this.connection.sendRequest(vscode_languageserver_protocol_1.ShowMessageRequest.type, params).then(null2Undefined);
    }
    showWarningMessage(message, ...actions) {
      let params = {
        type: vscode_languageserver_protocol_1.MessageType.Warning,
        message,
        actions
      };
      return this.connection.sendRequest(vscode_languageserver_protocol_1.ShowMessageRequest.type, params).then(null2Undefined);
    }
    showInformationMessage(message, ...actions) {
      let params = {
        type: vscode_languageserver_protocol_1.MessageType.Info,
        message,
        actions
      };
      return this.connection.sendRequest(vscode_languageserver_protocol_1.ShowMessageRequest.type, params).then(null2Undefined);
    }
  }
  const RemoteWindowImpl = (0, showDocument_1.ShowDocumentFeature)((0, progress_1.ProgressFeature)(_RemoteWindowImpl));
  var BulkRegistration;
  (function(BulkRegistration2) {
    function create() {
      return new BulkRegistrationImpl();
    }
    BulkRegistration2.create = create;
  })(BulkRegistration || (server.BulkRegistration = BulkRegistration = {}));
  class BulkRegistrationImpl {
    constructor() {
      this._registrations = [];
      this._registered = /* @__PURE__ */ new Set();
    }
    add(type, registerOptions) {
      const method = Is.string(type) ? type : type.method;
      if (this._registered.has(method)) {
        throw new Error(`${method} is already added to this registration`);
      }
      const id = UUID.generateUuid();
      this._registrations.push({
        id,
        method,
        registerOptions: registerOptions || {}
      });
      this._registered.add(method);
    }
    asRegistrationParams() {
      return {
        registrations: this._registrations
      };
    }
  }
  var BulkUnregistration;
  (function(BulkUnregistration2) {
    function create() {
      return new BulkUnregistrationImpl(void 0, []);
    }
    BulkUnregistration2.create = create;
  })(BulkUnregistration || (server.BulkUnregistration = BulkUnregistration = {}));
  class BulkUnregistrationImpl {
    constructor(_connection, unregistrations) {
      this._connection = _connection;
      this._unregistrations = /* @__PURE__ */ new Map();
      unregistrations.forEach((unregistration) => {
        this._unregistrations.set(unregistration.method, unregistration);
      });
    }
    get isAttached() {
      return !!this._connection;
    }
    attach(connection2) {
      this._connection = connection2;
    }
    add(unregistration) {
      this._unregistrations.set(unregistration.method, unregistration);
    }
    dispose() {
      let unregistrations = [];
      for (let unregistration of this._unregistrations.values()) {
        unregistrations.push(unregistration);
      }
      let params = {
        unregisterations: unregistrations
      };
      this._connection.sendRequest(vscode_languageserver_protocol_1.UnregistrationRequest.type, params).catch(() => {
        this._connection.console.info(`Bulk unregistration failed.`);
      });
    }
    disposeSingle(arg) {
      const method = Is.string(arg) ? arg : arg.method;
      const unregistration = this._unregistrations.get(method);
      if (!unregistration) {
        return false;
      }
      let params = {
        unregisterations: [unregistration]
      };
      this._connection.sendRequest(vscode_languageserver_protocol_1.UnregistrationRequest.type, params).then(() => {
        this._unregistrations.delete(method);
      }, (_error) => {
        this._connection.console.info(`Un-registering request handler for ${unregistration.id} failed.`);
      });
      return true;
    }
  }
  class RemoteClientImpl {
    attach(connection2) {
      this._connection = connection2;
    }
    get connection() {
      if (!this._connection) {
        throw new Error("Remote is not attached to a connection yet.");
      }
      return this._connection;
    }
    initialize(_capabilities) {
    }
    fillServerCapabilities(_capabilities) {
    }
    register(typeOrRegistrations, registerOptionsOrType, registerOptions) {
      if (typeOrRegistrations instanceof BulkRegistrationImpl) {
        return this.registerMany(typeOrRegistrations);
      } else if (typeOrRegistrations instanceof BulkUnregistrationImpl) {
        return this.registerSingle1(typeOrRegistrations, registerOptionsOrType, registerOptions);
      } else {
        return this.registerSingle2(typeOrRegistrations, registerOptionsOrType);
      }
    }
    registerSingle1(unregistration, type, registerOptions) {
      const method = Is.string(type) ? type : type.method;
      const id = UUID.generateUuid();
      let params = {
        registrations: [{
          id,
          method,
          registerOptions: registerOptions || {}
        }]
      };
      if (!unregistration.isAttached) {
        unregistration.attach(this.connection);
      }
      return this.connection.sendRequest(vscode_languageserver_protocol_1.RegistrationRequest.type, params).then((_result) => {
        unregistration.add({
          id,
          method
        });
        return unregistration;
      }, (_error) => {
        this.connection.console.info(`Registering request handler for ${method} failed.`);
        return Promise.reject(_error);
      });
    }
    registerSingle2(type, registerOptions) {
      const method = Is.string(type) ? type : type.method;
      const id = UUID.generateUuid();
      let params = {
        registrations: [{
          id,
          method,
          registerOptions: registerOptions || {}
        }]
      };
      return this.connection.sendRequest(vscode_languageserver_protocol_1.RegistrationRequest.type, params).then((_result) => vscode_languageserver_protocol_1.Disposable.create(() => {
        this.unregisterSingle(id, method).catch(() => {
          this.connection.console.info(`Un-registering capability with id ${id} failed.`);
        });
      }), (_error) => {
        this.connection.console.info(`Registering request handler for ${method} failed.`);
        return Promise.reject(_error);
      });
    }
    unregisterSingle(id, method) {
      let params = {
        unregisterations: [{
          id,
          method
        }]
      };
      return this.connection.sendRequest(vscode_languageserver_protocol_1.UnregistrationRequest.type, params).catch(() => {
        this.connection.console.info(`Un-registering request handler for ${id} failed.`);
      });
    }
    registerMany(registrations) {
      let params = registrations.asRegistrationParams();
      return this.connection.sendRequest(vscode_languageserver_protocol_1.RegistrationRequest.type, params).then(() => new BulkUnregistrationImpl(this._connection, params.registrations.map((registration) => ({
        id: registration.id,
        method: registration.method
      }))), (_error) => {
        this.connection.console.info(`Bulk registration failed.`);
        return Promise.reject(_error);
      });
    }
  }
  class _RemoteWorkspaceImpl {
    constructor() {
    }
    attach(connection2) {
      this._connection = connection2;
    }
    get connection() {
      if (!this._connection) {
        throw new Error("Remote is not attached to a connection yet.");
      }
      return this._connection;
    }
    initialize(_capabilities) {
    }
    fillServerCapabilities(_capabilities) {
    }
    applyEdit(paramOrEdit) {
      function isApplyWorkspaceEditParams(value) {
        return value && !!value.edit;
      }
      let params = isApplyWorkspaceEditParams(paramOrEdit) ? paramOrEdit : {
        edit: paramOrEdit
      };
      return this.connection.sendRequest(vscode_languageserver_protocol_1.ApplyWorkspaceEditRequest.type, params);
    }
  }
  const RemoteWorkspaceImpl = (0, fileOperations_1.FileOperationsFeature)((0, workspaceFolder_1.WorkspaceFoldersFeature)((0, configuration_1.ConfigurationFeature)(_RemoteWorkspaceImpl)));
  class TracerImpl {
    constructor() {
      this._trace = vscode_languageserver_protocol_1.Trace.Off;
    }
    attach(connection2) {
      this._connection = connection2;
    }
    get connection() {
      if (!this._connection) {
        throw new Error("Remote is not attached to a connection yet.");
      }
      return this._connection;
    }
    initialize(_capabilities) {
    }
    fillServerCapabilities(_capabilities) {
    }
    set trace(value) {
      this._trace = value;
    }
    log(message, verbose) {
      if (this._trace === vscode_languageserver_protocol_1.Trace.Off) {
        return;
      }
      this.connection.sendNotification(vscode_languageserver_protocol_1.LogTraceNotification.type, {
        message,
        verbose: this._trace === vscode_languageserver_protocol_1.Trace.Verbose ? verbose : void 0
      }).catch(() => {
      });
    }
  }
  class TelemetryImpl {
    constructor() {
    }
    attach(connection2) {
      this._connection = connection2;
    }
    get connection() {
      if (!this._connection) {
        throw new Error("Remote is not attached to a connection yet.");
      }
      return this._connection;
    }
    initialize(_capabilities) {
    }
    fillServerCapabilities(_capabilities) {
    }
    logEvent(data) {
      this.connection.sendNotification(vscode_languageserver_protocol_1.TelemetryEventNotification.type, data).catch(() => {
        this.connection.console.log(`Sending TelemetryEventNotification failed`);
      });
    }
  }
  class _LanguagesImpl {
    constructor() {
    }
    attach(connection2) {
      this._connection = connection2;
    }
    get connection() {
      if (!this._connection) {
        throw new Error("Remote is not attached to a connection yet.");
      }
      return this._connection;
    }
    initialize(_capabilities) {
    }
    fillServerCapabilities(_capabilities) {
    }
    attachWorkDoneProgress(params) {
      return (0, progress_1.attachWorkDone)(this.connection, params);
    }
    attachPartialResultProgress(_type, params) {
      return (0, progress_1.attachPartialResult)(this.connection, params);
    }
  }
  server._LanguagesImpl = _LanguagesImpl;
  const LanguagesImpl = (0, foldingRange_1.FoldingRangeFeature)((0, moniker_1.MonikerFeature)((0, diagnostic_1.DiagnosticFeature)((0, inlayHint_1.InlayHintFeature)((0, inlineValue_1.InlineValueFeature)((0, typeHierarchy_1.TypeHierarchyFeature)((0, linkedEditingRange_1.LinkedEditingRangeFeature)((0, semanticTokens_1.SemanticTokensFeature)((0, callHierarchy_1.CallHierarchyFeature)(_LanguagesImpl)))))))));
  class _NotebooksImpl {
    constructor() {
    }
    attach(connection2) {
      this._connection = connection2;
    }
    get connection() {
      if (!this._connection) {
        throw new Error("Remote is not attached to a connection yet.");
      }
      return this._connection;
    }
    initialize(_capabilities) {
    }
    fillServerCapabilities(_capabilities) {
    }
    attachWorkDoneProgress(params) {
      return (0, progress_1.attachWorkDone)(this.connection, params);
    }
    attachPartialResultProgress(_type, params) {
      return (0, progress_1.attachPartialResult)(this.connection, params);
    }
  }
  server._NotebooksImpl = _NotebooksImpl;
  const NotebooksImpl = (0, notebook_1.NotebookSyncFeature)(_NotebooksImpl);
  function combineConsoleFeatures(one, two) {
    return function(Base) {
      return two(one(Base));
    };
  }
  server.combineConsoleFeatures = combineConsoleFeatures;
  function combineTelemetryFeatures(one, two) {
    return function(Base) {
      return two(one(Base));
    };
  }
  server.combineTelemetryFeatures = combineTelemetryFeatures;
  function combineTracerFeatures(one, two) {
    return function(Base) {
      return two(one(Base));
    };
  }
  server.combineTracerFeatures = combineTracerFeatures;
  function combineClientFeatures(one, two) {
    return function(Base) {
      return two(one(Base));
    };
  }
  server.combineClientFeatures = combineClientFeatures;
  function combineWindowFeatures(one, two) {
    return function(Base) {
      return two(one(Base));
    };
  }
  server.combineWindowFeatures = combineWindowFeatures;
  function combineWorkspaceFeatures(one, two) {
    return function(Base) {
      return two(one(Base));
    };
  }
  server.combineWorkspaceFeatures = combineWorkspaceFeatures;
  function combineLanguagesFeatures(one, two) {
    return function(Base) {
      return two(one(Base));
    };
  }
  server.combineLanguagesFeatures = combineLanguagesFeatures;
  function combineNotebooksFeatures(one, two) {
    return function(Base) {
      return two(one(Base));
    };
  }
  server.combineNotebooksFeatures = combineNotebooksFeatures;
  function combineFeatures(one, two) {
    function combine(one2, two2, func) {
      if (one2 && two2) {
        return func(one2, two2);
      } else if (one2) {
        return one2;
      } else {
        return two2;
      }
    }
    let result = {
      __brand: "features",
      console: combine(one.console, two.console, combineConsoleFeatures),
      tracer: combine(one.tracer, two.tracer, combineTracerFeatures),
      telemetry: combine(one.telemetry, two.telemetry, combineTelemetryFeatures),
      client: combine(one.client, two.client, combineClientFeatures),
      window: combine(one.window, two.window, combineWindowFeatures),
      workspace: combine(one.workspace, two.workspace, combineWorkspaceFeatures),
      languages: combine(one.languages, two.languages, combineLanguagesFeatures),
      notebooks: combine(one.notebooks, two.notebooks, combineNotebooksFeatures)
    };
    return result;
  }
  server.combineFeatures = combineFeatures;
  function createConnection(connectionFactory, watchDog, factories) {
    const logger = factories && factories.console ? new (factories.console(RemoteConsoleImpl))() : new RemoteConsoleImpl();
    const connection2 = connectionFactory(logger);
    logger.rawAttach(connection2);
    const tracer = factories && factories.tracer ? new (factories.tracer(TracerImpl))() : new TracerImpl();
    const telemetry = factories && factories.telemetry ? new (factories.telemetry(TelemetryImpl))() : new TelemetryImpl();
    const client = factories && factories.client ? new (factories.client(RemoteClientImpl))() : new RemoteClientImpl();
    const remoteWindow = factories && factories.window ? new (factories.window(RemoteWindowImpl))() : new RemoteWindowImpl();
    const workspace = factories && factories.workspace ? new (factories.workspace(RemoteWorkspaceImpl))() : new RemoteWorkspaceImpl();
    const languages = factories && factories.languages ? new (factories.languages(LanguagesImpl))() : new LanguagesImpl();
    const notebooks = factories && factories.notebooks ? new (factories.notebooks(NotebooksImpl))() : new NotebooksImpl();
    const allRemotes = [logger, tracer, telemetry, client, remoteWindow, workspace, languages, notebooks];
    function asPromise(value) {
      if (value instanceof Promise) {
        return value;
      } else if (Is.thenable(value)) {
        return new Promise((resolve2, reject) => {
          value.then((resolved) => resolve2(resolved), (error2) => reject(error2));
        });
      } else {
        return Promise.resolve(value);
      }
    }
    let shutdownHandler = void 0;
    let initializeHandler = void 0;
    let exitHandler = void 0;
    let protocolConnection = {
      listen: () => connection2.listen(),
      sendRequest: (type, ...params) => connection2.sendRequest(Is.string(type) ? type : type.method, ...params),
      onRequest: (type, handler) => connection2.onRequest(type, handler),
      sendNotification: (type, param) => {
        const method = Is.string(type) ? type : type.method;
        return connection2.sendNotification(method, param);
      },
      onNotification: (type, handler) => connection2.onNotification(type, handler),
      onProgress: connection2.onProgress,
      sendProgress: connection2.sendProgress,
      onInitialize: (handler) => {
        initializeHandler = handler;
        return {
          dispose: () => {
            initializeHandler = void 0;
          }
        };
      },
      onInitialized: (handler) => connection2.onNotification(vscode_languageserver_protocol_1.InitializedNotification.type, handler),
      onShutdown: (handler) => {
        shutdownHandler = handler;
        return {
          dispose: () => {
            shutdownHandler = void 0;
          }
        };
      },
      onExit: (handler) => {
        exitHandler = handler;
        return {
          dispose: () => {
            exitHandler = void 0;
          }
        };
      },
      get console() {
        return logger;
      },
      get telemetry() {
        return telemetry;
      },
      get tracer() {
        return tracer;
      },
      get client() {
        return client;
      },
      get window() {
        return remoteWindow;
      },
      get workspace() {
        return workspace;
      },
      get languages() {
        return languages;
      },
      get notebooks() {
        return notebooks;
      },
      onDidChangeConfiguration: (handler) => connection2.onNotification(vscode_languageserver_protocol_1.DidChangeConfigurationNotification.type, handler),
      onDidChangeWatchedFiles: (handler) => connection2.onNotification(vscode_languageserver_protocol_1.DidChangeWatchedFilesNotification.type, handler),
      __textDocumentSync: void 0,
      onDidOpenTextDocument: (handler) => connection2.onNotification(vscode_languageserver_protocol_1.DidOpenTextDocumentNotification.type, handler),
      onDidChangeTextDocument: (handler) => connection2.onNotification(vscode_languageserver_protocol_1.DidChangeTextDocumentNotification.type, handler),
      onDidCloseTextDocument: (handler) => connection2.onNotification(vscode_languageserver_protocol_1.DidCloseTextDocumentNotification.type, handler),
      onWillSaveTextDocument: (handler) => connection2.onNotification(vscode_languageserver_protocol_1.WillSaveTextDocumentNotification.type, handler),
      onWillSaveTextDocumentWaitUntil: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.WillSaveTextDocumentWaitUntilRequest.type, handler),
      onDidSaveTextDocument: (handler) => connection2.onNotification(vscode_languageserver_protocol_1.DidSaveTextDocumentNotification.type, handler),
      sendDiagnostics: (params) => connection2.sendNotification(vscode_languageserver_protocol_1.PublishDiagnosticsNotification.type, params),
      onHover: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.HoverRequest.type, (params, cancel) => handler(params, cancel, (0, progress_1.attachWorkDone)(connection2, params), void 0)),
      onCompletion: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.CompletionRequest.type, (params, cancel) => handler(params, cancel, (0, progress_1.attachWorkDone)(connection2, params), (0, progress_1.attachPartialResult)(connection2, params))),
      onCompletionResolve: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.CompletionResolveRequest.type, handler),
      onSignatureHelp: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.SignatureHelpRequest.type, (params, cancel) => handler(params, cancel, (0, progress_1.attachWorkDone)(connection2, params), void 0)),
      onDeclaration: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.DeclarationRequest.type, (params, cancel) => handler(params, cancel, (0, progress_1.attachWorkDone)(connection2, params), (0, progress_1.attachPartialResult)(connection2, params))),
      onDefinition: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.DefinitionRequest.type, (params, cancel) => handler(params, cancel, (0, progress_1.attachWorkDone)(connection2, params), (0, progress_1.attachPartialResult)(connection2, params))),
      onTypeDefinition: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.TypeDefinitionRequest.type, (params, cancel) => handler(params, cancel, (0, progress_1.attachWorkDone)(connection2, params), (0, progress_1.attachPartialResult)(connection2, params))),
      onImplementation: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.ImplementationRequest.type, (params, cancel) => handler(params, cancel, (0, progress_1.attachWorkDone)(connection2, params), (0, progress_1.attachPartialResult)(connection2, params))),
      onReferences: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.ReferencesRequest.type, (params, cancel) => handler(params, cancel, (0, progress_1.attachWorkDone)(connection2, params), (0, progress_1.attachPartialResult)(connection2, params))),
      onDocumentHighlight: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.DocumentHighlightRequest.type, (params, cancel) => handler(params, cancel, (0, progress_1.attachWorkDone)(connection2, params), (0, progress_1.attachPartialResult)(connection2, params))),
      onDocumentSymbol: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.DocumentSymbolRequest.type, (params, cancel) => handler(params, cancel, (0, progress_1.attachWorkDone)(connection2, params), (0, progress_1.attachPartialResult)(connection2, params))),
      onWorkspaceSymbol: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.WorkspaceSymbolRequest.type, (params, cancel) => handler(params, cancel, (0, progress_1.attachWorkDone)(connection2, params), (0, progress_1.attachPartialResult)(connection2, params))),
      onWorkspaceSymbolResolve: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.WorkspaceSymbolResolveRequest.type, handler),
      onCodeAction: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.CodeActionRequest.type, (params, cancel) => handler(params, cancel, (0, progress_1.attachWorkDone)(connection2, params), (0, progress_1.attachPartialResult)(connection2, params))),
      onCodeActionResolve: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.CodeActionResolveRequest.type, (params, cancel) => handler(params, cancel)),
      onCodeLens: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.CodeLensRequest.type, (params, cancel) => handler(params, cancel, (0, progress_1.attachWorkDone)(connection2, params), (0, progress_1.attachPartialResult)(connection2, params))),
      onCodeLensResolve: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.CodeLensResolveRequest.type, (params, cancel) => handler(params, cancel)),
      onDocumentFormatting: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.DocumentFormattingRequest.type, (params, cancel) => handler(params, cancel, (0, progress_1.attachWorkDone)(connection2, params), void 0)),
      onDocumentRangeFormatting: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.DocumentRangeFormattingRequest.type, (params, cancel) => handler(params, cancel, (0, progress_1.attachWorkDone)(connection2, params), void 0)),
      onDocumentOnTypeFormatting: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.DocumentOnTypeFormattingRequest.type, (params, cancel) => handler(params, cancel)),
      onRenameRequest: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.RenameRequest.type, (params, cancel) => handler(params, cancel, (0, progress_1.attachWorkDone)(connection2, params), void 0)),
      onPrepareRename: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.PrepareRenameRequest.type, (params, cancel) => handler(params, cancel)),
      onDocumentLinks: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.DocumentLinkRequest.type, (params, cancel) => handler(params, cancel, (0, progress_1.attachWorkDone)(connection2, params), (0, progress_1.attachPartialResult)(connection2, params))),
      onDocumentLinkResolve: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.DocumentLinkResolveRequest.type, (params, cancel) => handler(params, cancel)),
      onDocumentColor: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.DocumentColorRequest.type, (params, cancel) => handler(params, cancel, (0, progress_1.attachWorkDone)(connection2, params), (0, progress_1.attachPartialResult)(connection2, params))),
      onColorPresentation: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.ColorPresentationRequest.type, (params, cancel) => handler(params, cancel, (0, progress_1.attachWorkDone)(connection2, params), (0, progress_1.attachPartialResult)(connection2, params))),
      onFoldingRanges: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.FoldingRangeRequest.type, (params, cancel) => handler(params, cancel, (0, progress_1.attachWorkDone)(connection2, params), (0, progress_1.attachPartialResult)(connection2, params))),
      onSelectionRanges: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.SelectionRangeRequest.type, (params, cancel) => handler(params, cancel, (0, progress_1.attachWorkDone)(connection2, params), (0, progress_1.attachPartialResult)(connection2, params))),
      onExecuteCommand: (handler) => connection2.onRequest(vscode_languageserver_protocol_1.ExecuteCommandRequest.type, (params, cancel) => handler(params, cancel, (0, progress_1.attachWorkDone)(connection2, params), void 0)),
      dispose: () => connection2.dispose()
    };
    for (let remote of allRemotes) {
      remote.attach(protocolConnection);
    }
    connection2.onRequest(vscode_languageserver_protocol_1.InitializeRequest.type, (params) => {
      watchDog.initialize(params);
      if (Is.string(params.trace)) {
        tracer.trace = vscode_languageserver_protocol_1.Trace.fromString(params.trace);
      }
      for (let remote of allRemotes) {
        remote.initialize(params.capabilities);
      }
      if (initializeHandler) {
        let result = initializeHandler(params, new vscode_languageserver_protocol_1.CancellationTokenSource().token, (0, progress_1.attachWorkDone)(connection2, params), void 0);
        return asPromise(result).then((value) => {
          if (value instanceof vscode_languageserver_protocol_1.ResponseError) {
            return value;
          }
          let result2 = value;
          if (!result2) {
            result2 = {
              capabilities: {}
            };
          }
          let capabilities = result2.capabilities;
          if (!capabilities) {
            capabilities = {};
            result2.capabilities = capabilities;
          }
          if (capabilities.textDocumentSync === void 0 || capabilities.textDocumentSync === null) {
            capabilities.textDocumentSync = Is.number(protocolConnection.__textDocumentSync) ? protocolConnection.__textDocumentSync : vscode_languageserver_protocol_1.TextDocumentSyncKind.None;
          } else if (!Is.number(capabilities.textDocumentSync) && !Is.number(capabilities.textDocumentSync.change)) {
            capabilities.textDocumentSync.change = Is.number(protocolConnection.__textDocumentSync) ? protocolConnection.__textDocumentSync : vscode_languageserver_protocol_1.TextDocumentSyncKind.None;
          }
          for (let remote of allRemotes) {
            remote.fillServerCapabilities(capabilities);
          }
          return result2;
        });
      } else {
        let result = {
          capabilities: {
            textDocumentSync: vscode_languageserver_protocol_1.TextDocumentSyncKind.None
          }
        };
        for (let remote of allRemotes) {
          remote.fillServerCapabilities(result.capabilities);
        }
        return result;
      }
    });
    connection2.onRequest(vscode_languageserver_protocol_1.ShutdownRequest.type, () => {
      watchDog.shutdownReceived = true;
      if (shutdownHandler) {
        return shutdownHandler(new vscode_languageserver_protocol_1.CancellationTokenSource().token);
      } else {
        return void 0;
      }
    });
    connection2.onNotification(vscode_languageserver_protocol_1.ExitNotification.type, () => {
      try {
        if (exitHandler) {
          exitHandler();
        }
      } finally {
        if (watchDog.shutdownReceived) {
          watchDog.exit(0);
        } else {
          watchDog.exit(1);
        }
      }
    });
    connection2.onNotification(vscode_languageserver_protocol_1.SetTraceNotification.type, (params) => {
      tracer.trace = vscode_languageserver_protocol_1.Trace.fromString(params.value);
    });
    return protocolConnection;
  }
  server.createConnection = createConnection;
  return server;
}
var files = {};
var hasRequiredFiles;
function requireFiles() {
  if (hasRequiredFiles) return files;
  hasRequiredFiles = 1;
  Object.defineProperty(files, "__esModule", {
    value: true
  });
  files.resolveModulePath = files.FileSystem = files.resolveGlobalYarnPath = files.resolveGlobalNodePath = files.resolve = files.uriToFilePath = void 0;
  const url = require$$0$2;
  const path2 = require$$1$1;
  const fs2 = require$$2$1;
  const child_process_1 = require$$3;
  function uriToFilePath(uri) {
    let parsed = url.parse(uri);
    if (parsed.protocol !== "file:" || !parsed.path) {
      return void 0;
    }
    let segments = parsed.path.split("/");
    for (var i = 0, len = segments.length; i < len; i++) {
      segments[i] = decodeURIComponent(segments[i]);
    }
    if (process.platform === "win32" && segments.length > 1) {
      let first = segments[0];
      let second = segments[1];
      if (first.length === 0 && second.length > 1 && second[1] === ":") {
        segments.shift();
      }
    }
    return path2.normalize(segments.join("/"));
  }
  files.uriToFilePath = uriToFilePath;
  function isWindows() {
    return process.platform === "win32";
  }
  function resolve2(moduleName, nodePath, cwd, tracer) {
    const nodePathKey = "NODE_PATH";
    const app = ["var p = process;", "p.on('message',function(m){", "if(m.c==='e'){", "p.exit(0);", "}", "else if(m.c==='rs'){", "try{", "var r=require.resolve(m.a);", "p.send({c:'r',s:true,r:r});", "}", "catch(err){", "p.send({c:'r',s:false});", "}", "}", "});"].join("");
    return new Promise((resolve3, reject) => {
      let env = process.env;
      let newEnv = /* @__PURE__ */ Object.create(null);
      Object.keys(env).forEach((key) => newEnv[key] = env[key]);
      if (nodePath && fs2.existsSync(nodePath)) {
        if (newEnv[nodePathKey]) {
          newEnv[nodePathKey] = nodePath + path2.delimiter + newEnv[nodePathKey];
        } else {
          newEnv[nodePathKey] = nodePath;
        }
        if (tracer) {
          tracer(`NODE_PATH value is: ${newEnv[nodePathKey]}`);
        }
      }
      newEnv["ELECTRON_RUN_AS_NODE"] = "1";
      try {
        let cp = (0, child_process_1.fork)("", [], {
          cwd,
          env: newEnv,
          execArgv: ["-e", app]
        });
        if (cp.pid === void 0) {
          reject(new Error(`Starting process to resolve node module  ${moduleName} failed`));
          return;
        }
        cp.on("error", (error2) => {
          reject(error2);
        });
        cp.on("message", (message2) => {
          if (message2.c === "r") {
            cp.send({
              c: "e"
            });
            if (message2.s) {
              resolve3(message2.r);
            } else {
              reject(new Error(`Failed to resolve module: ${moduleName}`));
            }
          }
        });
        let message = {
          c: "rs",
          a: moduleName
        };
        cp.send(message);
      } catch (error2) {
        reject(error2);
      }
    });
  }
  files.resolve = resolve2;
  function resolveGlobalNodePath(tracer) {
    let npmCommand = "npm";
    const env = /* @__PURE__ */ Object.create(null);
    Object.keys(process.env).forEach((key) => env[key] = process.env[key]);
    env["NO_UPDATE_NOTIFIER"] = "true";
    const options2 = {
      encoding: "utf8",
      env
    };
    if (isWindows()) {
      npmCommand = "npm.cmd";
      options2.shell = true;
    }
    let handler = () => {
    };
    try {
      process.on("SIGPIPE", handler);
      let stdout = (0, child_process_1.spawnSync)(npmCommand, ["config", "get", "prefix"], options2).stdout;
      if (!stdout) {
        if (tracer) {
          tracer(`'npm config get prefix' didn't return a value.`);
        }
        return void 0;
      }
      let prefix = stdout.trim();
      if (tracer) {
        tracer(`'npm config get prefix' value is: ${prefix}`);
      }
      if (prefix.length > 0) {
        if (isWindows()) {
          return path2.join(prefix, "node_modules");
        } else {
          return path2.join(prefix, "lib", "node_modules");
        }
      }
      return void 0;
    } catch (err) {
      return void 0;
    } finally {
      process.removeListener("SIGPIPE", handler);
    }
  }
  files.resolveGlobalNodePath = resolveGlobalNodePath;
  function resolveGlobalYarnPath(tracer) {
    let yarnCommand = "yarn";
    let options2 = {
      encoding: "utf8"
    };
    if (isWindows()) {
      yarnCommand = "yarn.cmd";
      options2.shell = true;
    }
    let handler = () => {
    };
    try {
      process.on("SIGPIPE", handler);
      let results = (0, child_process_1.spawnSync)(yarnCommand, ["global", "dir", "--json"], options2);
      let stdout = results.stdout;
      if (!stdout) {
        if (tracer) {
          tracer(`'yarn global dir' didn't return a value.`);
          if (results.stderr) {
            tracer(results.stderr);
          }
        }
        return void 0;
      }
      let lines = stdout.trim().split(/\r?\n/);
      for (let line of lines) {
        try {
          let yarn = JSON.parse(line);
          if (yarn.type === "log") {
            return path2.join(yarn.data, "node_modules");
          }
        } catch (e) {
        }
      }
      return void 0;
    } catch (err) {
      return void 0;
    } finally {
      process.removeListener("SIGPIPE", handler);
    }
  }
  files.resolveGlobalYarnPath = resolveGlobalYarnPath;
  var FileSystem;
  (function(FileSystem2) {
    let _isCaseSensitive = void 0;
    function isCaseSensitive() {
      if (_isCaseSensitive !== void 0) {
        return _isCaseSensitive;
      }
      if (process.platform === "win32") {
        _isCaseSensitive = false;
      } else {
        _isCaseSensitive = !fs2.existsSync(__filename.toUpperCase()) || !fs2.existsSync(__filename.toLowerCase());
      }
      return _isCaseSensitive;
    }
    FileSystem2.isCaseSensitive = isCaseSensitive;
    function isParent(parent, child) {
      if (isCaseSensitive()) {
        return path2.normalize(child).indexOf(path2.normalize(parent)) === 0;
      } else {
        return path2.normalize(child).toLowerCase().indexOf(path2.normalize(parent).toLowerCase()) === 0;
      }
    }
    FileSystem2.isParent = isParent;
  })(FileSystem || (files.FileSystem = FileSystem = {}));
  function resolveModulePath(workspaceRoot, moduleName, nodePath, tracer) {
    if (nodePath) {
      if (!path2.isAbsolute(nodePath)) {
        nodePath = path2.join(workspaceRoot, nodePath);
      }
      return resolve2(moduleName, nodePath, nodePath, tracer).then((value) => {
        if (FileSystem.isParent(nodePath, value)) {
          return value;
        } else {
          return Promise.reject(new Error(`Failed to load ${moduleName} from node path location.`));
        }
      }).then(void 0, (_error) => resolve2(moduleName, resolveGlobalNodePath(tracer), workspaceRoot, tracer));
    } else {
      return resolve2(moduleName, resolveGlobalNodePath(tracer), workspaceRoot, tracer);
    }
  }
  files.resolveModulePath = resolveModulePath;
  return files;
}
var node$1;
var hasRequiredNode$1;
function requireNode$1() {
  if (hasRequiredNode$1) return node$1;
  hasRequiredNode$1 = 1;
  node$1 = requireMain$1();
  return node$1;
}
var api = {};
var inlineCompletion_proposed = {};
var hasRequiredInlineCompletion_proposed;
function requireInlineCompletion_proposed() {
  if (hasRequiredInlineCompletion_proposed) return inlineCompletion_proposed;
  hasRequiredInlineCompletion_proposed = 1;
  Object.defineProperty(inlineCompletion_proposed, "__esModule", {
    value: true
  });
  inlineCompletion_proposed.InlineCompletionFeature = void 0;
  const vscode_languageserver_protocol_1 = requireMain$1();
  const InlineCompletionFeature = (Base) => class extends Base {
    get inlineCompletion() {
      return {
        on: (handler) => this.connection.onRequest(vscode_languageserver_protocol_1.InlineCompletionRequest.type, (params, cancel) => handler(params, cancel, this.attachWorkDoneProgress(params)))
      };
    }
  };
  inlineCompletion_proposed.InlineCompletionFeature = InlineCompletionFeature;
  return inlineCompletion_proposed;
}
var hasRequiredApi;
function requireApi() {
  if (hasRequiredApi) return api;
  hasRequiredApi = 1;
  (function(exports) {
    var __createBinding = api && api.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
          enumerable: true,
          get: function() {
            return m[k];
          }
        };
      }
      Object.defineProperty(o, k2, desc);
    } : function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = api && api.__exportStar || function(m, exports2) {
      for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports2, p)) __createBinding(exports2, m, p);
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.ProposedFeatures = exports.NotebookDocuments = exports.TextDocuments = exports.SemanticTokensBuilder = void 0;
    const semanticTokens_1 = requireSemanticTokens();
    Object.defineProperty(exports, "SemanticTokensBuilder", {
      enumerable: true,
      get: function() {
        return semanticTokens_1.SemanticTokensBuilder;
      }
    });
    const ic = requireInlineCompletion_proposed();
    __exportStar(requireMain$1(), exports);
    const textDocuments_1 = requireTextDocuments();
    Object.defineProperty(exports, "TextDocuments", {
      enumerable: true,
      get: function() {
        return textDocuments_1.TextDocuments;
      }
    });
    const notebook_1 = requireNotebook();
    Object.defineProperty(exports, "NotebookDocuments", {
      enumerable: true,
      get: function() {
        return notebook_1.NotebookDocuments;
      }
    });
    __exportStar(requireServer(), exports);
    var ProposedFeatures;
    (function(ProposedFeatures2) {
      ProposedFeatures2.all = {
        __brand: "features",
        languages: ic.InlineCompletionFeature
      };
    })(ProposedFeatures || (exports.ProposedFeatures = ProposedFeatures = {}));
  })(api);
  return api;
}
var hasRequiredMain;
function requireMain() {
  if (hasRequiredMain) return main$3;
  hasRequiredMain = 1;
  (function(exports) {
    var __createBinding = main$3 && main$3.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
          enumerable: true,
          get: function() {
            return m[k];
          }
        };
      }
      Object.defineProperty(o, k2, desc);
    } : function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = main$3 && main$3.__exportStar || function(m, exports2) {
      for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports2, p)) __createBinding(exports2, m, p);
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.createConnection = exports.Files = void 0;
    const node_util_1 = require$$0$3;
    const Is = requireIs$2();
    const server_1 = requireServer();
    const fm = requireFiles();
    const node_1 = requireNode$1();
    __exportStar(requireNode$1(), exports);
    __exportStar(requireApi(), exports);
    var Files;
    (function(Files2) {
      Files2.uriToFilePath = fm.uriToFilePath;
      Files2.resolveGlobalNodePath = fm.resolveGlobalNodePath;
      Files2.resolveGlobalYarnPath = fm.resolveGlobalYarnPath;
      Files2.resolve = fm.resolve;
      Files2.resolveModulePath = fm.resolveModulePath;
    })(Files || (exports.Files = Files = {}));
    function endProtocolConnection() {
      {
        return;
      }
    }
    let _shutdownReceived = false;
    let exitTimer = void 0;
    function setupExitTimer() {
      const argName = "--clientProcessId";
      function runTimer(value) {
        try {
          let processId = parseInt(value);
          if (!isNaN(processId)) {
            exitTimer = setInterval(() => {
              try {
                process.kill(processId, 0);
              } catch (ex) {
                endProtocolConnection();
                process.exit(_shutdownReceived ? 0 : 1);
              }
            }, 3e3);
          }
        } catch (e) {
        }
      }
      for (let i = 2; i < process.argv.length; i++) {
        let arg = process.argv[i];
        if (arg === argName && i + 1 < process.argv.length) {
          runTimer(process.argv[i + 1]);
          return;
        } else {
          let args = arg.split("=");
          if (args[0] === argName) {
            runTimer(args[1]);
          }
        }
      }
    }
    setupExitTimer();
    const watchDog = {
      initialize: (params) => {
        const processId = params.processId;
        if (Is.number(processId) && exitTimer === void 0) {
          setInterval(() => {
            try {
              process.kill(processId, 0);
            } catch (ex) {
              process.exit(_shutdownReceived ? 0 : 1);
            }
          }, 3e3);
        }
      },
      get shutdownReceived() {
        return _shutdownReceived;
      },
      set shutdownReceived(value) {
        _shutdownReceived = value;
      },
      exit: (code) => {
        process.exit(code);
      }
    };
    function createConnection(arg1, arg2, arg3, arg4) {
      let factories;
      let input;
      let output;
      let options2;
      if (arg1 !== void 0 && arg1.__brand === "features") {
        factories = arg1;
        arg1 = arg2;
        arg2 = arg3;
        arg3 = arg4;
      }
      if (node_1.ConnectionStrategy.is(arg1) || node_1.ConnectionOptions.is(arg1)) {
        options2 = arg1;
      } else {
        input = arg1;
        output = arg2;
        options2 = arg3;
      }
      return _createConnection(input, output, options2, factories);
    }
    exports.createConnection = createConnection;
    function _createConnection(input, output, options2, factories) {
      let stdio = false;
      if (!input && !output && process.argv.length > 2) {
        let port = void 0;
        let pipeName = void 0;
        let argv = process.argv.slice(2);
        for (let i = 0; i < argv.length; i++) {
          let arg = argv[i];
          if (arg === "--node-ipc") {
            input = new node_1.IPCMessageReader(process);
            output = new node_1.IPCMessageWriter(process);
            break;
          } else if (arg === "--stdio") {
            stdio = true;
            input = process.stdin;
            output = process.stdout;
            break;
          } else if (arg === "--socket") {
            port = parseInt(argv[i + 1]);
            break;
          } else if (arg === "--pipe") {
            pipeName = argv[i + 1];
            break;
          } else {
            var args = arg.split("=");
            if (args[0] === "--socket") {
              port = parseInt(args[1]);
              break;
            } else if (args[0] === "--pipe") {
              pipeName = args[1];
              break;
            }
          }
        }
        if (port) {
          let transport = (0, node_1.createServerSocketTransport)(port);
          input = transport[0];
          output = transport[1];
        } else if (pipeName) {
          let transport = (0, node_1.createServerPipeTransport)(pipeName);
          input = transport[0];
          output = transport[1];
        }
      }
      var commandLineMessage = "Use arguments of createConnection or set command line parameters: '--node-ipc', '--stdio' or '--socket={number}'";
      if (!input) {
        throw new Error("Connection input stream is not set. " + commandLineMessage);
      }
      if (!output) {
        throw new Error("Connection output stream is not set. " + commandLineMessage);
      }
      if (Is.func(input.read) && Is.func(input.on)) {
        let inputStream = input;
        inputStream.on("end", () => {
          process.exit(_shutdownReceived ? 0 : 1);
        });
        inputStream.on("close", () => {
          process.exit(_shutdownReceived ? 0 : 1);
        });
      }
      const connectionFactory = (logger) => {
        const result = (0, node_1.createProtocolConnection)(input, output, logger, options2);
        if (stdio) {
          patchConsole(logger);
        }
        return result;
      };
      return (0, server_1.createConnection)(connectionFactory, watchDog, factories);
    }
    function patchConsole(logger) {
      function serialize(args) {
        return args.map((arg) => typeof arg === "string" ? arg : (0, node_util_1.inspect)(arg)).join(" ");
      }
      const counters = /* @__PURE__ */ new Map();
      console.assert = function assert(assertion, ...args) {
        if (assertion) {
          return;
        }
        if (args.length === 0) {
          logger.error("Assertion failed");
        } else {
          const [message, ...rest] = args;
          logger.error(`Assertion failed: ${message} ${serialize(rest)}`);
        }
      };
      console.count = function count(label = "default") {
        const message = String(label);
        let counter = counters.get(message) ?? 0;
        counter += 1;
        counters.set(message, counter);
        logger.log(`${message}: ${message}`);
      };
      console.countReset = function countReset(label) {
        if (label === void 0) {
          counters.clear();
        } else {
          counters.delete(String(label));
        }
      };
      console.debug = function debug(...args) {
        logger.log(serialize(args));
      };
      console.dir = function dir(arg, options2) {
        logger.log((0, node_util_1.inspect)(arg, options2));
      };
      console.log = function log(...args) {
        logger.log(serialize(args));
      };
      console.error = function error2(...args) {
        logger.error(serialize(args));
      };
      console.trace = function trace(...args) {
        const stack = new Error().stack.replace(/(.+\n){2}/, "");
        let message = "Trace";
        if (args.length !== 0) {
          message += `: ${serialize(args)}`;
        }
        logger.log(`${message}
${stack}`);
      };
      console.warn = function warn(...args) {
        logger.warn(serialize(args));
      };
    }
  })(main$3);
  return main$3;
}
var mainExports$2 = requireMain();
var lsp$1 = getDefaultExportFromCjs(mainExports$2);
var node;
var hasRequiredNode;
function requireNode() {
  if (hasRequiredNode) return node;
  hasRequiredNode = 1;
  node = requireMain();
  return node;
}
var nodeExports = requireNode();
var lsp = getDefaultExportFromCjs(nodeExports);
var LogLevel;
(function(LogLevel2) {
  LogLevel2[LogLevel2["Error"] = 0] = "Error";
  LogLevel2[LogLevel2["Warning"] = 1] = "Warning";
  LogLevel2[LogLevel2["Info"] = 2] = "Info";
  LogLevel2[LogLevel2["Log"] = 3] = "Log";
})(LogLevel || (LogLevel = {}));
(function(LogLevel2) {
  function fromString(value) {
    switch (value?.toLowerCase()) {
      case "log":
        return LogLevel2.Log;
      case "info":
        return LogLevel2.Info;
      case "warning":
        return LogLevel2.Warning;
      case "error":
      default:
        return LogLevel2.Error;
    }
  }
  LogLevel2.fromString = fromString;
  function toString(level) {
    switch (level) {
      case LogLevel2.Error:
        return "error";
      case LogLevel2.Warning:
        return "warning";
      case LogLevel2.Info:
        return "info";
      case LogLevel2.Log:
        return "log";
    }
  }
  LogLevel2.toString = toString;
})(LogLevel || (LogLevel = {}));
var LspClientLogger = class {
  client;
  level;
  constructor(client, level) {
    this.client = client;
    this.level = level;
  }
  sendMessage(severity, messageObjects, options2) {
    if (this.level >= severity || options2?.overrideLevel) {
      const message = messageObjects.map((p) => {
        if (typeof p === "object") {
          return JSON.stringify(p, null, 2);
        } else {
          return p;
        }
      }).join(" ");
      this.client.logMessage({
        type: severity,
        message
      });
    }
  }
  logLevelToLspMessageType(level) {
    switch (level) {
      case LogLevel.Log:
        return lsp$1.MessageType.Log;
      case LogLevel.Info:
        return lsp$1.MessageType.Info;
      case LogLevel.Warning:
        return lsp$1.MessageType.Warning;
      case LogLevel.Error:
        return lsp$1.MessageType.Error;
    }
  }
  error(...args) {
    this.sendMessage(lsp$1.MessageType.Error, args);
  }
  warn(...args) {
    this.sendMessage(lsp$1.MessageType.Warning, args);
  }
  info(...args) {
    this.sendMessage(lsp$1.MessageType.Info, args);
  }
  log(...args) {
    this.sendMessage(lsp$1.MessageType.Log, args);
  }
  logIgnoringVerbosity(level, ...args) {
    this.sendMessage(this.logLevelToLspMessageType(level), args, {
      overrideLevel: true
    });
  }
  trace(level, message, data) {
    this.logIgnoringVerbosity(LogLevel.Log, `[${level}  - ${now()}] ${message}`);
    if (data) {
      this.logIgnoringVerbosity(LogLevel.Log, data2String(data));
    }
  }
};
var PrefixingLogger = class {
  logger;
  prefix;
  constructor(logger, prefix) {
    this.logger = logger;
    this.prefix = prefix;
  }
  error(...args) {
    this.logger.error(this.prefix, ...args);
  }
  warn(...args) {
    this.logger.warn(this.prefix, ...args);
  }
  info(...args) {
    this.logger.info(this.prefix, ...args);
  }
  log(...args) {
    this.logger.log(this.prefix, ...args);
  }
  logIgnoringVerbosity(level, ...args) {
    this.logger.logIgnoringVerbosity(level, this.prefix, ...args);
  }
  trace(level, message, data) {
    this.logIgnoringVerbosity(LogLevel.Log, this.prefix, `[${level}  - ${now()}] ${message}`);
    if (data) {
      this.logIgnoringVerbosity(LogLevel.Log, this.prefix, data2String(data));
    }
  }
};
function now() {
  const now2 = /* @__PURE__ */ new Date();
  return `${padLeft(`${now2.getUTCHours()}`, 2, "0")}:${padLeft(`${now2.getMinutes()}`, 2, "0")}:${padLeft(`${now2.getUTCSeconds()}`, 2, "0")}.${now2.getMilliseconds()}`;
}
function padLeft(s, n, pad = " ") {
  return pad.repeat(Math.max(0, n - s.length)) + s;
}
function data2String(data) {
  if (data instanceof Error) {
    return data.stack || data.message;
  }
  return data.success === false && data.message ? data.message : data.toString();
}
var fs$1 = {};
var universalify = {};
var hasRequiredUniversalify;
function requireUniversalify() {
  if (hasRequiredUniversalify) return universalify;
  hasRequiredUniversalify = 1;
  universalify.fromCallback = function(fn) {
    return Object.defineProperty(function(...args) {
      if (typeof args[args.length - 1] === "function") fn.apply(this, args);
      else {
        return new Promise((resolve2, reject) => {
          args.push((err, res) => err != null ? reject(err) : resolve2(res));
          fn.apply(this, args);
        });
      }
    }, "name", {
      value: fn.name
    });
  };
  universalify.fromPromise = function(fn) {
    return Object.defineProperty(function(...args) {
      const cb = args[args.length - 1];
      if (typeof cb !== "function") return fn.apply(this, args);
      else {
        args.pop();
        fn.apply(this, args).then((r) => cb(null, r), cb);
      }
    }, "name", {
      value: fn.name
    });
  };
  return universalify;
}
var polyfills;
var hasRequiredPolyfills;
function requirePolyfills() {
  if (hasRequiredPolyfills) return polyfills;
  hasRequiredPolyfills = 1;
  var constants2 = require$$0$4;
  var origCwd = process.cwd;
  var cwd = null;
  var platform = process.env.GRACEFUL_FS_PLATFORM || process.platform;
  process.cwd = function() {
    if (!cwd) cwd = origCwd.call(process);
    return cwd;
  };
  try {
    process.cwd();
  } catch (er) {
  }
  if (typeof process.chdir === "function") {
    var chdir = process.chdir;
    process.chdir = function(d) {
      cwd = null;
      chdir.call(process, d);
    };
    if (Object.setPrototypeOf) Object.setPrototypeOf(process.chdir, chdir);
  }
  polyfills = patch;
  function patch(fs2) {
    if (constants2.hasOwnProperty("O_SYMLINK") && process.version.match(/^v0\.6\.[0-2]|^v0\.5\./)) {
      patchLchmod(fs2);
    }
    if (!fs2.lutimes) {
      patchLutimes(fs2);
    }
    fs2.chown = chownFix(fs2.chown);
    fs2.fchown = chownFix(fs2.fchown);
    fs2.lchown = chownFix(fs2.lchown);
    fs2.chmod = chmodFix(fs2.chmod);
    fs2.fchmod = chmodFix(fs2.fchmod);
    fs2.lchmod = chmodFix(fs2.lchmod);
    fs2.chownSync = chownFixSync(fs2.chownSync);
    fs2.fchownSync = chownFixSync(fs2.fchownSync);
    fs2.lchownSync = chownFixSync(fs2.lchownSync);
    fs2.chmodSync = chmodFixSync(fs2.chmodSync);
    fs2.fchmodSync = chmodFixSync(fs2.fchmodSync);
    fs2.lchmodSync = chmodFixSync(fs2.lchmodSync);
    fs2.stat = statFix(fs2.stat);
    fs2.fstat = statFix(fs2.fstat);
    fs2.lstat = statFix(fs2.lstat);
    fs2.statSync = statFixSync(fs2.statSync);
    fs2.fstatSync = statFixSync(fs2.fstatSync);
    fs2.lstatSync = statFixSync(fs2.lstatSync);
    if (fs2.chmod && !fs2.lchmod) {
      fs2.lchmod = function(path2, mode, cb) {
        if (cb) process.nextTick(cb);
      };
      fs2.lchmodSync = function() {
      };
    }
    if (fs2.chown && !fs2.lchown) {
      fs2.lchown = function(path2, uid, gid, cb) {
        if (cb) process.nextTick(cb);
      };
      fs2.lchownSync = function() {
      };
    }
    if (platform === "win32") {
      fs2.rename = typeof fs2.rename !== "function" ? fs2.rename : (function(fs$rename) {
        function rename(from, to, cb) {
          var start = Date.now();
          var backoff = 0;
          fs$rename(from, to, function CB(er) {
            if (er && (er.code === "EACCES" || er.code === "EPERM" || er.code === "EBUSY") && Date.now() - start < 6e4) {
              setTimeout(function() {
                fs2.stat(to, function(stater, st) {
                  if (stater && stater.code === "ENOENT") fs$rename(from, to, CB);
                  else cb(er);
                });
              }, backoff);
              if (backoff < 100) backoff += 10;
              return;
            }
            if (cb) cb(er);
          });
        }
        if (Object.setPrototypeOf) Object.setPrototypeOf(rename, fs$rename);
        return rename;
      })(fs2.rename);
    }
    fs2.read = typeof fs2.read !== "function" ? fs2.read : (function(fs$read) {
      function read(fd, buffer2, offset, length, position, callback_) {
        var callback;
        if (callback_ && typeof callback_ === "function") {
          var eagCounter = 0;
          callback = function(er, _, __) {
            if (er && er.code === "EAGAIN" && eagCounter < 10) {
              eagCounter++;
              return fs$read.call(fs2, fd, buffer2, offset, length, position, callback);
            }
            callback_.apply(this, arguments);
          };
        }
        return fs$read.call(fs2, fd, buffer2, offset, length, position, callback);
      }
      if (Object.setPrototypeOf) Object.setPrototypeOf(read, fs$read);
      return read;
    })(fs2.read);
    fs2.readSync = typeof fs2.readSync !== "function" ? fs2.readSync : /* @__PURE__ */ (function(fs$readSync) {
      return function(fd, buffer2, offset, length, position) {
        var eagCounter = 0;
        while (true) {
          try {
            return fs$readSync.call(fs2, fd, buffer2, offset, length, position);
          } catch (er) {
            if (er.code === "EAGAIN" && eagCounter < 10) {
              eagCounter++;
              continue;
            }
            throw er;
          }
        }
      };
    })(fs2.readSync);
    function patchLchmod(fs3) {
      fs3.lchmod = function(path2, mode, callback) {
        fs3.open(path2, constants2.O_WRONLY | constants2.O_SYMLINK, mode, function(err, fd) {
          if (err) {
            if (callback) callback(err);
            return;
          }
          fs3.fchmod(fd, mode, function(err2) {
            fs3.close(fd, function(err22) {
              if (callback) callback(err2 || err22);
            });
          });
        });
      };
      fs3.lchmodSync = function(path2, mode) {
        var fd = fs3.openSync(path2, constants2.O_WRONLY | constants2.O_SYMLINK, mode);
        var threw = true;
        var ret;
        try {
          ret = fs3.fchmodSync(fd, mode);
          threw = false;
        } finally {
          if (threw) {
            try {
              fs3.closeSync(fd);
            } catch (er) {
            }
          } else {
            fs3.closeSync(fd);
          }
        }
        return ret;
      };
    }
    function patchLutimes(fs3) {
      if (constants2.hasOwnProperty("O_SYMLINK") && fs3.futimes) {
        fs3.lutimes = function(path2, at, mt, cb) {
          fs3.open(path2, constants2.O_SYMLINK, function(er, fd) {
            if (er) {
              if (cb) cb(er);
              return;
            }
            fs3.futimes(fd, at, mt, function(er2) {
              fs3.close(fd, function(er22) {
                if (cb) cb(er2 || er22);
              });
            });
          });
        };
        fs3.lutimesSync = function(path2, at, mt) {
          var fd = fs3.openSync(path2, constants2.O_SYMLINK);
          var ret;
          var threw = true;
          try {
            ret = fs3.futimesSync(fd, at, mt);
            threw = false;
          } finally {
            if (threw) {
              try {
                fs3.closeSync(fd);
              } catch (er) {
              }
            } else {
              fs3.closeSync(fd);
            }
          }
          return ret;
        };
      } else if (fs3.futimes) {
        fs3.lutimes = function(_a, _b, _c, cb) {
          if (cb) process.nextTick(cb);
        };
        fs3.lutimesSync = function() {
        };
      }
    }
    function chmodFix(orig) {
      if (!orig) return orig;
      return function(target, mode, cb) {
        return orig.call(fs2, target, mode, function(er) {
          if (chownErOk(er)) er = null;
          if (cb) cb.apply(this, arguments);
        });
      };
    }
    function chmodFixSync(orig) {
      if (!orig) return orig;
      return function(target, mode) {
        try {
          return orig.call(fs2, target, mode);
        } catch (er) {
          if (!chownErOk(er)) throw er;
        }
      };
    }
    function chownFix(orig) {
      if (!orig) return orig;
      return function(target, uid, gid, cb) {
        return orig.call(fs2, target, uid, gid, function(er) {
          if (chownErOk(er)) er = null;
          if (cb) cb.apply(this, arguments);
        });
      };
    }
    function chownFixSync(orig) {
      if (!orig) return orig;
      return function(target, uid, gid) {
        try {
          return orig.call(fs2, target, uid, gid);
        } catch (er) {
          if (!chownErOk(er)) throw er;
        }
      };
    }
    function statFix(orig) {
      if (!orig) return orig;
      return function(target, options2, cb) {
        if (typeof options2 === "function") {
          cb = options2;
          options2 = null;
        }
        function callback(er, stats) {
          if (stats) {
            if (stats.uid < 0) stats.uid += 4294967296;
            if (stats.gid < 0) stats.gid += 4294967296;
          }
          if (cb) cb.apply(this, arguments);
        }
        return options2 ? orig.call(fs2, target, options2, callback) : orig.call(fs2, target, callback);
      };
    }
    function statFixSync(orig) {
      if (!orig) return orig;
      return function(target, options2) {
        var stats = options2 ? orig.call(fs2, target, options2) : orig.call(fs2, target);
        if (stats) {
          if (stats.uid < 0) stats.uid += 4294967296;
          if (stats.gid < 0) stats.gid += 4294967296;
        }
        return stats;
      };
    }
    function chownErOk(er) {
      if (!er) return true;
      if (er.code === "ENOSYS") return true;
      var nonroot = !process.getuid || process.getuid() !== 0;
      if (nonroot) {
        if (er.code === "EINVAL" || er.code === "EPERM") return true;
      }
      return false;
    }
  }
  return polyfills;
}
var legacyStreams;
var hasRequiredLegacyStreams;
function requireLegacyStreams() {
  if (hasRequiredLegacyStreams) return legacyStreams;
  hasRequiredLegacyStreams = 1;
  var Stream = require$$0$5.Stream;
  legacyStreams = legacy;
  function legacy(fs2) {
    return {
      ReadStream,
      WriteStream
    };
    function ReadStream(path2, options2) {
      if (!(this instanceof ReadStream)) return new ReadStream(path2, options2);
      Stream.call(this);
      var self2 = this;
      this.path = path2;
      this.fd = null;
      this.readable = true;
      this.paused = false;
      this.flags = "r";
      this.mode = 438;
      this.bufferSize = 64 * 1024;
      options2 = options2 || {};
      var keys = Object.keys(options2);
      for (var index = 0, length = keys.length; index < length; index++) {
        var key = keys[index];
        this[key] = options2[key];
      }
      if (this.encoding) this.setEncoding(this.encoding);
      if (this.start !== void 0) {
        if ("number" !== typeof this.start) {
          throw TypeError("start must be a Number");
        }
        if (this.end === void 0) {
          this.end = Infinity;
        } else if ("number" !== typeof this.end) {
          throw TypeError("end must be a Number");
        }
        if (this.start > this.end) {
          throw new Error("start must be <= end");
        }
        this.pos = this.start;
      }
      if (this.fd !== null) {
        process.nextTick(function() {
          self2._read();
        });
        return;
      }
      fs2.open(this.path, this.flags, this.mode, function(err, fd) {
        if (err) {
          self2.emit("error", err);
          self2.readable = false;
          return;
        }
        self2.fd = fd;
        self2.emit("open", fd);
        self2._read();
      });
    }
    function WriteStream(path2, options2) {
      if (!(this instanceof WriteStream)) return new WriteStream(path2, options2);
      Stream.call(this);
      this.path = path2;
      this.fd = null;
      this.writable = true;
      this.flags = "w";
      this.encoding = "binary";
      this.mode = 438;
      this.bytesWritten = 0;
      options2 = options2 || {};
      var keys = Object.keys(options2);
      for (var index = 0, length = keys.length; index < length; index++) {
        var key = keys[index];
        this[key] = options2[key];
      }
      if (this.start !== void 0) {
        if ("number" !== typeof this.start) {
          throw TypeError("start must be a Number");
        }
        if (this.start < 0) {
          throw new Error("start must be >= zero");
        }
        this.pos = this.start;
      }
      this.busy = false;
      this._queue = [];
      if (this.fd === null) {
        this._open = fs2.open;
        this._queue.push([this._open, this.path, this.flags, this.mode, void 0]);
        this.flush();
      }
    }
  }
  return legacyStreams;
}
var clone_1;
var hasRequiredClone;
function requireClone() {
  if (hasRequiredClone) return clone_1;
  hasRequiredClone = 1;
  clone_1 = clone;
  var getPrototypeOf = Object.getPrototypeOf || function(obj) {
    return obj.__proto__;
  };
  function clone(obj) {
    if (obj === null || typeof obj !== "object") return obj;
    if (obj instanceof Object) var copy2 = {
      __proto__: getPrototypeOf(obj)
    };
    else var copy2 = /* @__PURE__ */ Object.create(null);
    Object.getOwnPropertyNames(obj).forEach(function(key) {
      Object.defineProperty(copy2, key, Object.getOwnPropertyDescriptor(obj, key));
    });
    return copy2;
  }
  return clone_1;
}
var gracefulFs;
var hasRequiredGracefulFs;
function requireGracefulFs() {
  if (hasRequiredGracefulFs) return gracefulFs;
  hasRequiredGracefulFs = 1;
  var fs2 = require$$2$1;
  var polyfills2 = requirePolyfills();
  var legacy = requireLegacyStreams();
  var clone = requireClone();
  var util = require$$0$1;
  var gracefulQueue;
  var previousSymbol;
  if (typeof Symbol === "function" && typeof Symbol.for === "function") {
    gracefulQueue = /* @__PURE__ */ Symbol.for("graceful-fs.queue");
    previousSymbol = /* @__PURE__ */ Symbol.for("graceful-fs.previous");
  } else {
    gracefulQueue = "___graceful-fs.queue";
    previousSymbol = "___graceful-fs.previous";
  }
  function noop() {
  }
  function publishQueue(context, queue2) {
    Object.defineProperty(context, gracefulQueue, {
      get: function() {
        return queue2;
      }
    });
  }
  var debug = noop;
  if (util.debuglog) debug = util.debuglog("gfs4");
  else if (/\bgfs4\b/i.test(process.env.NODE_DEBUG || "")) debug = function() {
    var m = util.format.apply(util, arguments);
    m = "GFS4: " + m.split(/\n/).join("\nGFS4: ");
    console.error(m);
  };
  if (!fs2[gracefulQueue]) {
    var queue = commonjsGlobal[gracefulQueue] || [];
    publishQueue(fs2, queue);
    fs2.close = (function(fs$close) {
      function close(fd, cb) {
        return fs$close.call(fs2, fd, function(err) {
          if (!err) {
            resetQueue();
          }
          if (typeof cb === "function") cb.apply(this, arguments);
        });
      }
      Object.defineProperty(close, previousSymbol, {
        value: fs$close
      });
      return close;
    })(fs2.close);
    fs2.closeSync = (function(fs$closeSync) {
      function closeSync(fd) {
        fs$closeSync.apply(fs2, arguments);
        resetQueue();
      }
      Object.defineProperty(closeSync, previousSymbol, {
        value: fs$closeSync
      });
      return closeSync;
    })(fs2.closeSync);
    if (/\bgfs4\b/i.test(process.env.NODE_DEBUG || "")) {
      process.on("exit", function() {
        debug(fs2[gracefulQueue]);
        require$$5.equal(fs2[gracefulQueue].length, 0);
      });
    }
  }
  if (!commonjsGlobal[gracefulQueue]) {
    publishQueue(commonjsGlobal, fs2[gracefulQueue]);
  }
  gracefulFs = patch(clone(fs2));
  if (process.env.TEST_GRACEFUL_FS_GLOBAL_PATCH && !fs2.__patched) {
    gracefulFs = patch(fs2);
    fs2.__patched = true;
  }
  function patch(fs3) {
    polyfills2(fs3);
    fs3.gracefulify = patch;
    fs3.createReadStream = createReadStream;
    fs3.createWriteStream = createWriteStream;
    var fs$readFile = fs3.readFile;
    fs3.readFile = readFile;
    function readFile(path2, options2, cb) {
      if (typeof options2 === "function") cb = options2, options2 = null;
      return go$readFile(path2, options2, cb);
      function go$readFile(path3, options3, cb2, startTime) {
        return fs$readFile(path3, options3, function(err) {
          if (err && (err.code === "EMFILE" || err.code === "ENFILE")) enqueue([go$readFile, [path3, options3, cb2], err, startTime || Date.now(), Date.now()]);
          else {
            if (typeof cb2 === "function") cb2.apply(this, arguments);
          }
        });
      }
    }
    var fs$writeFile = fs3.writeFile;
    fs3.writeFile = writeFile;
    function writeFile(path2, data, options2, cb) {
      if (typeof options2 === "function") cb = options2, options2 = null;
      return go$writeFile(path2, data, options2, cb);
      function go$writeFile(path3, data2, options3, cb2, startTime) {
        return fs$writeFile(path3, data2, options3, function(err) {
          if (err && (err.code === "EMFILE" || err.code === "ENFILE")) enqueue([go$writeFile, [path3, data2, options3, cb2], err, startTime || Date.now(), Date.now()]);
          else {
            if (typeof cb2 === "function") cb2.apply(this, arguments);
          }
        });
      }
    }
    var fs$appendFile = fs3.appendFile;
    if (fs$appendFile) fs3.appendFile = appendFile;
    function appendFile(path2, data, options2, cb) {
      if (typeof options2 === "function") cb = options2, options2 = null;
      return go$appendFile(path2, data, options2, cb);
      function go$appendFile(path3, data2, options3, cb2, startTime) {
        return fs$appendFile(path3, data2, options3, function(err) {
          if (err && (err.code === "EMFILE" || err.code === "ENFILE")) enqueue([go$appendFile, [path3, data2, options3, cb2], err, startTime || Date.now(), Date.now()]);
          else {
            if (typeof cb2 === "function") cb2.apply(this, arguments);
          }
        });
      }
    }
    var fs$copyFile = fs3.copyFile;
    if (fs$copyFile) fs3.copyFile = copyFile;
    function copyFile(src, dest, flags, cb) {
      if (typeof flags === "function") {
        cb = flags;
        flags = 0;
      }
      return go$copyFile(src, dest, flags, cb);
      function go$copyFile(src2, dest2, flags2, cb2, startTime) {
        return fs$copyFile(src2, dest2, flags2, function(err) {
          if (err && (err.code === "EMFILE" || err.code === "ENFILE")) enqueue([go$copyFile, [src2, dest2, flags2, cb2], err, startTime || Date.now(), Date.now()]);
          else {
            if (typeof cb2 === "function") cb2.apply(this, arguments);
          }
        });
      }
    }
    var fs$readdir = fs3.readdir;
    fs3.readdir = readdir;
    var noReaddirOptionVersions = /^v[0-5]\./;
    function readdir(path2, options2, cb) {
      if (typeof options2 === "function") cb = options2, options2 = null;
      var go$readdir = noReaddirOptionVersions.test(process.version) ? function go$readdir2(path3, options3, cb2, startTime) {
        return fs$readdir(path3, fs$readdirCallback(path3, options3, cb2, startTime));
      } : function go$readdir2(path3, options3, cb2, startTime) {
        return fs$readdir(path3, options3, fs$readdirCallback(path3, options3, cb2, startTime));
      };
      return go$readdir(path2, options2, cb);
      function fs$readdirCallback(path3, options3, cb2, startTime) {
        return function(err, files2) {
          if (err && (err.code === "EMFILE" || err.code === "ENFILE")) enqueue([go$readdir, [path3, options3, cb2], err, startTime || Date.now(), Date.now()]);
          else {
            if (files2 && files2.sort) files2.sort();
            if (typeof cb2 === "function") cb2.call(this, err, files2);
          }
        };
      }
    }
    if (process.version.substr(0, 4) === "v0.8") {
      var legStreams = legacy(fs3);
      ReadStream = legStreams.ReadStream;
      WriteStream = legStreams.WriteStream;
    }
    var fs$ReadStream = fs3.ReadStream;
    if (fs$ReadStream) {
      ReadStream.prototype = Object.create(fs$ReadStream.prototype);
      ReadStream.prototype.open = ReadStream$open;
    }
    var fs$WriteStream = fs3.WriteStream;
    if (fs$WriteStream) {
      WriteStream.prototype = Object.create(fs$WriteStream.prototype);
      WriteStream.prototype.open = WriteStream$open;
    }
    Object.defineProperty(fs3, "ReadStream", {
      get: function() {
        return ReadStream;
      },
      set: function(val) {
        ReadStream = val;
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(fs3, "WriteStream", {
      get: function() {
        return WriteStream;
      },
      set: function(val) {
        WriteStream = val;
      },
      enumerable: true,
      configurable: true
    });
    var FileReadStream = ReadStream;
    Object.defineProperty(fs3, "FileReadStream", {
      get: function() {
        return FileReadStream;
      },
      set: function(val) {
        FileReadStream = val;
      },
      enumerable: true,
      configurable: true
    });
    var FileWriteStream = WriteStream;
    Object.defineProperty(fs3, "FileWriteStream", {
      get: function() {
        return FileWriteStream;
      },
      set: function(val) {
        FileWriteStream = val;
      },
      enumerable: true,
      configurable: true
    });
    function ReadStream(path2, options2) {
      if (this instanceof ReadStream) return fs$ReadStream.apply(this, arguments), this;
      else return ReadStream.apply(Object.create(ReadStream.prototype), arguments);
    }
    function ReadStream$open() {
      var that = this;
      open(that.path, that.flags, that.mode, function(err, fd) {
        if (err) {
          if (that.autoClose) that.destroy();
          that.emit("error", err);
        } else {
          that.fd = fd;
          that.emit("open", fd);
          that.read();
        }
      });
    }
    function WriteStream(path2, options2) {
      if (this instanceof WriteStream) return fs$WriteStream.apply(this, arguments), this;
      else return WriteStream.apply(Object.create(WriteStream.prototype), arguments);
    }
    function WriteStream$open() {
      var that = this;
      open(that.path, that.flags, that.mode, function(err, fd) {
        if (err) {
          that.destroy();
          that.emit("error", err);
        } else {
          that.fd = fd;
          that.emit("open", fd);
        }
      });
    }
    function createReadStream(path2, options2) {
      return new fs3.ReadStream(path2, options2);
    }
    function createWriteStream(path2, options2) {
      return new fs3.WriteStream(path2, options2);
    }
    var fs$open = fs3.open;
    fs3.open = open;
    function open(path2, flags, mode, cb) {
      if (typeof mode === "function") cb = mode, mode = null;
      return go$open(path2, flags, mode, cb);
      function go$open(path3, flags2, mode2, cb2, startTime) {
        return fs$open(path3, flags2, mode2, function(err, fd) {
          if (err && (err.code === "EMFILE" || err.code === "ENFILE")) enqueue([go$open, [path3, flags2, mode2, cb2], err, startTime || Date.now(), Date.now()]);
          else {
            if (typeof cb2 === "function") cb2.apply(this, arguments);
          }
        });
      }
    }
    return fs3;
  }
  function enqueue(elem) {
    debug("ENQUEUE", elem[0].name, elem[1]);
    fs2[gracefulQueue].push(elem);
    retry();
  }
  var retryTimer;
  function resetQueue() {
    var now2 = Date.now();
    for (var i = 0; i < fs2[gracefulQueue].length; ++i) {
      if (fs2[gracefulQueue][i].length > 2) {
        fs2[gracefulQueue][i][3] = now2;
        fs2[gracefulQueue][i][4] = now2;
      }
    }
    retry();
  }
  function retry() {
    clearTimeout(retryTimer);
    retryTimer = void 0;
    if (fs2[gracefulQueue].length === 0) return;
    var elem = fs2[gracefulQueue].shift();
    var fn = elem[0];
    var args = elem[1];
    var err = elem[2];
    var startTime = elem[3];
    var lastTime = elem[4];
    if (startTime === void 0) {
      debug("RETRY", fn.name, args);
      fn.apply(null, args);
    } else if (Date.now() - startTime >= 6e4) {
      debug("TIMEOUT", fn.name, args);
      var cb = args.pop();
      if (typeof cb === "function") cb.call(null, err);
    } else {
      var sinceAttempt = Date.now() - lastTime;
      var sinceStart = Math.max(lastTime - startTime, 1);
      var desiredDelay = Math.min(sinceStart * 1.2, 100);
      if (sinceAttempt >= desiredDelay) {
        debug("RETRY", fn.name, args);
        fn.apply(null, args.concat([startTime]));
      } else {
        fs2[gracefulQueue].push(elem);
      }
    }
    if (retryTimer === void 0) {
      retryTimer = setTimeout(retry, 0);
    }
  }
  return gracefulFs;
}
var hasRequiredFs;
function requireFs() {
  if (hasRequiredFs) return fs$1;
  hasRequiredFs = 1;
  (function(exports) {
    const u = requireUniversalify().fromCallback;
    const fs2 = requireGracefulFs();
    const api2 = ["access", "appendFile", "chmod", "chown", "close", "copyFile", "cp", "fchmod", "fchown", "fdatasync", "fstat", "fsync", "ftruncate", "futimes", "glob", "lchmod", "lchown", "lutimes", "link", "lstat", "mkdir", "mkdtemp", "open", "opendir", "readdir", "readFile", "readlink", "realpath", "rename", "rm", "rmdir", "stat", "statfs", "symlink", "truncate", "unlink", "utimes", "writeFile"].filter((key) => typeof fs2[key] === "function");
    Object.assign(exports, fs2);
    api2.forEach((method) => {
      exports[method] = u(fs2[method]);
    });
    exports.exists = function(filename, callback) {
      if (typeof callback === "function") {
        return fs2.exists(filename, callback);
      }
      return new Promise((resolve2) => fs2.exists(filename, resolve2));
    };
    exports.read = function(fd, buffer2, offset, length, position, callback) {
      if (typeof callback === "function") {
        return fs2.read(fd, buffer2, offset, length, position, callback);
      }
      return new Promise((resolve2, reject) => {
        fs2.read(fd, buffer2, offset, length, position, (err, bytesRead, buffer3) => {
          if (err) return reject(err);
          resolve2({
            bytesRead,
            buffer: buffer3
          });
        });
      });
    };
    exports.write = function(fd, buffer2, ...args) {
      if (typeof args[args.length - 1] === "function") {
        return fs2.write(fd, buffer2, ...args);
      }
      return new Promise((resolve2, reject) => {
        fs2.write(fd, buffer2, ...args, (err, bytesWritten, buffer3) => {
          if (err) return reject(err);
          resolve2({
            bytesWritten,
            buffer: buffer3
          });
        });
      });
    };
    exports.readv = function(fd, buffers, ...args) {
      if (typeof args[args.length - 1] === "function") {
        return fs2.readv(fd, buffers, ...args);
      }
      return new Promise((resolve2, reject) => {
        fs2.readv(fd, buffers, ...args, (err, bytesRead, buffers2) => {
          if (err) return reject(err);
          resolve2({
            bytesRead,
            buffers: buffers2
          });
        });
      });
    };
    exports.writev = function(fd, buffers, ...args) {
      if (typeof args[args.length - 1] === "function") {
        return fs2.writev(fd, buffers, ...args);
      }
      return new Promise((resolve2, reject) => {
        fs2.writev(fd, buffers, ...args, (err, bytesWritten, buffers2) => {
          if (err) return reject(err);
          resolve2({
            bytesWritten,
            buffers: buffers2
          });
        });
      });
    };
    if (typeof fs2.realpath.native === "function") {
      exports.realpath.native = u(fs2.realpath.native);
    } else {
      process.emitWarning("fs.realpath.native is not a function. Is fs being monkey-patched?", "Warning", "fs-extra-WARN0003");
    }
  })(fs$1);
  return fs$1;
}
var makeDir = {};
var utils$1 = {};
var hasRequiredUtils$1;
function requireUtils$1() {
  if (hasRequiredUtils$1) return utils$1;
  hasRequiredUtils$1 = 1;
  const path2 = require$$1$1;
  utils$1.checkPath = function checkPath(pth) {
    if (process.platform === "win32") {
      const pathHasInvalidWinCharacters = /[<>:"|?*]/.test(pth.replace(path2.parse(pth).root, ""));
      if (pathHasInvalidWinCharacters) {
        const error2 = new Error(`Path contains invalid characters: ${pth}`);
        error2.code = "EINVAL";
        throw error2;
      }
    }
  };
  return utils$1;
}
var hasRequiredMakeDir;
function requireMakeDir() {
  if (hasRequiredMakeDir) return makeDir;
  hasRequiredMakeDir = 1;
  const fs2 = requireFs();
  const { checkPath } = requireUtils$1();
  const getMode = (options2) => {
    const defaults = {
      mode: 511
    };
    if (typeof options2 === "number") return options2;
    return {
      ...defaults,
      ...options2
    }.mode;
  };
  makeDir.makeDir = async (dir, options2) => {
    checkPath(dir);
    return fs2.mkdir(dir, {
      mode: getMode(options2),
      recursive: true
    });
  };
  makeDir.makeDirSync = (dir, options2) => {
    checkPath(dir);
    return fs2.mkdirSync(dir, {
      mode: getMode(options2),
      recursive: true
    });
  };
  return makeDir;
}
var mkdirs;
var hasRequiredMkdirs;
function requireMkdirs() {
  if (hasRequiredMkdirs) return mkdirs;
  hasRequiredMkdirs = 1;
  const u = requireUniversalify().fromPromise;
  const { makeDir: _makeDir, makeDirSync } = requireMakeDir();
  const makeDir2 = u(_makeDir);
  mkdirs = {
    mkdirs: makeDir2,
    mkdirsSync: makeDirSync,
    mkdirp: makeDir2,
    mkdirpSync: makeDirSync,
    ensureDir: makeDir2,
    ensureDirSync: makeDirSync
  };
  return mkdirs;
}
var pathExists_1;
var hasRequiredPathExists;
function requirePathExists() {
  if (hasRequiredPathExists) return pathExists_1;
  hasRequiredPathExists = 1;
  const u = requireUniversalify().fromPromise;
  const fs2 = requireFs();
  function pathExists(path2) {
    return fs2.access(path2).then(() => true).catch(() => false);
  }
  pathExists_1 = {
    pathExists: u(pathExists),
    pathExistsSync: fs2.existsSync
  };
  return pathExists_1;
}
var utimes;
var hasRequiredUtimes;
function requireUtimes() {
  if (hasRequiredUtimes) return utimes;
  hasRequiredUtimes = 1;
  const fs2 = requireFs();
  const u = requireUniversalify().fromPromise;
  async function utimesMillis(path2, atime, mtime) {
    const fd = await fs2.open(path2, "r+");
    let error2 = null;
    try {
      await fs2.futimes(fd, atime, mtime);
    } catch (futimesErr) {
      error2 = futimesErr;
    } finally {
      try {
        await fs2.close(fd);
      } catch (closeErr) {
        if (!error2) error2 = closeErr;
      }
    }
    if (error2) {
      throw error2;
    }
  }
  function utimesMillisSync(path2, atime, mtime) {
    const fd = fs2.openSync(path2, "r+");
    let error2 = null;
    try {
      fs2.futimesSync(fd, atime, mtime);
    } catch (futimesErr) {
      error2 = futimesErr;
    } finally {
      try {
        fs2.closeSync(fd);
      } catch (closeErr) {
        if (!error2) error2 = closeErr;
      }
    }
    if (error2) {
      throw error2;
    }
  }
  utimes = {
    utimesMillis: u(utimesMillis),
    utimesMillisSync
  };
  return utimes;
}
var stat;
var hasRequiredStat;
function requireStat() {
  if (hasRequiredStat) return stat;
  hasRequiredStat = 1;
  const fs2 = requireFs();
  const path2 = require$$1$1;
  const u = requireUniversalify().fromPromise;
  function getStats(src, dest, opts) {
    const statFunc = opts.dereference ? (file2) => fs2.stat(file2, {
      bigint: true
    }) : (file2) => fs2.lstat(file2, {
      bigint: true
    });
    return Promise.all([statFunc(src), statFunc(dest).catch((err) => {
      if (err.code === "ENOENT") return null;
      throw err;
    })]).then(([srcStat, destStat]) => ({
      srcStat,
      destStat
    }));
  }
  function getStatsSync(src, dest, opts) {
    let destStat;
    const statFunc = opts.dereference ? (file2) => fs2.statSync(file2, {
      bigint: true
    }) : (file2) => fs2.lstatSync(file2, {
      bigint: true
    });
    const srcStat = statFunc(src);
    try {
      destStat = statFunc(dest);
    } catch (err) {
      if (err.code === "ENOENT") return {
        srcStat,
        destStat: null
      };
      throw err;
    }
    return {
      srcStat,
      destStat
    };
  }
  async function checkPaths(src, dest, funcName, opts) {
    const { srcStat, destStat } = await getStats(src, dest, opts);
    if (destStat) {
      if (areIdentical(srcStat, destStat)) {
        const srcBaseName = path2.basename(src);
        const destBaseName = path2.basename(dest);
        if (funcName === "move" && srcBaseName !== destBaseName && srcBaseName.toLowerCase() === destBaseName.toLowerCase()) {
          return {
            srcStat,
            destStat,
            isChangingCase: true
          };
        }
        throw new Error("Source and destination must not be the same.");
      }
      if (srcStat.isDirectory() && !destStat.isDirectory()) {
        throw new Error(`Cannot overwrite non-directory '${dest}' with directory '${src}'.`);
      }
      if (!srcStat.isDirectory() && destStat.isDirectory()) {
        throw new Error(`Cannot overwrite directory '${dest}' with non-directory '${src}'.`);
      }
    }
    if (srcStat.isDirectory() && isSrcSubdir(src, dest)) {
      throw new Error(errMsg(src, dest, funcName));
    }
    return {
      srcStat,
      destStat
    };
  }
  function checkPathsSync(src, dest, funcName, opts) {
    const { srcStat, destStat } = getStatsSync(src, dest, opts);
    if (destStat) {
      if (areIdentical(srcStat, destStat)) {
        const srcBaseName = path2.basename(src);
        const destBaseName = path2.basename(dest);
        if (funcName === "move" && srcBaseName !== destBaseName && srcBaseName.toLowerCase() === destBaseName.toLowerCase()) {
          return {
            srcStat,
            destStat,
            isChangingCase: true
          };
        }
        throw new Error("Source and destination must not be the same.");
      }
      if (srcStat.isDirectory() && !destStat.isDirectory()) {
        throw new Error(`Cannot overwrite non-directory '${dest}' with directory '${src}'.`);
      }
      if (!srcStat.isDirectory() && destStat.isDirectory()) {
        throw new Error(`Cannot overwrite directory '${dest}' with non-directory '${src}'.`);
      }
    }
    if (srcStat.isDirectory() && isSrcSubdir(src, dest)) {
      throw new Error(errMsg(src, dest, funcName));
    }
    return {
      srcStat,
      destStat
    };
  }
  async function checkParentPaths(src, srcStat, dest, funcName) {
    const srcParent = path2.resolve(path2.dirname(src));
    const destParent = path2.resolve(path2.dirname(dest));
    if (destParent === srcParent || destParent === path2.parse(destParent).root) return;
    let destStat;
    try {
      destStat = await fs2.stat(destParent, {
        bigint: true
      });
    } catch (err) {
      if (err.code === "ENOENT") return;
      throw err;
    }
    if (areIdentical(srcStat, destStat)) {
      throw new Error(errMsg(src, dest, funcName));
    }
    return checkParentPaths(src, srcStat, destParent, funcName);
  }
  function checkParentPathsSync(src, srcStat, dest, funcName) {
    const srcParent = path2.resolve(path2.dirname(src));
    const destParent = path2.resolve(path2.dirname(dest));
    if (destParent === srcParent || destParent === path2.parse(destParent).root) return;
    let destStat;
    try {
      destStat = fs2.statSync(destParent, {
        bigint: true
      });
    } catch (err) {
      if (err.code === "ENOENT") return;
      throw err;
    }
    if (areIdentical(srcStat, destStat)) {
      throw new Error(errMsg(src, dest, funcName));
    }
    return checkParentPathsSync(src, srcStat, destParent, funcName);
  }
  function areIdentical(srcStat, destStat) {
    return destStat.ino !== void 0 && destStat.dev !== void 0 && destStat.ino === srcStat.ino && destStat.dev === srcStat.dev;
  }
  function isSrcSubdir(src, dest) {
    const srcArr = path2.resolve(src).split(path2.sep).filter((i) => i);
    const destArr = path2.resolve(dest).split(path2.sep).filter((i) => i);
    return srcArr.every((cur, i) => destArr[i] === cur);
  }
  function errMsg(src, dest, funcName) {
    return `Cannot ${funcName} '${src}' to a subdirectory of itself, '${dest}'.`;
  }
  stat = {
    checkPaths: u(checkPaths),
    checkPathsSync,
    checkParentPaths: u(checkParentPaths),
    checkParentPathsSync,
    isSrcSubdir,
    areIdentical
  };
  return stat;
}
var async;
var hasRequiredAsync;
function requireAsync() {
  if (hasRequiredAsync) return async;
  hasRequiredAsync = 1;
  async function asyncIteratorConcurrentProcess(iterator, fn) {
    const promises2 = [];
    for await (const item of iterator) {
      promises2.push(fn(item).then(() => null, (err) => err ?? new Error("unknown error")));
    }
    await Promise.all(promises2.map((promise) => promise.then((possibleErr) => {
      if (possibleErr !== null) throw possibleErr;
    })));
  }
  async = {
    asyncIteratorConcurrentProcess
  };
  return async;
}
var copy_1;
var hasRequiredCopy$1;
function requireCopy$1() {
  if (hasRequiredCopy$1) return copy_1;
  hasRequiredCopy$1 = 1;
  const fs2 = requireFs();
  const path2 = require$$1$1;
  const { mkdirs: mkdirs2 } = requireMkdirs();
  const { pathExists } = requirePathExists();
  const { utimesMillis } = requireUtimes();
  const stat2 = requireStat();
  const { asyncIteratorConcurrentProcess } = requireAsync();
  async function copy2(src, dest, opts = {}) {
    if (typeof opts === "function") {
      opts = {
        filter: opts
      };
    }
    opts.clobber = "clobber" in opts ? !!opts.clobber : true;
    opts.overwrite = "overwrite" in opts ? !!opts.overwrite : opts.clobber;
    if (opts.preserveTimestamps && process.arch === "ia32") {
      process.emitWarning("Using the preserveTimestamps option in 32-bit node is not recommended;\n\n	see https://github.com/jprichardson/node-fs-extra/issues/269", "Warning", "fs-extra-WARN0001");
    }
    const { srcStat, destStat } = await stat2.checkPaths(src, dest, "copy", opts);
    await stat2.checkParentPaths(src, srcStat, dest, "copy");
    const include = await runFilter(src, dest, opts);
    if (!include) return;
    const destParent = path2.dirname(dest);
    const dirExists = await pathExists(destParent);
    if (!dirExists) {
      await mkdirs2(destParent);
    }
    await getStatsAndPerformCopy(destStat, src, dest, opts);
  }
  async function runFilter(src, dest, opts) {
    if (!opts.filter) return true;
    return opts.filter(src, dest);
  }
  async function getStatsAndPerformCopy(destStat, src, dest, opts) {
    const statFn = opts.dereference ? fs2.stat : fs2.lstat;
    const srcStat = await statFn(src);
    if (srcStat.isDirectory()) return onDir(srcStat, destStat, src, dest, opts);
    if (srcStat.isFile() || srcStat.isCharacterDevice() || srcStat.isBlockDevice()) return onFile(srcStat, destStat, src, dest, opts);
    if (srcStat.isSymbolicLink()) return onLink(destStat, src, dest, opts);
    if (srcStat.isSocket()) throw new Error(`Cannot copy a socket file: ${src}`);
    if (srcStat.isFIFO()) throw new Error(`Cannot copy a FIFO pipe: ${src}`);
    throw new Error(`Unknown file: ${src}`);
  }
  async function onFile(srcStat, destStat, src, dest, opts) {
    if (!destStat) return copyFile(srcStat, src, dest, opts);
    if (opts.overwrite) {
      await fs2.unlink(dest);
      return copyFile(srcStat, src, dest, opts);
    }
    if (opts.errorOnExist) {
      throw new Error(`'${dest}' already exists`);
    }
  }
  async function copyFile(srcStat, src, dest, opts) {
    await fs2.copyFile(src, dest);
    if (opts.preserveTimestamps) {
      if (fileIsNotWritable(srcStat.mode)) {
        await makeFileWritable(dest, srcStat.mode);
      }
      const updatedSrcStat = await fs2.stat(src);
      await utimesMillis(dest, updatedSrcStat.atime, updatedSrcStat.mtime);
    }
    return fs2.chmod(dest, srcStat.mode);
  }
  function fileIsNotWritable(srcMode) {
    return (srcMode & 128) === 0;
  }
  function makeFileWritable(dest, srcMode) {
    return fs2.chmod(dest, srcMode | 128);
  }
  async function onDir(srcStat, destStat, src, dest, opts) {
    if (!destStat) {
      await fs2.mkdir(dest);
    }
    await asyncIteratorConcurrentProcess(await fs2.opendir(src), async (item) => {
      const srcItem = path2.join(src, item.name);
      const destItem = path2.join(dest, item.name);
      const include = await runFilter(srcItem, destItem, opts);
      if (include) {
        const { destStat: destStat2 } = await stat2.checkPaths(srcItem, destItem, "copy", opts);
        await getStatsAndPerformCopy(destStat2, srcItem, destItem, opts);
      }
    });
    if (!destStat) {
      await fs2.chmod(dest, srcStat.mode);
    }
  }
  async function onLink(destStat, src, dest, opts) {
    let resolvedSrc = await fs2.readlink(src);
    if (opts.dereference) {
      resolvedSrc = path2.resolve(process.cwd(), resolvedSrc);
    }
    if (!destStat) {
      return fs2.symlink(resolvedSrc, dest);
    }
    let resolvedDest = null;
    try {
      resolvedDest = await fs2.readlink(dest);
    } catch (e) {
      if (e.code === "EINVAL" || e.code === "UNKNOWN") return fs2.symlink(resolvedSrc, dest);
      throw e;
    }
    if (opts.dereference) {
      resolvedDest = path2.resolve(process.cwd(), resolvedDest);
    }
    if (resolvedSrc !== resolvedDest) {
      if (stat2.isSrcSubdir(resolvedSrc, resolvedDest)) {
        throw new Error(`Cannot copy '${resolvedSrc}' to a subdirectory of itself, '${resolvedDest}'.`);
      }
      if (stat2.isSrcSubdir(resolvedDest, resolvedSrc)) {
        throw new Error(`Cannot overwrite '${resolvedDest}' with '${resolvedSrc}'.`);
      }
    }
    await fs2.unlink(dest);
    return fs2.symlink(resolvedSrc, dest);
  }
  copy_1 = copy2;
  return copy_1;
}
var copySync_1;
var hasRequiredCopySync;
function requireCopySync() {
  if (hasRequiredCopySync) return copySync_1;
  hasRequiredCopySync = 1;
  const fs2 = requireGracefulFs();
  const path2 = require$$1$1;
  const mkdirsSync = requireMkdirs().mkdirsSync;
  const utimesMillisSync = requireUtimes().utimesMillisSync;
  const stat2 = requireStat();
  function copySync(src, dest, opts) {
    if (typeof opts === "function") {
      opts = {
        filter: opts
      };
    }
    opts = opts || {};
    opts.clobber = "clobber" in opts ? !!opts.clobber : true;
    opts.overwrite = "overwrite" in opts ? !!opts.overwrite : opts.clobber;
    if (opts.preserveTimestamps && process.arch === "ia32") {
      process.emitWarning("Using the preserveTimestamps option in 32-bit node is not recommended;\n\n	see https://github.com/jprichardson/node-fs-extra/issues/269", "Warning", "fs-extra-WARN0002");
    }
    const { srcStat, destStat } = stat2.checkPathsSync(src, dest, "copy", opts);
    stat2.checkParentPathsSync(src, srcStat, dest, "copy");
    if (opts.filter && !opts.filter(src, dest)) return;
    const destParent = path2.dirname(dest);
    if (!fs2.existsSync(destParent)) mkdirsSync(destParent);
    return getStats(destStat, src, dest, opts);
  }
  function getStats(destStat, src, dest, opts) {
    const statSync2 = opts.dereference ? fs2.statSync : fs2.lstatSync;
    const srcStat = statSync2(src);
    if (srcStat.isDirectory()) return onDir(srcStat, destStat, src, dest, opts);
    else if (srcStat.isFile() || srcStat.isCharacterDevice() || srcStat.isBlockDevice()) return onFile(srcStat, destStat, src, dest, opts);
    else if (srcStat.isSymbolicLink()) return onLink(destStat, src, dest, opts);
    else if (srcStat.isSocket()) throw new Error(`Cannot copy a socket file: ${src}`);
    else if (srcStat.isFIFO()) throw new Error(`Cannot copy a FIFO pipe: ${src}`);
    throw new Error(`Unknown file: ${src}`);
  }
  function onFile(srcStat, destStat, src, dest, opts) {
    if (!destStat) return copyFile(srcStat, src, dest, opts);
    return mayCopyFile(srcStat, src, dest, opts);
  }
  function mayCopyFile(srcStat, src, dest, opts) {
    if (opts.overwrite) {
      fs2.unlinkSync(dest);
      return copyFile(srcStat, src, dest, opts);
    } else if (opts.errorOnExist) {
      throw new Error(`'${dest}' already exists`);
    }
  }
  function copyFile(srcStat, src, dest, opts) {
    fs2.copyFileSync(src, dest);
    if (opts.preserveTimestamps) handleTimestamps(srcStat.mode, src, dest);
    return setDestMode(dest, srcStat.mode);
  }
  function handleTimestamps(srcMode, src, dest) {
    if (fileIsNotWritable(srcMode)) makeFileWritable(dest, srcMode);
    return setDestTimestamps(src, dest);
  }
  function fileIsNotWritable(srcMode) {
    return (srcMode & 128) === 0;
  }
  function makeFileWritable(dest, srcMode) {
    return setDestMode(dest, srcMode | 128);
  }
  function setDestMode(dest, srcMode) {
    return fs2.chmodSync(dest, srcMode);
  }
  function setDestTimestamps(src, dest) {
    const updatedSrcStat = fs2.statSync(src);
    return utimesMillisSync(dest, updatedSrcStat.atime, updatedSrcStat.mtime);
  }
  function onDir(srcStat, destStat, src, dest, opts) {
    if (!destStat) return mkDirAndCopy(srcStat.mode, src, dest, opts);
    return copyDir(src, dest, opts);
  }
  function mkDirAndCopy(srcMode, src, dest, opts) {
    fs2.mkdirSync(dest);
    copyDir(src, dest, opts);
    return setDestMode(dest, srcMode);
  }
  function copyDir(src, dest, opts) {
    const dir = fs2.opendirSync(src);
    try {
      let dirent;
      while ((dirent = dir.readSync()) !== null) {
        copyDirItem(dirent.name, src, dest, opts);
      }
    } finally {
      dir.closeSync();
    }
  }
  function copyDirItem(item, src, dest, opts) {
    const srcItem = path2.join(src, item);
    const destItem = path2.join(dest, item);
    if (opts.filter && !opts.filter(srcItem, destItem)) return;
    const { destStat } = stat2.checkPathsSync(srcItem, destItem, "copy", opts);
    return getStats(destStat, srcItem, destItem, opts);
  }
  function onLink(destStat, src, dest, opts) {
    let resolvedSrc = fs2.readlinkSync(src);
    if (opts.dereference) {
      resolvedSrc = path2.resolve(process.cwd(), resolvedSrc);
    }
    if (!destStat) {
      return fs2.symlinkSync(resolvedSrc, dest);
    } else {
      let resolvedDest;
      try {
        resolvedDest = fs2.readlinkSync(dest);
      } catch (err) {
        if (err.code === "EINVAL" || err.code === "UNKNOWN") return fs2.symlinkSync(resolvedSrc, dest);
        throw err;
      }
      if (opts.dereference) {
        resolvedDest = path2.resolve(process.cwd(), resolvedDest);
      }
      if (resolvedSrc !== resolvedDest) {
        if (stat2.isSrcSubdir(resolvedSrc, resolvedDest)) {
          throw new Error(`Cannot copy '${resolvedSrc}' to a subdirectory of itself, '${resolvedDest}'.`);
        }
        if (stat2.isSrcSubdir(resolvedDest, resolvedSrc)) {
          throw new Error(`Cannot overwrite '${resolvedDest}' with '${resolvedSrc}'.`);
        }
      }
      return copyLink(resolvedSrc, dest);
    }
  }
  function copyLink(resolvedSrc, dest) {
    fs2.unlinkSync(dest);
    return fs2.symlinkSync(resolvedSrc, dest);
  }
  copySync_1 = copySync;
  return copySync_1;
}
var copy;
var hasRequiredCopy;
function requireCopy() {
  if (hasRequiredCopy) return copy;
  hasRequiredCopy = 1;
  const u = requireUniversalify().fromPromise;
  copy = {
    copy: u(requireCopy$1()),
    copySync: requireCopySync()
  };
  return copy;
}
var remove_1;
var hasRequiredRemove;
function requireRemove() {
  if (hasRequiredRemove) return remove_1;
  hasRequiredRemove = 1;
  const fs2 = requireGracefulFs();
  const u = requireUniversalify().fromCallback;
  function remove(path2, callback) {
    fs2.rm(path2, {
      recursive: true,
      force: true
    }, callback);
  }
  function removeSync(path2) {
    fs2.rmSync(path2, {
      recursive: true,
      force: true
    });
  }
  remove_1 = {
    remove: u(remove),
    removeSync
  };
  return remove_1;
}
var empty;
var hasRequiredEmpty;
function requireEmpty() {
  if (hasRequiredEmpty) return empty;
  hasRequiredEmpty = 1;
  const u = requireUniversalify().fromPromise;
  const fs2 = requireFs();
  const path2 = require$$1$1;
  const mkdir = requireMkdirs();
  const remove = requireRemove();
  const emptyDir = u(async function emptyDir2(dir) {
    let items;
    try {
      items = await fs2.readdir(dir);
    } catch {
      return mkdir.mkdirs(dir);
    }
    return Promise.all(items.map((item) => remove.remove(path2.join(dir, item))));
  });
  function emptyDirSync(dir) {
    let items;
    try {
      items = fs2.readdirSync(dir);
    } catch {
      return mkdir.mkdirsSync(dir);
    }
    items.forEach((item) => {
      item = path2.join(dir, item);
      remove.removeSync(item);
    });
  }
  empty = {
    emptyDirSync,
    emptydirSync: emptyDirSync,
    emptyDir,
    emptydir: emptyDir
  };
  return empty;
}
var file$1;
var hasRequiredFile;
function requireFile() {
  if (hasRequiredFile) return file$1;
  hasRequiredFile = 1;
  const u = requireUniversalify().fromPromise;
  const path2 = require$$1$1;
  const fs2 = requireFs();
  const mkdir = requireMkdirs();
  async function createFile(file2) {
    let stats;
    try {
      stats = await fs2.stat(file2);
    } catch {
    }
    if (stats && stats.isFile()) return;
    const dir = path2.dirname(file2);
    let dirStats = null;
    try {
      dirStats = await fs2.stat(dir);
    } catch (err) {
      if (err.code === "ENOENT") {
        await mkdir.mkdirs(dir);
        await fs2.writeFile(file2, "");
        return;
      } else {
        throw err;
      }
    }
    if (dirStats.isDirectory()) {
      await fs2.writeFile(file2, "");
    } else {
      await fs2.readdir(dir);
    }
  }
  function createFileSync(file2) {
    let stats;
    try {
      stats = fs2.statSync(file2);
    } catch {
    }
    if (stats && stats.isFile()) return;
    const dir = path2.dirname(file2);
    try {
      if (!fs2.statSync(dir).isDirectory()) {
        fs2.readdirSync(dir);
      }
    } catch (err) {
      if (err && err.code === "ENOENT") mkdir.mkdirsSync(dir);
      else throw err;
    }
    fs2.writeFileSync(file2, "");
  }
  file$1 = {
    createFile: u(createFile),
    createFileSync
  };
  return file$1;
}
var link;
var hasRequiredLink;
function requireLink() {
  if (hasRequiredLink) return link;
  hasRequiredLink = 1;
  const u = requireUniversalify().fromPromise;
  const path2 = require$$1$1;
  const fs2 = requireFs();
  const mkdir = requireMkdirs();
  const { pathExists } = requirePathExists();
  const { areIdentical } = requireStat();
  async function createLink(srcpath, dstpath) {
    let dstStat;
    try {
      dstStat = await fs2.lstat(dstpath, {
        bigint: true
      });
    } catch {
    }
    let srcStat;
    try {
      srcStat = await fs2.lstat(srcpath, {
        bigint: true
      });
    } catch (err) {
      err.message = err.message.replace("lstat", "ensureLink");
      throw err;
    }
    if (dstStat && areIdentical(srcStat, dstStat)) return;
    const dir = path2.dirname(dstpath);
    const dirExists = await pathExists(dir);
    if (!dirExists) {
      await mkdir.mkdirs(dir);
    }
    await fs2.link(srcpath, dstpath);
  }
  function createLinkSync(srcpath, dstpath) {
    let dstStat;
    try {
      dstStat = fs2.lstatSync(dstpath, {
        bigint: true
      });
    } catch {
    }
    try {
      const srcStat = fs2.lstatSync(srcpath, {
        bigint: true
      });
      if (dstStat && areIdentical(srcStat, dstStat)) return;
    } catch (err) {
      err.message = err.message.replace("lstat", "ensureLink");
      throw err;
    }
    const dir = path2.dirname(dstpath);
    const dirExists = fs2.existsSync(dir);
    if (dirExists) return fs2.linkSync(srcpath, dstpath);
    mkdir.mkdirsSync(dir);
    return fs2.linkSync(srcpath, dstpath);
  }
  link = {
    createLink: u(createLink),
    createLinkSync
  };
  return link;
}
var symlinkPaths_1;
var hasRequiredSymlinkPaths;
function requireSymlinkPaths() {
  if (hasRequiredSymlinkPaths) return symlinkPaths_1;
  hasRequiredSymlinkPaths = 1;
  const path2 = require$$1$1;
  const fs2 = requireFs();
  const { pathExists } = requirePathExists();
  const u = requireUniversalify().fromPromise;
  async function symlinkPaths(srcpath, dstpath) {
    if (path2.isAbsolute(srcpath)) {
      try {
        await fs2.lstat(srcpath);
      } catch (err) {
        err.message = err.message.replace("lstat", "ensureSymlink");
        throw err;
      }
      return {
        toCwd: srcpath,
        toDst: srcpath
      };
    }
    const dstdir = path2.dirname(dstpath);
    const relativeToDst = path2.join(dstdir, srcpath);
    const exists = await pathExists(relativeToDst);
    if (exists) {
      return {
        toCwd: relativeToDst,
        toDst: srcpath
      };
    }
    try {
      await fs2.lstat(srcpath);
    } catch (err) {
      err.message = err.message.replace("lstat", "ensureSymlink");
      throw err;
    }
    return {
      toCwd: srcpath,
      toDst: path2.relative(dstdir, srcpath)
    };
  }
  function symlinkPathsSync(srcpath, dstpath) {
    if (path2.isAbsolute(srcpath)) {
      const exists2 = fs2.existsSync(srcpath);
      if (!exists2) throw new Error("absolute srcpath does not exist");
      return {
        toCwd: srcpath,
        toDst: srcpath
      };
    }
    const dstdir = path2.dirname(dstpath);
    const relativeToDst = path2.join(dstdir, srcpath);
    const exists = fs2.existsSync(relativeToDst);
    if (exists) {
      return {
        toCwd: relativeToDst,
        toDst: srcpath
      };
    }
    const srcExists = fs2.existsSync(srcpath);
    if (!srcExists) throw new Error("relative srcpath does not exist");
    return {
      toCwd: srcpath,
      toDst: path2.relative(dstdir, srcpath)
    };
  }
  symlinkPaths_1 = {
    symlinkPaths: u(symlinkPaths),
    symlinkPathsSync
  };
  return symlinkPaths_1;
}
var symlinkType_1;
var hasRequiredSymlinkType;
function requireSymlinkType() {
  if (hasRequiredSymlinkType) return symlinkType_1;
  hasRequiredSymlinkType = 1;
  const fs2 = requireFs();
  const u = requireUniversalify().fromPromise;
  async function symlinkType(srcpath, type) {
    if (type) return type;
    let stats;
    try {
      stats = await fs2.lstat(srcpath);
    } catch {
      return "file";
    }
    return stats && stats.isDirectory() ? "dir" : "file";
  }
  function symlinkTypeSync(srcpath, type) {
    if (type) return type;
    let stats;
    try {
      stats = fs2.lstatSync(srcpath);
    } catch {
      return "file";
    }
    return stats && stats.isDirectory() ? "dir" : "file";
  }
  symlinkType_1 = {
    symlinkType: u(symlinkType),
    symlinkTypeSync
  };
  return symlinkType_1;
}
var symlink;
var hasRequiredSymlink;
function requireSymlink() {
  if (hasRequiredSymlink) return symlink;
  hasRequiredSymlink = 1;
  const u = requireUniversalify().fromPromise;
  const path2 = require$$1$1;
  const fs2 = requireFs();
  const { mkdirs: mkdirs2, mkdirsSync } = requireMkdirs();
  const { symlinkPaths, symlinkPathsSync } = requireSymlinkPaths();
  const { symlinkType, symlinkTypeSync } = requireSymlinkType();
  const { pathExists } = requirePathExists();
  const { areIdentical } = requireStat();
  async function createSymlink(srcpath, dstpath, type) {
    let stats;
    try {
      stats = await fs2.lstat(dstpath);
    } catch {
    }
    if (stats && stats.isSymbolicLink()) {
      let srcStat;
      if (path2.isAbsolute(srcpath)) {
        srcStat = await fs2.stat(srcpath, {
          bigint: true
        });
      } else {
        const dstdir = path2.dirname(dstpath);
        const relativeToDst = path2.join(dstdir, srcpath);
        try {
          srcStat = await fs2.stat(relativeToDst, {
            bigint: true
          });
        } catch {
          srcStat = await fs2.stat(srcpath, {
            bigint: true
          });
        }
      }
      const dstStat = await fs2.stat(dstpath, {
        bigint: true
      });
      if (areIdentical(srcStat, dstStat)) return;
    }
    const relative = await symlinkPaths(srcpath, dstpath);
    srcpath = relative.toDst;
    const toType = await symlinkType(relative.toCwd, type);
    const dir = path2.dirname(dstpath);
    if (!await pathExists(dir)) {
      await mkdirs2(dir);
    }
    return fs2.symlink(srcpath, dstpath, toType);
  }
  function createSymlinkSync(srcpath, dstpath, type) {
    let stats;
    try {
      stats = fs2.lstatSync(dstpath);
    } catch {
    }
    if (stats && stats.isSymbolicLink()) {
      let srcStat;
      if (path2.isAbsolute(srcpath)) {
        srcStat = fs2.statSync(srcpath, {
          bigint: true
        });
      } else {
        const dstdir = path2.dirname(dstpath);
        const relativeToDst = path2.join(dstdir, srcpath);
        try {
          srcStat = fs2.statSync(relativeToDst, {
            bigint: true
          });
        } catch {
          srcStat = fs2.statSync(srcpath, {
            bigint: true
          });
        }
      }
      const dstStat = fs2.statSync(dstpath, {
        bigint: true
      });
      if (areIdentical(srcStat, dstStat)) return;
    }
    const relative = symlinkPathsSync(srcpath, dstpath);
    srcpath = relative.toDst;
    type = symlinkTypeSync(relative.toCwd, type);
    const dir = path2.dirname(dstpath);
    const exists = fs2.existsSync(dir);
    if (exists) return fs2.symlinkSync(srcpath, dstpath, type);
    mkdirsSync(dir);
    return fs2.symlinkSync(srcpath, dstpath, type);
  }
  symlink = {
    createSymlink: u(createSymlink),
    createSymlinkSync
  };
  return symlink;
}
var ensure;
var hasRequiredEnsure;
function requireEnsure() {
  if (hasRequiredEnsure) return ensure;
  hasRequiredEnsure = 1;
  const { createFile, createFileSync } = requireFile();
  const { createLink, createLinkSync } = requireLink();
  const { createSymlink, createSymlinkSync } = requireSymlink();
  ensure = {
    createFile,
    createFileSync,
    ensureFile: createFile,
    ensureFileSync: createFileSync,
    createLink,
    createLinkSync,
    ensureLink: createLink,
    ensureLinkSync: createLinkSync,
    createSymlink,
    createSymlinkSync,
    ensureSymlink: createSymlink,
    ensureSymlinkSync: createSymlinkSync
  };
  return ensure;
}
var utils;
var hasRequiredUtils;
function requireUtils() {
  if (hasRequiredUtils) return utils;
  hasRequiredUtils = 1;
  function stringify(obj, { EOL = "\n", finalEOL = true, replacer = null, spaces } = {}) {
    const EOF = finalEOL ? EOL : "";
    const str = JSON.stringify(obj, replacer, spaces);
    if (str === void 0) {
      throw new TypeError(`Converting ${typeof obj} value to JSON is not supported`);
    }
    return str.replace(/\n/g, EOL) + EOF;
  }
  function stripBom(content) {
    if (Buffer.isBuffer(content)) content = content.toString("utf8");
    return content.replace(/^\uFEFF/, "");
  }
  utils = {
    stringify,
    stripBom
  };
  return utils;
}
var jsonfile$1;
var hasRequiredJsonfile$1;
function requireJsonfile$1() {
  if (hasRequiredJsonfile$1) return jsonfile$1;
  hasRequiredJsonfile$1 = 1;
  let _fs;
  try {
    _fs = requireGracefulFs();
  } catch (_) {
    _fs = require$$2$1;
  }
  const universalify2 = requireUniversalify();
  const { stringify, stripBom } = requireUtils();
  async function _readFile(file2, options2 = {}) {
    if (typeof options2 === "string") {
      options2 = {
        encoding: options2
      };
    }
    const fs2 = options2.fs || _fs;
    const shouldThrow = "throws" in options2 ? options2.throws : true;
    let data = await universalify2.fromCallback(fs2.readFile)(file2, options2);
    data = stripBom(data);
    let obj;
    try {
      obj = JSON.parse(data, options2 ? options2.reviver : null);
    } catch (err) {
      if (shouldThrow) {
        err.message = `${file2}: ${err.message}`;
        throw err;
      } else {
        return null;
      }
    }
    return obj;
  }
  const readFile = universalify2.fromPromise(_readFile);
  function readFileSync2(file2, options2 = {}) {
    if (typeof options2 === "string") {
      options2 = {
        encoding: options2
      };
    }
    const fs2 = options2.fs || _fs;
    const shouldThrow = "throws" in options2 ? options2.throws : true;
    try {
      let content = fs2.readFileSync(file2, options2);
      content = stripBom(content);
      return JSON.parse(content, options2.reviver);
    } catch (err) {
      if (shouldThrow) {
        err.message = `${file2}: ${err.message}`;
        throw err;
      } else {
        return null;
      }
    }
  }
  async function _writeFile(file2, obj, options2 = {}) {
    const fs2 = options2.fs || _fs;
    const str = stringify(obj, options2);
    await universalify2.fromCallback(fs2.writeFile)(file2, str, options2);
  }
  const writeFile = universalify2.fromPromise(_writeFile);
  function writeFileSync(file2, obj, options2 = {}) {
    const fs2 = options2.fs || _fs;
    const str = stringify(obj, options2);
    return fs2.writeFileSync(file2, str, options2);
  }
  jsonfile$1 = {
    readFile,
    readFileSync: readFileSync2,
    writeFile,
    writeFileSync
  };
  return jsonfile$1;
}
var jsonfile;
var hasRequiredJsonfile;
function requireJsonfile() {
  if (hasRequiredJsonfile) return jsonfile;
  hasRequiredJsonfile = 1;
  const jsonFile = requireJsonfile$1();
  jsonfile = {
    readJson: jsonFile.readFile,
    readJsonSync: jsonFile.readFileSync,
    writeJson: jsonFile.writeFile,
    writeJsonSync: jsonFile.writeFileSync
  };
  return jsonfile;
}
var outputFile_1;
var hasRequiredOutputFile;
function requireOutputFile() {
  if (hasRequiredOutputFile) return outputFile_1;
  hasRequiredOutputFile = 1;
  const u = requireUniversalify().fromPromise;
  const fs2 = requireFs();
  const path2 = require$$1$1;
  const mkdir = requireMkdirs();
  const pathExists = requirePathExists().pathExists;
  async function outputFile(file2, data, encoding = "utf-8") {
    const dir = path2.dirname(file2);
    if (!await pathExists(dir)) {
      await mkdir.mkdirs(dir);
    }
    return fs2.writeFile(file2, data, encoding);
  }
  function outputFileSync(file2, ...args) {
    const dir = path2.dirname(file2);
    if (!fs2.existsSync(dir)) {
      mkdir.mkdirsSync(dir);
    }
    fs2.writeFileSync(file2, ...args);
  }
  outputFile_1 = {
    outputFile: u(outputFile),
    outputFileSync
  };
  return outputFile_1;
}
var outputJson_1;
var hasRequiredOutputJson;
function requireOutputJson() {
  if (hasRequiredOutputJson) return outputJson_1;
  hasRequiredOutputJson = 1;
  const { stringify } = requireUtils();
  const { outputFile } = requireOutputFile();
  async function outputJson(file2, data, options2 = {}) {
    const str = stringify(data, options2);
    await outputFile(file2, str, options2);
  }
  outputJson_1 = outputJson;
  return outputJson_1;
}
var outputJsonSync_1;
var hasRequiredOutputJsonSync;
function requireOutputJsonSync() {
  if (hasRequiredOutputJsonSync) return outputJsonSync_1;
  hasRequiredOutputJsonSync = 1;
  const { stringify } = requireUtils();
  const { outputFileSync } = requireOutputFile();
  function outputJsonSync(file2, data, options2) {
    const str = stringify(data, options2);
    outputFileSync(file2, str, options2);
  }
  outputJsonSync_1 = outputJsonSync;
  return outputJsonSync_1;
}
var json;
var hasRequiredJson;
function requireJson() {
  if (hasRequiredJson) return json;
  hasRequiredJson = 1;
  const u = requireUniversalify().fromPromise;
  const jsonFile = requireJsonfile();
  jsonFile.outputJson = u(requireOutputJson());
  jsonFile.outputJsonSync = requireOutputJsonSync();
  jsonFile.outputJSON = jsonFile.outputJson;
  jsonFile.outputJSONSync = jsonFile.outputJsonSync;
  jsonFile.writeJSON = jsonFile.writeJson;
  jsonFile.writeJSONSync = jsonFile.writeJsonSync;
  jsonFile.readJSON = jsonFile.readJson;
  jsonFile.readJSONSync = jsonFile.readJsonSync;
  json = jsonFile;
  return json;
}
var move_1;
var hasRequiredMove$1;
function requireMove$1() {
  if (hasRequiredMove$1) return move_1;
  hasRequiredMove$1 = 1;
  const fs2 = requireFs();
  const path2 = require$$1$1;
  const { copy: copy2 } = requireCopy();
  const { remove } = requireRemove();
  const { mkdirp } = requireMkdirs();
  const { pathExists } = requirePathExists();
  const stat2 = requireStat();
  async function move2(src, dest, opts = {}) {
    const overwrite = opts.overwrite || opts.clobber || false;
    const { srcStat, isChangingCase = false } = await stat2.checkPaths(src, dest, "move", opts);
    await stat2.checkParentPaths(src, srcStat, dest, "move");
    const destParent = path2.dirname(dest);
    const parsedParentPath = path2.parse(destParent);
    if (parsedParentPath.root !== destParent) {
      await mkdirp(destParent);
    }
    return doRename(src, dest, overwrite, isChangingCase);
  }
  async function doRename(src, dest, overwrite, isChangingCase) {
    if (!isChangingCase) {
      if (overwrite) {
        await remove(dest);
      } else if (await pathExists(dest)) {
        throw new Error("dest already exists.");
      }
    }
    try {
      await fs2.rename(src, dest);
    } catch (err) {
      if (err.code !== "EXDEV") {
        throw err;
      }
      await moveAcrossDevice(src, dest, overwrite);
    }
  }
  async function moveAcrossDevice(src, dest, overwrite) {
    const opts = {
      overwrite,
      errorOnExist: true,
      preserveTimestamps: true
    };
    await copy2(src, dest, opts);
    return remove(src);
  }
  move_1 = move2;
  return move_1;
}
var moveSync_1;
var hasRequiredMoveSync;
function requireMoveSync() {
  if (hasRequiredMoveSync) return moveSync_1;
  hasRequiredMoveSync = 1;
  const fs2 = requireGracefulFs();
  const path2 = require$$1$1;
  const copySync = requireCopy().copySync;
  const removeSync = requireRemove().removeSync;
  const mkdirpSync = requireMkdirs().mkdirpSync;
  const stat2 = requireStat();
  function moveSync(src, dest, opts) {
    opts = opts || {};
    const overwrite = opts.overwrite || opts.clobber || false;
    const { srcStat, isChangingCase = false } = stat2.checkPathsSync(src, dest, "move", opts);
    stat2.checkParentPathsSync(src, srcStat, dest, "move");
    if (!isParentRoot(dest)) mkdirpSync(path2.dirname(dest));
    return doRename(src, dest, overwrite, isChangingCase);
  }
  function isParentRoot(dest) {
    const parent = path2.dirname(dest);
    const parsedPath = path2.parse(parent);
    return parsedPath.root === parent;
  }
  function doRename(src, dest, overwrite, isChangingCase) {
    if (isChangingCase) return rename(src, dest, overwrite);
    if (overwrite) {
      removeSync(dest);
      return rename(src, dest, overwrite);
    }
    if (fs2.existsSync(dest)) throw new Error("dest already exists.");
    return rename(src, dest, overwrite);
  }
  function rename(src, dest, overwrite) {
    try {
      fs2.renameSync(src, dest);
    } catch (err) {
      if (err.code !== "EXDEV") throw err;
      return moveAcrossDevice(src, dest, overwrite);
    }
  }
  function moveAcrossDevice(src, dest, overwrite) {
    const opts = {
      overwrite,
      errorOnExist: true,
      preserveTimestamps: true
    };
    copySync(src, dest, opts);
    return removeSync(src);
  }
  moveSync_1 = moveSync;
  return moveSync_1;
}
var move;
var hasRequiredMove;
function requireMove() {
  if (hasRequiredMove) return move;
  hasRequiredMove = 1;
  const u = requireUniversalify().fromPromise;
  move = {
    move: u(requireMove$1()),
    moveSync: requireMoveSync()
  };
  return move;
}
var lib$1;
var hasRequiredLib$1;
function requireLib$1() {
  if (hasRequiredLib$1) return lib$1;
  hasRequiredLib$1 = 1;
  lib$1 = {
    ...requireFs(),
    ...requireCopy(),
    ...requireEmpty(),
    ...requireEnsure(),
    ...requireJson(),
    ...requireMkdirs(),
    ...requireMove(),
    ...requireOutputFile(),
    ...requirePathExists(),
    ...requireRemove()
  };
  return lib$1;
}
var libExports$1 = requireLib$1();
var fs = getDefaultExportFromCjs(libExports$1);
var LIB;
(() => {
  var t = {
    975: (t2) => {
      function e2(t3) {
        if ("string" != typeof t3) throw new TypeError("Path must be a string. Received " + JSON.stringify(t3));
      }
      function r2(t3, e3) {
        for (var r3, n3 = "", i2 = 0, o2 = -1, s2 = 0, h2 = 0; h2 <= t3.length; ++h2) {
          if (h2 < t3.length) r3 = t3.charCodeAt(h2);
          else {
            if (47 === r3) break;
            r3 = 47;
          }
          if (47 === r3) {
            if (o2 === h2 - 1 || 1 === s2) ;
            else if (o2 !== h2 - 1 && 2 === s2) {
              if (n3.length < 2 || 2 !== i2 || 46 !== n3.charCodeAt(n3.length - 1) || 46 !== n3.charCodeAt(n3.length - 2)) {
                if (n3.length > 2) {
                  var a2 = n3.lastIndexOf("/");
                  if (a2 !== n3.length - 1) {
                    -1 === a2 ? (n3 = "", i2 = 0) : i2 = (n3 = n3.slice(0, a2)).length - 1 - n3.lastIndexOf("/"), o2 = h2, s2 = 0;
                    continue;
                  }
                } else if (2 === n3.length || 1 === n3.length) {
                  n3 = "", i2 = 0, o2 = h2, s2 = 0;
                  continue;
                }
              }
              e3 && (n3.length > 0 ? n3 += "/.." : n3 = "..", i2 = 2);
            } else n3.length > 0 ? n3 += "/" + t3.slice(o2 + 1, h2) : n3 = t3.slice(o2 + 1, h2), i2 = h2 - o2 - 1;
            o2 = h2, s2 = 0;
          } else 46 === r3 && -1 !== s2 ? ++s2 : s2 = -1;
        }
        return n3;
      }
      var n2 = {
        resolve: function() {
          for (var t3, n3 = "", i2 = false, o2 = arguments.length - 1; o2 >= -1 && !i2; o2--) {
            var s2;
            o2 >= 0 ? s2 = arguments[o2] : (void 0 === t3 && (t3 = process.cwd()), s2 = t3), e2(s2), 0 !== s2.length && (n3 = s2 + "/" + n3, i2 = 47 === s2.charCodeAt(0));
          }
          return n3 = r2(n3, !i2), i2 ? n3.length > 0 ? "/" + n3 : "/" : n3.length > 0 ? n3 : ".";
        },
        normalize: function(t3) {
          if (e2(t3), 0 === t3.length) return ".";
          var n3 = 47 === t3.charCodeAt(0), i2 = 47 === t3.charCodeAt(t3.length - 1);
          return 0 !== (t3 = r2(t3, !n3)).length || n3 || (t3 = "."), t3.length > 0 && i2 && (t3 += "/"), n3 ? "/" + t3 : t3;
        },
        isAbsolute: function(t3) {
          return e2(t3), t3.length > 0 && 47 === t3.charCodeAt(0);
        },
        join: function() {
          if (0 === arguments.length) return ".";
          for (var t3, r3 = 0; r3 < arguments.length; ++r3) {
            var i2 = arguments[r3];
            e2(i2), i2.length > 0 && (void 0 === t3 ? t3 = i2 : t3 += "/" + i2);
          }
          return void 0 === t3 ? "." : n2.normalize(t3);
        },
        relative: function(t3, r3) {
          if (e2(t3), e2(r3), t3 === r3) return "";
          if ((t3 = n2.resolve(t3)) === (r3 = n2.resolve(r3))) return "";
          for (var i2 = 1; i2 < t3.length && 47 === t3.charCodeAt(i2); ++i2) ;
          for (var o2 = t3.length, s2 = o2 - i2, h2 = 1; h2 < r3.length && 47 === r3.charCodeAt(h2); ++h2) ;
          for (var a2 = r3.length - h2, c2 = s2 < a2 ? s2 : a2, f2 = -1, u2 = 0; u2 <= c2; ++u2) {
            if (u2 === c2) {
              if (a2 > c2) {
                if (47 === r3.charCodeAt(h2 + u2)) return r3.slice(h2 + u2 + 1);
                if (0 === u2) return r3.slice(h2 + u2);
              } else s2 > c2 && (47 === t3.charCodeAt(i2 + u2) ? f2 = u2 : 0 === u2 && (f2 = 0));
              break;
            }
            var l2 = t3.charCodeAt(i2 + u2);
            if (l2 !== r3.charCodeAt(h2 + u2)) break;
            47 === l2 && (f2 = u2);
          }
          var g2 = "";
          for (u2 = i2 + f2 + 1; u2 <= o2; ++u2) u2 !== o2 && 47 !== t3.charCodeAt(u2) || (0 === g2.length ? g2 += ".." : g2 += "/..");
          return g2.length > 0 ? g2 + r3.slice(h2 + f2) : (h2 += f2, 47 === r3.charCodeAt(h2) && ++h2, r3.slice(h2));
        },
        _makeLong: function(t3) {
          return t3;
        },
        dirname: function(t3) {
          if (e2(t3), 0 === t3.length) return ".";
          for (var r3 = t3.charCodeAt(0), n3 = 47 === r3, i2 = -1, o2 = true, s2 = t3.length - 1; s2 >= 1; --s2) if (47 === (r3 = t3.charCodeAt(s2))) {
            if (!o2) {
              i2 = s2;
              break;
            }
          } else o2 = false;
          return -1 === i2 ? n3 ? "/" : "." : n3 && 1 === i2 ? "//" : t3.slice(0, i2);
        },
        basename: function(t3, r3) {
          if (void 0 !== r3 && "string" != typeof r3) throw new TypeError('"ext" argument must be a string');
          e2(t3);
          var n3, i2 = 0, o2 = -1, s2 = true;
          if (void 0 !== r3 && r3.length > 0 && r3.length <= t3.length) {
            if (r3.length === t3.length && r3 === t3) return "";
            var h2 = r3.length - 1, a2 = -1;
            for (n3 = t3.length - 1; n3 >= 0; --n3) {
              var c2 = t3.charCodeAt(n3);
              if (47 === c2) {
                if (!s2) {
                  i2 = n3 + 1;
                  break;
                }
              } else -1 === a2 && (s2 = false, a2 = n3 + 1), h2 >= 0 && (c2 === r3.charCodeAt(h2) ? -1 == --h2 && (o2 = n3) : (h2 = -1, o2 = a2));
            }
            return i2 === o2 ? o2 = a2 : -1 === o2 && (o2 = t3.length), t3.slice(i2, o2);
          }
          for (n3 = t3.length - 1; n3 >= 0; --n3) if (47 === t3.charCodeAt(n3)) {
            if (!s2) {
              i2 = n3 + 1;
              break;
            }
          } else -1 === o2 && (s2 = false, o2 = n3 + 1);
          return -1 === o2 ? "" : t3.slice(i2, o2);
        },
        extname: function(t3) {
          e2(t3);
          for (var r3 = -1, n3 = 0, i2 = -1, o2 = true, s2 = 0, h2 = t3.length - 1; h2 >= 0; --h2) {
            var a2 = t3.charCodeAt(h2);
            if (47 !== a2) -1 === i2 && (o2 = false, i2 = h2 + 1), 46 === a2 ? -1 === r3 ? r3 = h2 : 1 !== s2 && (s2 = 1) : -1 !== r3 && (s2 = -1);
            else if (!o2) {
              n3 = h2 + 1;
              break;
            }
          }
          return -1 === r3 || -1 === i2 || 0 === s2 || 1 === s2 && r3 === i2 - 1 && r3 === n3 + 1 ? "" : t3.slice(r3, i2);
        },
        format: function(t3) {
          if (null === t3 || "object" != typeof t3) throw new TypeError('The "pathObject" argument must be of type Object. Received type ' + typeof t3);
          return (function(t4, e3) {
            var r3 = e3.dir || e3.root, n3 = e3.base || (e3.name || "") + (e3.ext || "");
            return r3 ? r3 === e3.root ? r3 + n3 : r3 + "/" + n3 : n3;
          })(0, t3);
        },
        parse: function(t3) {
          e2(t3);
          var r3 = {
            root: "",
            dir: "",
            base: "",
            ext: "",
            name: ""
          };
          if (0 === t3.length) return r3;
          var n3, i2 = t3.charCodeAt(0), o2 = 47 === i2;
          o2 ? (r3.root = "/", n3 = 1) : n3 = 0;
          for (var s2 = -1, h2 = 0, a2 = -1, c2 = true, f2 = t3.length - 1, u2 = 0; f2 >= n3; --f2) if (47 !== (i2 = t3.charCodeAt(f2))) -1 === a2 && (c2 = false, a2 = f2 + 1), 46 === i2 ? -1 === s2 ? s2 = f2 : 1 !== u2 && (u2 = 1) : -1 !== s2 && (u2 = -1);
          else if (!c2) {
            h2 = f2 + 1;
            break;
          }
          return -1 === s2 || -1 === a2 || 0 === u2 || 1 === u2 && s2 === a2 - 1 && s2 === h2 + 1 ? -1 !== a2 && (r3.base = r3.name = 0 === h2 && o2 ? t3.slice(1, a2) : t3.slice(h2, a2)) : (0 === h2 && o2 ? (r3.name = t3.slice(1, s2), r3.base = t3.slice(1, a2)) : (r3.name = t3.slice(h2, s2), r3.base = t3.slice(h2, a2)), r3.ext = t3.slice(s2, a2)), h2 > 0 ? r3.dir = t3.slice(0, h2 - 1) : o2 && (r3.dir = "/"), r3;
        },
        sep: "/",
        delimiter: ":",
        win32: null,
        posix: null
      };
      n2.posix = n2, t2.exports = n2;
    }
  }, e = {};
  function r(n2) {
    var i2 = e[n2];
    if (void 0 !== i2) return i2.exports;
    var o2 = e[n2] = {
      exports: {}
    };
    return t[n2](o2, o2.exports, r), o2.exports;
  }
  r.d = (t2, e2) => {
    for (var n2 in e2) r.o(e2, n2) && !r.o(t2, n2) && Object.defineProperty(t2, n2, {
      enumerable: true,
      get: e2[n2]
    });
  }, r.o = (t2, e2) => Object.prototype.hasOwnProperty.call(t2, e2), r.r = (t2) => {
    "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t2, Symbol.toStringTag, {
      value: "Module"
    }), Object.defineProperty(t2, "__esModule", {
      value: true
    });
  };
  var n = {};
  let i;
  if (r.r(n), r.d(n, {
    URI: () => l,
    Utils: () => I
  }), "object" == typeof process) i = "win32" === process.platform;
  else if ("object" == typeof navigator) {
    let t2 = navigator.userAgent;
    i = t2.indexOf("Windows") >= 0;
  }
  const o = /^\w[\w\d+.-]*$/, s = /^\//, h = /^\/\//;
  function a(t2, e2) {
    if (!t2.scheme && e2) throw new Error(`[UriError]: Scheme is missing: {scheme: "", authority: "${t2.authority}", path: "${t2.path}", query: "${t2.query}", fragment: "${t2.fragment}"}`);
    if (t2.scheme && !o.test(t2.scheme)) throw new Error("[UriError]: Scheme contains illegal characters.");
    if (t2.path) {
      if (t2.authority) {
        if (!s.test(t2.path)) throw new Error('[UriError]: If a URI contains an authority component, then the path component must either be empty or begin with a slash ("/") character');
      } else if (h.test(t2.path)) throw new Error('[UriError]: If a URI does not contain an authority component, then the path cannot begin with two slash characters ("//")');
    }
  }
  const c = "", f = "/", u = /^(([^:/?#]+?):)?(\/\/([^/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?/;
  class l {
    static isUri(t2) {
      return t2 instanceof l || !!t2 && "string" == typeof t2.authority && "string" == typeof t2.fragment && "string" == typeof t2.path && "string" == typeof t2.query && "string" == typeof t2.scheme && "string" == typeof t2.fsPath && "function" == typeof t2.with && "function" == typeof t2.toString;
    }
    scheme;
    authority;
    path;
    query;
    fragment;
    constructor(t2, e2, r2, n2, i2, o2 = false) {
      "object" == typeof t2 ? (this.scheme = t2.scheme || c, this.authority = t2.authority || c, this.path = t2.path || c, this.query = t2.query || c, this.fragment = t2.fragment || c) : (this.scheme = /* @__PURE__ */ (function(t3, e3) {
        return t3 || e3 ? t3 : "file";
      })(t2, o2), this.authority = e2 || c, this.path = (function(t3, e3) {
        switch (t3) {
          case "https":
          case "http":
          case "file":
            e3 ? e3[0] !== f && (e3 = f + e3) : e3 = f;
        }
        return e3;
      })(this.scheme, r2 || c), this.query = n2 || c, this.fragment = i2 || c, a(this, o2));
    }
    get fsPath() {
      return v(this);
    }
    with(t2) {
      if (!t2) return this;
      let { scheme: e2, authority: r2, path: n2, query: i2, fragment: o2 } = t2;
      return void 0 === e2 ? e2 = this.scheme : null === e2 && (e2 = c), void 0 === r2 ? r2 = this.authority : null === r2 && (r2 = c), void 0 === n2 ? n2 = this.path : null === n2 && (n2 = c), void 0 === i2 ? i2 = this.query : null === i2 && (i2 = c), void 0 === o2 ? o2 = this.fragment : null === o2 && (o2 = c), e2 === this.scheme && r2 === this.authority && n2 === this.path && i2 === this.query && o2 === this.fragment ? this : new d(e2, r2, n2, i2, o2);
    }
    static parse(t2, e2 = false) {
      const r2 = u.exec(t2);
      return r2 ? new d(r2[2] || c, w(r2[4] || c), w(r2[5] || c), w(r2[7] || c), w(r2[9] || c), e2) : new d(c, c, c, c, c);
    }
    static file(t2) {
      let e2 = c;
      if (i && (t2 = t2.replace(/\\/g, f)), t2[0] === f && t2[1] === f) {
        const r2 = t2.indexOf(f, 2);
        -1 === r2 ? (e2 = t2.substring(2), t2 = f) : (e2 = t2.substring(2, r2), t2 = t2.substring(r2) || f);
      }
      return new d("file", e2, t2, c, c);
    }
    static from(t2) {
      const e2 = new d(t2.scheme, t2.authority, t2.path, t2.query, t2.fragment);
      return a(e2, true), e2;
    }
    toString(t2 = false) {
      return b(this, t2);
    }
    toJSON() {
      return this;
    }
    static revive(t2) {
      if (t2) {
        if (t2 instanceof l) return t2;
        {
          const e2 = new d(t2);
          return e2._formatted = t2.external, e2._fsPath = t2._sep === g ? t2.fsPath : null, e2;
        }
      }
      return t2;
    }
  }
  const g = i ? 1 : void 0;
  class d extends l {
    _formatted = null;
    _fsPath = null;
    get fsPath() {
      return this._fsPath || (this._fsPath = v(this)), this._fsPath;
    }
    toString(t2 = false) {
      return t2 ? b(this, true) : (this._formatted || (this._formatted = b(this, false)), this._formatted);
    }
    toJSON() {
      const t2 = {
        $mid: 1
      };
      return this._fsPath && (t2.fsPath = this._fsPath, t2._sep = g), this._formatted && (t2.external = this._formatted), this.path && (t2.path = this.path), this.scheme && (t2.scheme = this.scheme), this.authority && (t2.authority = this.authority), this.query && (t2.query = this.query), this.fragment && (t2.fragment = this.fragment), t2;
    }
  }
  const p = {
    58: "%3A",
    47: "%2F",
    63: "%3F",
    35: "%23",
    91: "%5B",
    93: "%5D",
    64: "%40",
    33: "%21",
    36: "%24",
    38: "%26",
    39: "%27",
    40: "%28",
    41: "%29",
    42: "%2A",
    43: "%2B",
    44: "%2C",
    59: "%3B",
    61: "%3D",
    32: "%20"
  };
  function m(t2, e2, r2) {
    let n2, i2 = -1;
    for (let o2 = 0; o2 < t2.length; o2++) {
      const s2 = t2.charCodeAt(o2);
      if (s2 >= 97 && s2 <= 122 || s2 >= 65 && s2 <= 90 || s2 >= 48 && s2 <= 57 || 45 === s2 || 46 === s2 || 95 === s2 || 126 === s2 || e2 && 47 === s2 || r2 && 91 === s2 || r2 && 93 === s2 || r2 && 58 === s2) -1 !== i2 && (n2 += encodeURIComponent(t2.substring(i2, o2)), i2 = -1), void 0 !== n2 && (n2 += t2.charAt(o2));
      else {
        void 0 === n2 && (n2 = t2.substr(0, o2));
        const e3 = p[s2];
        void 0 !== e3 ? (-1 !== i2 && (n2 += encodeURIComponent(t2.substring(i2, o2)), i2 = -1), n2 += e3) : -1 === i2 && (i2 = o2);
      }
    }
    return -1 !== i2 && (n2 += encodeURIComponent(t2.substring(i2))), void 0 !== n2 ? n2 : t2;
  }
  function y(t2) {
    let e2;
    for (let r2 = 0; r2 < t2.length; r2++) {
      const n2 = t2.charCodeAt(r2);
      35 === n2 || 63 === n2 ? (void 0 === e2 && (e2 = t2.substr(0, r2)), e2 += p[n2]) : void 0 !== e2 && (e2 += t2[r2]);
    }
    return void 0 !== e2 ? e2 : t2;
  }
  function v(t2, e2) {
    let r2;
    return r2 = t2.authority && t2.path.length > 1 && "file" === t2.scheme ? `//${t2.authority}${t2.path}` : 47 === t2.path.charCodeAt(0) && (t2.path.charCodeAt(1) >= 65 && t2.path.charCodeAt(1) <= 90 || t2.path.charCodeAt(1) >= 97 && t2.path.charCodeAt(1) <= 122) && 58 === t2.path.charCodeAt(2) ? t2.path[1].toLowerCase() + t2.path.substr(2) : t2.path, i && (r2 = r2.replace(/\//g, "\\")), r2;
  }
  function b(t2, e2) {
    const r2 = e2 ? y : m;
    let n2 = "", { scheme: i2, authority: o2, path: s2, query: h2, fragment: a2 } = t2;
    if (i2 && (n2 += i2, n2 += ":"), (o2 || "file" === i2) && (n2 += f, n2 += f), o2) {
      let t3 = o2.indexOf("@");
      if (-1 !== t3) {
        const e3 = o2.substr(0, t3);
        o2 = o2.substr(t3 + 1), t3 = e3.lastIndexOf(":"), -1 === t3 ? n2 += r2(e3, false, false) : (n2 += r2(e3.substr(0, t3), false, false), n2 += ":", n2 += r2(e3.substr(t3 + 1), false, true)), n2 += "@";
      }
      o2 = o2.toLowerCase(), t3 = o2.lastIndexOf(":"), -1 === t3 ? n2 += r2(o2, false, true) : (n2 += r2(o2.substr(0, t3), false, true), n2 += o2.substr(t3));
    }
    if (s2) {
      if (s2.length >= 3 && 47 === s2.charCodeAt(0) && 58 === s2.charCodeAt(2)) {
        const t3 = s2.charCodeAt(1);
        t3 >= 65 && t3 <= 90 && (s2 = `/${String.fromCharCode(t3 + 32)}:${s2.substr(3)}`);
      } else if (s2.length >= 2 && 58 === s2.charCodeAt(1)) {
        const t3 = s2.charCodeAt(0);
        t3 >= 65 && t3 <= 90 && (s2 = `${String.fromCharCode(t3 + 32)}:${s2.substr(2)}`);
      }
      n2 += r2(s2, true, false);
    }
    return h2 && (n2 += "?", n2 += r2(h2, false, false)), a2 && (n2 += "#", n2 += e2 ? a2 : m(a2, false, false)), n2;
  }
  function C(t2) {
    try {
      return decodeURIComponent(t2);
    } catch {
      return t2.length > 3 ? t2.substr(0, 3) + C(t2.substr(3)) : t2;
    }
  }
  const A = /(%[0-9A-Za-z][0-9A-Za-z])+/g;
  function w(t2) {
    return t2.match(A) ? t2.replace(A, (t3) => C(t3)) : t2;
  }
  var x = r(975);
  const P = x.posix || x, _ = "/";
  var I;
  !(function(t2) {
    t2.joinPath = function(t3, ...e2) {
      return t3.with({
        path: P.join(t3.path, ...e2)
      });
    }, t2.resolvePath = function(t3, ...e2) {
      let r2 = t3.path, n2 = false;
      r2[0] !== _ && (r2 = _ + r2, n2 = true);
      let i2 = P.resolve(r2, ...e2);
      return n2 && i2[0] === _ && !t3.authority && (i2 = i2.substring(1)), t3.with({
        path: i2
      });
    }, t2.dirname = function(t3) {
      if (0 === t3.path.length || t3.path === _) return t3;
      let e2 = P.dirname(t3.path);
      return 1 === e2.length && 46 === e2.charCodeAt(0) && (e2 = ""), t3.with({
        path: e2
      });
    }, t2.basename = function(t3) {
      return P.basename(t3.path);
    }, t2.extname = function(t3) {
      return P.extname(t3.path);
    };
  })(I || (I = {})), LIB = n;
})();
var { URI, Utils } = LIB;
var mainExports$1 = requireMain$3();
var FullTextDocument = class _FullTextDocument {
  constructor(uri, languageId, version2, content) {
    this._uri = uri;
    this._languageId = languageId;
    this._version = version2;
    this._content = content;
    this._lineOffsets = void 0;
  }
  get uri() {
    return this._uri;
  }
  get languageId() {
    return this._languageId;
  }
  get version() {
    return this._version;
  }
  getText(range2) {
    if (range2) {
      const start = this.offsetAt(range2.start);
      const end = this.offsetAt(range2.end);
      return this._content.substring(start, end);
    }
    return this._content;
  }
  update(changes, version2) {
    for (const change of changes) {
      if (_FullTextDocument.isIncremental(change)) {
        const range2 = getWellformedRange(change.range);
        const startOffset = this.offsetAt(range2.start);
        const endOffset = this.offsetAt(range2.end);
        this._content = this._content.substring(0, startOffset) + change.text + this._content.substring(endOffset, this._content.length);
        const startLine = Math.max(range2.start.line, 0);
        const endLine = Math.max(range2.end.line, 0);
        let lineOffsets = this._lineOffsets;
        const addedLineOffsets = computeLineOffsets(change.text, false, startOffset);
        if (endLine - startLine === addedLineOffsets.length) {
          for (let i = 0, len = addedLineOffsets.length; i < len; i++) {
            lineOffsets[i + startLine + 1] = addedLineOffsets[i];
          }
        } else {
          if (addedLineOffsets.length < 1e4) {
            lineOffsets.splice(startLine + 1, endLine - startLine, ...addedLineOffsets);
          } else {
            this._lineOffsets = lineOffsets = lineOffsets.slice(0, startLine + 1).concat(addedLineOffsets, lineOffsets.slice(endLine + 1));
          }
        }
        const diff = change.text.length - (endOffset - startOffset);
        if (diff !== 0) {
          for (let i = startLine + 1 + addedLineOffsets.length, len = lineOffsets.length; i < len; i++) {
            lineOffsets[i] = lineOffsets[i] + diff;
          }
        }
      } else if (_FullTextDocument.isFull(change)) {
        this._content = change.text;
        this._lineOffsets = void 0;
      } else {
        throw new Error("Unknown change event received");
      }
    }
    this._version = version2;
  }
  getLineOffsets() {
    if (this._lineOffsets === void 0) {
      this._lineOffsets = computeLineOffsets(this._content, true);
    }
    return this._lineOffsets;
  }
  positionAt(offset) {
    offset = Math.max(Math.min(offset, this._content.length), 0);
    const lineOffsets = this.getLineOffsets();
    let low = 0, high = lineOffsets.length;
    if (high === 0) {
      return {
        line: 0,
        character: offset
      };
    }
    while (low < high) {
      const mid = Math.floor((low + high) / 2);
      if (lineOffsets[mid] > offset) {
        high = mid;
      } else {
        low = mid + 1;
      }
    }
    const line = low - 1;
    offset = this.ensureBeforeEOL(offset, lineOffsets[line]);
    return {
      line,
      character: offset - lineOffsets[line]
    };
  }
  offsetAt(position) {
    const lineOffsets = this.getLineOffsets();
    if (position.line >= lineOffsets.length) {
      return this._content.length;
    } else if (position.line < 0) {
      return 0;
    }
    const lineOffset = lineOffsets[position.line];
    if (position.character <= 0) {
      return lineOffset;
    }
    const nextLineOffset = position.line + 1 < lineOffsets.length ? lineOffsets[position.line + 1] : this._content.length;
    const offset = Math.min(lineOffset + position.character, nextLineOffset);
    return this.ensureBeforeEOL(offset, lineOffset);
  }
  ensureBeforeEOL(offset, lineOffset) {
    while (offset > lineOffset && isEOL(this._content.charCodeAt(offset - 1))) {
      offset--;
    }
    return offset;
  }
  get lineCount() {
    return this.getLineOffsets().length;
  }
  static isIncremental(event) {
    const candidate = event;
    return candidate !== void 0 && candidate !== null && typeof candidate.text === "string" && candidate.range !== void 0 && (candidate.rangeLength === void 0 || typeof candidate.rangeLength === "number");
  }
  static isFull(event) {
    const candidate = event;
    return candidate !== void 0 && candidate !== null && typeof candidate.text === "string" && candidate.range === void 0 && candidate.rangeLength === void 0;
  }
};
var TextDocument;
(function(TextDocument2) {
  function create(uri, languageId, version2, content) {
    return new FullTextDocument(uri, languageId, version2, content);
  }
  TextDocument2.create = create;
  function update(document, changes, version2) {
    if (document instanceof FullTextDocument) {
      document.update(changes, version2);
      return document;
    } else {
      throw new Error("TextDocument.update: document must be created by TextDocument.create");
    }
  }
  TextDocument2.update = update;
  function applyEdits(document, edits) {
    const text = document.getText();
    const sortedEdits = mergeSort(edits.map(getWellformedEdit), (a, b) => {
      const diff = a.range.start.line - b.range.start.line;
      if (diff === 0) {
        return a.range.start.character - b.range.start.character;
      }
      return diff;
    });
    let lastModifiedOffset = 0;
    const spans = [];
    for (const e of sortedEdits) {
      const startOffset = document.offsetAt(e.range.start);
      if (startOffset < lastModifiedOffset) {
        throw new Error("Overlapping edit");
      } else if (startOffset > lastModifiedOffset) {
        spans.push(text.substring(lastModifiedOffset, startOffset));
      }
      if (e.newText.length) {
        spans.push(e.newText);
      }
      lastModifiedOffset = document.offsetAt(e.range.end);
    }
    spans.push(text.substr(lastModifiedOffset));
    return spans.join("");
  }
  TextDocument2.applyEdits = applyEdits;
})(TextDocument || (TextDocument = {}));
function mergeSort(data, compare) {
  if (data.length <= 1) {
    return data;
  }
  const p = data.length / 2 | 0;
  const left = data.slice(0, p);
  const right = data.slice(p);
  mergeSort(left, compare);
  mergeSort(right, compare);
  let leftIdx = 0;
  let rightIdx = 0;
  let i = 0;
  while (leftIdx < left.length && rightIdx < right.length) {
    const ret = compare(left[leftIdx], right[rightIdx]);
    if (ret <= 0) {
      data[i++] = left[leftIdx++];
    } else {
      data[i++] = right[rightIdx++];
    }
  }
  while (leftIdx < left.length) {
    data[i++] = left[leftIdx++];
  }
  while (rightIdx < right.length) {
    data[i++] = right[rightIdx++];
  }
  return data;
}
function computeLineOffsets(text, isAtLineStart, textOffset = 0) {
  const result = isAtLineStart ? [textOffset] : [];
  for (let i = 0; i < text.length; i++) {
    const ch = text.charCodeAt(i);
    if (isEOL(ch)) {
      if (ch === 13 && i + 1 < text.length && text.charCodeAt(i + 1) === 10) {
        i++;
      }
      result.push(textOffset + i + 1);
    }
  }
  return result;
}
function isEOL(char) {
  return char === 13 || char === 10;
}
function getWellformedRange(range2) {
  const start = range2.start;
  const end = range2.end;
  if (start.line > end.line || start.line === end.line && start.character > end.character) {
    return {
      start: end,
      end: start
    };
  }
  return range2;
}
function getWellformedEdit(textEdit) {
  const range2 = getWellformedRange(textEdit.range);
  if (range2 !== textEdit.range) {
    return {
      newText: textEdit.newText,
      range: range2
    };
  }
  return textEdit;
}
var typescript = "typescript";
var typescriptreact = "typescriptreact";
var javascript = "javascript";
var javascriptreact = "javascriptreact";
var jsTsLanguageModes = [javascript, javascriptreact, typescript, typescriptreact];
function isTypeScriptDocument(doc) {
  return [typescript, typescriptreact].includes(doc.languageId);
}
var mainExports = requireMain$1();
var TypeScriptRenameRequest;
(function(TypeScriptRenameRequest2) {
  TypeScriptRenameRequest2.type = new mainExports.RequestType("_typescript.rename");
})(TypeScriptRenameRequest || (TypeScriptRenameRequest = {}));
var CommandTypes;
(function(CommandTypes2) {
  CommandTypes2["JsxClosingTag"] = "jsxClosingTag";
  CommandTypes2["LinkedEditingRange"] = "linkedEditingRange";
  CommandTypes2["Brace"] = "brace";
  CommandTypes2["BraceCompletion"] = "braceCompletion";
  CommandTypes2["GetSpanOfEnclosingComment"] = "getSpanOfEnclosingComment";
  CommandTypes2["Change"] = "change";
  CommandTypes2["Close"] = "close";
  CommandTypes2["Completions"] = "completions";
  CommandTypes2["CompletionInfo"] = "completionInfo";
  CommandTypes2["CompletionDetails"] = "completionEntryDetails";
  CommandTypes2["CompileOnSaveAffectedFileList"] = "compileOnSaveAffectedFileList";
  CommandTypes2["CompileOnSaveEmitFile"] = "compileOnSaveEmitFile";
  CommandTypes2["Configure"] = "configure";
  CommandTypes2["Definition"] = "definition";
  CommandTypes2["DefinitionAndBoundSpan"] = "definitionAndBoundSpan";
  CommandTypes2["EncodedSemanticClassificationsFull"] = "encodedSemanticClassifications-full";
  CommandTypes2["Implementation"] = "implementation";
  CommandTypes2["Exit"] = "exit";
  CommandTypes2["FileReferences"] = "fileReferences";
  CommandTypes2["Format"] = "format";
  CommandTypes2["Formatonkey"] = "formatonkey";
  CommandTypes2["Geterr"] = "geterr";
  CommandTypes2["GeterrForProject"] = "geterrForProject";
  CommandTypes2["SemanticDiagnosticsSync"] = "semanticDiagnosticsSync";
  CommandTypes2["SyntacticDiagnosticsSync"] = "syntacticDiagnosticsSync";
  CommandTypes2["SuggestionDiagnosticsSync"] = "suggestionDiagnosticsSync";
  CommandTypes2["NavBar"] = "navbar";
  CommandTypes2["Navto"] = "navto";
  CommandTypes2["NavTree"] = "navtree";
  CommandTypes2["NavTreeFull"] = "navtree-full";
  CommandTypes2["Occurrences"] = "occurrences";
  CommandTypes2["DocumentHighlights"] = "documentHighlights";
  CommandTypes2["Open"] = "open";
  CommandTypes2["Quickinfo"] = "quickinfo";
  CommandTypes2["References"] = "references";
  CommandTypes2["Reload"] = "reload";
  CommandTypes2["Rename"] = "rename";
  CommandTypes2["Saveto"] = "saveto";
  CommandTypes2["SignatureHelp"] = "signatureHelp";
  CommandTypes2["FindSourceDefinition"] = "findSourceDefinition";
  CommandTypes2["Status"] = "status";
  CommandTypes2["TypeDefinition"] = "typeDefinition";
  CommandTypes2["ProjectInfo"] = "projectInfo";
  CommandTypes2["ReloadProjects"] = "reloadProjects";
  CommandTypes2["Unknown"] = "unknown";
  CommandTypes2["OpenExternalProject"] = "openExternalProject";
  CommandTypes2["OpenExternalProjects"] = "openExternalProjects";
  CommandTypes2["CloseExternalProject"] = "closeExternalProject";
  CommandTypes2["UpdateOpen"] = "updateOpen";
  CommandTypes2["GetOutliningSpans"] = "getOutliningSpans";
  CommandTypes2["TodoComments"] = "todoComments";
  CommandTypes2["Indentation"] = "indentation";
  CommandTypes2["DocCommentTemplate"] = "docCommentTemplate";
  CommandTypes2["CompilerOptionsForInferredProjects"] = "compilerOptionsForInferredProjects";
  CommandTypes2["GetCodeFixes"] = "getCodeFixes";
  CommandTypes2["GetCombinedCodeFix"] = "getCombinedCodeFix";
  CommandTypes2["ApplyCodeActionCommand"] = "applyCodeActionCommand";
  CommandTypes2["GetSupportedCodeFixes"] = "getSupportedCodeFixes";
  CommandTypes2["GetApplicableRefactors"] = "getApplicableRefactors";
  CommandTypes2["GetEditsForRefactor"] = "getEditsForRefactor";
  CommandTypes2["OrganizeImports"] = "organizeImports";
  CommandTypes2["GetEditsForFileRename"] = "getEditsForFileRename";
  CommandTypes2["ConfigurePlugin"] = "configurePlugin";
  CommandTypes2["SelectionRange"] = "selectionRange";
  CommandTypes2["ToggleLineComment"] = "toggleLineComment";
  CommandTypes2["ToggleMultilineComment"] = "toggleMultilineComment";
  CommandTypes2["CommentSelection"] = "commentSelection";
  CommandTypes2["UncommentSelection"] = "uncommentSelection";
  CommandTypes2["PrepareCallHierarchy"] = "prepareCallHierarchy";
  CommandTypes2["ProvideCallHierarchyIncomingCalls"] = "provideCallHierarchyIncomingCalls";
  CommandTypes2["ProvideCallHierarchyOutgoingCalls"] = "provideCallHierarchyOutgoingCalls";
  CommandTypes2["ProvideInlayHints"] = "provideInlayHints";
  CommandTypes2["WatchChange"] = "watchChange";
})(CommandTypes || (CommandTypes = {}));
var HighlightSpanKind;
(function(HighlightSpanKind2) {
  HighlightSpanKind2["none"] = "none";
  HighlightSpanKind2["definition"] = "definition";
  HighlightSpanKind2["reference"] = "reference";
  HighlightSpanKind2["writtenReference"] = "writtenReference";
})(HighlightSpanKind || (HighlightSpanKind = {}));
var JsxEmit;
(function(JsxEmit2) {
  JsxEmit2["None"] = "none";
  JsxEmit2["Preserve"] = "preserve";
  JsxEmit2["ReactNative"] = "react-native";
  JsxEmit2["React"] = "react";
  JsxEmit2["ReactJSX"] = "react-jsx";
  JsxEmit2["ReactJSXDev"] = "react-jsxdev";
})(JsxEmit || (JsxEmit = {}));
var ModuleKind;
(function(ModuleKind2) {
  ModuleKind2["None"] = "none";
  ModuleKind2["CommonJS"] = "commonjs";
  ModuleKind2["AMD"] = "amd";
  ModuleKind2["UMD"] = "umd";
  ModuleKind2["System"] = "system";
  ModuleKind2["ES6"] = "es6";
  ModuleKind2["ES2015"] = "es2015";
  ModuleKind2["ES2020"] = "es2020";
  ModuleKind2["ES2022"] = "es2022";
  ModuleKind2["ESNext"] = "esnext";
  ModuleKind2["Node16"] = "node16";
  ModuleKind2["Node18"] = "node18";
  ModuleKind2["Node20"] = "node20";
  ModuleKind2["NodeNext"] = "nodenext";
  ModuleKind2["Preserve"] = "preserve";
})(ModuleKind || (ModuleKind = {}));
var ModuleResolutionKind;
(function(ModuleResolutionKind2) {
  ModuleResolutionKind2["Classic"] = "classic";
  ModuleResolutionKind2["Node"] = "node";
  ModuleResolutionKind2["NodeJs"] = "node";
  ModuleResolutionKind2["Node10"] = "node10";
  ModuleResolutionKind2["Node16"] = "node16";
  ModuleResolutionKind2["NodeNext"] = "nodenext";
  ModuleResolutionKind2["Bundler"] = "bundler";
})(ModuleResolutionKind || (ModuleResolutionKind = {}));
var SemicolonPreference;
(function(SemicolonPreference2) {
  SemicolonPreference2["Ignore"] = "ignore";
  SemicolonPreference2["Insert"] = "insert";
  SemicolonPreference2["Remove"] = "remove";
})(SemicolonPreference || (SemicolonPreference = {}));
var ScriptElementKind;
(function(ScriptElementKind2) {
  ScriptElementKind2["unknown"] = "";
  ScriptElementKind2["warning"] = "warning";
  ScriptElementKind2["keyword"] = "keyword";
  ScriptElementKind2["scriptElement"] = "script";
  ScriptElementKind2["moduleElement"] = "module";
  ScriptElementKind2["classElement"] = "class";
  ScriptElementKind2["localClassElement"] = "local class";
  ScriptElementKind2["interfaceElement"] = "interface";
  ScriptElementKind2["typeElement"] = "type";
  ScriptElementKind2["enumElement"] = "enum";
  ScriptElementKind2["enumMemberElement"] = "enum member";
  ScriptElementKind2["variableElement"] = "var";
  ScriptElementKind2["localVariableElement"] = "local var";
  ScriptElementKind2["variableUsingElement"] = "using";
  ScriptElementKind2["variableAwaitUsingElement"] = "await using";
  ScriptElementKind2["functionElement"] = "function";
  ScriptElementKind2["localFunctionElement"] = "local function";
  ScriptElementKind2["memberFunctionElement"] = "method";
  ScriptElementKind2["memberGetAccessorElement"] = "getter";
  ScriptElementKind2["memberSetAccessorElement"] = "setter";
  ScriptElementKind2["memberVariableElement"] = "property";
  ScriptElementKind2["memberAccessorVariableElement"] = "accessor";
  ScriptElementKind2["constructorImplementationElement"] = "constructor";
  ScriptElementKind2["callSignatureElement"] = "call";
  ScriptElementKind2["indexSignatureElement"] = "index";
  ScriptElementKind2["constructSignatureElement"] = "construct";
  ScriptElementKind2["parameterElement"] = "parameter";
  ScriptElementKind2["typeParameterElement"] = "type parameter";
  ScriptElementKind2["primitiveType"] = "primitive type";
  ScriptElementKind2["label"] = "label";
  ScriptElementKind2["alias"] = "alias";
  ScriptElementKind2["constElement"] = "const";
  ScriptElementKind2["letElement"] = "let";
  ScriptElementKind2["directory"] = "directory";
  ScriptElementKind2["externalModuleName"] = "external module name";
  ScriptElementKind2["jsxAttribute"] = "JSX attribute";
  ScriptElementKind2["string"] = "string";
  ScriptElementKind2["link"] = "link";
  ScriptElementKind2["linkName"] = "link name";
  ScriptElementKind2["linkText"] = "link text";
})(ScriptElementKind || (ScriptElementKind = {}));
var ScriptElementKindModifier;
(function(ScriptElementKindModifier2) {
  ScriptElementKindModifier2["none"] = "";
  ScriptElementKindModifier2["publicMemberModifier"] = "public";
  ScriptElementKindModifier2["privateMemberModifier"] = "private";
  ScriptElementKindModifier2["protectedMemberModifier"] = "protected";
  ScriptElementKindModifier2["exportedModifier"] = "export";
  ScriptElementKindModifier2["ambientModifier"] = "declare";
  ScriptElementKindModifier2["staticModifier"] = "static";
  ScriptElementKindModifier2["abstractModifier"] = "abstract";
  ScriptElementKindModifier2["optionalModifier"] = "optional";
  ScriptElementKindModifier2["deprecatedModifier"] = "deprecated";
  ScriptElementKindModifier2["dtsModifier"] = ".d.ts";
  ScriptElementKindModifier2["tsModifier"] = ".ts";
  ScriptElementKindModifier2["tsxModifier"] = ".tsx";
  ScriptElementKindModifier2["jsModifier"] = ".js";
  ScriptElementKindModifier2["jsxModifier"] = ".jsx";
  ScriptElementKindModifier2["jsonModifier"] = ".json";
  ScriptElementKindModifier2["dmtsModifier"] = ".d.mts";
  ScriptElementKindModifier2["mtsModifier"] = ".mts";
  ScriptElementKindModifier2["mjsModifier"] = ".mjs";
  ScriptElementKindModifier2["dctsModifier"] = ".d.cts";
  ScriptElementKindModifier2["ctsModifier"] = ".cts";
  ScriptElementKindModifier2["cjsModifier"] = ".cjs";
})(ScriptElementKindModifier || (ScriptElementKindModifier = {}));
var ScriptTarget;
(function(ScriptTarget2) {
  ScriptTarget2["ES3"] = "es3";
  ScriptTarget2["ES5"] = "es5";
  ScriptTarget2["ES6"] = "es6";
  ScriptTarget2["ES2015"] = "es2015";
  ScriptTarget2["ES2016"] = "es2016";
  ScriptTarget2["ES2017"] = "es2017";
  ScriptTarget2["ES2018"] = "es2018";
  ScriptTarget2["ES2019"] = "es2019";
  ScriptTarget2["ES2020"] = "es2020";
  ScriptTarget2["ES2021"] = "es2021";
  ScriptTarget2["ES2022"] = "es2022";
  ScriptTarget2["ES2023"] = "es2023";
  ScriptTarget2["ES2024"] = "es2024";
  ScriptTarget2["ESNext"] = "esnext";
  ScriptTarget2["JSON"] = "json";
  ScriptTarget2["Latest"] = "esnext";
})(ScriptTarget || (ScriptTarget = {}));
var SymbolDisplayPartKind;
(function(SymbolDisplayPartKind2) {
  SymbolDisplayPartKind2[SymbolDisplayPartKind2["aliasName"] = 0] = "aliasName";
  SymbolDisplayPartKind2[SymbolDisplayPartKind2["className"] = 1] = "className";
  SymbolDisplayPartKind2[SymbolDisplayPartKind2["enumName"] = 2] = "enumName";
  SymbolDisplayPartKind2[SymbolDisplayPartKind2["fieldName"] = 3] = "fieldName";
  SymbolDisplayPartKind2[SymbolDisplayPartKind2["interfaceName"] = 4] = "interfaceName";
  SymbolDisplayPartKind2[SymbolDisplayPartKind2["keyword"] = 5] = "keyword";
  SymbolDisplayPartKind2[SymbolDisplayPartKind2["lineBreak"] = 6] = "lineBreak";
  SymbolDisplayPartKind2[SymbolDisplayPartKind2["numericLiteral"] = 7] = "numericLiteral";
  SymbolDisplayPartKind2[SymbolDisplayPartKind2["stringLiteral"] = 8] = "stringLiteral";
  SymbolDisplayPartKind2[SymbolDisplayPartKind2["localName"] = 9] = "localName";
  SymbolDisplayPartKind2[SymbolDisplayPartKind2["methodName"] = 10] = "methodName";
  SymbolDisplayPartKind2[SymbolDisplayPartKind2["moduleName"] = 11] = "moduleName";
  SymbolDisplayPartKind2[SymbolDisplayPartKind2["operator"] = 12] = "operator";
  SymbolDisplayPartKind2[SymbolDisplayPartKind2["parameterName"] = 13] = "parameterName";
  SymbolDisplayPartKind2[SymbolDisplayPartKind2["propertyName"] = 14] = "propertyName";
  SymbolDisplayPartKind2[SymbolDisplayPartKind2["punctuation"] = 15] = "punctuation";
  SymbolDisplayPartKind2[SymbolDisplayPartKind2["space"] = 16] = "space";
  SymbolDisplayPartKind2[SymbolDisplayPartKind2["text"] = 17] = "text";
  SymbolDisplayPartKind2[SymbolDisplayPartKind2["typeParameterName"] = 18] = "typeParameterName";
  SymbolDisplayPartKind2[SymbolDisplayPartKind2["enumMemberName"] = 19] = "enumMemberName";
  SymbolDisplayPartKind2[SymbolDisplayPartKind2["functionName"] = 20] = "functionName";
  SymbolDisplayPartKind2[SymbolDisplayPartKind2["regularExpressionLiteral"] = 21] = "regularExpressionLiteral";
  SymbolDisplayPartKind2[SymbolDisplayPartKind2["link"] = 22] = "link";
  SymbolDisplayPartKind2[SymbolDisplayPartKind2["linkName"] = 23] = "linkName";
  SymbolDisplayPartKind2[SymbolDisplayPartKind2["linkText"] = 24] = "linkText";
})(SymbolDisplayPartKind || (SymbolDisplayPartKind = {}));
var OrganizeImportsMode;
(function(OrganizeImportsMode2) {
  OrganizeImportsMode2["All"] = "All";
  OrganizeImportsMode2["SortAndCombine"] = "SortAndCombine";
  OrganizeImportsMode2["RemoveUnused"] = "RemoveUnused";
})(OrganizeImportsMode || (OrganizeImportsMode = {}));
var EventName;
(function(EventName2) {
  EventName2["syntaxDiag"] = "syntaxDiag";
  EventName2["semanticDiag"] = "semanticDiag";
  EventName2["suggestionDiag"] = "suggestionDiag";
  EventName2["configFileDiag"] = "configFileDiag";
  EventName2["telemetry"] = "telemetry";
  EventName2["projectLanguageServiceState"] = "projectLanguageServiceState";
  EventName2["projectsUpdatedInBackground"] = "projectsUpdatedInBackground";
  EventName2["beginInstallTypes"] = "beginInstallTypes";
  EventName2["endInstallTypes"] = "endInstallTypes";
  EventName2["typesInstallerInitializationFailed"] = "typesInstallerInitializationFailed";
  EventName2["surveyReady"] = "surveyReady";
  EventName2["projectLoadingStart"] = "projectLoadingStart";
  EventName2["projectLoadingFinish"] = "projectLoadingFinish";
  EventName2["createFileWatcher"] = "createFileWatcher";
  EventName2["createDirectoryWatcher"] = "createDirectoryWatcher";
  EventName2["closeFileWatcher"] = "closeFileWatcher";
})(EventName || (EventName = {}));
var KindModifiers = class _KindModifiers {
  static optional = "optional";
  static deprecated = "deprecated";
  static color = "color";
  static dtsFile = ".d.ts";
  static tsFile = ".ts";
  static tsxFile = ".tsx";
  static jsFile = ".js";
  static jsxFile = ".jsx";
  static jsonFile = ".json";
  static fileExtensionKindModifiers = [_KindModifiers.dtsFile, _KindModifiers.tsFile, _KindModifiers.tsxFile, _KindModifiers.jsFile, _KindModifiers.jsxFile, _KindModifiers.jsonFile];
};
var SYMBOL_DISPLAY_PART_KIND_MAP = {
  aliasName: 0,
  className: 1,
  enumName: 2,
  fieldName: 3,
  interfaceName: 4,
  keyword: 5,
  lineBreak: 6,
  numericLiteral: 7,
  stringLiteral: 8,
  localName: 9,
  methodName: 10,
  moduleName: 11,
  operator: 12,
  parameterName: 13,
  propertyName: 14,
  punctuation: 15,
  space: 16,
  text: 17,
  typeParameterName: 18,
  enumMemberName: 19,
  functionName: 20,
  regularExpressionLiteral: 21,
  link: 22,
  linkName: 23,
  linkText: 24
};
function toSymbolDisplayPartKind(kind) {
  return SYMBOL_DISPLAY_PART_KIND_MAP[kind];
}
var ServerType;
(function(ServerType2) {
  ServerType2["Syntax"] = "syntax";
  ServerType2["Semantic"] = "semantic";
})(ServerType || (ServerType = {}));
var ServerResponse;
(function(ServerResponse2) {
  class Cancelled {
    reason;
    type = "cancelled";
    constructor(reason) {
      this.reason = reason;
    }
  }
  ServerResponse2.Cancelled = Cancelled;
  ServerResponse2.NoContent = {
    type: "noContent"
  };
  ServerResponse2.NoServer = {
    type: "noServer"
  };
})(ServerResponse || (ServerResponse = {}));
var ClientCapability;
(function(ClientCapability2) {
  ClientCapability2[ClientCapability2["Syntax"] = 0] = "Syntax";
  ClientCapability2[ClientCapability2["EnhancedSyntax"] = 1] = "EnhancedSyntax";
  ClientCapability2[ClientCapability2["Semantic"] = 2] = "Semantic";
})(ClientCapability || (ClientCapability = {}));
var ClientCapabilities = class {
  capabilities;
  constructor(...capabilities) {
    this.capabilities = new Set(capabilities);
  }
  has(capability) {
    return this.capabilities.has(capability);
  }
};
var re = {
  exports: {}
};
var constants;
var hasRequiredConstants;
function requireConstants() {
  if (hasRequiredConstants) return constants;
  hasRequiredConstants = 1;
  const SEMVER_SPEC_VERSION = "2.0.0";
  const MAX_LENGTH = 256;
  const MAX_SAFE_INTEGER = Number.MAX_SAFE_INTEGER || 9007199254740991;
  const MAX_SAFE_COMPONENT_LENGTH = 16;
  const MAX_SAFE_BUILD_LENGTH = MAX_LENGTH - 6;
  const RELEASE_TYPES = ["major", "premajor", "minor", "preminor", "patch", "prepatch", "prerelease"];
  constants = {
    MAX_LENGTH,
    MAX_SAFE_COMPONENT_LENGTH,
    MAX_SAFE_BUILD_LENGTH,
    MAX_SAFE_INTEGER,
    RELEASE_TYPES,
    SEMVER_SPEC_VERSION,
    FLAG_INCLUDE_PRERELEASE: 1,
    FLAG_LOOSE: 2
  };
  return constants;
}
var debug_1;
var hasRequiredDebug;
function requireDebug() {
  if (hasRequiredDebug) return debug_1;
  hasRequiredDebug = 1;
  const debug = typeof process === "object" && process.env && process.env.NODE_DEBUG && /\bsemver\b/i.test(process.env.NODE_DEBUG) ? (...args) => console.error("SEMVER", ...args) : () => {
  };
  debug_1 = debug;
  return debug_1;
}
var hasRequiredRe;
function requireRe() {
  if (hasRequiredRe) return re.exports;
  hasRequiredRe = 1;
  (function(module, exports) {
    const { MAX_SAFE_COMPONENT_LENGTH, MAX_SAFE_BUILD_LENGTH, MAX_LENGTH } = requireConstants();
    const debug = requireDebug();
    exports = module.exports = {};
    const re2 = exports.re = [];
    const safeRe = exports.safeRe = [];
    const src = exports.src = [];
    const safeSrc = exports.safeSrc = [];
    const t = exports.t = {};
    let R = 0;
    const LETTERDASHNUMBER = "[a-zA-Z0-9-]";
    const safeRegexReplacements = [["\\s", 1], ["\\d", MAX_LENGTH], [LETTERDASHNUMBER, MAX_SAFE_BUILD_LENGTH]];
    const makeSafeRegex = (value) => {
      for (const [token, max] of safeRegexReplacements) {
        value = value.split(`${token}*`).join(`${token}{0,${max}}`).split(`${token}+`).join(`${token}{1,${max}}`);
      }
      return value;
    };
    const createToken = (name, value, isGlobal) => {
      const safe = makeSafeRegex(value);
      const index = R++;
      debug(name, index, value);
      t[name] = index;
      src[index] = value;
      safeSrc[index] = safe;
      re2[index] = new RegExp(value, isGlobal ? "g" : void 0);
      safeRe[index] = new RegExp(safe, isGlobal ? "g" : void 0);
    };
    createToken("NUMERICIDENTIFIER", "0|[1-9]\\d*");
    createToken("NUMERICIDENTIFIERLOOSE", "\\d+");
    createToken("NONNUMERICIDENTIFIER", `\\d*[a-zA-Z-]${LETTERDASHNUMBER}*`);
    createToken("MAINVERSION", `(${src[t.NUMERICIDENTIFIER]})\\.(${src[t.NUMERICIDENTIFIER]})\\.(${src[t.NUMERICIDENTIFIER]})`);
    createToken("MAINVERSIONLOOSE", `(${src[t.NUMERICIDENTIFIERLOOSE]})\\.(${src[t.NUMERICIDENTIFIERLOOSE]})\\.(${src[t.NUMERICIDENTIFIERLOOSE]})`);
    createToken("PRERELEASEIDENTIFIER", `(?:${src[t.NONNUMERICIDENTIFIER]}|${src[t.NUMERICIDENTIFIER]})`);
    createToken("PRERELEASEIDENTIFIERLOOSE", `(?:${src[t.NONNUMERICIDENTIFIER]}|${src[t.NUMERICIDENTIFIERLOOSE]})`);
    createToken("PRERELEASE", `(?:-(${src[t.PRERELEASEIDENTIFIER]}(?:\\.${src[t.PRERELEASEIDENTIFIER]})*))`);
    createToken("PRERELEASELOOSE", `(?:-?(${src[t.PRERELEASEIDENTIFIERLOOSE]}(?:\\.${src[t.PRERELEASEIDENTIFIERLOOSE]})*))`);
    createToken("BUILDIDENTIFIER", `${LETTERDASHNUMBER}+`);
    createToken("BUILD", `(?:\\+(${src[t.BUILDIDENTIFIER]}(?:\\.${src[t.BUILDIDENTIFIER]})*))`);
    createToken("FULLPLAIN", `v?${src[t.MAINVERSION]}${src[t.PRERELEASE]}?${src[t.BUILD]}?`);
    createToken("FULL", `^${src[t.FULLPLAIN]}$`);
    createToken("LOOSEPLAIN", `[v=\\s]*${src[t.MAINVERSIONLOOSE]}${src[t.PRERELEASELOOSE]}?${src[t.BUILD]}?`);
    createToken("LOOSE", `^${src[t.LOOSEPLAIN]}$`);
    createToken("GTLT", "((?:<|>)?=?)");
    createToken("XRANGEIDENTIFIERLOOSE", `${src[t.NUMERICIDENTIFIERLOOSE]}|x|X|\\*`);
    createToken("XRANGEIDENTIFIER", `${src[t.NUMERICIDENTIFIER]}|x|X|\\*`);
    createToken("XRANGEPLAIN", `[v=\\s]*(${src[t.XRANGEIDENTIFIER]})(?:\\.(${src[t.XRANGEIDENTIFIER]})(?:\\.(${src[t.XRANGEIDENTIFIER]})(?:${src[t.PRERELEASE]})?${src[t.BUILD]}?)?)?`);
    createToken("XRANGEPLAINLOOSE", `[v=\\s]*(${src[t.XRANGEIDENTIFIERLOOSE]})(?:\\.(${src[t.XRANGEIDENTIFIERLOOSE]})(?:\\.(${src[t.XRANGEIDENTIFIERLOOSE]})(?:${src[t.PRERELEASELOOSE]})?${src[t.BUILD]}?)?)?`);
    createToken("XRANGE", `^${src[t.GTLT]}\\s*${src[t.XRANGEPLAIN]}$`);
    createToken("XRANGELOOSE", `^${src[t.GTLT]}\\s*${src[t.XRANGEPLAINLOOSE]}$`);
    createToken("COERCEPLAIN", `${"(^|[^\\d])(\\d{1,"}${MAX_SAFE_COMPONENT_LENGTH}})(?:\\.(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}}))?(?:\\.(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}}))?`);
    createToken("COERCE", `${src[t.COERCEPLAIN]}(?:$|[^\\d])`);
    createToken("COERCEFULL", src[t.COERCEPLAIN] + `(?:${src[t.PRERELEASE]})?(?:${src[t.BUILD]})?(?:$|[^\\d])`);
    createToken("COERCERTL", src[t.COERCE], true);
    createToken("COERCERTLFULL", src[t.COERCEFULL], true);
    createToken("LONETILDE", "(?:~>?)");
    createToken("TILDETRIM", `(\\s*)${src[t.LONETILDE]}\\s+`, true);
    exports.tildeTrimReplace = "$1~";
    createToken("TILDE", `^${src[t.LONETILDE]}${src[t.XRANGEPLAIN]}$`);
    createToken("TILDELOOSE", `^${src[t.LONETILDE]}${src[t.XRANGEPLAINLOOSE]}$`);
    createToken("LONECARET", "(?:\\^)");
    createToken("CARETTRIM", `(\\s*)${src[t.LONECARET]}\\s+`, true);
    exports.caretTrimReplace = "$1^";
    createToken("CARET", `^${src[t.LONECARET]}${src[t.XRANGEPLAIN]}$`);
    createToken("CARETLOOSE", `^${src[t.LONECARET]}${src[t.XRANGEPLAINLOOSE]}$`);
    createToken("COMPARATORLOOSE", `^${src[t.GTLT]}\\s*(${src[t.LOOSEPLAIN]})$|^$`);
    createToken("COMPARATOR", `^${src[t.GTLT]}\\s*(${src[t.FULLPLAIN]})$|^$`);
    createToken("COMPARATORTRIM", `(\\s*)${src[t.GTLT]}\\s*(${src[t.LOOSEPLAIN]}|${src[t.XRANGEPLAIN]})`, true);
    exports.comparatorTrimReplace = "$1$2$3";
    createToken("HYPHENRANGE", `^\\s*(${src[t.XRANGEPLAIN]})\\s+-\\s+(${src[t.XRANGEPLAIN]})\\s*$`);
    createToken("HYPHENRANGELOOSE", `^\\s*(${src[t.XRANGEPLAINLOOSE]})\\s+-\\s+(${src[t.XRANGEPLAINLOOSE]})\\s*$`);
    createToken("STAR", "(<|>)?=?\\s*\\*");
    createToken("GTE0", "^\\s*>=\\s*0\\.0\\.0\\s*$");
    createToken("GTE0PRE", "^\\s*>=\\s*0\\.0\\.0-0\\s*$");
  })(re, re.exports);
  return re.exports;
}
var parseOptions_1;
var hasRequiredParseOptions;
function requireParseOptions() {
  if (hasRequiredParseOptions) return parseOptions_1;
  hasRequiredParseOptions = 1;
  const looseOption = Object.freeze({
    loose: true
  });
  const emptyOpts = Object.freeze({});
  const parseOptions = (options2) => {
    if (!options2) {
      return emptyOpts;
    }
    if (typeof options2 !== "object") {
      return looseOption;
    }
    return options2;
  };
  parseOptions_1 = parseOptions;
  return parseOptions_1;
}
var identifiers;
var hasRequiredIdentifiers;
function requireIdentifiers() {
  if (hasRequiredIdentifiers) return identifiers;
  hasRequiredIdentifiers = 1;
  const numeric = /^[0-9]+$/;
  const compareIdentifiers = (a, b) => {
    if (typeof a === "number" && typeof b === "number") {
      return a === b ? 0 : a < b ? -1 : 1;
    }
    const anum = numeric.test(a);
    const bnum = numeric.test(b);
    if (anum && bnum) {
      a = +a;
      b = +b;
    }
    return a === b ? 0 : anum && !bnum ? -1 : bnum && !anum ? 1 : a < b ? -1 : 1;
  };
  const rcompareIdentifiers = (a, b) => compareIdentifiers(b, a);
  identifiers = {
    compareIdentifiers,
    rcompareIdentifiers
  };
  return identifiers;
}
var semver$2;
var hasRequiredSemver$1;
function requireSemver$1() {
  if (hasRequiredSemver$1) return semver$2;
  hasRequiredSemver$1 = 1;
  const debug = requireDebug();
  const { MAX_LENGTH, MAX_SAFE_INTEGER } = requireConstants();
  const { safeRe: re2, t } = requireRe();
  const parseOptions = requireParseOptions();
  const { compareIdentifiers } = requireIdentifiers();
  class SemVer {
    constructor(version2, options2) {
      options2 = parseOptions(options2);
      if (version2 instanceof SemVer) {
        if (version2.loose === !!options2.loose && version2.includePrerelease === !!options2.includePrerelease) {
          return version2;
        } else {
          version2 = version2.version;
        }
      } else if (typeof version2 !== "string") {
        throw new TypeError(`Invalid version. Must be a string. Got type "${typeof version2}".`);
      }
      if (version2.length > MAX_LENGTH) {
        throw new TypeError(`version is longer than ${MAX_LENGTH} characters`);
      }
      debug("SemVer", version2, options2);
      this.options = options2;
      this.loose = !!options2.loose;
      this.includePrerelease = !!options2.includePrerelease;
      const m = version2.trim().match(options2.loose ? re2[t.LOOSE] : re2[t.FULL]);
      if (!m) {
        throw new TypeError(`Invalid Version: ${version2}`);
      }
      this.raw = version2;
      this.major = +m[1];
      this.minor = +m[2];
      this.patch = +m[3];
      if (this.major > MAX_SAFE_INTEGER || this.major < 0) {
        throw new TypeError("Invalid major version");
      }
      if (this.minor > MAX_SAFE_INTEGER || this.minor < 0) {
        throw new TypeError("Invalid minor version");
      }
      if (this.patch > MAX_SAFE_INTEGER || this.patch < 0) {
        throw new TypeError("Invalid patch version");
      }
      if (!m[4]) {
        this.prerelease = [];
      } else {
        this.prerelease = m[4].split(".").map((id) => {
          if (/^[0-9]+$/.test(id)) {
            const num = +id;
            if (num >= 0 && num < MAX_SAFE_INTEGER) {
              return num;
            }
          }
          return id;
        });
      }
      this.build = m[5] ? m[5].split(".") : [];
      this.format();
    }
    format() {
      this.version = `${this.major}.${this.minor}.${this.patch}`;
      if (this.prerelease.length) {
        this.version += `-${this.prerelease.join(".")}`;
      }
      return this.version;
    }
    toString() {
      return this.version;
    }
    compare(other) {
      debug("SemVer.compare", this.version, this.options, other);
      if (!(other instanceof SemVer)) {
        if (typeof other === "string" && other === this.version) {
          return 0;
        }
        other = new SemVer(other, this.options);
      }
      if (other.version === this.version) {
        return 0;
      }
      return this.compareMain(other) || this.comparePre(other);
    }
    compareMain(other) {
      if (!(other instanceof SemVer)) {
        other = new SemVer(other, this.options);
      }
      if (this.major < other.major) {
        return -1;
      }
      if (this.major > other.major) {
        return 1;
      }
      if (this.minor < other.minor) {
        return -1;
      }
      if (this.minor > other.minor) {
        return 1;
      }
      if (this.patch < other.patch) {
        return -1;
      }
      if (this.patch > other.patch) {
        return 1;
      }
      return 0;
    }
    comparePre(other) {
      if (!(other instanceof SemVer)) {
        other = new SemVer(other, this.options);
      }
      if (this.prerelease.length && !other.prerelease.length) {
        return -1;
      } else if (!this.prerelease.length && other.prerelease.length) {
        return 1;
      } else if (!this.prerelease.length && !other.prerelease.length) {
        return 0;
      }
      let i = 0;
      do {
        const a = this.prerelease[i];
        const b = other.prerelease[i];
        debug("prerelease compare", i, a, b);
        if (a === void 0 && b === void 0) {
          return 0;
        } else if (b === void 0) {
          return 1;
        } else if (a === void 0) {
          return -1;
        } else if (a === b) {
          continue;
        } else {
          return compareIdentifiers(a, b);
        }
      } while (++i);
    }
    compareBuild(other) {
      if (!(other instanceof SemVer)) {
        other = new SemVer(other, this.options);
      }
      let i = 0;
      do {
        const a = this.build[i];
        const b = other.build[i];
        debug("build compare", i, a, b);
        if (a === void 0 && b === void 0) {
          return 0;
        } else if (b === void 0) {
          return 1;
        } else if (a === void 0) {
          return -1;
        } else if (a === b) {
          continue;
        } else {
          return compareIdentifiers(a, b);
        }
      } while (++i);
    }
    inc(release, identifier, identifierBase) {
      if (release.startsWith("pre")) {
        if (!identifier && identifierBase === false) {
          throw new Error("invalid increment argument: identifier is empty");
        }
        if (identifier) {
          const match = `-${identifier}`.match(this.options.loose ? re2[t.PRERELEASELOOSE] : re2[t.PRERELEASE]);
          if (!match || match[1] !== identifier) {
            throw new Error(`invalid identifier: ${identifier}`);
          }
        }
      }
      switch (release) {
        case "premajor":
          this.prerelease.length = 0;
          this.patch = 0;
          this.minor = 0;
          this.major++;
          this.inc("pre", identifier, identifierBase);
          break;
        case "preminor":
          this.prerelease.length = 0;
          this.patch = 0;
          this.minor++;
          this.inc("pre", identifier, identifierBase);
          break;
        case "prepatch":
          this.prerelease.length = 0;
          this.inc("patch", identifier, identifierBase);
          this.inc("pre", identifier, identifierBase);
          break;
        case "prerelease":
          if (this.prerelease.length === 0) {
            this.inc("patch", identifier, identifierBase);
          }
          this.inc("pre", identifier, identifierBase);
          break;
        case "release":
          if (this.prerelease.length === 0) {
            throw new Error(`version ${this.raw} is not a prerelease`);
          }
          this.prerelease.length = 0;
          break;
        case "major":
          if (this.minor !== 0 || this.patch !== 0 || this.prerelease.length === 0) {
            this.major++;
          }
          this.minor = 0;
          this.patch = 0;
          this.prerelease = [];
          break;
        case "minor":
          if (this.patch !== 0 || this.prerelease.length === 0) {
            this.minor++;
          }
          this.patch = 0;
          this.prerelease = [];
          break;
        case "patch":
          if (this.prerelease.length === 0) {
            this.patch++;
          }
          this.prerelease = [];
          break;
        case "pre": {
          const base = Number(identifierBase) ? 1 : 0;
          if (this.prerelease.length === 0) {
            this.prerelease = [base];
          } else {
            let i = this.prerelease.length;
            while (--i >= 0) {
              if (typeof this.prerelease[i] === "number") {
                this.prerelease[i]++;
                i = -2;
              }
            }
            if (i === -1) {
              if (identifier === this.prerelease.join(".") && identifierBase === false) {
                throw new Error("invalid increment argument: identifier already exists");
              }
              this.prerelease.push(base);
            }
          }
          if (identifier) {
            let prerelease = [identifier, base];
            if (identifierBase === false) {
              prerelease = [identifier];
            }
            if (compareIdentifiers(this.prerelease[0], identifier) === 0) {
              if (isNaN(this.prerelease[1])) {
                this.prerelease = prerelease;
              }
            } else {
              this.prerelease = prerelease;
            }
          }
          break;
        }
        default:
          throw new Error(`invalid increment argument: ${release}`);
      }
      this.raw = this.format();
      if (this.build.length) {
        this.raw += `+${this.build.join(".")}`;
      }
      return this;
    }
  }
  semver$2 = SemVer;
  return semver$2;
}
var parse_1;
var hasRequiredParse;
function requireParse() {
  if (hasRequiredParse) return parse_1;
  hasRequiredParse = 1;
  const SemVer = requireSemver$1();
  const parse = (version2, options2, throwErrors = false) => {
    if (version2 instanceof SemVer) {
      return version2;
    }
    try {
      return new SemVer(version2, options2);
    } catch (er) {
      if (!throwErrors) {
        return null;
      }
      throw er;
    }
  };
  parse_1 = parse;
  return parse_1;
}
var valid_1;
var hasRequiredValid$1;
function requireValid$1() {
  if (hasRequiredValid$1) return valid_1;
  hasRequiredValid$1 = 1;
  const parse = requireParse();
  const valid2 = (version2, options2) => {
    const v = parse(version2, options2);
    return v ? v.version : null;
  };
  valid_1 = valid2;
  return valid_1;
}
var clean_1;
var hasRequiredClean;
function requireClean() {
  if (hasRequiredClean) return clean_1;
  hasRequiredClean = 1;
  const parse = requireParse();
  const clean = (version2, options2) => {
    const s = parse(version2.trim().replace(/^[=v]+/, ""), options2);
    return s ? s.version : null;
  };
  clean_1 = clean;
  return clean_1;
}
var inc_1;
var hasRequiredInc;
function requireInc() {
  if (hasRequiredInc) return inc_1;
  hasRequiredInc = 1;
  const SemVer = requireSemver$1();
  const inc = (version2, release, options2, identifier, identifierBase) => {
    if (typeof options2 === "string") {
      identifierBase = identifier;
      identifier = options2;
      options2 = void 0;
    }
    try {
      return new SemVer(version2 instanceof SemVer ? version2.version : version2, options2).inc(release, identifier, identifierBase).version;
    } catch (er) {
      return null;
    }
  };
  inc_1 = inc;
  return inc_1;
}
var diff_1;
var hasRequiredDiff;
function requireDiff() {
  if (hasRequiredDiff) return diff_1;
  hasRequiredDiff = 1;
  const parse = requireParse();
  const diff = (version1, version2) => {
    const v1 = parse(version1, null, true);
    const v2 = parse(version2, null, true);
    const comparison = v1.compare(v2);
    if (comparison === 0) {
      return null;
    }
    const v1Higher = comparison > 0;
    const highVersion = v1Higher ? v1 : v2;
    const lowVersion = v1Higher ? v2 : v1;
    const highHasPre = !!highVersion.prerelease.length;
    const lowHasPre = !!lowVersion.prerelease.length;
    if (lowHasPre && !highHasPre) {
      if (!lowVersion.patch && !lowVersion.minor) {
        return "major";
      }
      if (lowVersion.compareMain(highVersion) === 0) {
        if (lowVersion.minor && !lowVersion.patch) {
          return "minor";
        }
        return "patch";
      }
    }
    const prefix = highHasPre ? "pre" : "";
    if (v1.major !== v2.major) {
      return prefix + "major";
    }
    if (v1.minor !== v2.minor) {
      return prefix + "minor";
    }
    if (v1.patch !== v2.patch) {
      return prefix + "patch";
    }
    return "prerelease";
  };
  diff_1 = diff;
  return diff_1;
}
var major_1;
var hasRequiredMajor;
function requireMajor() {
  if (hasRequiredMajor) return major_1;
  hasRequiredMajor = 1;
  const SemVer = requireSemver$1();
  const major = (a, loose) => new SemVer(a, loose).major;
  major_1 = major;
  return major_1;
}
var minor_1;
var hasRequiredMinor;
function requireMinor() {
  if (hasRequiredMinor) return minor_1;
  hasRequiredMinor = 1;
  const SemVer = requireSemver$1();
  const minor = (a, loose) => new SemVer(a, loose).minor;
  minor_1 = minor;
  return minor_1;
}
var patch_1;
var hasRequiredPatch;
function requirePatch() {
  if (hasRequiredPatch) return patch_1;
  hasRequiredPatch = 1;
  const SemVer = requireSemver$1();
  const patch = (a, loose) => new SemVer(a, loose).patch;
  patch_1 = patch;
  return patch_1;
}
var prerelease_1;
var hasRequiredPrerelease;
function requirePrerelease() {
  if (hasRequiredPrerelease) return prerelease_1;
  hasRequiredPrerelease = 1;
  const parse = requireParse();
  const prerelease = (version2, options2) => {
    const parsed = parse(version2, options2);
    return parsed && parsed.prerelease.length ? parsed.prerelease : null;
  };
  prerelease_1 = prerelease;
  return prerelease_1;
}
var compare_1;
var hasRequiredCompare;
function requireCompare() {
  if (hasRequiredCompare) return compare_1;
  hasRequiredCompare = 1;
  const SemVer = requireSemver$1();
  const compare = (a, b, loose) => new SemVer(a, loose).compare(new SemVer(b, loose));
  compare_1 = compare;
  return compare_1;
}
var rcompare_1;
var hasRequiredRcompare;
function requireRcompare() {
  if (hasRequiredRcompare) return rcompare_1;
  hasRequiredRcompare = 1;
  const compare = requireCompare();
  const rcompare = (a, b, loose) => compare(b, a, loose);
  rcompare_1 = rcompare;
  return rcompare_1;
}
var compareLoose_1;
var hasRequiredCompareLoose;
function requireCompareLoose() {
  if (hasRequiredCompareLoose) return compareLoose_1;
  hasRequiredCompareLoose = 1;
  const compare = requireCompare();
  const compareLoose = (a, b) => compare(a, b, true);
  compareLoose_1 = compareLoose;
  return compareLoose_1;
}
var compareBuild_1;
var hasRequiredCompareBuild;
function requireCompareBuild() {
  if (hasRequiredCompareBuild) return compareBuild_1;
  hasRequiredCompareBuild = 1;
  const SemVer = requireSemver$1();
  const compareBuild = (a, b, loose) => {
    const versionA = new SemVer(a, loose);
    const versionB = new SemVer(b, loose);
    return versionA.compare(versionB) || versionA.compareBuild(versionB);
  };
  compareBuild_1 = compareBuild;
  return compareBuild_1;
}
var sort_1;
var hasRequiredSort;
function requireSort() {
  if (hasRequiredSort) return sort_1;
  hasRequiredSort = 1;
  const compareBuild = requireCompareBuild();
  const sort = (list, loose) => list.sort((a, b) => compareBuild(a, b, loose));
  sort_1 = sort;
  return sort_1;
}
var rsort_1;
var hasRequiredRsort;
function requireRsort() {
  if (hasRequiredRsort) return rsort_1;
  hasRequiredRsort = 1;
  const compareBuild = requireCompareBuild();
  const rsort = (list, loose) => list.sort((a, b) => compareBuild(b, a, loose));
  rsort_1 = rsort;
  return rsort_1;
}
var gt_1;
var hasRequiredGt;
function requireGt() {
  if (hasRequiredGt) return gt_1;
  hasRequiredGt = 1;
  const compare = requireCompare();
  const gt = (a, b, loose) => compare(a, b, loose) > 0;
  gt_1 = gt;
  return gt_1;
}
var lt_1;
var hasRequiredLt;
function requireLt() {
  if (hasRequiredLt) return lt_1;
  hasRequiredLt = 1;
  const compare = requireCompare();
  const lt = (a, b, loose) => compare(a, b, loose) < 0;
  lt_1 = lt;
  return lt_1;
}
var eq_1;
var hasRequiredEq;
function requireEq() {
  if (hasRequiredEq) return eq_1;
  hasRequiredEq = 1;
  const compare = requireCompare();
  const eq = (a, b, loose) => compare(a, b, loose) === 0;
  eq_1 = eq;
  return eq_1;
}
var neq_1;
var hasRequiredNeq;
function requireNeq() {
  if (hasRequiredNeq) return neq_1;
  hasRequiredNeq = 1;
  const compare = requireCompare();
  const neq = (a, b, loose) => compare(a, b, loose) !== 0;
  neq_1 = neq;
  return neq_1;
}
var gte_1;
var hasRequiredGte;
function requireGte() {
  if (hasRequiredGte) return gte_1;
  hasRequiredGte = 1;
  const compare = requireCompare();
  const gte = (a, b, loose) => compare(a, b, loose) >= 0;
  gte_1 = gte;
  return gte_1;
}
var lte_1;
var hasRequiredLte;
function requireLte() {
  if (hasRequiredLte) return lte_1;
  hasRequiredLte = 1;
  const compare = requireCompare();
  const lte = (a, b, loose) => compare(a, b, loose) <= 0;
  lte_1 = lte;
  return lte_1;
}
var cmp_1;
var hasRequiredCmp;
function requireCmp() {
  if (hasRequiredCmp) return cmp_1;
  hasRequiredCmp = 1;
  const eq = requireEq();
  const neq = requireNeq();
  const gt = requireGt();
  const gte = requireGte();
  const lt = requireLt();
  const lte = requireLte();
  const cmp = (a, op, b, loose) => {
    switch (op) {
      case "===":
        if (typeof a === "object") {
          a = a.version;
        }
        if (typeof b === "object") {
          b = b.version;
        }
        return a === b;
      case "!==":
        if (typeof a === "object") {
          a = a.version;
        }
        if (typeof b === "object") {
          b = b.version;
        }
        return a !== b;
      case "":
      case "=":
      case "==":
        return eq(a, b, loose);
      case "!=":
        return neq(a, b, loose);
      case ">":
        return gt(a, b, loose);
      case ">=":
        return gte(a, b, loose);
      case "<":
        return lt(a, b, loose);
      case "<=":
        return lte(a, b, loose);
      default:
        throw new TypeError(`Invalid operator: ${op}`);
    }
  };
  cmp_1 = cmp;
  return cmp_1;
}
var coerce_1;
var hasRequiredCoerce;
function requireCoerce() {
  if (hasRequiredCoerce) return coerce_1;
  hasRequiredCoerce = 1;
  const SemVer = requireSemver$1();
  const parse = requireParse();
  const { safeRe: re2, t } = requireRe();
  const coerce = (version2, options2) => {
    if (version2 instanceof SemVer) {
      return version2;
    }
    if (typeof version2 === "number") {
      version2 = String(version2);
    }
    if (typeof version2 !== "string") {
      return null;
    }
    options2 = options2 || {};
    let match = null;
    if (!options2.rtl) {
      match = version2.match(options2.includePrerelease ? re2[t.COERCEFULL] : re2[t.COERCE]);
    } else {
      const coerceRtlRegex = options2.includePrerelease ? re2[t.COERCERTLFULL] : re2[t.COERCERTL];
      let next;
      while ((next = coerceRtlRegex.exec(version2)) && (!match || match.index + match[0].length !== version2.length)) {
        if (!match || next.index + next[0].length !== match.index + match[0].length) {
          match = next;
        }
        coerceRtlRegex.lastIndex = next.index + next[1].length + next[2].length;
      }
      coerceRtlRegex.lastIndex = -1;
    }
    if (match === null) {
      return null;
    }
    const major = match[2];
    const minor = match[3] || "0";
    const patch = match[4] || "0";
    const prerelease = options2.includePrerelease && match[5] ? `-${match[5]}` : "";
    const build = options2.includePrerelease && match[6] ? `+${match[6]}` : "";
    return parse(`${major}.${minor}.${patch}${prerelease}${build}`, options2);
  };
  coerce_1 = coerce;
  return coerce_1;
}
var truncate_1;
var hasRequiredTruncate;
function requireTruncate() {
  if (hasRequiredTruncate) return truncate_1;
  hasRequiredTruncate = 1;
  const parse = requireParse();
  const constants2 = requireConstants();
  const SemVer = requireSemver$1();
  const truncate = (version2, truncation, options2) => {
    if (!constants2.RELEASE_TYPES.includes(truncation)) {
      return null;
    }
    const clonedVersion = cloneInputVersion(version2, options2);
    return clonedVersion && doTruncation(clonedVersion, truncation);
  };
  const cloneInputVersion = (version2, options2) => {
    const versionStringToParse = version2 instanceof SemVer ? version2.version : version2;
    return parse(versionStringToParse, options2);
  };
  const doTruncation = (version2, truncation) => {
    if (isPrerelease(truncation)) {
      return version2.version;
    }
    version2.prerelease = [];
    switch (truncation) {
      case "major":
        version2.minor = 0;
        version2.patch = 0;
        break;
      case "minor":
        version2.patch = 0;
        break;
    }
    return version2.format();
  };
  const isPrerelease = (type) => type.startsWith("pre");
  truncate_1 = truncate;
  return truncate_1;
}
var lrucache;
var hasRequiredLrucache;
function requireLrucache() {
  if (hasRequiredLrucache) return lrucache;
  hasRequiredLrucache = 1;
  class LRUCache {
    constructor() {
      this.max = 1e3;
      this.map = /* @__PURE__ */ new Map();
    }
    get(key) {
      const value = this.map.get(key);
      if (value === void 0) {
        return void 0;
      } else {
        this.map.delete(key);
        this.map.set(key, value);
        return value;
      }
    }
    delete(key) {
      return this.map.delete(key);
    }
    set(key, value) {
      const deleted = this.delete(key);
      if (!deleted && value !== void 0) {
        if (this.map.size >= this.max) {
          const firstKey = this.map.keys().next().value;
          this.delete(firstKey);
        }
        this.map.set(key, value);
      }
      return this;
    }
  }
  lrucache = LRUCache;
  return lrucache;
}
var range;
var hasRequiredRange;
function requireRange() {
  if (hasRequiredRange) return range;
  hasRequiredRange = 1;
  const SPACE_CHARACTERS = /\s+/g;
  class Range2 {
    constructor(range2, options2) {
      options2 = parseOptions(options2);
      if (range2 instanceof Range2) {
        if (range2.loose === !!options2.loose && range2.includePrerelease === !!options2.includePrerelease) {
          return range2;
        } else {
          return new Range2(range2.raw, options2);
        }
      }
      if (range2 instanceof Comparator) {
        this.raw = range2.value;
        this.set = [[range2]];
        this.formatted = void 0;
        return this;
      }
      this.options = options2;
      this.loose = !!options2.loose;
      this.includePrerelease = !!options2.includePrerelease;
      this.raw = range2.trim().replace(SPACE_CHARACTERS, " ");
      this.set = this.raw.split("||").map((r) => this.parseRange(r.trim())).filter((c) => c.length);
      if (!this.set.length) {
        throw new TypeError(`Invalid SemVer Range: ${this.raw}`);
      }
      if (this.set.length > 1) {
        const first = this.set[0];
        this.set = this.set.filter((c) => !isNullSet(c[0]));
        if (this.set.length === 0) {
          this.set = [first];
        } else if (this.set.length > 1) {
          for (const c of this.set) {
            if (c.length === 1 && isAny(c[0])) {
              this.set = [c];
              break;
            }
          }
        }
      }
      this.formatted = void 0;
    }
    get range() {
      if (this.formatted === void 0) {
        this.formatted = "";
        for (let i = 0; i < this.set.length; i++) {
          if (i > 0) {
            this.formatted += "||";
          }
          const comps = this.set[i];
          for (let k = 0; k < comps.length; k++) {
            if (k > 0) {
              this.formatted += " ";
            }
            this.formatted += comps[k].toString().trim();
          }
        }
      }
      return this.formatted;
    }
    format() {
      return this.range;
    }
    toString() {
      return this.range;
    }
    parseRange(range2) {
      const memoOpts = (this.options.includePrerelease && FLAG_INCLUDE_PRERELEASE) | (this.options.loose && FLAG_LOOSE);
      const memoKey = memoOpts + ":" + range2;
      const cached = cache.get(memoKey);
      if (cached) {
        return cached;
      }
      const loose = this.options.loose;
      const hr = loose ? re2[t.HYPHENRANGELOOSE] : re2[t.HYPHENRANGE];
      range2 = range2.replace(hr, hyphenReplace(this.options.includePrerelease));
      debug("hyphen replace", range2);
      range2 = range2.replace(re2[t.COMPARATORTRIM], comparatorTrimReplace);
      debug("comparator trim", range2);
      range2 = range2.replace(re2[t.TILDETRIM], tildeTrimReplace);
      debug("tilde trim", range2);
      range2 = range2.replace(re2[t.CARETTRIM], caretTrimReplace);
      debug("caret trim", range2);
      let rangeList = range2.split(" ").map((comp) => parseComparator(comp, this.options)).join(" ").split(/\s+/).map((comp) => replaceGTE0(comp, this.options));
      if (loose) {
        rangeList = rangeList.filter((comp) => {
          debug("loose invalid filter", comp, this.options);
          return !!comp.match(re2[t.COMPARATORLOOSE]);
        });
      }
      debug("range list", rangeList);
      const rangeMap = /* @__PURE__ */ new Map();
      const comparators = rangeList.map((comp) => new Comparator(comp, this.options));
      for (const comp of comparators) {
        if (isNullSet(comp)) {
          return [comp];
        }
        rangeMap.set(comp.value, comp);
      }
      if (rangeMap.size > 1 && rangeMap.has("")) {
        rangeMap.delete("");
      }
      const result = [...rangeMap.values()];
      cache.set(memoKey, result);
      return result;
    }
    intersects(range2, options2) {
      if (!(range2 instanceof Range2)) {
        throw new TypeError("a Range is required");
      }
      return this.set.some((thisComparators) => isSatisfiable(thisComparators, options2) && range2.set.some((rangeComparators) => isSatisfiable(rangeComparators, options2) && thisComparators.every((thisComparator) => rangeComparators.every((rangeComparator) => thisComparator.intersects(rangeComparator, options2)))));
    }
    test(version2) {
      if (!version2) {
        return false;
      }
      if (typeof version2 === "string") {
        try {
          version2 = new SemVer(version2, this.options);
        } catch (er) {
          return false;
        }
      }
      for (let i = 0; i < this.set.length; i++) {
        if (testSet(this.set[i], version2, this.options)) {
          return true;
        }
      }
      return false;
    }
  }
  range = Range2;
  const LRU = requireLrucache();
  const cache = new LRU();
  const parseOptions = requireParseOptions();
  const Comparator = requireComparator();
  const debug = requireDebug();
  const SemVer = requireSemver$1();
  const { safeRe: re2, t, comparatorTrimReplace, tildeTrimReplace, caretTrimReplace } = requireRe();
  const { FLAG_INCLUDE_PRERELEASE, FLAG_LOOSE } = requireConstants();
  const isNullSet = (c) => c.value === "<0.0.0-0";
  const isAny = (c) => c.value === "";
  const isSatisfiable = (comparators, options2) => {
    let result = true;
    const remainingComparators = comparators.slice();
    let testComparator = remainingComparators.pop();
    while (result && remainingComparators.length) {
      result = remainingComparators.every((otherComparator) => testComparator.intersects(otherComparator, options2));
      testComparator = remainingComparators.pop();
    }
    return result;
  };
  const parseComparator = (comp, options2) => {
    comp = comp.replace(re2[t.BUILD], "");
    debug("comp", comp, options2);
    comp = replaceCarets(comp, options2);
    debug("caret", comp);
    comp = replaceTildes(comp, options2);
    debug("tildes", comp);
    comp = replaceXRanges(comp, options2);
    debug("xrange", comp);
    comp = replaceStars(comp, options2);
    debug("stars", comp);
    return comp;
  };
  const isX = (id) => !id || id.toLowerCase() === "x" || id === "*";
  const replaceTildes = (comp, options2) => comp.trim().split(/\s+/).map((c) => replaceTilde(c, options2)).join(" ");
  const replaceTilde = (comp, options2) => {
    const r = options2.loose ? re2[t.TILDELOOSE] : re2[t.TILDE];
    return comp.replace(r, (_, M, m, p, pr) => {
      debug("tilde", comp, _, M, m, p, pr);
      let ret;
      if (isX(M)) {
        ret = "";
      } else if (isX(m)) {
        ret = `>=${M}.0.0 <${+M + 1}.0.0-0`;
      } else if (isX(p)) {
        ret = `>=${M}.${m}.0 <${M}.${+m + 1}.0-0`;
      } else if (pr) {
        debug("replaceTilde pr", pr);
        ret = `>=${M}.${m}.${p}-${pr} <${M}.${+m + 1}.0-0`;
      } else {
        ret = `>=${M}.${m}.${p} <${M}.${+m + 1}.0-0`;
      }
      debug("tilde return", ret);
      return ret;
    });
  };
  const replaceCarets = (comp, options2) => comp.trim().split(/\s+/).map((c) => replaceCaret(c, options2)).join(" ");
  const replaceCaret = (comp, options2) => {
    debug("caret", comp, options2);
    const r = options2.loose ? re2[t.CARETLOOSE] : re2[t.CARET];
    const z = options2.includePrerelease ? "-0" : "";
    return comp.replace(r, (_, M, m, p, pr) => {
      debug("caret", comp, _, M, m, p, pr);
      let ret;
      if (isX(M)) {
        ret = "";
      } else if (isX(m)) {
        ret = `>=${M}.0.0${z} <${+M + 1}.0.0-0`;
      } else if (isX(p)) {
        if (M === "0") {
          ret = `>=${M}.${m}.0${z} <${M}.${+m + 1}.0-0`;
        } else {
          ret = `>=${M}.${m}.0${z} <${+M + 1}.0.0-0`;
        }
      } else if (pr) {
        debug("replaceCaret pr", pr);
        if (M === "0") {
          if (m === "0") {
            ret = `>=${M}.${m}.${p}-${pr} <${M}.${m}.${+p + 1}-0`;
          } else {
            ret = `>=${M}.${m}.${p}-${pr} <${M}.${+m + 1}.0-0`;
          }
        } else {
          ret = `>=${M}.${m}.${p}-${pr} <${+M + 1}.0.0-0`;
        }
      } else {
        debug("no pr");
        if (M === "0") {
          if (m === "0") {
            ret = `>=${M}.${m}.${p}${z} <${M}.${m}.${+p + 1}-0`;
          } else {
            ret = `>=${M}.${m}.${p}${z} <${M}.${+m + 1}.0-0`;
          }
        } else {
          ret = `>=${M}.${m}.${p} <${+M + 1}.0.0-0`;
        }
      }
      debug("caret return", ret);
      return ret;
    });
  };
  const replaceXRanges = (comp, options2) => {
    debug("replaceXRanges", comp, options2);
    return comp.split(/\s+/).map((c) => replaceXRange(c, options2)).join(" ");
  };
  const replaceXRange = (comp, options2) => {
    comp = comp.trim();
    const r = options2.loose ? re2[t.XRANGELOOSE] : re2[t.XRANGE];
    return comp.replace(r, (ret, gtlt, M, m, p, pr) => {
      debug("xRange", comp, ret, gtlt, M, m, p, pr);
      const xM = isX(M);
      const xm = xM || isX(m);
      const xp = xm || isX(p);
      const anyX = xp;
      if (gtlt === "=" && anyX) {
        gtlt = "";
      }
      pr = options2.includePrerelease ? "-0" : "";
      if (xM) {
        if (gtlt === ">" || gtlt === "<") {
          ret = "<0.0.0-0";
        } else {
          ret = "*";
        }
      } else if (gtlt && anyX) {
        if (xm) {
          m = 0;
        }
        p = 0;
        if (gtlt === ">") {
          gtlt = ">=";
          if (xm) {
            M = +M + 1;
            m = 0;
            p = 0;
          } else {
            m = +m + 1;
            p = 0;
          }
        } else if (gtlt === "<=") {
          gtlt = "<";
          if (xm) {
            M = +M + 1;
          } else {
            m = +m + 1;
          }
        }
        if (gtlt === "<") {
          pr = "-0";
        }
        ret = `${gtlt + M}.${m}.${p}${pr}`;
      } else if (xm) {
        ret = `>=${M}.0.0${pr} <${+M + 1}.0.0-0`;
      } else if (xp) {
        ret = `>=${M}.${m}.0${pr} <${M}.${+m + 1}.0-0`;
      }
      debug("xRange return", ret);
      return ret;
    });
  };
  const replaceStars = (comp, options2) => {
    debug("replaceStars", comp, options2);
    return comp.trim().replace(re2[t.STAR], "");
  };
  const replaceGTE0 = (comp, options2) => {
    debug("replaceGTE0", comp, options2);
    return comp.trim().replace(re2[options2.includePrerelease ? t.GTE0PRE : t.GTE0], "");
  };
  const hyphenReplace = (incPr) => ($0, from, fM, fm, fp, fpr, fb, to, tM, tm, tp, tpr) => {
    if (isX(fM)) {
      from = "";
    } else if (isX(fm)) {
      from = `>=${fM}.0.0${incPr ? "-0" : ""}`;
    } else if (isX(fp)) {
      from = `>=${fM}.${fm}.0${incPr ? "-0" : ""}`;
    } else if (fpr) {
      from = `>=${from}`;
    } else {
      from = `>=${from}${incPr ? "-0" : ""}`;
    }
    if (isX(tM)) {
      to = "";
    } else if (isX(tm)) {
      to = `<${+tM + 1}.0.0-0`;
    } else if (isX(tp)) {
      to = `<${tM}.${+tm + 1}.0-0`;
    } else if (tpr) {
      to = `<=${tM}.${tm}.${tp}-${tpr}`;
    } else if (incPr) {
      to = `<${tM}.${tm}.${+tp + 1}-0`;
    } else {
      to = `<=${to}`;
    }
    return `${from} ${to}`.trim();
  };
  const testSet = (set, version2, options2) => {
    for (let i = 0; i < set.length; i++) {
      if (!set[i].test(version2)) {
        return false;
      }
    }
    if (version2.prerelease.length && !options2.includePrerelease) {
      for (let i = 0; i < set.length; i++) {
        debug(set[i].semver);
        if (set[i].semver === Comparator.ANY) {
          continue;
        }
        if (set[i].semver.prerelease.length > 0) {
          const allowed = set[i].semver;
          if (allowed.major === version2.major && allowed.minor === version2.minor && allowed.patch === version2.patch) {
            return true;
          }
        }
      }
      return false;
    }
    return true;
  };
  return range;
}
var comparator;
var hasRequiredComparator;
function requireComparator() {
  if (hasRequiredComparator) return comparator;
  hasRequiredComparator = 1;
  const ANY = /* @__PURE__ */ Symbol("SemVer ANY");
  class Comparator {
    static get ANY() {
      return ANY;
    }
    constructor(comp, options2) {
      options2 = parseOptions(options2);
      if (comp instanceof Comparator) {
        if (comp.loose === !!options2.loose) {
          return comp;
        } else {
          comp = comp.value;
        }
      }
      comp = comp.trim().split(/\s+/).join(" ");
      debug("comparator", comp, options2);
      this.options = options2;
      this.loose = !!options2.loose;
      this.parse(comp);
      if (this.semver === ANY) {
        this.value = "";
      } else {
        this.value = this.operator + this.semver.version;
      }
      debug("comp", this);
    }
    parse(comp) {
      const r = this.options.loose ? re2[t.COMPARATORLOOSE] : re2[t.COMPARATOR];
      const m = comp.match(r);
      if (!m) {
        throw new TypeError(`Invalid comparator: ${comp}`);
      }
      this.operator = m[1] !== void 0 ? m[1] : "";
      if (this.operator === "=") {
        this.operator = "";
      }
      if (!m[2]) {
        this.semver = ANY;
      } else {
        this.semver = new SemVer(m[2], this.options.loose);
      }
    }
    toString() {
      return this.value;
    }
    test(version2) {
      debug("Comparator.test", version2, this.options.loose);
      if (this.semver === ANY || version2 === ANY) {
        return true;
      }
      if (typeof version2 === "string") {
        try {
          version2 = new SemVer(version2, this.options);
        } catch (er) {
          return false;
        }
      }
      return cmp(version2, this.operator, this.semver, this.options);
    }
    intersects(comp, options2) {
      if (!(comp instanceof Comparator)) {
        throw new TypeError("a Comparator is required");
      }
      if (this.operator === "") {
        if (this.value === "") {
          return true;
        }
        return new Range2(comp.value, options2).test(this.value);
      } else if (comp.operator === "") {
        if (comp.value === "") {
          return true;
        }
        return new Range2(this.value, options2).test(comp.semver);
      }
      options2 = parseOptions(options2);
      if (options2.includePrerelease && (this.value === "<0.0.0-0" || comp.value === "<0.0.0-0")) {
        return false;
      }
      if (!options2.includePrerelease && (this.value.startsWith("<0.0.0") || comp.value.startsWith("<0.0.0"))) {
        return false;
      }
      if (this.operator.startsWith(">") && comp.operator.startsWith(">")) {
        return true;
      }
      if (this.operator.startsWith("<") && comp.operator.startsWith("<")) {
        return true;
      }
      if (this.semver.version === comp.semver.version && this.operator.includes("=") && comp.operator.includes("=")) {
        return true;
      }
      if (cmp(this.semver, "<", comp.semver, options2) && this.operator.startsWith(">") && comp.operator.startsWith("<")) {
        return true;
      }
      if (cmp(this.semver, ">", comp.semver, options2) && this.operator.startsWith("<") && comp.operator.startsWith(">")) {
        return true;
      }
      return false;
    }
  }
  comparator = Comparator;
  const parseOptions = requireParseOptions();
  const { safeRe: re2, t } = requireRe();
  const cmp = requireCmp();
  const debug = requireDebug();
  const SemVer = requireSemver$1();
  const Range2 = requireRange();
  return comparator;
}
var satisfies_1;
var hasRequiredSatisfies;
function requireSatisfies() {
  if (hasRequiredSatisfies) return satisfies_1;
  hasRequiredSatisfies = 1;
  const Range2 = requireRange();
  const satisfies = (version2, range2, options2) => {
    try {
      range2 = new Range2(range2, options2);
    } catch (er) {
      return false;
    }
    return range2.test(version2);
  };
  satisfies_1 = satisfies;
  return satisfies_1;
}
var toComparators_1;
var hasRequiredToComparators;
function requireToComparators() {
  if (hasRequiredToComparators) return toComparators_1;
  hasRequiredToComparators = 1;
  const Range2 = requireRange();
  const toComparators = (range2, options2) => new Range2(range2, options2).set.map((comp) => comp.map((c) => c.value).join(" ").trim().split(" "));
  toComparators_1 = toComparators;
  return toComparators_1;
}
var maxSatisfying_1;
var hasRequiredMaxSatisfying;
function requireMaxSatisfying() {
  if (hasRequiredMaxSatisfying) return maxSatisfying_1;
  hasRequiredMaxSatisfying = 1;
  const SemVer = requireSemver$1();
  const Range2 = requireRange();
  const maxSatisfying = (versions, range2, options2) => {
    let max = null;
    let maxSV = null;
    let rangeObj = null;
    try {
      rangeObj = new Range2(range2, options2);
    } catch (er) {
      return null;
    }
    versions.forEach((v) => {
      if (rangeObj.test(v)) {
        if (!max || maxSV.compare(v) === -1) {
          max = v;
          maxSV = new SemVer(max, options2);
        }
      }
    });
    return max;
  };
  maxSatisfying_1 = maxSatisfying;
  return maxSatisfying_1;
}
var minSatisfying_1;
var hasRequiredMinSatisfying;
function requireMinSatisfying() {
  if (hasRequiredMinSatisfying) return minSatisfying_1;
  hasRequiredMinSatisfying = 1;
  const SemVer = requireSemver$1();
  const Range2 = requireRange();
  const minSatisfying = (versions, range2, options2) => {
    let min = null;
    let minSV = null;
    let rangeObj = null;
    try {
      rangeObj = new Range2(range2, options2);
    } catch (er) {
      return null;
    }
    versions.forEach((v) => {
      if (rangeObj.test(v)) {
        if (!min || minSV.compare(v) === 1) {
          min = v;
          minSV = new SemVer(min, options2);
        }
      }
    });
    return min;
  };
  minSatisfying_1 = minSatisfying;
  return minSatisfying_1;
}
var minVersion_1;
var hasRequiredMinVersion;
function requireMinVersion() {
  if (hasRequiredMinVersion) return minVersion_1;
  hasRequiredMinVersion = 1;
  const SemVer = requireSemver$1();
  const Range2 = requireRange();
  const gt = requireGt();
  const minVersion = (range2, loose) => {
    range2 = new Range2(range2, loose);
    let minver = new SemVer("0.0.0");
    if (range2.test(minver)) {
      return minver;
    }
    minver = new SemVer("0.0.0-0");
    if (range2.test(minver)) {
      return minver;
    }
    minver = null;
    for (let i = 0; i < range2.set.length; ++i) {
      const comparators = range2.set[i];
      let setMin = null;
      comparators.forEach((comparator2) => {
        const compver = new SemVer(comparator2.semver.version);
        switch (comparator2.operator) {
          case ">":
            if (compver.prerelease.length === 0) {
              compver.patch++;
            } else {
              compver.prerelease.push(0);
            }
            compver.raw = compver.format();
          case "":
          case ">=":
            if (!setMin || gt(compver, setMin)) {
              setMin = compver;
            }
            break;
          case "<":
          case "<=":
            break;
          default:
            throw new Error(`Unexpected operation: ${comparator2.operator}`);
        }
      });
      if (setMin && (!minver || gt(minver, setMin))) {
        minver = setMin;
      }
    }
    if (minver && range2.test(minver)) {
      return minver;
    }
    return null;
  };
  minVersion_1 = minVersion;
  return minVersion_1;
}
var valid;
var hasRequiredValid;
function requireValid() {
  if (hasRequiredValid) return valid;
  hasRequiredValid = 1;
  const Range2 = requireRange();
  const validRange = (range2, options2) => {
    try {
      return new Range2(range2, options2).range || "*";
    } catch (er) {
      return null;
    }
  };
  valid = validRange;
  return valid;
}
var outside_1;
var hasRequiredOutside;
function requireOutside() {
  if (hasRequiredOutside) return outside_1;
  hasRequiredOutside = 1;
  const SemVer = requireSemver$1();
  const Comparator = requireComparator();
  const { ANY } = Comparator;
  const Range2 = requireRange();
  const satisfies = requireSatisfies();
  const gt = requireGt();
  const lt = requireLt();
  const lte = requireLte();
  const gte = requireGte();
  const outside = (version2, range2, hilo, options2) => {
    version2 = new SemVer(version2, options2);
    range2 = new Range2(range2, options2);
    let gtfn, ltefn, ltfn, comp, ecomp;
    switch (hilo) {
      case ">":
        gtfn = gt;
        ltefn = lte;
        ltfn = lt;
        comp = ">";
        ecomp = ">=";
        break;
      case "<":
        gtfn = lt;
        ltefn = gte;
        ltfn = gt;
        comp = "<";
        ecomp = "<=";
        break;
      default:
        throw new TypeError('Must provide a hilo val of "<" or ">"');
    }
    if (satisfies(version2, range2, options2)) {
      return false;
    }
    for (let i = 0; i < range2.set.length; ++i) {
      const comparators = range2.set[i];
      let high = null;
      let low = null;
      comparators.forEach((comparator2) => {
        if (comparator2.semver === ANY) {
          comparator2 = new Comparator(">=0.0.0");
        }
        high = high || comparator2;
        low = low || comparator2;
        if (gtfn(comparator2.semver, high.semver, options2)) {
          high = comparator2;
        } else if (ltfn(comparator2.semver, low.semver, options2)) {
          low = comparator2;
        }
      });
      if (high.operator === comp || high.operator === ecomp) {
        return false;
      }
      if ((!low.operator || low.operator === comp) && ltefn(version2, low.semver)) {
        return false;
      } else if (low.operator === ecomp && ltfn(version2, low.semver)) {
        return false;
      }
    }
    return true;
  };
  outside_1 = outside;
  return outside_1;
}
var gtr_1;
var hasRequiredGtr;
function requireGtr() {
  if (hasRequiredGtr) return gtr_1;
  hasRequiredGtr = 1;
  const outside = requireOutside();
  const gtr = (version2, range2, options2) => outside(version2, range2, ">", options2);
  gtr_1 = gtr;
  return gtr_1;
}
var ltr_1;
var hasRequiredLtr;
function requireLtr() {
  if (hasRequiredLtr) return ltr_1;
  hasRequiredLtr = 1;
  const outside = requireOutside();
  const ltr = (version2, range2, options2) => outside(version2, range2, "<", options2);
  ltr_1 = ltr;
  return ltr_1;
}
var intersects_1;
var hasRequiredIntersects;
function requireIntersects() {
  if (hasRequiredIntersects) return intersects_1;
  hasRequiredIntersects = 1;
  const Range2 = requireRange();
  const intersects = (r1, r2, options2) => {
    r1 = new Range2(r1, options2);
    r2 = new Range2(r2, options2);
    return r1.intersects(r2, options2);
  };
  intersects_1 = intersects;
  return intersects_1;
}
var simplify;
var hasRequiredSimplify;
function requireSimplify() {
  if (hasRequiredSimplify) return simplify;
  hasRequiredSimplify = 1;
  const satisfies = requireSatisfies();
  const compare = requireCompare();
  simplify = (versions, range2, options2) => {
    const set = [];
    let first = null;
    let prev = null;
    const v = versions.sort((a, b) => compare(a, b, options2));
    for (const version2 of v) {
      const included = satisfies(version2, range2, options2);
      if (included) {
        prev = version2;
        if (!first) {
          first = version2;
        }
      } else {
        if (prev) {
          set.push([first, prev]);
        }
        prev = null;
        first = null;
      }
    }
    if (first) {
      set.push([first, null]);
    }
    const ranges = [];
    for (const [min, max] of set) {
      if (min === max) {
        ranges.push(min);
      } else if (!max && min === v[0]) {
        ranges.push("*");
      } else if (!max) {
        ranges.push(`>=${min}`);
      } else if (min === v[0]) {
        ranges.push(`<=${max}`);
      } else {
        ranges.push(`${min} - ${max}`);
      }
    }
    const simplified = ranges.join(" || ");
    const original = typeof range2.raw === "string" ? range2.raw : String(range2);
    return simplified.length < original.length ? simplified : range2;
  };
  return simplify;
}
var subset_1;
var hasRequiredSubset;
function requireSubset() {
  if (hasRequiredSubset) return subset_1;
  hasRequiredSubset = 1;
  const Range2 = requireRange();
  const Comparator = requireComparator();
  const { ANY } = Comparator;
  const satisfies = requireSatisfies();
  const compare = requireCompare();
  const subset = (sub, dom, options2 = {}) => {
    if (sub === dom) {
      return true;
    }
    sub = new Range2(sub, options2);
    dom = new Range2(dom, options2);
    let sawNonNull = false;
    OUTER: for (const simpleSub of sub.set) {
      for (const simpleDom of dom.set) {
        const isSub = simpleSubset(simpleSub, simpleDom, options2);
        sawNonNull = sawNonNull || isSub !== null;
        if (isSub) {
          continue OUTER;
        }
      }
      if (sawNonNull) {
        return false;
      }
    }
    return true;
  };
  const minimumVersionWithPreRelease = [new Comparator(">=0.0.0-0")];
  const minimumVersion = [new Comparator(">=0.0.0")];
  const simpleSubset = (sub, dom, options2) => {
    if (sub === dom) {
      return true;
    }
    if (sub.length === 1 && sub[0].semver === ANY) {
      if (dom.length === 1 && dom[0].semver === ANY) {
        return true;
      } else if (options2.includePrerelease) {
        sub = minimumVersionWithPreRelease;
      } else {
        sub = minimumVersion;
      }
    }
    if (dom.length === 1 && dom[0].semver === ANY) {
      if (options2.includePrerelease) {
        return true;
      } else {
        dom = minimumVersion;
      }
    }
    const eqSet = /* @__PURE__ */ new Set();
    let gt, lt;
    for (const c of sub) {
      if (c.operator === ">" || c.operator === ">=") {
        gt = higherGT(gt, c, options2);
      } else if (c.operator === "<" || c.operator === "<=") {
        lt = lowerLT(lt, c, options2);
      } else {
        eqSet.add(c.semver);
      }
    }
    if (eqSet.size > 1) {
      return null;
    }
    let gtltComp;
    if (gt && lt) {
      gtltComp = compare(gt.semver, lt.semver, options2);
      if (gtltComp > 0) {
        return null;
      } else if (gtltComp === 0 && (gt.operator !== ">=" || lt.operator !== "<=")) {
        return null;
      }
    }
    for (const eq of eqSet) {
      if (gt && !satisfies(eq, String(gt), options2)) {
        return null;
      }
      if (lt && !satisfies(eq, String(lt), options2)) {
        return null;
      }
      for (const c of dom) {
        if (!satisfies(eq, String(c), options2)) {
          return false;
        }
      }
      return true;
    }
    let higher, lower;
    let hasDomLT, hasDomGT;
    let needDomLTPre = lt && !options2.includePrerelease && lt.semver.prerelease.length ? lt.semver : false;
    let needDomGTPre = gt && !options2.includePrerelease && gt.semver.prerelease.length ? gt.semver : false;
    if (needDomLTPre && needDomLTPre.prerelease.length === 1 && lt.operator === "<" && needDomLTPre.prerelease[0] === 0) {
      needDomLTPre = false;
    }
    for (const c of dom) {
      hasDomGT = hasDomGT || c.operator === ">" || c.operator === ">=";
      hasDomLT = hasDomLT || c.operator === "<" || c.operator === "<=";
      if (gt) {
        if (needDomGTPre) {
          if (c.semver.prerelease && c.semver.prerelease.length && c.semver.major === needDomGTPre.major && c.semver.minor === needDomGTPre.minor && c.semver.patch === needDomGTPre.patch) {
            needDomGTPre = false;
          }
        }
        if (c.operator === ">" || c.operator === ">=") {
          higher = higherGT(gt, c, options2);
          if (higher === c && higher !== gt) {
            return false;
          }
        } else if (gt.operator === ">=" && !satisfies(gt.semver, String(c), options2)) {
          return false;
        }
      }
      if (lt) {
        if (needDomLTPre) {
          if (c.semver.prerelease && c.semver.prerelease.length && c.semver.major === needDomLTPre.major && c.semver.minor === needDomLTPre.minor && c.semver.patch === needDomLTPre.patch) {
            needDomLTPre = false;
          }
        }
        if (c.operator === "<" || c.operator === "<=") {
          lower = lowerLT(lt, c, options2);
          if (lower === c && lower !== lt) {
            return false;
          }
        } else if (lt.operator === "<=" && !satisfies(lt.semver, String(c), options2)) {
          return false;
        }
      }
      if (!c.operator && (lt || gt) && gtltComp !== 0) {
        return false;
      }
    }
    if (gt && hasDomLT && !lt && gtltComp !== 0) {
      return false;
    }
    if (lt && hasDomGT && !gt && gtltComp !== 0) {
      return false;
    }
    if (needDomGTPre || needDomLTPre) {
      return false;
    }
    return true;
  };
  const higherGT = (a, b, options2) => {
    if (!a) {
      return b;
    }
    const comp = compare(a.semver, b.semver, options2);
    return comp > 0 ? a : comp < 0 ? b : b.operator === ">" && a.operator === ">=" ? b : a;
  };
  const lowerLT = (a, b, options2) => {
    if (!a) {
      return b;
    }
    const comp = compare(a.semver, b.semver, options2);
    return comp < 0 ? a : comp > 0 ? b : b.operator === "<" && a.operator === "<=" ? b : a;
  };
  subset_1 = subset;
  return subset_1;
}
var semver$1;
var hasRequiredSemver;
function requireSemver() {
  if (hasRequiredSemver) return semver$1;
  hasRequiredSemver = 1;
  const internalRe = requireRe();
  const constants2 = requireConstants();
  const SemVer = requireSemver$1();
  const identifiers2 = requireIdentifiers();
  const parse = requireParse();
  const valid2 = requireValid$1();
  const clean = requireClean();
  const inc = requireInc();
  const diff = requireDiff();
  const major = requireMajor();
  const minor = requireMinor();
  const patch = requirePatch();
  const prerelease = requirePrerelease();
  const compare = requireCompare();
  const rcompare = requireRcompare();
  const compareLoose = requireCompareLoose();
  const compareBuild = requireCompareBuild();
  const sort = requireSort();
  const rsort = requireRsort();
  const gt = requireGt();
  const lt = requireLt();
  const eq = requireEq();
  const neq = requireNeq();
  const gte = requireGte();
  const lte = requireLte();
  const cmp = requireCmp();
  const coerce = requireCoerce();
  const truncate = requireTruncate();
  const Comparator = requireComparator();
  const Range2 = requireRange();
  const satisfies = requireSatisfies();
  const toComparators = requireToComparators();
  const maxSatisfying = requireMaxSatisfying();
  const minSatisfying = requireMinSatisfying();
  const minVersion = requireMinVersion();
  const validRange = requireValid();
  const outside = requireOutside();
  const gtr = requireGtr();
  const ltr = requireLtr();
  const intersects = requireIntersects();
  const simplifyRange = requireSimplify();
  const subset = requireSubset();
  semver$1 = {
    parse,
    valid: valid2,
    clean,
    inc,
    diff,
    major,
    minor,
    patch,
    prerelease,
    compare,
    rcompare,
    compareLoose,
    compareBuild,
    sort,
    rsort,
    gt,
    lt,
    eq,
    neq,
    gte,
    lte,
    cmp,
    coerce,
    truncate,
    Comparator,
    Range: Range2,
    satisfies,
    toComparators,
    maxSatisfying,
    minSatisfying,
    minVersion,
    validRange,
    outside,
    gtr,
    ltr,
    intersects,
    simplifyRange,
    subset,
    SemVer,
    re: internalRe.re,
    src: internalRe.src,
    tokens: internalRe.t,
    SEMVER_SPEC_VERSION: constants2.SEMVER_SPEC_VERSION,
    RELEASE_TYPES: constants2.RELEASE_TYPES,
    compareIdentifiers: identifiers2.compareIdentifiers,
    rcompareIdentifiers: identifiers2.rcompareIdentifiers
  };
  return semver$1;
}
var semverExports = requireSemver();
var semver = getDefaultExportFromCjs(semverExports);
var API = class _API {
  displayName;
  version;
  fullVersionString;
  static fromSimpleString(value) {
    return new _API(value, value, value);
  }
  static defaultVersion = _API.fromSimpleString("1.0.0");
  static v300 = _API.fromSimpleString("3.0.0");
  static v310 = _API.fromSimpleString("3.1.0");
  static v314 = _API.fromSimpleString("3.1.4");
  static v320 = _API.fromSimpleString("3.2.0");
  static v333 = _API.fromSimpleString("3.3.3");
  static v340 = _API.fromSimpleString("3.4.0");
  static v345 = _API.fromSimpleString("3.4.5");
  static v350 = _API.fromSimpleString("3.5.0");
  static v380 = _API.fromSimpleString("3.8.0");
  static v381 = _API.fromSimpleString("3.8.1");
  static v390 = _API.fromSimpleString("3.9.0");
  static v400 = _API.fromSimpleString("4.0.0");
  static v401 = _API.fromSimpleString("4.0.1");
  static v420 = _API.fromSimpleString("4.2.0");
  static v430 = _API.fromSimpleString("4.3.0");
  static v440 = _API.fromSimpleString("4.4.0");
  static v460 = _API.fromSimpleString("4.6.0");
  static v470 = _API.fromSimpleString("4.7.0");
  static v480 = _API.fromSimpleString("4.8.0");
  static v490 = _API.fromSimpleString("4.9.0");
  static v500 = _API.fromSimpleString("5.0.0");
  static v510 = _API.fromSimpleString("5.1.0");
  static v520 = _API.fromSimpleString("5.2.0");
  static v540 = _API.fromSimpleString("5.4.0");
  static v544 = _API.fromSimpleString("5.4.4");
  static v590 = _API.fromSimpleString("5.9.0");
  static fromVersionString(versionString) {
    let version2 = semver.valid(versionString);
    if (!version2) {
      return new _API("invalid version", "1.0.0", "1.0.0");
    }
    const index = versionString.indexOf("-");
    if (index >= 0) {
      version2 = version2.substr(0, index);
    }
    return new _API(versionString, version2, versionString);
  }
  constructor(displayName, version2, fullVersionString) {
    this.displayName = displayName;
    this.version = version2;
    this.fullVersionString = fullVersionString;
  }
  eq(other) {
    return semver.eq(this.version, other.version);
  }
  gte(other) {
    return semver.gte(this.version, other.version);
  }
  lt(other) {
    return !this.gte(other);
  }
};
function equals$1(a, b, itemEquals = (a2, b2) => a2 === b2) {
  if (a === b) {
    return true;
  }
  if (a.length !== b.length) {
    return false;
  }
  return a.every((x, i) => itemEquals(x, b[i]));
}
function coalesce(array) {
  return array.filter((e) => !!e);
}
var Delayer = class {
  defaultDelay;
  timeout;
  completionPromise;
  onSuccess;
  task;
  constructor(defaultDelay) {
    this.defaultDelay = defaultDelay;
    this.timeout = null;
    this.completionPromise = null;
    this.onSuccess = null;
    this.task = null;
  }
  trigger(task, delay = this.defaultDelay) {
    this.task = task;
    if (delay >= 0) {
      this.cancelTimeout();
    }
    if (!this.completionPromise) {
      this.completionPromise = new Promise((resolve2) => {
        this.onSuccess = resolve2;
      }).then(() => {
        this.completionPromise = null;
        this.onSuccess = null;
        const result = this.task?.();
        this.task = null;
        return result;
      });
    }
    if (delay >= 0 || this.timeout === null) {
      this.timeout = setTimeout(() => {
        this.timeout = null;
        this.onSuccess?.(void 0);
      }, delay >= 0 ? delay : this.defaultDelay);
    }
    return this.completionPromise;
  }
  cancelTimeout() {
    if (this.timeout !== null) {
      clearTimeout(this.timeout);
      this.timeout = null;
    }
  }
};
function makeRandomHexString(length) {
  const chars = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f"];
  let result = "";
  for (let i = 0; i < length; i++) {
    const idx = Math.floor(chars.length * Math.random());
    result += chars[idx];
  }
  return result;
}
var getRootTempDir = /* @__PURE__ */ (() => {
  let dir;
  return () => {
    if (!dir) {
      const filename = `typescript-language-server${process.platform !== "win32" && process.getuid ? process.getuid() : ""}`;
      dir = path__default.join(os.tmpdir(), filename);
    }
    if (!fs$2.existsSync(dir)) {
      fs$2.mkdirSync(dir);
    }
    return dir;
  };
})();
var getInstanceTempDir = /* @__PURE__ */ (() => {
  let dir;
  return () => {
    dir ??= path__default.join(getRootTempDir(), makeRandomHexString(20));
    if (!fs$2.existsSync(dir)) {
      fs$2.mkdirSync(dir);
    }
    return dir;
  };
})();
function getTempFile(prefix) {
  return path__default.join(getInstanceTempDir(), `${prefix}-${makeRandomHexString(20)}.tmp`);
}
function looksLikeAbsoluteWindowsPath(path2) {
  return /^[a-zA-Z]:[/\\]/.test(path2);
}
var onCaseInsensitiveFileSystem = /* @__PURE__ */ (() => {
  let value;
  return () => {
    if (typeof value === "undefined") {
      if (process.platform === "win32") {
        value = true;
      } else if (process.platform !== "darwin") {
        value = false;
      } else {
        const temp = getTempFile("typescript-case-check");
        fs$2.writeFileSync(temp, "");
        value = fs$2.existsSync(temp.toUpperCase());
      }
    }
    return value;
  };
})();
var ResourceMap = class _ResourceMap {
  _normalizePath;
  config;
  static defaultPathNormalizer = (resource) => {
    if (resource.scheme === "file") {
      return resource.fsPath;
    }
    return resource.toString(true);
  };
  _map = /* @__PURE__ */ new Map();
  constructor(_normalizePath = _ResourceMap.defaultPathNormalizer, config) {
    this._normalizePath = _normalizePath;
    this.config = config;
  }
  get size() {
    return this._map.size;
  }
  has(resource) {
    const file2 = this.toKey(resource);
    return !!file2 && this._map.has(file2);
  }
  get(resource) {
    const file2 = this.toKey(resource);
    if (!file2) {
      return void 0;
    }
    const entry = this._map.get(file2);
    return entry ? entry.value : void 0;
  }
  set(resource, value) {
    const file2 = this.toKey(resource);
    if (!file2) {
      return;
    }
    const entry = this._map.get(file2);
    if (entry) {
      entry.value = value;
    } else {
      this._map.set(file2, {
        resource,
        value
      });
    }
  }
  delete(resource) {
    const file2 = this.toKey(resource);
    if (file2) {
      this._map.delete(file2);
    }
  }
  clear() {
    this._map.clear();
  }
  values() {
    return Array.from(this._map.values(), (x) => x.value);
  }
  entries() {
    return this._map.values();
  }
  toKey(resource) {
    const key = this._normalizePath(resource);
    if (!key) {
      return key;
    }
    return this.isCaseInsensitivePath(key) ? key.toLowerCase() : key;
  }
  isCaseInsensitivePath(path2) {
    if (looksLikeAbsoluteWindowsPath(path2)) {
      return true;
    }
    return path2[0] === "/" && this.config.onCaseInsensitiveFileSystem;
  }
};
function mode2ScriptKind(mode) {
  switch (mode) {
    case typescript:
      return "TS";
    case typescriptreact:
      return "TSX";
    case javascript:
      return "JS";
    case javascriptreact:
      return "JSX";
  }
  return void 0;
}
function getModeFromFileUri(uri) {
  const extension = extname(uri).toUpperCase();
  switch (extension) {
    case ".TS":
      return typescript;
    case ".TSX":
      return typescriptreact;
    case ".JS":
      return javascript;
    case ".JSX":
      return javascriptreact;
  }
  return void 0;
}
var PendingDiagnostics = class extends ResourceMap {
  getOrderedFileSet() {
    const orderedResources = Array.from(this.entries()).sort((a, b) => a.value - b.value).map((entry) => entry.resource);
    const map = new ResourceMap(this._normalizePath, this.config);
    for (const resource of orderedResources) {
      map.set(resource, void 0);
    }
    return map;
  }
};
var GetErrRequest = class _GetErrRequest {
  client;
  files;
  static executeGetErrRequest(client, files2, onDone) {
    return new _GetErrRequest(client, files2, onDone);
  }
  _done = false;
  _token = new mainExports$2.CancellationTokenSource();
  constructor(client, files2, onDone) {
    this.client = client;
    this.files = files2;
    if (!this.isErrorReportingEnabled()) {
      this._done = true;
      setImmediate(onDone);
      return;
    }
    const supportsSyntaxGetErr = this.client.apiVersion.gte(API.v440);
    const allFiles = coalesce(Array.from(files2.entries()).filter((entry) => supportsSyntaxGetErr || client.hasCapabilityForResource(entry.resource, ClientCapability.Semantic)).map((entry) => client.toTsFilePath(entry.resource.toString())));
    if (!allFiles.length) {
      this._done = true;
      setImmediate(onDone);
    } else {
      const request = this.areProjectDiagnosticsEnabled() ? client.executeAsync(CommandTypes.GeterrForProject, {
        delay: 0,
        file: allFiles[0]
      }, this._token.token) : client.executeAsync(CommandTypes.Geterr, {
        delay: 0,
        files: allFiles
      }, this._token.token);
      request.finally(() => {
        if (this._done) {
          return;
        }
        this._done = true;
        onDone();
      });
    }
  }
  isErrorReportingEnabled() {
    if (this.client.apiVersion.gte(API.v440)) {
      return true;
    } else {
      return this.client.capabilities.has(ClientCapability.Semantic);
    }
  }
  areProjectDiagnosticsEnabled() {
    return false;
  }
  cancel() {
    if (!this._done) {
      this._token.cancel();
    }
    this._token.dispose();
  }
};
var LspDocument = class {
  _document;
  _uri;
  _filepath;
  constructor(doc, filepath) {
    const { uri, languageId, version: version2, text } = doc;
    this._document = TextDocument.create(uri, languageId, version2, text);
    this._uri = URI.parse(uri);
    this._filepath = filepath;
  }
  get uri() {
    return this._uri;
  }
  get filepath() {
    return this._filepath;
  }
  get languageId() {
    return this._document.languageId;
  }
  get version() {
    return this._document.version;
  }
  getText(range2) {
    return this._document.getText(range2);
  }
  positionAt(offset) {
    return this._document.positionAt(offset);
  }
  offsetAt(position) {
    return this._document.offsetAt(position);
  }
  get lineCount() {
    return this._document.lineCount;
  }
  getLine(line) {
    const lineRange = this.getLineRange(line);
    return this.getText(lineRange);
  }
  getLineRange(line) {
    const lineStart = this.getLineStart(line);
    const lineEnd = this.getLineEnd(line);
    return mainExports$2.Range.create(lineStart, lineEnd);
  }
  getLineEnd(line) {
    const nextLine = line + 1;
    const nextLineOffset = this.getLineOffset(nextLine);
    return this.positionAt(nextLine < this._document.lineCount ? nextLineOffset - 1 : nextLineOffset);
  }
  getLineOffset(line) {
    const lineStart = this.getLineStart(line);
    return this.offsetAt(lineStart);
  }
  getLineStart(line) {
    return mainExports$2.Position.create(line, 0);
  }
  getFullRange() {
    return mainExports$2.Range.create(mainExports$2.Position.create(0, 0), this.getLineEnd(Math.max(this.lineCount - 1, 0)));
  }
  applyEdit(version2, change) {
    const content = this.getText();
    let newContent = change.text;
    if (mainExports$2.TextDocumentContentChangeEvent.isIncremental(change)) {
      const start = this.offsetAt(change.range.start);
      const end = this.offsetAt(change.range.end);
      newContent = content.substr(0, start) + change.text + content.substr(end);
    }
    this._document = TextDocument.create(this._uri.toString(), this.languageId, version2, newContent);
  }
};
var LspDocuments = class {
  client;
  lspClient;
  _validateJavaScript = true;
  _validateTypeScript = true;
  modeIds = /* @__PURE__ */ new Set();
  _files = [];
  documents = /* @__PURE__ */ new Map();
  pendingDiagnostics;
  diagnosticDelayer;
  pendingGetErr;
  constructor(client, lspClient, onCaseInsensitiveFileSystem2) {
    this.client = client;
    this.lspClient = lspClient;
    const pathNormalizer = (path2) => this.client.toTsFilePath(path2.toString());
    this.pendingDiagnostics = new PendingDiagnostics(pathNormalizer, {
      onCaseInsensitiveFileSystem: onCaseInsensitiveFileSystem2
    });
    this.diagnosticDelayer = new Delayer(300);
  }
  initialize(allModeIds) {
    this.modeIds = new Set(allModeIds);
  }
  get files() {
    return this._files;
  }
  get documentsForTesting() {
    return this.documents;
  }
  get(file2) {
    const document = this.documents.get(file2);
    if (!document) {
      return void 0;
    }
    if (this.files[0] !== file2) {
      this._files.splice(this._files.indexOf(file2), 1);
      this._files.unshift(file2);
    }
    return document;
  }
  openTextDocument(textDocument) {
    if (!this.modeIds.has(textDocument.languageId)) {
      const detectedLanguageId = getModeFromFileUri(textDocument.uri);
      if (detectedLanguageId) {
        this.lspClient.logMessage({
          type: mainExports$2.MessageType.Warning,
          message: `Invalid languageId "${textDocument.languageId}" provided for uri "${textDocument.uri}". Correcting to "${detectedLanguageId}"`
        });
        textDocument.languageId = detectedLanguageId;
      } else {
        return false;
      }
    }
    const resource = textDocument.uri;
    const filepath = this.client.toTsFilePath(resource);
    if (!filepath) {
      return false;
    }
    if (this.documents.has(filepath)) {
      return true;
    }
    const document = new LspDocument(textDocument, filepath);
    this.documents.set(filepath, document);
    this._files.unshift(filepath);
    this.client.executeWithoutWaitingForResponse(CommandTypes.Open, {
      file: filepath,
      fileContent: textDocument.text,
      scriptKindName: mode2ScriptKind(textDocument.languageId),
      projectRootPath: this.getProjectRootPath(document.uri)
    });
    this.requestDiagnostic(document);
    return true;
  }
  onDidCloseTextDocument(uri) {
    const document = this.client.toOpenDocument(uri);
    if (!document) {
      return;
    }
    this._files.splice(this._files.indexOf(document.filepath), 1);
    this.pendingDiagnostics.delete(document.uri);
    this.pendingGetErr?.files.delete(document.uri);
    this.documents.delete(document.filepath);
    this.client.cancelInflightRequestsForResource(document.uri);
    this.client.executeWithoutWaitingForResponse(CommandTypes.Close, {
      file: document.filepath
    });
    this.requestAllDiagnostics();
  }
  requestDiagnosticsForTesting() {
    this.triggerDiagnostics(0);
  }
  onDidChangeTextDocument(params) {
    const { textDocument } = params;
    if (textDocument.version === null) {
      throw new Error(`Received document change event for ${textDocument.uri} without valid version identifier`);
    }
    const filepath = this.client.toTsFilePath(textDocument.uri);
    if (!filepath) {
      return;
    }
    const document = this.documents.get(filepath);
    if (!document) {
      return;
    }
    this.client.cancelInflightRequestsForResource(document.uri);
    for (const change of params.contentChanges) {
      let line;
      let offset;
      let endLine;
      let endOffset;
      if (mainExports$2.TextDocumentContentChangeEvent.isIncremental(change)) {
        line = change.range.start.line + 1;
        offset = change.range.start.character + 1;
        endLine = change.range.end.line + 1;
        endOffset = change.range.end.character + 1;
      } else {
        line = 1;
        offset = 1;
        const endPos = document.positionAt(document.getText().length);
        endLine = endPos.line + 1;
        endOffset = endPos.character + 1;
      }
      this.client.executeWithoutWaitingForResponse(CommandTypes.Change, {
        file: filepath,
        line,
        offset,
        endLine,
        endOffset,
        insertString: change.text
      });
      document.applyEdit(textDocument.version, change);
    }
    const didTrigger = this.requestDiagnostic(document);
    if (!didTrigger && this.pendingGetErr) {
      this.pendingGetErr.cancel();
      this.pendingGetErr = void 0;
      this.triggerDiagnostics();
    }
  }
  interruptGetErr(f) {
    if (!this.pendingGetErr) {
      return f();
    }
    this.pendingGetErr.cancel();
    this.pendingGetErr = void 0;
    const result = f();
    this.triggerDiagnostics();
    return result;
  }
  getProjectRootPath(resource) {
    const workspaceRoot = this.client.getWorkspaceRootForResource(resource);
    if (workspaceRoot) {
      return this.client.toTsFilePath(workspaceRoot.toString());
    }
    return void 0;
  }
  handles(resource) {
    const filepath = this.client.toTsFilePath(resource.toString());
    return filepath !== void 0 && this.documents.has(filepath);
  }
  requestAllDiagnostics() {
    for (const buffer2 of this.documents.values()) {
      if (this.shouldValidate(buffer2)) {
        this.pendingDiagnostics.set(buffer2.uri, Date.now());
      }
    }
    this.triggerDiagnostics();
  }
  hasPendingDiagnostics(resource) {
    return this.pendingDiagnostics.has(resource);
  }
  getErr(resources) {
    const handledResources = resources.filter((resource) => this.handles(resource));
    if (!handledResources.length) {
      return;
    }
    for (const resource of handledResources) {
      this.pendingDiagnostics.set(resource, Date.now());
    }
    this.triggerDiagnostics();
  }
  triggerDiagnostics(delay = 200) {
    this.diagnosticDelayer.trigger(() => {
      this.sendPendingDiagnostics();
    }, delay);
  }
  requestDiagnostic(buffer2) {
    if (!this.shouldValidate(buffer2)) {
      return false;
    }
    this.pendingDiagnostics.set(buffer2.uri, Date.now());
    const delay = Math.min(Math.max(Math.ceil(buffer2.lineCount / 20), 300), 800);
    this.triggerDiagnostics(delay);
    return true;
  }
  sendPendingDiagnostics() {
    const orderedFileSet = this.pendingDiagnostics.getOrderedFileSet();
    if (this.pendingGetErr) {
      this.pendingGetErr.cancel();
      for (const { resource } of this.pendingGetErr.files.entries()) {
        const filename = this.client.toTsFilePath(resource.toString());
        if (filename && this.documents.get(filename)) {
          orderedFileSet.set(resource, void 0);
        }
      }
      this.pendingGetErr = void 0;
    }
    for (const buffer2 of this.documents.values()) {
      orderedFileSet.set(buffer2.uri, void 0);
    }
    if (orderedFileSet.size) {
      const getErr = this.pendingGetErr = GetErrRequest.executeGetErrRequest(this.client, orderedFileSet, () => {
        if (this.pendingGetErr === getErr) {
          this.pendingGetErr = void 0;
        }
      });
    }
    this.pendingDiagnostics.clear();
  }
  shouldValidate(buffer2) {
    switch (buffer2.languageId) {
      case "javascript":
      case "javascriptreact":
        return this._validateJavaScript;
      case "typescript":
      case "typescriptreact":
      default:
        return this._validateTypeScript;
    }
  }
};
var file = "file";
var untitled = "untitled";
var git = "git";
var github = "github";
var azurerepos = "azurerepos";
var buffer = "buffer";
var zipfile = "zipfile";
var vsls = "vsls";
function getSemanticSupportedSchemes() {
  return [file, untitled, buffer, zipfile];
}
var disabledSchemes = /* @__PURE__ */ new Set([git, vsls, github, azurerepos]);
var TypeScriptServerPlugin;
(function(TypeScriptServerPlugin2) {
  function equals2(a, b) {
    return a.uri.toString() === b.uri.toString() && a.name === b.name && equals$1(a.languages, b.languages);
  }
  TypeScriptServerPlugin2.equals = equals2;
})(TypeScriptServerPlugin || (TypeScriptServerPlugin = {}));
var PluginManager = class {
  _plugins;
  setPlugins(plugins) {
    this._plugins = this.readPlugins(plugins);
  }
  get plugins() {
    return Array.from(this._plugins || []);
  }
  readPlugins(plugins) {
    const newPlugins = [];
    for (const plugin of plugins) {
      newPlugins.push({
        name: plugin.name,
        uri: URI.file(plugin.location),
        languages: Array.isArray(plugin.languages) ? plugin.languages : []
      });
    }
    return newPlugins;
  }
};
var TypeScriptServerError = class _TypeScriptServerError extends Error {
  serverId;
  version;
  response;
  serverMessage;
  serverStack;
  static create(serverId, version2, response) {
    const parsedResult = _TypeScriptServerError.parseErrorText(response);
    return new _TypeScriptServerError(serverId, version2, response, parsedResult?.message, parsedResult?.stack);
  }
  constructor(serverId, version2, response, serverMessage, serverStack) {
    super(`<${serverId}> TypeScript Server Error (${version2.versionString})
${serverMessage}
${serverStack}`);
    this.serverId = serverId;
    this.version = version2;
    this.response = response;
    this.serverMessage = serverMessage;
    this.serverStack = serverStack;
  }
  get serverErrorText() {
    return this.response.message;
  }
  get serverCommand() {
    return this.response.command;
  }
  static parseErrorText(response) {
    const errorText = response.message;
    if (errorText) {
      const errorPrefix = "Error processing request. ";
      if (errorText.startsWith(errorPrefix)) {
        const prefixFreeErrorText = errorText.substr(errorPrefix.length);
        const newlineIndex = prefixFreeErrorText.indexOf("\n");
        if (newlineIndex >= 0) {
          const stack = prefixFreeErrorText.substring(newlineIndex + 1);
          return {
            message: prefixFreeErrorText.substring(0, newlineIndex),
            stack
          };
        }
      }
    }
    return void 0;
  }
};
var randomBytesAsync = promisify(crypto.randomBytes);
var urlSafeCharacters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~".split("");
var numericCharacters = "0123456789".split("");
var distinguishableCharacters = "CDEHKMPRTUWXY012458".split("");
var asciiPrintableCharacters = "!\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~".split("");
var alphanumericCharacters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split("");
var generateForCustomCharacters = (length, characters) => {
  const characterCount = characters.length;
  const maxValidSelector = Math.floor(65536 / characterCount) * characterCount - 1;
  const entropyLength = 2 * Math.ceil(1.1 * length);
  let string = "";
  let stringLength = 0;
  while (stringLength < length) {
    const entropy = crypto.randomBytes(entropyLength);
    let entropyPosition = 0;
    while (entropyPosition < entropyLength && stringLength < length) {
      const entropyValue = entropy.readUInt16LE(entropyPosition);
      entropyPosition += 2;
      if (entropyValue > maxValidSelector) {
        continue;
      }
      string += characters[entropyValue % characterCount];
      stringLength++;
    }
  }
  return string;
};
var generateForCustomCharactersAsync = async (length, characters) => {
  const characterCount = characters.length;
  const maxValidSelector = Math.floor(65536 / characterCount) * characterCount - 1;
  const entropyLength = 2 * Math.ceil(1.1 * length);
  let string = "";
  let stringLength = 0;
  while (stringLength < length) {
    const entropy = await randomBytesAsync(entropyLength);
    let entropyPosition = 0;
    while (entropyPosition < entropyLength && stringLength < length) {
      const entropyValue = entropy.readUInt16LE(entropyPosition);
      entropyPosition += 2;
      if (entropyValue > maxValidSelector) {
        continue;
      }
      string += characters[entropyValue % characterCount];
      stringLength++;
    }
  }
  return string;
};
var generateRandomBytes = (byteLength, type, length) => crypto.randomBytes(byteLength).toString(type).slice(0, length);
var generateRandomBytesAsync = async (byteLength, type, length) => {
  const buffer2 = await randomBytesAsync(byteLength);
  return buffer2.toString(type).slice(0, length);
};
var allowedTypes = /* @__PURE__ */ new Set([void 0, "hex", "base64", "url-safe", "numeric", "distinguishable", "ascii-printable", "alphanumeric"]);
var createGenerator = (generateForCustomCharacters2, generateRandomBytes2) => ({ length, type, characters }) => {
  if (!(length >= 0 && Number.isFinite(length))) {
    throw new TypeError("Expected a `length` to be a non-negative finite number");
  }
  if (type !== void 0 && characters !== void 0) {
    throw new TypeError("Expected either `type` or `characters`");
  }
  if (characters !== void 0 && typeof characters !== "string") {
    throw new TypeError("Expected `characters` to be string");
  }
  if (!allowedTypes.has(type)) {
    throw new TypeError(`Unknown type: ${type}`);
  }
  if (type === void 0 && characters === void 0) {
    type = "hex";
  }
  if (type === "hex" || type === void 0 && characters === void 0) {
    return generateRandomBytes2(Math.ceil(length * 0.5), "hex", length);
  }
  if (type === "base64") {
    return generateRandomBytes2(Math.ceil(length * 0.75), "base64", length);
  }
  if (type === "url-safe") {
    return generateForCustomCharacters2(length, urlSafeCharacters);
  }
  if (type === "numeric") {
    return generateForCustomCharacters2(length, numericCharacters);
  }
  if (type === "distinguishable") {
    return generateForCustomCharacters2(length, distinguishableCharacters);
  }
  if (type === "ascii-printable") {
    return generateForCustomCharacters2(length, asciiPrintableCharacters);
  }
  if (type === "alphanumeric") {
    return generateForCustomCharacters2(length, alphanumericCharacters);
  }
  if (characters.length === 0) {
    throw new TypeError("Expected `characters` string length to be greater than or equal to 1");
  }
  if (characters.length > 65536) {
    throw new TypeError("Expected `characters` string length to be less or equal to 65536");
  }
  return generateForCustomCharacters2(length, characters.split(""));
};
var cryptoRandomString = createGenerator(generateForCustomCharacters, generateRandomBytes);
cryptoRandomString.async = createGenerator(generateForCustomCharactersAsync, generateRandomBytesAsync);
function uniqueString() {
  return cryptoRandomString({
    length: 32
  });
}
var temporaryDirectory$1 = await promises.realpath(os.tmpdir());
promisify$1(stream.pipeline);
function assertSafePathComponent(pathComponent) {
  if (typeof pathComponent !== "string") {
    throw new TypeError(`Expected a string, got ${typeof pathComponent}`);
  }
  const trimmed = pathComponent.trim();
  const isSafe = trimmed !== "" && trimmed !== "." && trimmed !== ".." && !pathComponent.includes("/") && !pathComponent.includes("\\") && !pathComponent.includes("\0");
  if (!isSafe) {
    throw new Error(`Unsafe path component: ${JSON.stringify(pathComponent)}`);
  }
}
function resolveParentDirectory(parentDirectory, rootDirectory) {
  assertSafePathComponent(parentDirectory);
  const base = rootDirectory ?? temporaryDirectory$1;
  const resolved = path__default.join(base, parentDirectory);
  fs$2.mkdirSync(resolved, {
    recursive: true
  });
  return resolved;
}
var getPath = (prefix = "", { parentDirectory, rootDirectory } = {}) => {
  if (prefix) {
    assertSafePathComponent(prefix);
  }
  if (rootDirectory !== void 0) {
    if (!path__default.isAbsolute(rootDirectory)) {
      throw new Error("The `rootDirectory` option must be an absolute path");
    }
    fs$2.mkdirSync(rootDirectory, {
      recursive: true
    });
  }
  const parent = parentDirectory ? resolveParentDirectory(parentDirectory, rootDirectory) : rootDirectory ?? temporaryDirectory$1;
  return path__default.join(parent, prefix + uniqueString());
};
function temporaryFile({ name, extension, parentDirectory, rootDirectory } = {}) {
  if (name !== void 0 && name !== null) {
    if (extension !== void 0 && extension !== null) {
      throw new Error("The `name` and `extension` options are mutually exclusive");
    }
    assertSafePathComponent(name);
    return path__default.join(temporaryDirectory({
      parentDirectory,
      rootDirectory
    }), name);
  }
  if (extension !== void 0 && extension !== null) {
    assertSafePathComponent(extension);
  }
  return getPath("", {
    parentDirectory,
    rootDirectory
  }) + (extension === void 0 || extension === null ? "" : "." + extension.replace(/^\./, ""));
}
function temporaryDirectory({ prefix = "", parentDirectory, rootDirectory } = {}) {
  const directory = getPath(prefix, {
    parentDirectory,
    rootDirectory
  });
  fs$2.mkdirSync(directory, {
    recursive: true
  });
  return directory;
}
var NodeRequestCanceller = class {
  _serverId;
  _tracer;
  cancellationPipeName;
  constructor(_serverId, _tracer) {
    this._serverId = _serverId;
    this._tracer = _tracer;
    this.cancellationPipeName = temporaryFile({
      name: "tscancellation"
    });
  }
  tryCancelOngoingRequest(seq) {
    if (!this.cancellationPipeName) {
      return false;
    }
    this._tracer.logTrace(this._serverId, `TypeScript Server: trying to cancel ongoing request with sequence number ${seq}`);
    try {
      fs$2.writeFileSync(this.cancellationPipeName + String(seq), "");
    } catch {
    }
    return true;
  }
};
var nodeRequestCancellerFactory = new class {
  create(serverId, tracer) {
    return new NodeRequestCanceller(serverId, tracer);
  }
}();
var RequestQueueingType;
(function(RequestQueueingType2) {
  RequestQueueingType2[RequestQueueingType2["Normal"] = 1] = "Normal";
  RequestQueueingType2[RequestQueueingType2["LowPriority"] = 2] = "LowPriority";
  RequestQueueingType2[RequestQueueingType2["Fence"] = 3] = "Fence";
})(RequestQueueingType || (RequestQueueingType = {}));
var RequestQueue = class {
  queue = [];
  sequenceNumber = 0;
  get length() {
    return this.queue.length;
  }
  enqueue(item) {
    if (item.queueingType === RequestQueueingType.Normal) {
      let index = this.queue.length - 1;
      while (index >= 0) {
        if (this.queue[index].queueingType !== RequestQueueingType.LowPriority) {
          break;
        }
        --index;
      }
      this.queue.splice(index + 1, 0, item);
    } else {
      this.queue.push(item);
    }
  }
  dequeue() {
    return this.queue.shift();
  }
  tryDeletePendingRequest(seq) {
    for (let i = 0; i < this.queue.length; i++) {
      if (this.queue[i].request.seq === seq) {
        this.queue.splice(i, 1);
        return true;
      }
    }
    return false;
  }
  createRequest(command2, args) {
    return {
      seq: this.sequenceNumber++,
      type: "request",
      command: command2,
      arguments: args
    };
  }
};
var CallbackMap = class {
  _callbacks = /* @__PURE__ */ new Map();
  _asyncCallbacks = /* @__PURE__ */ new Map();
  destroy(cause) {
    const cancellation2 = new ServerResponse.Cancelled(cause);
    for (const callback of this._callbacks.values()) {
      callback.onSuccess(cancellation2);
    }
    this._callbacks.clear();
    for (const callback of this._asyncCallbacks.values()) {
      callback.onSuccess(cancellation2);
    }
    this._asyncCallbacks.clear();
  }
  add(seq, callback, isAsync) {
    if (isAsync) {
      this._asyncCallbacks.set(seq, callback);
    } else {
      this._callbacks.set(seq, callback);
    }
  }
  fetch(seq) {
    const callback = this._callbacks.get(seq) || this._asyncCallbacks.get(seq);
    this.delete(seq);
    return callback;
  }
  delete(seq) {
    if (!this._callbacks.delete(seq)) {
      this._asyncCallbacks.delete(seq);
    }
  }
};
var ExecutionTarget;
(function(ExecutionTarget2) {
  ExecutionTarget2[ExecutionTarget2["Semantic"] = 0] = "Semantic";
  ExecutionTarget2[ExecutionTarget2["Syntax"] = 1] = "Syntax";
})(ExecutionTarget || (ExecutionTarget = {}));
var SingleTsServer = class _SingleTsServer {
  _serverId;
  _serverSource;
  _process;
  _tsServerLogFile;
  _requestCanceller;
  _version;
  _tracer;
  _requestQueue = new RequestQueue();
  _callbacks = new CallbackMap();
  _pendingResponses = /* @__PURE__ */ new Set();
  _eventHandlers = /* @__PURE__ */ new Set();
  _exitHandlers = /* @__PURE__ */ new Set();
  _errorHandlers = /* @__PURE__ */ new Set();
  _stdErrHandlers = /* @__PURE__ */ new Set();
  constructor(_serverId, _serverSource, _process, _tsServerLogFile, _requestCanceller, _version, _tracer) {
    this._serverId = _serverId;
    this._serverSource = _serverSource;
    this._process = _process;
    this._tsServerLogFile = _tsServerLogFile;
    this._requestCanceller = _requestCanceller;
    this._version = _version;
    this._tracer = _tracer;
    this._process.onData((msg) => {
      this.dispatchMessage(msg);
    });
    this._process.onStdErr((error2) => {
      this._stdErrHandlers.forEach((handler) => handler(error2));
    });
    this._process.onExit((code, signal) => {
      this._exitHandlers.forEach((handler) => handler({
        code,
        signal
      }));
      this._callbacks.destroy("server exited");
    });
    this._process.onError((error2) => {
      this._errorHandlers.forEach((handler) => handler(error2));
      this._callbacks.destroy("server errored");
    });
  }
  onEvent(handler) {
    this._eventHandlers.add(handler);
  }
  onExit(handler) {
    this._exitHandlers.add(handler);
  }
  onStdErr(handler) {
    this._stdErrHandlers.add(handler);
  }
  onError(handler) {
    this._errorHandlers.add(handler);
  }
  get tsServerLogFile() {
    return this._tsServerLogFile;
  }
  write(serverRequest) {
    this._process.write(serverRequest);
  }
  dispose() {
    this._callbacks.destroy("server disposed");
    this._pendingResponses.clear();
    this._eventHandlers.clear();
    this._exitHandlers.clear();
    this._errorHandlers.clear();
  }
  kill() {
    this.dispose();
    this._process.kill();
  }
  dispatchMessage(message) {
    try {
      switch (message.type) {
        case "response":
          if (this._serverSource) {
            this.dispatchResponse({
              ...message
            });
          } else {
            this.dispatchResponse(message);
          }
          break;
        case "event": {
          const event = message;
          if (event.event === "requestCompleted") {
            const seq = event.body.request_seq;
            const callback = this._callbacks.fetch(seq);
            if (callback) {
              this._tracer.traceRequestCompleted(this._serverId, "requestCompleted", seq, callback);
              callback.onSuccess(void 0);
            }
          } else {
            this._tracer.traceEvent(this._serverId, event);
            this._eventHandlers.forEach((handler) => handler(event));
          }
          break;
        }
        default:
          throw new Error(`Unknown message type ${message.type} received`);
      }
    } finally {
      this.sendNextRequests();
    }
  }
  tryCancelRequest(seq, command2) {
    try {
      if (this._requestQueue.tryDeletePendingRequest(seq)) {
        this.logTrace(`Canceled pending request with sequence number ${seq}`);
        return true;
      }
      if (this._requestCanceller.tryCancelOngoingRequest(seq)) {
        return true;
      }
      this.logTrace(`Tried to cancel request with sequence number ${seq}. But request got already delivered.`);
      return false;
    } finally {
      const callback = this.fetchCallback(seq);
      callback?.onSuccess(new ServerResponse.Cancelled(`Cancelled request ${seq} - ${command2}`));
    }
  }
  dispatchResponse(response) {
    const callback = this.fetchCallback(response.request_seq);
    if (!callback) {
      return;
    }
    this._tracer.traceResponse(this._serverId, response, callback);
    if (response.success) {
      callback.onSuccess(response);
    } else if (response.message === "No content available.") {
      callback.onSuccess(ServerResponse.NoContent);
    } else {
      callback.onError(TypeScriptServerError.create(this._serverId, this._version, response));
    }
  }
  executeImpl(command2, args, executeInfo) {
    const request = this._requestQueue.createRequest(command2, args);
    const requestInfo = {
      request,
      expectsResponse: executeInfo.expectsResult,
      isAsync: executeInfo.isAsync,
      queueingType: _SingleTsServer.getQueueingType(command2, executeInfo.lowPriority)
    };
    let result;
    if (executeInfo.expectsResult) {
      result = new Promise((resolve2, reject) => {
        this._callbacks.add(request.seq, {
          onSuccess: resolve2,
          onError: reject,
          queuingStartTime: Date.now(),
          isAsync: executeInfo.isAsync
        }, executeInfo.isAsync);
        if (executeInfo.token) {
          executeInfo.token.onCancellationRequested(() => {
            this.tryCancelRequest(request.seq, command2);
          });
        }
      });
    }
    this._requestQueue.enqueue(requestInfo);
    this.sendNextRequests();
    return [result];
  }
  sendNextRequests() {
    while (this._pendingResponses.size === 0 && this._requestQueue.length > 0) {
      const item = this._requestQueue.dequeue();
      if (item) {
        this.sendRequest(item);
      }
    }
  }
  sendRequest(requestItem) {
    const serverRequest = requestItem.request;
    this._tracer.traceRequest(this._serverId, serverRequest, requestItem.expectsResponse, this._requestQueue.length);
    if (requestItem.expectsResponse && !requestItem.isAsync) {
      this._pendingResponses.add(requestItem.request.seq);
    }
    try {
      this.write(serverRequest);
    } catch (err) {
      const callback = this.fetchCallback(serverRequest.seq);
      callback?.onError(err);
    }
  }
  fetchCallback(seq) {
    const callback = this._callbacks.fetch(seq);
    if (!callback) {
      return void 0;
    }
    this._pendingResponses.delete(seq);
    return callback;
  }
  logTrace(message) {
    this._tracer.logTrace(this._serverId, message);
  }
  static fenceCommands = /* @__PURE__ */ new Set(["change", "close", "open", "updateOpen"]);
  static getQueueingType(command2, lowPriority) {
    if (_SingleTsServer.fenceCommands.has(command2)) {
      return RequestQueueingType.Fence;
    }
    return lowPriority ? RequestQueueingType.LowPriority : RequestQueueingType.Normal;
  }
};
var RequestRouter = class _RequestRouter {
  servers;
  delegate;
  static sharedCommands = /* @__PURE__ */ new Set([CommandTypes.Change, CommandTypes.Close, CommandTypes.Open, CommandTypes.UpdateOpen, CommandTypes.Configure]);
  constructor(servers, delegate) {
    this.servers = servers;
    this.delegate = delegate;
  }
  execute(command2, args, executeInfo) {
    if (_RequestRouter.sharedCommands.has(command2) && typeof executeInfo.executionTarget === "undefined") {
      const requestStates = this.servers.map(() => RequestState.Unresolved);
      let token = void 0;
      if (executeInfo.token) {
        const source = new mainExports$2.CancellationTokenSource();
        executeInfo.token.onCancellationRequested(() => {
          if (requestStates.some((state) => state === RequestState.Resolved)) {
            return;
          }
          source.cancel();
        });
        token = source.token;
      }
      const allRequests = [];
      for (let serverIndex = 0; serverIndex < this.servers.length; ++serverIndex) {
        const server2 = this.servers[serverIndex].server;
        const request = server2.executeImpl(command2, args, {
          ...executeInfo,
          token
        })[0];
        allRequests.push(request);
        if (request) {
          request.then((result) => {
            requestStates[serverIndex] = RequestState.Resolved;
            const erroredRequest = requestStates.find((state) => state.type === 2);
            if (erroredRequest) {
              this.delegate.onFatalError(command2, erroredRequest.err);
            }
            return result;
          }, (err) => {
            requestStates[serverIndex] = new RequestState.Errored(err);
            if (requestStates.some((state) => state === RequestState.Resolved)) {
              this.delegate.onFatalError(command2, err);
            }
            throw err;
          });
        }
      }
      return allRequests;
    }
    for (const { canRun, server: server2 } of this.servers) {
      if (!canRun || canRun(command2, executeInfo)) {
        return server2.executeImpl(command2, args, executeInfo);
      }
    }
    throw new Error(`Could not find server for command: '${command2}'`);
  }
};
var SyntaxRoutingTsServer = class _SyntaxRoutingTsServer {
  static syntaxAlwaysCommands = /* @__PURE__ */ new Set([CommandTypes.NavTree, CommandTypes.GetOutliningSpans, CommandTypes.JsxClosingTag, CommandTypes.SelectionRange, CommandTypes.Format, CommandTypes.Formatonkey, CommandTypes.DocCommentTemplate]);
  static semanticCommands = /* @__PURE__ */ new Set([CommandTypes.Geterr, CommandTypes.GeterrForProject, CommandTypes.ProjectInfo, CommandTypes.ConfigurePlugin]);
  static syntaxAllowedCommands = /* @__PURE__ */ new Set([CommandTypes.CompletionDetails, CommandTypes.CompletionInfo, CommandTypes.Definition, CommandTypes.DefinitionAndBoundSpan, CommandTypes.DocumentHighlights, CommandTypes.Implementation, CommandTypes.Navto, CommandTypes.Quickinfo, CommandTypes.References, CommandTypes.Rename, CommandTypes.SignatureHelp]);
  syntaxServer;
  semanticServer;
  router;
  _projectLoading = true;
  _eventHandlers = /* @__PURE__ */ new Set();
  _exitHandlers = /* @__PURE__ */ new Set();
  _errorHandlers = /* @__PURE__ */ new Set();
  constructor(servers, delegate, enableDynamicRouting) {
    this.syntaxServer = servers.syntax;
    this.semanticServer = servers.semantic;
    this.router = new RequestRouter([{
      server: this.syntaxServer,
      canRun: (command2, execInfo) => {
        switch (execInfo.executionTarget) {
          case ExecutionTarget.Semantic:
            return false;
          case ExecutionTarget.Syntax:
            return true;
        }
        if (_SyntaxRoutingTsServer.syntaxAlwaysCommands.has(command2)) {
          return true;
        }
        if (_SyntaxRoutingTsServer.semanticCommands.has(command2)) {
          return false;
        }
        if (enableDynamicRouting && this.projectLoading && _SyntaxRoutingTsServer.syntaxAllowedCommands.has(command2)) {
          return true;
        }
        return false;
      }
    }, {
      server: this.semanticServer,
      canRun: void 0
    }], delegate);
    this.syntaxServer.onEvent((event) => {
      this._eventHandlers.forEach((handler) => handler(event));
    });
    this.semanticServer.onEvent((event) => {
      switch (event.event) {
        case EventName.projectLoadingStart:
          this._projectLoading = true;
          break;
        case EventName.projectLoadingFinish:
        case EventName.semanticDiag:
        case EventName.syntaxDiag:
        case EventName.suggestionDiag:
        case EventName.configFileDiag:
          this._projectLoading = false;
          break;
      }
      this._eventHandlers.forEach((handler) => handler(event));
    });
    this.semanticServer.onExit((event) => {
      this._exitHandlers.forEach((handler) => handler(event));
      this.syntaxServer.kill();
    });
    this.semanticServer.onError((event) => this._errorHandlers.forEach((handler) => handler(event)));
  }
  get projectLoading() {
    return this._projectLoading;
  }
  dispose() {
    this._eventHandlers.clear();
    this._exitHandlers.clear();
    this._errorHandlers.clear();
  }
  onEvent(handler) {
    this._eventHandlers.add(handler);
  }
  onExit(handler) {
    this._exitHandlers.add(handler);
  }
  onError(handler) {
    this._errorHandlers.add(handler);
  }
  onStdErr(_handler) {
  }
  get tsServerLogFile() {
    return this.semanticServer.tsServerLogFile;
  }
  kill() {
    this.dispose();
    this.syntaxServer.kill();
    this.semanticServer.kill();
  }
  executeImpl(command2, args, executeInfo) {
    return this.router.execute(command2, args, executeInfo);
  }
};
var RequestState;
(function(RequestState2) {
  RequestState2.Unresolved = {
    type: 0
  };
  RequestState2.Resolved = {
    type: 1
  };
  class Errored {
    err;
    type = 2;
    constructor(err) {
      this.err = err;
    }
  }
  RequestState2.Errored = Errored;
})(RequestState || (RequestState = {}));
var NodeTsServerProcessFactory = class {
  fork(version2, args, kind, configuration2) {
    const tsServerPath = version2.tsServerPath;
    const useIpc = version2.version?.gte(API.v490);
    const runtimeArgs = [...args];
    if (useIpc) {
      runtimeArgs.push("--useNodeIpc");
    }
    const childProcess = require$$1.fork(tsServerPath, runtimeArgs, {
      silent: true,
      cwd: void 0,
      env: generatePatchedEnv(process.env, tsServerPath),
      execArgv: getExecArgv(kind, configuration2),
      stdio: useIpc ? ["pipe", "pipe", "pipe", "ipc"] : void 0
    });
    return useIpc ? new IpcChildServerProcess(childProcess) : new StdioChildServerProcess(childProcess);
  }
};
function generatePatchedEnv(env, modulePath) {
  const newEnv = Object.assign({}, env);
  newEnv.NODE_PATH = path__default.join(modulePath, "..", "..", "..");
  newEnv.PATH = newEnv.PATH || process.env.PATH;
  return newEnv;
}
function getExecArgv(kind, configuration2) {
  const args = [];
  const debugPort = getDebugPort(kind);
  if (debugPort) {
    const inspectFlag = getTssDebugBrk() ? "--inspect-brk" : "--inspect";
    args.push(`${inspectFlag}=${debugPort}`);
  }
  if (configuration2.maxTsServerMemory) {
    args.push(`--max-old-space-size=${configuration2.maxTsServerMemory}`);
  }
  return args;
}
function getDebugPort(kind) {
  if (kind === "syntax") {
    return void 0;
  }
  const value = getTssDebugBrk() || getTssDebug();
  if (value) {
    const port = parseInt(value);
    if (!isNaN(port)) {
      return port;
    }
  }
  return void 0;
}
function getTssDebug() {
  return process.env.TSS_DEBUG;
}
function getTssDebugBrk() {
  return process.env.TSS_DEBUG_BRK;
}
var IpcChildServerProcess = class {
  _process;
  constructor(_process) {
    this._process = _process;
  }
  write(serverRequest) {
    this._process.send(serverRequest);
  }
  onData(handler) {
    this._process.on("message", handler);
  }
  onExit(handler) {
    this._process.on("exit", handler);
  }
  onStdErr(handler) {
    this._process.stderr.on("data", (data) => handler(data.toString()));
  }
  onError(handler) {
    this._process.on("error", handler);
  }
  kill() {
    this._process.kill();
  }
};
var StdioChildServerProcess = class {
  _process;
  _reader;
  constructor(_process) {
    this._process = _process;
    this._reader = new Reader(this._process.stdout);
  }
  get reader() {
    return this._reader;
  }
  write(serverRequest) {
    this._process.stdin.write(`${JSON.stringify(serverRequest)}\r
`, "utf8");
  }
  onData(handler) {
    this.reader.onData(handler);
  }
  onExit(handler) {
    this._process.on("exit", handler);
  }
  onStdErr(handler) {
    this._process.stderr.on("data", (data) => handler(data.toString()));
  }
  onError(handler) {
    this._process.on("error", handler);
    this.reader.onError(handler);
  }
  kill() {
    this._process.kill();
    this.reader.dispose();
    this._reader = null;
  }
};
var Reader = class {
  buffer = new ProtocolBuffer();
  nextMessageLength = -1;
  _onError = (_error) => {
  };
  _onData = (_data) => {
  };
  isDisposed = false;
  constructor(readable) {
    readable.on("data", (data) => this.onLengthData(data));
  }
  dispose() {
    this.isDisposed = true;
    this._onError = (_error) => {
    };
    this._onData = (_data) => {
    };
  }
  onError(handler) {
    this._onError = handler;
  }
  onData(handler) {
    this._onData = handler;
  }
  onLengthData(data) {
    if (this.isDisposed) {
      return;
    }
    try {
      this.buffer.append(data);
      while (true) {
        if (this.nextMessageLength === -1) {
          this.nextMessageLength = this.buffer.tryReadContentLength();
          if (this.nextMessageLength === -1) {
            return;
          }
        }
        const msg = this.buffer.tryReadContent(this.nextMessageLength);
        if (msg === null) {
          return;
        }
        this.nextMessageLength = -1;
        const json2 = JSON.parse(msg);
        this._onData(json2);
      }
    } catch (e) {
      this._onError(e);
    }
  }
};
var defaultSize = 8192;
var contentLength = "Content-Length: ";
var contentLengthSize = Buffer.byteLength(contentLength, "utf8");
var blank = Buffer.from(" ", "utf8")[0];
var backslashR = Buffer.from("\r", "utf8")[0];
var backslashN = Buffer.from("\n", "utf8")[0];
var ProtocolBuffer = class {
  index = 0;
  buffer = Buffer.allocUnsafe(defaultSize);
  append(data) {
    const toAppend = Buffer.isBuffer(data) ? data : Buffer.from(data, "utf8");
    if (this.buffer.length - this.index >= toAppend.length) {
      toAppend.copy(this.buffer, this.index, 0, toAppend.length);
    } else {
      const newSize = (Math.ceil((this.index + toAppend.length) / defaultSize) + 1) * defaultSize;
      if (this.index === 0) {
        this.buffer = Buffer.allocUnsafe(newSize);
        toAppend.copy(this.buffer, 0, 0, toAppend.length);
      } else {
        this.buffer = Buffer.concat([this.buffer.slice(0, this.index), toAppend], newSize);
      }
    }
    this.index += toAppend.length;
  }
  tryReadContentLength() {
    let result = -1;
    let current = 0;
    while (current < this.index && (this.buffer[current] === blank || this.buffer[current] === backslashR || this.buffer[current] === backslashN)) {
      current++;
    }
    if (this.index < current + contentLengthSize) {
      return result;
    }
    current += contentLengthSize;
    const start = current;
    while (current < this.index && this.buffer[current] !== backslashR) {
      current++;
    }
    if (current + 3 >= this.index || this.buffer[current + 1] !== backslashN || this.buffer[current + 2] !== backslashR || this.buffer[current + 3] !== backslashN) {
      return result;
    }
    const data = this.buffer.toString("utf8", start, current);
    result = parseInt(data);
    this.buffer = this.buffer.slice(current + 4);
    this.index = this.index - (current + 4);
    return result;
  }
  tryReadContent(length) {
    if (this.index < length) {
      return null;
    }
    const result = this.buffer.toString("utf8", 0, length);
    let sourceStart = length;
    while (sourceStart < this.index && (this.buffer[sourceStart] === backslashR || this.buffer[sourceStart] === backslashN)) {
      sourceStart++;
    }
    this.buffer.copy(this.buffer, 0, sourceStart);
    this.index = this.index - sourceStart;
    return result;
  }
};
var TsServerLogLevel;
(function(TsServerLogLevel2) {
  TsServerLogLevel2[TsServerLogLevel2["Off"] = 0] = "Off";
  TsServerLogLevel2[TsServerLogLevel2["Normal"] = 1] = "Normal";
  TsServerLogLevel2[TsServerLogLevel2["Terse"] = 2] = "Terse";
  TsServerLogLevel2[TsServerLogLevel2["RequestTime"] = 3] = "RequestTime";
  TsServerLogLevel2[TsServerLogLevel2["Verbose"] = 4] = "Verbose";
})(TsServerLogLevel || (TsServerLogLevel = {}));
(function(TsServerLogLevel2) {
  function fromString(value) {
    switch (value?.toLowerCase()) {
      case "normal":
        return TsServerLogLevel2.Normal;
      case "terse":
        return TsServerLogLevel2.Terse;
      case "requesttime":
        return TsServerLogLevel2.RequestTime;
      case "verbose":
        return TsServerLogLevel2.Verbose;
      case "off":
      default:
        return TsServerLogLevel2.Off;
    }
  }
  TsServerLogLevel2.fromString = fromString;
  function toString(value) {
    switch (value) {
      case TsServerLogLevel2.Normal:
        return "normal";
      case TsServerLogLevel2.Terse:
        return "terse";
      case TsServerLogLevel2.Verbose:
        return "verbose";
      case TsServerLogLevel2.Off:
      default:
        return "off";
    }
  }
  TsServerLogLevel2.toString = toString;
})(TsServerLogLevel || (TsServerLogLevel = {}));
var SyntaxServerConfiguration;
(function(SyntaxServerConfiguration2) {
  SyntaxServerConfiguration2[SyntaxServerConfiguration2["Never"] = 0] = "Never";
  SyntaxServerConfiguration2[SyntaxServerConfiguration2["Always"] = 1] = "Always";
  SyntaxServerConfiguration2[SyntaxServerConfiguration2["Auto"] = 2] = "Auto";
})(SyntaxServerConfiguration || (SyntaxServerConfiguration = {}));
function toSyntaxServerConfiguration(value) {
  switch (value) {
    case "never":
      return SyntaxServerConfiguration.Never;
    case "auto":
      return SyntaxServerConfiguration.Auto;
  }
  return SyntaxServerConfiguration.Auto;
}
var CompositeServerType;
(function(CompositeServerType2) {
  CompositeServerType2[CompositeServerType2["Single"] = 0] = "Single";
  CompositeServerType2[CompositeServerType2["SeparateSyntax"] = 1] = "SeparateSyntax";
  CompositeServerType2[CompositeServerType2["DynamicSeparateSyntax"] = 2] = "DynamicSeparateSyntax";
  CompositeServerType2[CompositeServerType2["SyntaxOnly"] = 3] = "SyntaxOnly";
})(CompositeServerType || (CompositeServerType = {}));
var TypeScriptServerSpawner = class {
  _apiVersion;
  _logDirectoryProvider;
  _logger;
  _tracer;
  constructor(_apiVersion, _logDirectoryProvider, _logger, _tracer) {
    this._apiVersion = _apiVersion;
    this._logDirectoryProvider = _logDirectoryProvider;
    this._logger = _logger;
    this._tracer = _tracer;
  }
  spawn(version2, capabilities, configuration2, pluginManager, delegate) {
    let primaryServer;
    const serverType = this.getCompositeServerType(version2, capabilities, configuration2);
    switch (serverType) {
      case CompositeServerType.SeparateSyntax:
      case CompositeServerType.DynamicSeparateSyntax: {
        const enableDynamicRouting = serverType === CompositeServerType.DynamicSeparateSyntax;
        primaryServer = new SyntaxRoutingTsServer({
          syntax: this.spawnTsServer("syntax", version2, configuration2, pluginManager),
          semantic: this.spawnTsServer("semantic", version2, configuration2, pluginManager)
        }, delegate, enableDynamicRouting);
        break;
      }
      case CompositeServerType.Single: {
        primaryServer = this.spawnTsServer("main", version2, configuration2, pluginManager);
        break;
      }
      case CompositeServerType.SyntaxOnly: {
        primaryServer = this.spawnTsServer("syntax", version2, configuration2, pluginManager);
        break;
      }
    }
    return primaryServer;
  }
  getCompositeServerType(version2, capabilities, configuration2) {
    if (!capabilities.has(ClientCapability.Semantic)) {
      return CompositeServerType.SyntaxOnly;
    }
    switch (configuration2.useSyntaxServer) {
      case SyntaxServerConfiguration.Always:
        return CompositeServerType.SyntaxOnly;
      case SyntaxServerConfiguration.Never:
        return CompositeServerType.Single;
      case SyntaxServerConfiguration.Auto:
        if (version2.version?.gte(API.v340)) {
          return version2.version?.gte(API.v400) ? CompositeServerType.DynamicSeparateSyntax : CompositeServerType.SeparateSyntax;
        }
        return CompositeServerType.Single;
    }
  }
  spawnTsServer(kind, version2, configuration2, pluginManager) {
    const processFactory = new NodeTsServerProcessFactory();
    const canceller = nodeRequestCancellerFactory.create(kind, this._tracer);
    const { args, tsServerLogFile } = this.getTsServerArgs(kind, configuration2, this._apiVersion, pluginManager, canceller.cancellationPipeName);
    if (this.isLoggingEnabled(configuration2)) {
      if (tsServerLogFile) {
        this._logger.logIgnoringVerbosity(LogLevel.Info, `<${kind}> Log file: ${tsServerLogFile}`);
      } else {
        this._logger.logIgnoringVerbosity(LogLevel.Error, `<${kind}> Could not create log directory`);
      }
    }
    const tsProcess = processFactory.fork(version2, args, kind, configuration2);
    this._logger.log("Starting tsserver");
    return new SingleTsServer(kind, this.kindToServerType(kind), tsProcess, tsServerLogFile, canceller, version2, this._tracer);
  }
  kindToServerType(kind) {
    switch (kind) {
      case "syntax":
        return ServerType.Syntax;
      case "main":
      case "semantic":
      case "diagnostics":
      default:
        return ServerType.Semantic;
    }
  }
  getTsServerArgs(kind, configuration2, apiVersion, pluginManager, cancellationPipeName) {
    const args = [];
    let tsServerLogFile;
    if (kind === "syntax") {
      if (apiVersion.gte(API.v401)) {
        args.push("--serverMode", "partialSemantic");
      } else {
        args.push("--syntaxOnly");
      }
    }
    args.push("--useInferredProjectPerProjectRoot");
    const { disableAutomaticTypingAcquisition, locale, npmLocation } = configuration2;
    if (disableAutomaticTypingAcquisition || kind === "syntax" || kind === "diagnostics") {
      args.push("--disableAutomaticTypingAcquisition");
    }
    if (cancellationPipeName) {
      args.push("--cancellationPipeName", `${cancellationPipeName}*`);
    }
    if (this.isLoggingEnabled(configuration2)) {
      const logDir = this._logDirectoryProvider.getNewLogDirectory();
      if (logDir) {
        tsServerLogFile = path__default.join(logDir, "tsserver.log");
        args.push("--logVerbosity", TsServerLogLevel.toString(configuration2.logVerbosity));
        args.push("--logFile", tsServerLogFile);
      }
    }
    const pluginPaths = [];
    if (pluginManager.plugins.length) {
      args.push("--globalPlugins", pluginManager.plugins.map((x) => x.name).join(","));
      for (const plugin of pluginManager.plugins) {
        pluginPaths.push(plugin.uri.fsPath);
      }
    }
    if (pluginPaths.length !== 0) {
      args.push("--pluginProbeLocations", pluginPaths.join(","));
    }
    if (npmLocation) {
      this._logger.info(`using npm from ${npmLocation}`);
      args.push("--npmLocation", `"${npmLocation}"`);
    }
    if (configuration2.useClientFileWatcher && apiVersion.gte(API.v544)) {
      args.push("--canUseWatchEvents");
    }
    args.push("--locale", locale || "en");
    args.push("--validateDefaultNpmLocation");
    return {
      args,
      tsServerLogFile
    };
  }
  isLoggingEnabled(configuration2) {
    return configuration2.logVerbosity !== TsServerLogLevel.Off;
  }
};
var Trace;
(function(Trace2) {
  Trace2[Trace2["Off"] = 0] = "Off";
  Trace2[Trace2["Messages"] = 1] = "Messages";
  Trace2[Trace2["Verbose"] = 2] = "Verbose";
})(Trace || (Trace = {}));
(function(Trace2) {
  function fromString(value) {
    value = value.toLowerCase();
    switch (value) {
      case "off":
        return Trace2.Off;
      case "messages":
        return Trace2.Messages;
      case "verbose":
        return Trace2.Verbose;
      default:
        return Trace2.Off;
    }
  }
  Trace2.fromString = fromString;
})(Trace || (Trace = {}));
var Tracer = class {
  logger;
  trace;
  constructor(logger, trace) {
    this.logger = logger;
    this.trace = trace;
  }
  traceRequest(serverId, request, responseExpected, queueLength) {
    if (this.trace === Trace.Off) {
      return;
    }
    let data = void 0;
    if (this.trace === Trace.Verbose && request.arguments) {
      data = `Arguments: ${JSON.stringify(request.arguments, null, 4)}`;
    }
    this.logTrace(serverId, `Sending request: ${request.command} (${request.seq}). Response expected: ${responseExpected ? "yes" : "no"}. Current queue length: ${queueLength}`, data);
  }
  traceResponse(serverId, response, meta) {
    if (this.trace === Trace.Off) {
      return;
    }
    let data = void 0;
    if (this.trace === Trace.Verbose && response.body) {
      data = `Result: ${JSON.stringify(response.body, null, 4)}`;
    }
    this.logTrace(serverId, `Response received: ${response.command} (${response.request_seq}). Request took ${Date.now() - meta.queuingStartTime} ms. Success: ${response.success} ${!response.success ? `. Message: ${response.message}` : ""}`, data);
  }
  traceRequestCompleted(serverId, command2, request_seq, meta) {
    if (this.trace === Trace.Off) {
      return;
    }
    this.logTrace(serverId, `Async response received: ${command2} (${request_seq}). Request took ${Date.now() - meta.queuingStartTime} ms.`);
  }
  traceEvent(serverId, event) {
    if (this.trace === Trace.Off) {
      return;
    }
    let data = void 0;
    if (this.trace === Trace.Verbose && event.body) {
      data = `Data: ${JSON.stringify(event.body, null, 4)}`;
    }
    this.logTrace(serverId, `Event received: ${event.event} (${event.seq}).`, data);
  }
  logTrace(serverId, message, data) {
    if (this.trace !== Trace.Off) {
      this.logger.trace("Trace", `<${serverId}> ${message}`, data);
    }
  }
};
var index_min = {};
var hasRequiredIndex_min;
function requireIndex_min() {
  if (hasRequiredIndex_min) return index_min;
  hasRequiredIndex_min = 1;
  (function(exports) {
    var a = (t, e) => () => (e || t((e = {
      exports: {}
    }).exports, e), e.exports);
    var _ = a((i) => {
      Object.defineProperty(i, "__esModule", {
        value: true
      });
      i.sync = i.isexe = void 0;
      var M = fs$2, x = fsPromises, q = async (t, e = {}) => {
        let { ignoreErrors: r = false } = e;
        try {
          return d(await (0, x.stat)(t), e);
        } catch (s) {
          let n = s;
          if (r || n.code === "EACCES") return false;
          throw n;
        }
      };
      i.isexe = q;
      var m = (t, e = {}) => {
        let { ignoreErrors: r = false } = e;
        try {
          return d((0, M.statSync)(t), e);
        } catch (s) {
          let n = s;
          if (r || n.code === "EACCES") return false;
          throw n;
        }
      };
      i.sync = m;
      var d = (t, e) => t.isFile() && A(t, e), A = (t, e) => {
        let r = e.uid ?? process.getuid?.(), s = e.groups ?? process.getgroups?.() ?? [], n = e.gid ?? process.getgid?.() ?? s[0];
        if (r === void 0 || n === void 0) throw new Error("cannot get uid or gid");
        let u = /* @__PURE__ */ new Set([n, ...s]), c = t.mode, S = t.uid, P = t.gid, f = parseInt("100", 8), l = parseInt("010", 8), j = parseInt("001", 8), C = f | l;
        return !!(c & j || c & l && u.has(P) || c & f && S === r || c & C && r === 0);
      };
    });
    var g = a((o) => {
      Object.defineProperty(o, "__esModule", {
        value: true
      });
      o.sync = o.isexe = void 0;
      var T = fs$2, I = fsPromises, D = path__default, F = async (t, e = {}) => {
        let { ignoreErrors: r = false } = e;
        try {
          return y(await (0, I.stat)(t), t, e);
        } catch (s) {
          let n = s;
          if (r || n.code === "EACCES") return false;
          throw n;
        }
      };
      o.isexe = F;
      var L = (t, e = {}) => {
        let { ignoreErrors: r = false } = e;
        try {
          return y((0, T.statSync)(t), t, e);
        } catch (s) {
          let n = s;
          if (r || n.code === "EACCES") return false;
          throw n;
        }
      };
      o.sync = L;
      var B = (t, e) => {
        let { pathExt: r = process.env.PATHEXT || "" } = e, s = r.split(D.delimiter);
        if (s.indexOf("") !== -1) return true;
        for (let n of s) {
          let u = n.toLowerCase(), c = t.substring(t.length - u.length).toLowerCase();
          if (u && c === u) return true;
        }
        return false;
      }, y = (t, e, r) => t.isFile() && B(e, r);
    });
    var p = a((h) => {
      Object.defineProperty(h, "__esModule", {
        value: true
      });
    });
    var v = exports && exports.__createBinding || (Object.create ? function(t, e, r, s) {
      s === void 0 && (s = r);
      var n = Object.getOwnPropertyDescriptor(e, r);
      (!n || ("get" in n ? !e.__esModule : n.writable || n.configurable)) && (n = {
        enumerable: true,
        get: function() {
          return e[r];
        }
      }), Object.defineProperty(t, s, n);
    } : function(t, e, r, s) {
      s === void 0 && (s = r), t[s] = e[r];
    }), G = exports && exports.__setModuleDefault || (Object.create ? function(t, e) {
      Object.defineProperty(t, "default", {
        enumerable: true,
        value: e
      });
    } : function(t, e) {
      t.default = e;
    }), w = exports && exports.__importStar || /* @__PURE__ */ (function() {
      var t = function(e) {
        return t = Object.getOwnPropertyNames || function(r) {
          var s = [];
          for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (s[s.length] = n);
          return s;
        }, t(e);
      };
      return function(e) {
        if (e && e.__esModule) return e;
        var r = {};
        if (e != null) for (var s = t(e), n = 0; n < s.length; n++) s[n] !== "default" && v(r, e, s[n]);
        return G(r, e), r;
      };
    })(), X = exports && exports.__exportStar || function(t, e) {
      for (var r in t) r !== "default" && !Object.prototype.hasOwnProperty.call(e, r) && v(e, t, r);
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.sync = exports.isexe = exports.posix = exports.win32 = void 0;
    var E = w(_());
    exports.posix = E;
    var O = w(g());
    exports.win32 = O;
    X(p(), exports);
    var H = process.env._ISEXE_TEST_PLATFORM_ || process.platform, b = H === "win32" ? O : E;
    exports.isexe = b.isexe;
    exports.sync = b.sync;
  })(index_min);
  return index_min;
}
var lib;
var hasRequiredLib;
function requireLib() {
  if (hasRequiredLib) return lib;
  hasRequiredLib = 1;
  const { isexe, sync: isexeSync } = requireIndex_min();
  const { join: join2, delimiter, sep, posix } = require$$1$1;
  const isWindows = process.platform === "win32";
  const rSlash = new RegExp(`[${posix.sep}${sep === posix.sep ? "" : sep}]`.replace(/(\\)/g, "\\$1"));
  const rRel = new RegExp(`^\\.${rSlash.source}`);
  const getNotFoundError = (cmd) => Object.assign(new Error(`not found: ${cmd}`), {
    code: "ENOENT"
  });
  const getPathInfo = (cmd, { path: optPath = process.env.PATH, pathExt: optPathExt = process.env.PATHEXT, delimiter: optDelimiter = delimiter }) => {
    const pathEnv = cmd.match(rSlash) ? [""] : [...isWindows ? [process.cwd()] : [], ...(optPath || "").split(optDelimiter)];
    if (isWindows) {
      const pathExtExe = optPathExt || [".EXE", ".CMD", ".BAT", ".COM"].join(optDelimiter);
      const pathExt = pathExtExe.split(optDelimiter).flatMap((item) => [item, item.toLowerCase()]);
      if (cmd.includes(".") && pathExt[0] !== "") {
        pathExt.unshift("");
      }
      return {
        pathEnv,
        pathExt,
        pathExtExe
      };
    }
    return {
      pathEnv,
      pathExt: [""]
    };
  };
  const getPathPart = (raw, cmd) => {
    const pathPart = /^".*"$/.test(raw) ? raw.slice(1, -1) : raw;
    const prefix = !pathPart && rRel.test(cmd) ? cmd.slice(0, 2) : "";
    return prefix + join2(pathPart, cmd);
  };
  const which2 = async (cmd, opt = {}) => {
    const { pathEnv, pathExt, pathExtExe } = getPathInfo(cmd, opt);
    const found = [];
    for (const envPart of pathEnv) {
      const p = getPathPart(envPart, cmd);
      for (const ext of pathExt) {
        const withExt = p + ext;
        const is2 = await isexe(withExt, {
          pathExt: pathExtExe,
          ignoreErrors: true
        });
        if (is2) {
          if (!opt.all) {
            return withExt;
          }
          found.push(withExt);
        }
      }
    }
    if (opt.all && found.length) {
      return found;
    }
    if (opt.nothrow) {
      return null;
    }
    throw getNotFoundError(cmd);
  };
  const whichSync = (cmd, opt = {}) => {
    const { pathEnv, pathExt, pathExtExe } = getPathInfo(cmd, opt);
    const found = [];
    for (const pathEnvPart of pathEnv) {
      const p = getPathPart(pathEnvPart, cmd);
      for (const ext of pathExt) {
        const withExt = p + ext;
        const is2 = isexeSync(withExt, {
          pathExt: pathExtExe,
          ignoreErrors: true
        });
        if (is2) {
          if (!opt.all) {
            return withExt;
          }
          found.push(withExt);
        }
      }
    }
    if (opt.all && found.length) {
      return found;
    }
    if (opt.nothrow) {
      return null;
    }
    throw getNotFoundError(cmd);
  };
  lib = which2;
  which2.sync = whichSync;
  return lib;
}
var libExports = requireLib();
var which = getDefaultExportFromCjs(libExports);
var toPath = (urlOrPath) => urlOrPath instanceof URL ? fileURLToPath(urlOrPath) : urlOrPath;
function findUpSync(name, { cwd = process$1.cwd(), type = "file", stopAt } = {}) {
  let directory = path__default.resolve(toPath(cwd) ?? "");
  const { root } = path__default.parse(directory);
  stopAt = path__default.resolve(directory, toPath(stopAt) ?? root);
  const isAbsoluteName = path__default.isAbsolute(name);
  while (directory) {
    const filePath = isAbsoluteName ? name : path__default.join(directory, name);
    try {
      const stats = fs$2.statSync(filePath, {
        throwIfNoEntry: false
      });
      if (type === "file" && stats?.isFile() || type === "directory" && stats?.isDirectory()) {
        return filePath;
      }
    } catch {
    }
    if (directory === stopAt || directory === root) {
      break;
    }
    directory = path__default.dirname(directory);
  }
}
function packageUpSync({ cwd = process$1.cwd() } = {}) {
  return findUpSync("package.json", {
    cwd
  });
}
function findPathToModule(dir, moduleNames) {
  const stat2 = statSync(dir);
  if (stat2.isDirectory()) {
    const candidates = moduleNames.map((moduleName) => resolve(dir, moduleName));
    const modulePath = candidates.find(existsSync);
    if (modulePath) {
      return modulePath;
    }
  }
  const parent = resolve(dir, "..");
  if (parent !== dir) {
    return findPathToModule(parent, moduleNames);
  }
}
var TypeScriptVersionSource;
(function(TypeScriptVersionSource2) {
  TypeScriptVersionSource2["Bundled"] = "bundled";
  TypeScriptVersionSource2["UserSetting"] = "user-setting";
  TypeScriptVersionSource2["Workspace"] = "workspace";
})(TypeScriptVersionSource || (TypeScriptVersionSource = {}));
var TypeScriptVersion = class {
  source;
  path;
  logger;
  _api;
  constructor(source, path2, logger) {
    this.source = source;
    this.path = path2;
    this.logger = logger;
    this._api = null;
  }
  get tsServerPath() {
    return this.path;
  }
  get isValid() {
    return this.version !== null;
  }
  get version() {
    if (this._api) {
      return this._api;
    }
    this._api = this.getTypeScriptVersion(this.tsServerPath);
    return this._api;
  }
  get versionString() {
    const version2 = this.version;
    return version2 ? version2.displayName : null;
  }
  getTypeScriptVersion(serverPath) {
    this.logger.log(`Resolving TypeScript version from path "${serverPath}"...`);
    if (!fs$2.existsSync(serverPath)) {
      this.logger.log("Server path does not exist on disk");
      return null;
    }
    const p = serverPath.split(path__default.sep);
    if (p.length <= 2) {
      this.logger.log("Server path is invalid (has less than two path components).");
      return null;
    }
    const p2 = p.slice(0, -2);
    const modulePath = p2.join(path__default.sep);
    let fileName = path__default.join(modulePath, "package.json");
    if (!fs$2.existsSync(fileName)) {
      if (path__default.basename(modulePath) === "built") {
        fileName = path__default.join(modulePath, "..", "package.json");
      }
    }
    if (!fs$2.existsSync(fileName)) {
      this.logger.log(`Failed to find package.json at path "${fileName}"`);
      return null;
    }
    this.logger.log(`Reading version from package.json at "${fileName}"`);
    const contents = fs$2.readFileSync(fileName).toString();
    let desc;
    try {
      desc = JSON.parse(contents);
    } catch {
      this.logger.log("Failed parsing contents of package.json.");
      return null;
    }
    if (!desc?.version) {
      this.logger.log("Failed reading version number from package.json.");
      return null;
    }
    this.logger.log(`Resolved TypeScript version to "${desc.version}"`);
    return API.fromVersionString(desc.version);
  }
};
var MODULE_FOLDERS = ["node_modules/typescript/lib", ".vscode/pnpify/typescript/lib", ".yarn/sdks/typescript/lib"];
var TypeScriptVersionProvider = class {
  userTsserverPath;
  logger;
  constructor(userTsserverPath, logger) {
    this.userTsserverPath = userTsserverPath;
    this.logger = logger;
  }
  getUserSettingVersion() {
    if (!this.userTsserverPath) {
      return null;
    }
    this.logger.log(`Resolving user-provided tsserver path "${this.userTsserverPath}"...`);
    let resolvedPath = this.userTsserverPath;
    if (!path__default.isAbsolute(resolvedPath)) {
      const binaryPath = which.sync(resolvedPath, {
        nothrow: true
      });
      if (binaryPath) {
        resolvedPath = binaryPath;
      }
      this.logger.log(`Non-absolute tsserver path resolved to "${binaryPath ? resolvedPath : "<failed>"}"`);
    }
    let stat2 = fs$2.lstatSync(resolvedPath, {
      throwIfNoEntry: false
    });
    if (stat2?.isSymbolicLink()) {
      resolvedPath = fs$2.realpathSync(resolvedPath);
      this.logger.log(`Symbolic link tsserver path resolved to "${resolvedPath}"`);
    }
    stat2 = fs$2.lstatSync(resolvedPath, {
      throwIfNoEntry: false
    });
    if (stat2?.isFile()) {
      if (path__default.basename(resolvedPath) === "tsserver.js") {
        this.logger.log(`Resolved tsserver location: ${resolvedPath}`);
        return new TypeScriptVersion(TypeScriptVersionSource.UserSetting, resolvedPath, this.logger);
      }
      resolvedPath = path__default.dirname(resolvedPath);
      this.logger.log(`Resolved directory path from a file path: ${resolvedPath}`);
    }
    try {
      const packageJsonPath = packageUpSync({
        cwd: resolvedPath
      });
      this.logger.log(`Resolved package.json location: "${packageJsonPath}"`);
      if (packageJsonPath) {
        resolvedPath = path__default.join(path__default.dirname(packageJsonPath), "lib", "tsserver.js");
        this.logger.log(`Resolved tsserver location: "${resolvedPath}"`);
      }
    } catch {
    }
    return new TypeScriptVersion(TypeScriptVersionSource.UserSetting, resolvedPath, this.logger);
  }
  getWorkspaceVersion(workspaceFolders) {
    for (const p of workspaceFolders) {
      const libFolder = findPathToModule(p, MODULE_FOLDERS);
      if (libFolder) {
        const tsServerPath = path__default.join(libFolder, "tsserver.js");
        const version2 = new TypeScriptVersion(TypeScriptVersionSource.Workspace, tsServerPath, this.logger);
        if (version2.isValid) {
          return version2;
        }
      }
    }
    return null;
  }
  bundledVersion() {
    const require2 = createRequire(import.meta.url);
    try {
      const file2 = require2.resolve("typescript");
      const tsServerPath = path__default.join(path__default.dirname(file2), "tsserver.js");
      const bundledVersion = new TypeScriptVersion(TypeScriptVersionSource.Bundled, tsServerPath, this.logger);
      return bundledVersion;
    } catch {
      return null;
    }
  }
};
var ZipfileURI = class _ZipfileURI extends URI {
  _originalUri;
  constructor(uri, components) {
    super(components);
    this._originalUri = uri;
  }
  toString(_skipEncoding = false) {
    return this._originalUri;
  }
  static parse(value, _strict = false) {
    const uri = URI.parse(value, _strict);
    return new _ZipfileURI(value, uri);
  }
};
var ServerState;
(function(ServerState2) {
  let Type;
  (function(Type2) {
    Type2[Type2["None"] = 0] = "None";
    Type2[Type2["Running"] = 1] = "Running";
    Type2[Type2["Errored"] = 2] = "Errored";
  })(Type = ServerState2.Type || (ServerState2.Type = {}));
  ServerState2.None = {
    type: Type.None
  };
  class Running {
    server;
    apiVersion;
    tsserverVersion;
    languageServiceEnabled;
    type = Type.Running;
    constructor(server2, apiVersion, tsserverVersion, languageServiceEnabled) {
      this.server = server2;
      this.apiVersion = apiVersion;
      this.tsserverVersion = tsserverVersion;
      this.languageServiceEnabled = languageServiceEnabled;
    }
    toCancelOnResourceChange = /* @__PURE__ */ new Set();
    updateTsserverVersion(tsserverVersion) {
      this.tsserverVersion = tsserverVersion;
    }
    updateLanguageServiceEnabled(enabled) {
      this.languageServiceEnabled = enabled;
    }
  }
  ServerState2.Running = Running;
  class Errored {
    error;
    tsServerLogFile;
    type = Type.Errored;
    constructor(error2, tsServerLogFile) {
      this.error = error2;
      this.tsServerLogFile = tsServerLogFile;
    }
  }
  ServerState2.Errored = Errored;
})(ServerState || (ServerState = {}));
var DiagnosticKind;
(function(DiagnosticKind2) {
  DiagnosticKind2[DiagnosticKind2["Syntax"] = 0] = "Syntax";
  DiagnosticKind2[DiagnosticKind2["Semantic"] = 1] = "Semantic";
  DiagnosticKind2[DiagnosticKind2["Suggestion"] = 2] = "Suggestion";
})(DiagnosticKind || (DiagnosticKind = {}));
function getDignosticsKind(event) {
  switch (event.event) {
    case "syntaxDiag":
      return DiagnosticKind.Syntax;
    case "semanticDiag":
      return DiagnosticKind.Semantic;
    case "suggestionDiag":
      return DiagnosticKind.Suggestion;
  }
  throw new Error("Unknown dignostics kind");
}
var ServerInitializingIndicator = class {
  lspClient;
  _loadingProjectName;
  _task;
  constructor(lspClient) {
    this.lspClient = lspClient;
  }
  reset() {
    if (this._task) {
      const task = this._task;
      this._task = void 0;
      task.then((reporter) => reporter.done());
    }
  }
  startedLoadingProject(projectName) {
    this.reset();
    this._loadingProjectName = projectName;
    this._task = this.lspClient.createProgressReporter();
    this._task.then((reporter) => reporter.begin("Initializing JS/TS language features\u2026"));
  }
  finishedLoadingProject(projectName) {
    if (this._loadingProjectName === projectName) {
      this.reset();
    }
  }
};
var emptyAuthority = "ts-nul-authority";
var inMemoryResourcePrefix = "^";
var RE_IN_MEMORY_FILEPATH = /^\^\/([^/]+)\/([^/]*)\/(.+)$/;
var TsClient = class {
  apiVersion = API.defaultVersion;
  typescriptVersionSource = TypeScriptVersionSource.Bundled;
  pluginManager;
  serverState = ServerState.None;
  lspClient;
  logger;
  tsserverLogger;
  loadingIndicator;
  isNeovimHost = false;
  tracer;
  workspaceFolders = [];
  documents;
  useSyntaxServer = SyntaxServerConfiguration.Auto;
  onEvent;
  onExit;
  constructor(onCaseInsensitiveFileSystem2, logger, lspClient) {
    this.pluginManager = new PluginManager();
    this.documents = new LspDocuments(this, lspClient, onCaseInsensitiveFileSystem2);
    this.logger = new PrefixingLogger(logger, "[tsclient]");
    this.tsserverLogger = new PrefixingLogger(this.logger, "[tsserver]");
    this.lspClient = lspClient;
    this.loadingIndicator = new ServerInitializingIndicator(this.lspClient);
  }
  get documentsForTesting() {
    return this.documents.documentsForTesting;
  }
  openTextDocument(textDocument) {
    return this.documents.openTextDocument(textDocument);
  }
  onDidCloseTextDocument(uri) {
    this.documents.onDidCloseTextDocument(uri);
  }
  onDidChangeTextDocument(params) {
    this.documents.onDidChangeTextDocument(params);
  }
  lastFileOrDummy() {
    return this.documents.files[0] || this.workspaceFolders[0]?.uri.fsPath;
  }
  toTsFilePath(stringUri) {
    if (this.isNeovimHost && stringUri.startsWith("zipfile:")) {
      return stringUri;
    }
    const resource = URI.parse(stringUri);
    if (disabledSchemes.has(resource.scheme)) {
      return void 0;
    }
    if (resource.scheme === file) {
      return resource.fsPath;
    }
    return inMemoryResourcePrefix + "/" + resource.scheme + "/" + (resource.authority || emptyAuthority) + (resource.path.startsWith("/") ? resource.path : "/" + resource.path) + (resource.fragment ? "#" + resource.fragment : "");
  }
  toOpenDocument(textDocumentUri, options2 = {}) {
    const filepath = this.toTsFilePath(textDocumentUri);
    const document = filepath && this.documents.get(filepath);
    if (!document) {
      const uri = URI.parse(textDocumentUri);
      if (!options2.suppressAlertOnFailure && !disabledSchemes.has(uri.scheme)) {
        console.error(`Unexpected resource ${textDocumentUri}`);
      }
      return void 0;
    }
    return document;
  }
  requestDiagnosticsForTesting() {
    this.documents.requestDiagnosticsForTesting();
  }
  hasPendingDiagnostics(resource) {
    return this.documents.hasPendingDiagnostics(resource);
  }
  toResource(filepath) {
    if (this.isNeovimHost && filepath.startsWith("zipfile:")) {
      return ZipfileURI.parse(filepath);
    }
    if (filepath.startsWith(inMemoryResourcePrefix)) {
      const parts = filepath.match(RE_IN_MEMORY_FILEPATH);
      if (parts) {
        const resource = URI.parse(parts[1] + "://" + (parts[2] === emptyAuthority ? "" : parts[2]) + "/" + parts[3]);
        const tsFilepath = this.toTsFilePath(resource.toString());
        const document2 = tsFilepath && this.documents.get(tsFilepath);
        return document2 ? document2.uri : resource;
      }
    }
    const fileUri = URI.file(filepath);
    const document = this.documents.get(fileUri.fsPath);
    return document ? document.uri : fileUri;
  }
  toResourceUri(filepath) {
    return this.toResource(filepath).toString();
  }
  getWorkspaceRootForResource(resource) {
    for (const root of this.workspaceFolders.sort((a, b) => a.uri.fsPath.length - b.uri.fsPath.length)) {
      if (root.uri.scheme === resource.scheme && root.uri.authority === resource.authority) {
        if (resource.fsPath.startsWith(root.uri.fsPath + path__default.sep)) {
          return root.uri;
        }
      }
    }
    return void 0;
  }
  get capabilities() {
    if (this.useSyntaxServer === SyntaxServerConfiguration.Always) {
      return new ClientCapabilities(ClientCapability.Syntax, ClientCapability.EnhancedSyntax);
    }
    if (this.apiVersion.gte(API.v400)) {
      return new ClientCapabilities(ClientCapability.Syntax, ClientCapability.EnhancedSyntax, ClientCapability.Semantic);
    }
    return new ClientCapabilities(ClientCapability.Syntax, ClientCapability.Semantic);
  }
  hasCapabilityForResource(resource, capability) {
    if (!this.capabilities.has(capability)) {
      return false;
    }
    switch (capability) {
      case ClientCapability.Semantic: {
        return getSemanticSupportedSchemes().includes(resource.scheme);
      }
      case ClientCapability.Syntax:
      case ClientCapability.EnhancedSyntax: {
        return true;
      }
    }
  }
  configurePlugin(pluginName, configuration2) {
    if (this.apiVersion.gte(API.v314)) {
      this.executeWithoutWaitingForResponse(CommandTypes.ConfigurePlugin, {
        pluginName,
        configuration: configuration2
      });
    }
  }
  sendWatchChanges(args) {
    this.executeWithoutWaitingForResponse(CommandTypes.WatchChange, args);
  }
  start(workspaceRoot, options2) {
    this.apiVersion = options2.typescriptVersion.version || API.defaultVersion;
    this.typescriptVersionSource = options2.typescriptVersion.source;
    this.isNeovimHost = options2.hostInfo === "neovim";
    this.tracer = new Tracer(this.tsserverLogger, options2.trace);
    this.workspaceFolders = workspaceRoot ? [{
      uri: URI.file(workspaceRoot)
    }] : [];
    this.useSyntaxServer = options2.useSyntaxServer;
    this.onEvent = options2.onEvent;
    this.onExit = options2.onExit;
    this.pluginManager.setPlugins(options2.plugins);
    const modeIds = [...jsTsLanguageModes, ...this.pluginManager.plugins.flatMap((x) => x.languages)];
    this.documents.initialize(modeIds);
    const tsServerSpawner = new TypeScriptServerSpawner(this.apiVersion, options2.logDirectoryProvider, this.logger, this.tracer);
    const tsServer = tsServerSpawner.spawn(options2.typescriptVersion, this.capabilities, options2, this.pluginManager, {
      onFatalError: (command2, err) => this.fatalError(command2, err)
    });
    this.serverState = new ServerState.Running(tsServer, this.apiVersion, void 0, true);
    tsServer.onExit((data) => {
      this.serverState = ServerState.None;
      this.shutdown();
      this.tsserverLogger.error(`Exited. Code: ${data.code}. Signal: ${data.signal}`);
      this.onExit?.(data.code, data.signal);
    });
    tsServer.onStdErr((error2) => {
      if (error2) {
        this.logger.error(error2);
      }
    });
    tsServer.onError((err) => {
      this.serverState = new ServerState.Errored(err, tsServer.tsServerLogFile);
      if (err) {
        this.tsserverLogger.error("Exited with error. Error message is: {0}", err.message || err.name);
      }
      this.serviceExited();
    });
    tsServer.onEvent((event) => this.dispatchEvent(event));
    return true;
  }
  serviceExited() {
    if (this.serverState.type === ServerState.Type.Running) {
      this.serverState.server.kill();
    }
    this.loadingIndicator.reset();
  }
  dispatchEvent(event) {
    switch (event.event) {
      case EventName.syntaxDiag:
      case EventName.semanticDiag:
      case EventName.suggestionDiag:
      case EventName.configFileDiag:
        this.loadingIndicator.reset();
      case EventName.createDirectoryWatcher:
      case EventName.createFileWatcher:
      case EventName.closeFileWatcher: {
        this.onEvent?.(event);
        break;
      }
      case EventName.projectsUpdatedInBackground: {
        this.loadingIndicator.reset();
        const body = event.body;
        const resources = body.openFiles.map((file2) => this.toResource(file2));
        this.documents.getErr(resources);
        break;
      }
      case EventName.projectLoadingStart:
        this.loadingIndicator.startedLoadingProject(event.body.projectName);
        break;
      case EventName.projectLoadingFinish:
        this.loadingIndicator.finishedLoadingProject(event.body.projectName);
        break;
    }
  }
  shutdown() {
    if (this.loadingIndicator) {
      this.loadingIndicator.reset();
    }
    if (this.serverState.type === ServerState.Type.Running) {
      this.serverState.server.kill();
    }
    this.serverState = ServerState.None;
  }
  execute(command2, args, token, config) {
    let executions;
    if (config?.cancelOnResourceChange) {
      const runningServerState = this.serverState;
      if (token && runningServerState.type === ServerState.Type.Running) {
        const source = new mainExports$1.CancellationTokenSource();
        token.onCancellationRequested(() => source.cancel());
        const inFlight = {
          resource: config.cancelOnResourceChange,
          cancel: () => source.cancel()
        };
        runningServerState.toCancelOnResourceChange.add(inFlight);
        executions = this.executeImpl(command2, args, {
          isAsync: false,
          token: source.token,
          expectsResult: true,
          ...config
        });
        executions[0].catch(() => {
        }).finally(() => {
          runningServerState.toCancelOnResourceChange.delete(inFlight);
          source.dispose();
        });
      }
    }
    if (!executions) {
      executions = this.executeImpl(command2, args, {
        isAsync: false,
        token,
        expectsResult: true,
        ...config
      });
    }
    if (config?.nonRecoverable) {
      executions[0].catch((err) => this.fatalError(command2, err));
    }
    if (command2 === CommandTypes.UpdateOpen) {
      const executionsWithResults = executions.filter((e) => e !== void 0);
      Promise.all(executionsWithResults).then(() => {
        this.loadingIndicator.reset();
      });
    }
    return executions[0].catch((error2) => {
      throw new mainExports$2.ResponseError(1, error2.message);
    });
  }
  executeWithoutWaitingForResponse(command2, args) {
    this.executeImpl(command2, args, {
      isAsync: false,
      token: void 0,
      expectsResult: false
    });
  }
  executeAsync(command2, args, token) {
    return this.executeImpl(command2, args, {
      isAsync: true,
      token,
      expectsResult: true
    })[0];
  }
  executeCustom(command2, args, executeInfo) {
    const updatedExecuteInfo = {
      expectsResult: true,
      isAsync: false,
      ...executeInfo
    };
    const executions = this.executeImpl(command2, args, updatedExecuteInfo);
    return executions[0].catch((error2) => {
      throw new mainExports$2.ResponseError(1, error2.message);
    });
  }
  interruptGetErr(f) {
    return this.documents.interruptGetErr(f);
  }
  cancelInflightRequestsForResource(resource) {
    if (this.serverState.type !== ServerState.Type.Running) {
      return;
    }
    for (const request of this.serverState.toCancelOnResourceChange) {
      if (request.resource === resource.toString()) {
        request.cancel();
      }
    }
  }
  executeImpl(command2, args, executeInfo) {
    const serverState = this.serverState;
    if (serverState.type === ServerState.Type.Running) {
      return serverState.server.executeImpl(command2, args, executeInfo);
    } else {
      return [Promise.resolve(ServerResponse.NoServer)];
    }
  }
  fatalError(command2, error2) {
    this.tsserverLogger.error(`A non-recoverable error occurred while executing command: ${command2}`);
    if (error2 instanceof TypeScriptServerError && error2.serverErrorText) {
      this.tsserverLogger.error(error2.serverErrorText);
    }
    if (this.serverState.type === ServerState.Type.Running) {
      this.logger.info("Killing TS Server");
      const logfile = this.serverState.server.tsServerLogFile;
      this.serverState.server.kill();
      if (error2 instanceof TypeScriptServerError) {
        this.serverState = new ServerState.Errored(error2, logfile);
      }
    }
  }
};
var pDebounce = (functionToDebounce, wait, options2 = {}) => {
  if (!Number.isFinite(wait)) {
    throw new TypeError("Expected `wait` to be a finite number");
  }
  let leadingValue;
  let timeout;
  let promiseHandlers = [];
  const onAbort = () => {
    clearTimeout(timeout);
    timeout = void 0;
    try {
      options2.signal?.throwIfAborted();
    } catch (error2) {
      for (const { reject } of promiseHandlers) {
        reject(error2);
      }
      promiseHandlers = [];
    }
  };
  return function(...arguments_) {
    return new Promise((resolve2, reject) => {
      try {
        options2.signal?.throwIfAborted();
      } catch (error2) {
        reject(error2);
        return;
      }
      const shouldCallNow = options2.before && !timeout;
      clearTimeout(timeout);
      timeout = setTimeout(async () => {
        timeout = void 0;
        const currentHandlers = promiseHandlers;
        promiseHandlers = [];
        try {
          const result = options2.before ? leadingValue : await functionToDebounce.apply(this, arguments_);
          for (const { resolve: resolveFunction } of currentHandlers) {
            resolveFunction(result);
          }
        } catch (error2) {
          for (const { reject: rejectFunction } of currentHandlers) {
            rejectFunction(error2);
          }
        }
        leadingValue = void 0;
        options2.signal?.removeEventListener("abort", onAbort);
      }, wait);
      if (shouldCallNow) {
        (async () => {
          try {
            leadingValue = await functionToDebounce.apply(this, arguments_);
            resolve2(leadingValue);
          } catch (error2) {
            reject(error2);
          }
        })();
      } else {
        promiseHandlers.push({
          resolve: resolve2,
          reject
        });
        if (options2.signal && promiseHandlers.length === 1) {
          options2.signal.addEventListener("abort", onAbort, {
            once: true
          });
        }
      }
    });
  };
};
pDebounce.promise = (function_, options2 = {}) => {
  let currentPromise;
  let queuedCall;
  return async function(...arguments_) {
    if (currentPromise) {
      if (!options2.after) {
        return currentPromise;
      }
      queuedCall ??= {
        resolvers: []
      };
      queuedCall.arguments = arguments_;
      queuedCall.context = this;
      return new Promise((resolve2, reject) => {
        queuedCall.resolvers.push({
          resolve: resolve2,
          reject
        });
      });
    }
    currentPromise = (async () => {
      let result;
      let initialError;
      try {
        result = await function_.apply(this, arguments_);
      } catch (error2) {
        initialError = error2;
      }
      while (queuedCall) {
        const call = queuedCall;
        queuedCall = void 0;
        try {
          const queuedResult = await function_.apply(call.context, call.arguments);
          for (const { resolve: resolve2 } of call.resolvers) {
            resolve2(queuedResult);
          }
        } catch (error2) {
          for (const { reject } of call.resolvers) {
            reject(error2);
          }
        }
      }
      if (initialError) {
        throw initialError;
      }
      return result;
    })();
    try {
      return await currentPromise;
    } finally {
      currentPromise = void 0;
    }
  };
};
var Range;
(function(Range2) {
  Range2.fromTextSpan = (span) => Range2.fromLocations(span.start, span.end);
  Range2.toTextSpan = (range2) => ({
    start: Position.toLocation(range2.start),
    end: Position.toLocation(range2.end)
  });
  Range2.fromLocations = (start, end) => mainExports.Range.create(Math.max(0, start.line - 1), Math.max(start.offset - 1, 0), Math.max(0, end.line - 1), Math.max(0, end.offset - 1));
  Range2.toFileRangeRequestArgs = (file2, range2) => ({
    file: file2,
    startLine: range2.start.line + 1,
    startOffset: range2.start.character + 1,
    endLine: range2.end.line + 1,
    endOffset: range2.end.character + 1
  });
  Range2.toFormattingRequestArgs = (file2, range2) => ({
    file: file2,
    line: range2.start.line + 1,
    offset: range2.start.character + 1,
    endLine: range2.end.line + 1,
    endOffset: range2.end.character + 1
  });
  function intersection(one, other) {
    const start = Position.Max(other.start, one.start);
    const end = Position.Min(other.end, one.end);
    if (Position.isAfter(start, end)) {
      return void 0;
    }
    return mainExports.Range.create(start, end);
  }
  Range2.intersection = intersection;
  function union(one, other) {
    const start = Position.Min(other.start, one.start);
    const end = Position.Max(other.end, one.end);
    return mainExports.Range.create(start, end);
  }
  Range2.union = union;
})(Range || (Range = {}));
var Position;
(function(Position2) {
  Position2.fromLocation = (tslocation) => ({
    line: Math.max(tslocation.line - 1, 0),
    character: Math.max(tslocation.offset - 1, 0)
  });
  Position2.toLocation = (position) => ({
    line: position.line + 1,
    offset: position.character + 1
  });
  Position2.toFileLocationRequestArgs = (file2, position) => ({
    file: file2,
    line: position.line + 1,
    offset: position.character + 1
  });
  function Min(...positions) {
    if (!positions.length) {
      return void 0;
    }
    let result = positions.pop();
    for (const p of positions) {
      if (isBefore(p, result)) {
        result = p;
      }
    }
    return result;
  }
  Position2.Min = Min;
  function isBefore(one, other) {
    if (one.line < other.line) {
      return true;
    }
    if (other.line < one.line) {
      return false;
    }
    return one.character < other.character;
  }
  Position2.isBefore = isBefore;
  function isEqual(one, other) {
    return one.line === other.line && one.character === other.character;
  }
  Position2.isEqual = isEqual;
  function Max(...positions) {
    if (!positions.length) {
      return void 0;
    }
    let result = positions.pop();
    for (const p of positions) {
      if (isAfter(p, result)) {
        result = p;
      }
    }
    return result;
  }
  Position2.Max = Max;
  function isAfter(one, other) {
    return !isBeforeOrEqual(one, other);
  }
  Position2.isAfter = isAfter;
  function isBeforeOrEqual(one, other) {
    if (one.line < other.line) {
      return true;
    }
    if (other.line < one.line) {
      return false;
    }
    return one.character <= other.character;
  }
  Position2.isBeforeOrEqual = isBeforeOrEqual;
})(Position || (Position = {}));
var Location;
(function(Location2) {
  Location2.fromTextSpan = (resource, tsTextSpan) => mainExports.Location.create(resource, Range.fromTextSpan(tsTextSpan));
})(Location || (Location = {}));
function toLocation(fileSpan, client) {
  const uri = client.toResourceUri(fileSpan.file);
  return {
    uri,
    range: {
      start: Position.fromLocation(fileSpan.start),
      end: Position.fromLocation(fileSpan.end)
    }
  };
}
var symbolKindsMapping = {
  "enum member": mainExports$2.SymbolKind.Constant,
  "JSX attribute": mainExports$2.SymbolKind.Property,
  "local class": mainExports$2.SymbolKind.Class,
  "local function": mainExports$2.SymbolKind.Function,
  "local var": mainExports$2.SymbolKind.Variable,
  "type parameter": mainExports$2.SymbolKind.Variable,
  alias: mainExports$2.SymbolKind.Variable,
  class: mainExports$2.SymbolKind.Class,
  const: mainExports$2.SymbolKind.Constant,
  constructor: mainExports$2.SymbolKind.Constructor,
  enum: mainExports$2.SymbolKind.Enum,
  field: mainExports$2.SymbolKind.Field,
  file: mainExports$2.SymbolKind.File,
  function: mainExports$2.SymbolKind.Function,
  getter: mainExports$2.SymbolKind.Method,
  interface: mainExports$2.SymbolKind.Interface,
  let: mainExports$2.SymbolKind.Variable,
  method: mainExports$2.SymbolKind.Method,
  module: mainExports$2.SymbolKind.Module,
  parameter: mainExports$2.SymbolKind.Variable,
  property: mainExports$2.SymbolKind.Property,
  setter: mainExports$2.SymbolKind.Method,
  var: mainExports$2.SymbolKind.Variable
};
function toSymbolKind(tspKind) {
  return symbolKindsMapping[tspKind] || mainExports$2.SymbolKind.Variable;
}
function toDiagnosticSeverity(category) {
  switch (category) {
    case "error":
      return mainExports$2.DiagnosticSeverity.Error;
    case "warning":
      return mainExports$2.DiagnosticSeverity.Warning;
    case "suggestion":
      return mainExports$2.DiagnosticSeverity.Hint;
    default:
      return mainExports$2.DiagnosticSeverity.Error;
  }
}
function toDiagnostic(diagnostic2, client, features) {
  const lspDiagnostic = {
    range: {
      start: Position.fromLocation(diagnostic2.start),
      end: Position.fromLocation(diagnostic2.end)
    },
    message: diagnostic2.text,
    severity: toDiagnosticSeverity(diagnostic2.category),
    code: diagnostic2.code,
    source: diagnostic2.source || "typescript",
    relatedInformation: asRelatedInformation(diagnostic2.relatedInformation, client)
  };
  if (features.diagnosticsTagSupport) {
    lspDiagnostic.tags = getDiagnosticTags(diagnostic2);
  }
  return lspDiagnostic;
}
function getDiagnosticTags(diagnostic2) {
  const tags = [];
  if (diagnostic2.reportsUnnecessary) {
    tags.push(mainExports$2.DiagnosticTag.Unnecessary);
  }
  if (diagnostic2.reportsDeprecated) {
    tags.push(mainExports$2.DiagnosticTag.Deprecated);
  }
  return tags;
}
function asRelatedInformation(info, client) {
  if (!info) {
    return void 0;
  }
  const result = [];
  for (const item of info) {
    const span = item.span;
    if (span) {
      result.push(mainExports$2.DiagnosticRelatedInformation.create(toLocation(span, client), item.message));
    }
  }
  return result;
}
function toSelectionRange(range2) {
  return mainExports$2.SelectionRange.create(Range.fromTextSpan(range2.textSpan), range2.parent ? toSelectionRange(range2.parent) : void 0);
}
function toTextEdit(edit) {
  return {
    range: {
      start: Position.fromLocation(edit.start),
      end: Position.fromLocation(edit.end)
    },
    newText: edit.newText
  };
}
function toTextDocumentEdit(change, client) {
  const uri = client.toResourceUri(change.fileName);
  const document = client.toOpenDocument(uri);
  return {
    textDocument: {
      uri,
      version: document?.version ?? null
    },
    edits: change.textChanges.map((c) => toTextEdit(c))
  };
}
function toDocumentHighlight(item) {
  return item.highlightSpans.map((i) => ({
    kind: toDocumentHighlightKind(i.kind),
    range: {
      start: Position.fromLocation(i.start),
      end: Position.fromLocation(i.end)
    }
  }));
}
function toDocumentHighlightKind(kind) {
  switch (kind) {
    case HighlightSpanKind.definition:
      return mainExports$2.DocumentHighlightKind.Write;
    case HighlightSpanKind.reference:
    case HighlightSpanKind.writtenReference:
      return mainExports$2.DocumentHighlightKind.Read;
    default:
      return mainExports$2.DocumentHighlightKind.Text;
  }
}
var FileDiagnostics = class {
  uri;
  onPublishDiagnostics;
  client;
  features;
  closed = false;
  diagnosticsPerKind = /* @__PURE__ */ new Map();
  firePublishDiagnostics = pDebounce(() => this.publishDiagnostics(), 50);
  constructor(uri, onPublishDiagnostics, client, features) {
    this.uri = uri;
    this.onPublishDiagnostics = onPublishDiagnostics;
    this.client = client;
    this.features = features;
  }
  update(kind, diagnostics) {
    if (this.diagnosticsPerKind.get(kind)?.length === 0 && diagnostics.length === 0) {
      return;
    }
    this.diagnosticsPerKind.set(kind, diagnostics);
    this.firePublishDiagnostics();
  }
  publishDiagnostics() {
    if (this.closed || !this.features.diagnosticsSupport) {
      return;
    }
    const diagnostics = this.getDiagnostics();
    this.onPublishDiagnostics({
      uri: this.uri,
      diagnostics
    });
  }
  getDiagnostics() {
    const result = [];
    for (const diagnostics of this.diagnosticsPerKind.values()) {
      for (const diagnostic2 of diagnostics) {
        result.push(toDiagnostic(diagnostic2, this.client, this.features));
      }
    }
    return result;
  }
  onDidClose() {
    this.diagnosticsPerKind.clear();
    this.publishDiagnostics();
    this.closed = true;
  }
  async waitForDiagnosticsForTesting() {
    return new Promise((resolve2) => {
      const interval = setInterval(() => {
        if (this.diagnosticsPerKind.size === 3) {
          clearInterval(interval);
          this.publishDiagnostics();
          resolve2();
        }
      }, 50);
    });
  }
};
var DiagnosticsManager = class {
  publishDiagnostics;
  client;
  features;
  logger;
  diagnostics = /* @__PURE__ */ new Map();
  ignoredDiagnosticCodes = /* @__PURE__ */ new Set();
  constructor(publishDiagnostics, client, features, logger) {
    this.publishDiagnostics = publishDiagnostics;
    this.client = client;
    this.features = features;
    this.logger = logger;
  }
  updateDiagnostics(kind, file2, diagnostics) {
    if (kind !== DiagnosticKind.Syntax && !this.client.hasCapabilityForResource(this.client.toResource(file2), ClientCapability.Semantic)) {
      return;
    }
    if (this.ignoredDiagnosticCodes.size) {
      diagnostics = diagnostics.filter((diagnostic2) => !this.isDiagnosticIgnored(diagnostic2));
    }
    const uri = this.client.toResourceUri(file2);
    const diagnosticsForFile = this.diagnostics.get(uri) || new FileDiagnostics(uri, this.publishDiagnostics, this.client, this.features);
    diagnosticsForFile.update(kind, diagnostics);
    this.diagnostics.set(uri, diagnosticsForFile);
  }
  updateIgnoredDiagnosticCodes(ignoredCodes) {
    this.ignoredDiagnosticCodes = new Set(ignoredCodes);
  }
  getDiagnosticsForFile(file2) {
    const uri = this.client.toResourceUri(file2);
    return this.diagnostics.get(uri)?.getDiagnostics() || [];
  }
  onDidCloseFile(file2) {
    const uri = this.client.toResourceUri(file2);
    const diagnosticsForFile = this.diagnostics.get(uri);
    diagnosticsForFile?.onDidClose();
    this.diagnostics.delete(uri);
  }
  clearDiagnosticsForFile(file2) {
    if (!this.features.diagnosticsSupport) {
      return;
    }
    const uri = this.client.toResourceUri(file2);
    const diagnosticsForFile = this.diagnostics.get(uri);
    if (diagnosticsForFile) {
      diagnosticsForFile.onDidClose();
      this.diagnostics.delete(uri);
    } else {
      this.publishDiagnostics({
        uri,
        diagnostics: []
      });
    }
  }
  async waitForDiagnosticsForTesting(file2) {
    const uri = this.client.toResourceUri(file2);
    let diagnosticsForFile = this.diagnostics.get(uri);
    if (diagnosticsForFile) {
      diagnosticsForFile.onDidClose();
    }
    diagnosticsForFile = new FileDiagnostics(uri, this.publishDiagnostics, this.client, this.features);
    this.diagnostics.set(uri, diagnosticsForFile);
    this.client.requestDiagnosticsForTesting();
    await diagnosticsForFile.waitForDiagnosticsForTesting();
  }
  isDiagnosticIgnored(diagnostic2) {
    return diagnostic2.code !== void 0 && this.ignoredDiagnosticCodes.has(diagnostic2.code);
  }
};
var SourceDefinitionCommand = class _SourceDefinitionCommand {
  static id = "_typescript.goToSourceDefinition";
  static minVersion = API.v470;
  static async execute(uri, position, client, lspClient, reporter, token) {
    if (client.apiVersion.lt(_SourceDefinitionCommand.minVersion)) {
      lspClient.showErrorMessage("Go to Source Definition failed. Requires TypeScript 4.7+.");
      return;
    }
    if (!position || typeof position.character !== "number" || typeof position.line !== "number") {
      lspClient.showErrorMessage("Go to Source Definition failed. Invalid position.");
      return;
    }
    let file2;
    if (!uri || typeof uri !== "string" || !(file2 = client.toTsFilePath(uri))) {
      lspClient.showErrorMessage("Go to Source Definition failed. No resource provided.");
      return;
    }
    const document = client.toOpenDocument(client.toResourceUri(file2));
    if (!document) {
      lspClient.showErrorMessage("Go to Source Definition failed. File not opened in the editor.");
      return;
    }
    const args = Position.toFileLocationRequestArgs(file2, position);
    return await lspClient.withProgress({
      message: "Finding source definitions\u2026",
      reporter
    }, async () => {
      const response = await client.execute(CommandTypes.FindSourceDefinition, args, token);
      if (response.type !== "response" || !response.body) {
        lspClient.showErrorMessage("No source definitions found.");
        return;
      }
      return response.body.map((reference) => toLocation(reference, client));
    });
  }
};
var Commands = {
  APPLY_REFACTORING: "_typescript.applyRefactoring",
  CONFIGURE_PLUGIN: "_typescript.configurePlugin",
  ORGANIZE_IMPORTS: "_typescript.organizeImports",
  APPLY_RENAME_FILE: "_typescript.applyRenameFile",
  APPLY_COMPLETION_CODE_ACTION: "_typescript.applyCompletionCodeAction",
  SELECT_REFACTORING: "_typescript.selectRefactoring",
  SOURCE_DEFINITION: SourceDefinitionCommand.id
};
var TypescriptVersionNotification = new mainExports$2.NotificationType("$/typescriptVersion");
var MarkdownStringTextNewlineStyle;
(function(MarkdownStringTextNewlineStyle2) {
  MarkdownStringTextNewlineStyle2[MarkdownStringTextNewlineStyle2["Paragraph"] = 0] = "Paragraph";
  MarkdownStringTextNewlineStyle2[MarkdownStringTextNewlineStyle2["Break"] = 1] = "Break";
})(MarkdownStringTextNewlineStyle || (MarkdownStringTextNewlineStyle = {}));
var MarkdownString = class {
  value;
  constructor(value = "") {
    this.value = value;
  }
  appendText(value, newlineStyle = MarkdownStringTextNewlineStyle.Paragraph) {
    this.value += escapeMarkdownSyntaxTokens(value).replace(/([ \t]+)/g, (_match, g1) => "&nbsp;".repeat(g1.length)).replace(/>/gm, "\\>").replace(/\n/g, newlineStyle === MarkdownStringTextNewlineStyle.Break ? "\\\n" : "\n\n");
    return this;
  }
  appendMarkdown(value) {
    this.value += value;
    return this;
  }
  appendCodeblock(langId, code) {
    this.value += "\n```";
    this.value += langId;
    this.value += "\n";
    this.value += code;
    this.value += "\n```\n";
    return this;
  }
  toMarkupContent() {
    return {
      kind: "markdown",
      value: this.value
    };
  }
};
function escapeMarkdownSyntaxTokens(text) {
  return text.replace(/[\\`*_{}[\]()#+\-!]/g, "\\$&");
}
function replaceLinks(text) {
  return text.replace(/\{@(link|linkplain|linkcode) (https?:\/\/[^ |}]+?)(?:[| ]([^{}\n]+?))?\}/gi, (_, tag, link2, text2) => {
    switch (tag) {
      case "linkcode":
        return `[\`${text2 ? text2.trim() : link2}\`](${link2})`;
      default:
        return `[${text2 ? text2.trim() : link2}](${link2})`;
    }
  });
}
function processInlineTags(text) {
  return replaceLinks(text);
}
function getTagBodyText(tag, filePathConverter) {
  if (!tag.text) {
    return void 0;
  }
  function makeCodeblock(text2) {
    if (/^\s*[~`]{3}/m.test(text2)) {
      return text2;
    }
    return "```typescript\n" + text2 + "\n```";
  }
  const text = convertLinkTags(tag.text, filePathConverter);
  switch (tag.name) {
    case "example": {
      const captionTagMatches = text.match(/<caption>(.*?)<\/caption>\s*(\r\n|\n)/);
      if (captionTagMatches && captionTagMatches.index === 0) {
        return captionTagMatches[1] + "\n" + makeCodeblock(text.substring(captionTagMatches[0].length));
      } else {
        return makeCodeblock(text);
      }
    }
    case "author": {
      const emailMatch = text.match(/(.+)\s<([-.\w]+@[-.\w]+)>/);
      if (emailMatch === null) {
        return text;
      } else {
        return `${emailMatch[1]} ${emailMatch[2]}`;
      }
    }
    case "default":
      return makeCodeblock(text);
  }
  return processInlineTags(text);
}
function getTagBody(tag, filePathConverter) {
  if (tag.name === "template") {
    const parts = tag.text;
    if (parts && typeof parts !== "string") {
      const params = parts.filter((p) => p.kind === "typeParameterName").map((p) => p.text).join(", ");
      const docs = parts.filter((p) => p.kind === "text").map((p) => convertLinkTags(p.text.replace(/^\s*-?\s*/, ""), filePathConverter)).join(" ");
      return params ? ["", params, docs] : void 0;
    }
  }
  return convertLinkTags(tag.text, filePathConverter).split(/^(\S+)\s*-?\s*/);
}
function getTagDocumentation(tag, filePathConverter) {
  switch (tag.name) {
    case "augments":
    case "extends":
    case "param":
    case "template": {
      const body = getTagBody(tag, filePathConverter);
      if (body?.length === 3) {
        const param = body[1];
        const doc = body[2];
        const label2 = `*@${tag.name}* \`${param}\``;
        if (!doc) {
          return label2;
        }
        return label2 + (doc.match(/\r\n|\n/g) ? "  \n" + processInlineTags(doc) : ` \u2014 ${processInlineTags(doc)}`);
      }
      break;
    }
    case "return":
    case "returns": {
      if (!tag.text?.length) {
        return void 0;
      }
      break;
    }
  }
  const label = `*@${tag.name}*`;
  const text = getTagBodyText(tag, filePathConverter);
  if (!text) {
    return label;
  }
  return label + (text.match(/\r\n|\n/g) ? "  \n" + text : ` \u2014 ${text}`);
}
function plainWithLinks(parts, filePathConverter) {
  return processInlineTags(convertLinkTags(parts, filePathConverter));
}
function convertLinkTags(parts, filePathConverter) {
  if (!parts) {
    return "";
  }
  if (typeof parts === "string") {
    return parts;
  }
  const out = [];
  let currentLink;
  for (const part of parts) {
    switch (part.kind) {
      case "link":
        if (currentLink) {
          if (currentLink.target) {
            const link2 = filePathConverter.toResource(currentLink.target.file).with({
              fragment: `L${currentLink.target.start.line},${currentLink.target.start.offset}`
            });
            const linkText = currentLink.text ? currentLink.text : escapeMarkdownSyntaxTokensForCode(currentLink.name ?? "");
            out.push(`[${currentLink.linkcode ? "`" + linkText + "`" : linkText}](${link2.toString()})`);
          } else {
            const text = currentLink.text ?? currentLink.name;
            if (text) {
              if (/^https?:/.test(text)) {
                const parts2 = text.split(" ");
                if (parts2.length === 1) {
                  out.push(parts2[0]);
                } else if (parts2.length > 1) {
                  const linkText = escapeMarkdownSyntaxTokensForCode(parts2.slice(1).join(" "));
                  out.push(`[${currentLink.linkcode ? "`" + linkText + "`" : linkText}](${parts2[0]})`);
                }
              } else {
                out.push(escapeMarkdownSyntaxTokensForCode(text));
              }
            }
          }
          currentLink = void 0;
        } else {
          currentLink = {
            linkcode: part.text === "{@linkcode "
          };
        }
        break;
      case "linkName":
        if (currentLink) {
          currentLink.name = part.text;
          currentLink.target = part.target;
        }
        break;
      case "linkText":
        if (currentLink) {
          currentLink.text = part.text;
        }
        break;
      default:
        out.push(part.text);
        break;
    }
  }
  return processInlineTags(out.join(""));
}
function tagsMarkdownPreview(tags, filePathConverter) {
  return tags.map((tag) => getTagDocumentation(tag, filePathConverter)).join("  \n\n");
}
function markdownDocumentation(documentation, tags, filePathConverter) {
  const out = new MarkdownString();
  addMarkdownDocumentation(out, documentation, tags, filePathConverter);
  return out.value ? out.toMarkupContent() : void 0;
}
function addMarkdownDocumentation(out, documentation, tags, converter) {
  if (documentation) {
    out.appendMarkdown(plainWithLinks(documentation, converter));
  }
  if (tags) {
    const tagsPreview = tagsMarkdownPreview(tags, converter);
    if (tagsPreview) {
      out.appendMarkdown("\n\n" + tagsPreview);
    }
  }
  return out;
}
function escapeMarkdownSyntaxTokensForCode(text) {
  return text.replace(/`/g, "\\$&");
}
var SnippetString = class _SnippetString {
  static isSnippetString(thing) {
    if (thing instanceof _SnippetString) {
      return true;
    }
    if (!thing) {
      return false;
    }
    return typeof thing.value === "string";
  }
  static _escape(value) {
    return value.replace(/\$|}|\\/g, "\\$&");
  }
  _tabstop = 1;
  value;
  constructor(value) {
    this.value = value || "";
  }
  appendText(str) {
    this.value += _SnippetString._escape(str);
    return this;
  }
  appendTabstop(n = this._tabstop++) {
    this.value += "$";
    this.value += n;
    return this;
  }
  appendPlaceholder(value, n = this._tabstop++) {
    if (typeof value === "function") {
      const nested = new _SnippetString();
      nested._tabstop = this._tabstop;
      value(nested);
      this._tabstop = nested._tabstop;
      value = nested.value;
    } else {
      value = _SnippetString._escape(value);
    }
    this.value += "${";
    this.value += n;
    this.value += ":";
    this.value += value;
    this.value += "}";
    return this;
  }
  appendVariable(name, defaultValue) {
    if (typeof defaultValue === "function") {
      const nested = new _SnippetString();
      nested._tabstop = this._tabstop;
      defaultValue(nested);
      this._tabstop = nested._tabstop;
      defaultValue = nested.value;
    } else if (typeof defaultValue === "string") {
      defaultValue = defaultValue.replace(/\$|}/g, "\\$&");
    }
    this.value += "${";
    this.value += name;
    if (defaultValue) {
      this.value += ":";
      this.value += defaultValue;
    }
    this.value += "}";
    return this;
  }
};
var CompletionDataCache = class {
  store = /* @__PURE__ */ new Map();
  lastCacheId = 0;
  reset() {
    this.lastCacheId = 0;
    this.store.clear();
  }
  add(data) {
    const cacheId = ++this.lastCacheId;
    this.store.set(cacheId, data);
    return cacheId;
  }
  get(cacheId) {
    return this.store.get(cacheId);
  }
};
function asCompletionItems(entries, completionDataCache, file2, position, document, filePathConverter, options2, features, completionContext, defaultCommitCharacters) {
  const completions = [];
  for (const entry of entries) {
    const completion = asCompletionItem(entry, completionDataCache, file2, position, document, filePathConverter, options2, features, completionContext, defaultCommitCharacters);
    if (!completion) {
      continue;
    }
    completions.push(completion);
  }
  return completions;
}
function asCompletionItem(entry, completionDataCache, file2, position, document, filePathConverter, options2, features, completionContext, defaultCommitCharacters) {
  const cacheId = completionDataCache.add({
    file: file2,
    line: position.line + 1,
    offset: position.character + 1,
    entryNames: [entry.source || entry.data ? {
      name: entry.name,
      source: entry.source,
      data: entry.data
    } : entry.name]
  });
  const item = {
    label: entry.name || (entry.insertText ?? ""),
    kind: asCompletionItemKind(entry.kind),
    sortText: entry.sortText,
    preselect: entry.isRecommended,
    data: {
      cacheId
    }
  };
  if (entry.source && entry.hasAction) {
    item.sortText = `\uFFFF${entry.sortText}`;
  }
  if (features.completionCommitCharactersSupport) {
    item.commitCharacters = asCommitCharacters(completionContext, entry, defaultCommitCharacters);
  }
  if (features.completionLabelDetails) {
    item.labelDetails = entry.labelDetails;
  }
  const { isSnippet, replacementSpan, sourceDisplay } = entry;
  if (isSnippet && !features.completionSnippets) {
    return null;
  }
  if (features.completionSnippets && (isSnippet || canCreateSnippetOfFunctionCall(item.kind, options2))) {
    item.insertTextFormat = mainExports$2.InsertTextFormat.Snippet;
  }
  if (sourceDisplay) {
    item.detail = plainWithLinks(sourceDisplay, filePathConverter);
  }
  const { line, optionalReplacementRange, isMemberCompletion, dotAccessorContext } = completionContext;
  let range2 = getRangeFromReplacementSpan(replacementSpan, optionalReplacementRange, position, document, features);
  let { insertText } = entry;
  if (!features.completionDisableFilterText) {
    item.filterText = getFilterText(entry, optionalReplacementRange, line, insertText);
  }
  if (isMemberCompletion && dotAccessorContext && !entry.isSnippet) {
    const newInsertText = dotAccessorContext.text + (insertText || item.label);
    if (!features.completionDisableFilterText) {
      item.filterText = newInsertText;
    }
    if (!range2) {
      if (features.completionInsertReplaceSupport && optionalReplacementRange) {
        range2 = {
          insert: dotAccessorContext.range,
          replace: Range.union(dotAccessorContext.range, optionalReplacementRange)
        };
      } else {
        range2 = {
          replace: dotAccessorContext.range
        };
      }
      insertText = newInsertText;
    }
  }
  if (entry.kindModifiers) {
    const kindModifiers = new Set(entry.kindModifiers.split(/,|\s+/g));
    if (kindModifiers.has(KindModifiers.optional)) {
      if (!insertText) {
        insertText = item.label;
      }
      if (!item.filterText) {
        item.filterText = item.label;
      }
      item.label += "?";
    }
    if (kindModifiers.has(KindModifiers.deprecated)) {
      item.tags = [mainExports$2.CompletionItemTag.Deprecated];
    }
    if (kindModifiers.has(KindModifiers.color)) {
      item.kind = mainExports$2.CompletionItemKind.Color;
    }
    if (entry.kind === ScriptElementKind.scriptElement) {
      for (const extModifier of KindModifiers.fileExtensionKindModifiers) {
        if (kindModifiers.has(extModifier)) {
          if (entry.name.toLowerCase().endsWith(extModifier)) {
            item.detail = entry.name;
          } else {
            item.detail = entry.name + extModifier;
          }
          break;
        }
      }
    }
  }
  if (range2) {
    item.textEdit = range2.insert ? mainExports$2.InsertReplaceEdit.create(insertText || item.label, range2.insert, range2.replace) : mainExports$2.TextEdit.replace(range2.replace, insertText || item.label);
  } else {
    item.insertText = insertText;
  }
  return item;
}
function getRangeFromReplacementSpan(replacementSpan, optionalReplacementRange, position, document, features) {
  if (replacementSpan) {
    return {
      replace: ensureRangeIsOnSingleLine(Range.fromTextSpan(replacementSpan), document)
    };
  }
  if (features.completionInsertReplaceSupport && optionalReplacementRange) {
    const range2 = ensureRangeIsOnSingleLine(optionalReplacementRange, document);
    return {
      insert: mainExports$2.Range.create(range2.start, position),
      replace: range2
    };
  }
}
function getFilterText(entry, wordRange, line, insertText) {
  if (entry.name.startsWith("#")) {
    const wordStart = wordRange ? line.charAt(wordRange.start.character) : void 0;
    if (insertText) {
      if (insertText.startsWith("this.#")) {
        return wordStart === "#" ? insertText : insertText.replace(/&this\.#/, "");
      } else {
        return wordStart;
      }
    } else {
      return wordStart === "#" ? void 0 : entry.name.replace(/^#/, "");
    }
  }
  if (insertText?.startsWith("this.")) {
    return void 0;
  }
  if (insertText?.startsWith("[")) {
    return insertText.replace(/^\[['"](.+)[['"]\]$/, ".$1");
  }
  return insertText;
}
function ensureRangeIsOnSingleLine(range2, document) {
  if (range2.start.line !== range2.end.line) {
    return mainExports$2.Range.create(range2.start, document.getLineEnd(range2.start.line));
  }
  return range2;
}
function asCompletionItemKind(kind) {
  switch (kind) {
    case ScriptElementKind.primitiveType:
    case ScriptElementKind.keyword:
      return mainExports$2.CompletionItemKind.Keyword;
    case ScriptElementKind.constElement:
    case ScriptElementKind.letElement:
    case ScriptElementKind.variableElement:
    case ScriptElementKind.localVariableElement:
    case ScriptElementKind.alias:
    case ScriptElementKind.parameterElement:
      return mainExports$2.CompletionItemKind.Variable;
    case ScriptElementKind.memberVariableElement:
    case ScriptElementKind.memberGetAccessorElement:
    case ScriptElementKind.memberSetAccessorElement:
      return mainExports$2.CompletionItemKind.Field;
    case ScriptElementKind.functionElement:
    case ScriptElementKind.localFunctionElement:
      return mainExports$2.CompletionItemKind.Function;
    case ScriptElementKind.memberFunctionElement:
    case ScriptElementKind.constructSignatureElement:
    case ScriptElementKind.callSignatureElement:
    case ScriptElementKind.indexSignatureElement:
      return mainExports$2.CompletionItemKind.Method;
    case ScriptElementKind.enumElement:
      return mainExports$2.CompletionItemKind.Enum;
    case ScriptElementKind.enumMemberElement:
      return mainExports$2.CompletionItemKind.EnumMember;
    case ScriptElementKind.moduleElement:
    case ScriptElementKind.externalModuleName:
      return mainExports$2.CompletionItemKind.Module;
    case ScriptElementKind.classElement:
    case ScriptElementKind.typeElement:
      return mainExports$2.CompletionItemKind.Class;
    case ScriptElementKind.interfaceElement:
      return mainExports$2.CompletionItemKind.Interface;
    case ScriptElementKind.warning:
      return mainExports$2.CompletionItemKind.Text;
    case ScriptElementKind.scriptElement:
      return mainExports$2.CompletionItemKind.File;
    case ScriptElementKind.directory:
      return mainExports$2.CompletionItemKind.Folder;
    case ScriptElementKind.string:
      return mainExports$2.CompletionItemKind.Constant;
  }
  return mainExports$2.CompletionItemKind.Property;
}
function asCommitCharacters(context, entry, defaultCommitCharacters) {
  const kind = entry.kind;
  let commitCharacters = entry.commitCharacters ?? (defaultCommitCharacters ? Array.from(defaultCommitCharacters) : void 0);
  if (commitCharacters) {
    if (context.enableCallCompletions && !context.isNewIdentifierLocation && kind !== ScriptElementKind.warning && kind !== ScriptElementKind.string) {
      commitCharacters.push("(");
    }
    return commitCharacters;
  }
  if (kind === ScriptElementKind.warning || kind === ScriptElementKind.string) {
    return void 0;
  }
  commitCharacters = [".", ",", ";"];
  if (context.enableCallCompletions) {
    commitCharacters.push("(");
  }
  return commitCharacters;
}
async function asResolvedCompletionItem(item, details, document, client, options2, features) {
  item.detail = asDetail(details, client);
  const { documentation, tags } = details;
  item.documentation = markdownDocumentation(documentation, tags, client);
  if (details.codeActions?.length) {
    const { additionalTextEdits, command: command2 } = getCodeActions(details.codeActions, document.filepath, client);
    item.additionalTextEdits = additionalTextEdits;
    item.command = command2;
  }
  if (document && features.completionSnippets && canCreateSnippetOfFunctionCall(item.kind, options2)) {
    const { line, offset } = item.data;
    const position = Position.fromLocation({
      line,
      offset
    });
    const shouldCompleteFunction = await isValidFunctionCompletionContext(position, client, document);
    if (shouldCompleteFunction) {
      createSnippetOfFunctionCall(item, details);
    }
  }
  return item;
}
async function isValidFunctionCompletionContext(position, client, document) {
  try {
    const args = Position.toFileLocationRequestArgs(document.filepath, position);
    const response = await client.execute(CommandTypes.Quickinfo, args);
    if (response.type === "response" && response.body) {
      switch (response.body.kind) {
        case ScriptElementKind.variableElement:
        case ScriptElementKind.letElement:
        case ScriptElementKind.constElement:
        case ScriptElementKind.alias:
          return false;
      }
    }
  } catch {
  }
  const after = document.getLine(position.line).slice(position.character);
  return after.match(/^[a-z_$0-9]*\s*\(/gi) === null;
}
function canCreateSnippetOfFunctionCall(kind, options2) {
  return options2.completeFunctionCalls === true && (kind === mainExports$2.CompletionItemKind.Function || kind === mainExports$2.CompletionItemKind.Method);
}
function createSnippetOfFunctionCall(item, detail) {
  const { displayParts } = detail;
  const parameterListParts = getParameterListParts(displayParts);
  const snippet = new SnippetString();
  snippet.appendText(`${item.insertText || item.textEdit?.newText || item.label}(`);
  appendJoinedPlaceholders(snippet, parameterListParts.parts, ", ");
  if (parameterListParts.hasOptionalParameters) {
    snippet.appendTabstop();
  }
  snippet.appendText(")");
  snippet.appendTabstop(0);
  item.insertText = snippet.value;
  item.insertTextFormat = mainExports$2.InsertTextFormat.Snippet;
  if (item.textEdit) {
    item.textEdit.newText = snippet.value;
  }
}
function getParameterListParts(displayParts) {
  const parts = [];
  let isInMethod = false;
  let hasOptionalParameters = false;
  let parenCount = 0;
  let braceCount = 0;
  outer: for (let i = 0; i < displayParts.length; ++i) {
    const part = displayParts[i];
    switch (toSymbolDisplayPartKind(part.kind)) {
      case SymbolDisplayPartKind.methodName:
      case SymbolDisplayPartKind.functionName:
      case SymbolDisplayPartKind.text:
      case SymbolDisplayPartKind.propertyName:
        if (parenCount === 0 && braceCount === 0) {
          isInMethod = true;
        }
        break;
      case SymbolDisplayPartKind.parameterName:
        if (parenCount === 1 && braceCount === 0 && isInMethod) {
          const next = displayParts[i + 1];
          const nameIsFollowedByOptionalIndicator = next && next.text === "?";
          const nameIsThis = part.text === "this";
          if (!nameIsFollowedByOptionalIndicator && !nameIsThis) {
            parts.push(part);
          }
          hasOptionalParameters = hasOptionalParameters || nameIsFollowedByOptionalIndicator;
        }
        break;
      case SymbolDisplayPartKind.punctuation:
        if (part.text === "(") {
          ++parenCount;
        } else if (part.text === ")") {
          --parenCount;
          if (parenCount <= 0 && isInMethod) {
            break outer;
          }
        } else if (part.text === "..." && parenCount === 1) {
          hasOptionalParameters = true;
          break outer;
        } else if (part.text === "{") {
          ++braceCount;
        } else if (part.text === "}") {
          --braceCount;
        }
        break;
    }
  }
  return {
    hasOptionalParameters,
    parts
  };
}
function appendJoinedPlaceholders(snippet, parts, joiner) {
  for (let i = 0; i < parts.length; ++i) {
    const paramterPart = parts[i];
    snippet.appendPlaceholder(paramterPart.text);
    if (i !== parts.length - 1) {
      snippet.appendText(joiner);
    }
  }
}
function getCodeActions(codeActions, filepath, client) {
  const additionalTextEdits = [];
  let hasRemainingCommandsOrEdits = false;
  for (const tsAction of codeActions) {
    if (tsAction.commands) {
      hasRemainingCommandsOrEdits = true;
    }
    if (tsAction.changes) {
      for (const change of tsAction.changes) {
        const tsFileName = client.toResource(change.fileName).fsPath;
        if (tsFileName === filepath) {
          additionalTextEdits.push(...change.textChanges.map(toTextEdit));
        } else {
          hasRemainingCommandsOrEdits = true;
        }
      }
    }
  }
  let command2 = void 0;
  if (hasRemainingCommandsOrEdits) {
    command2 = {
      title: "",
      command: Commands.APPLY_COMPLETION_CODE_ACTION,
      arguments: [filepath, codeActions.map((codeAction) => ({
        commands: codeAction.commands,
        description: codeAction.description,
        changes: codeAction.changes.filter((x) => x.fileName !== filepath)
      }))]
    };
  }
  return {
    command: command2,
    additionalTextEdits: additionalTextEdits.length ? additionalTextEdits : void 0
  };
}
function asDetail({ displayParts, sourceDisplay, source: deprecatedSource }, filePathConverter) {
  const result = [];
  const source = sourceDisplay || deprecatedSource;
  if (source) {
    result.push(`Auto import from '${plainWithLinks(source, filePathConverter)}'`);
  }
  const detail = plainWithLinks(displayParts, filePathConverter);
  if (detail) {
    result.push(detail);
  }
  return result.join("\n");
}
function getCompletionTriggerCharacter(character) {
  switch (character) {
    case "@":
    case "#":
    case " ":
    case ".":
    case '"':
    case "'":
    case "`":
    case "/":
    case "<":
      return character;
    default:
      return void 0;
  }
}
function asSignatureHelp(info, context, filePathConverter) {
  const signatures = info.items.map((item) => asSignatureInformation(item, filePathConverter));
  return {
    activeSignature: getActiveSignature(info, signatures, context),
    activeParameter: getActiveParameter(info),
    signatures
  };
}
function getActiveSignature(info, signatures, context) {
  if (context?.activeSignatureHelp?.activeSignature !== void 0) {
    const previouslyActiveSignature = context.activeSignatureHelp.signatures[context.activeSignatureHelp.activeSignature];
    if (previouslyActiveSignature && context.isRetrigger) {
      const existingIndex = signatures.findIndex((other) => other.label === previouslyActiveSignature.label);
      if (existingIndex !== -1) {
        return existingIndex;
      }
    }
  }
  return info.selectedItemIndex;
}
function getActiveParameter(info) {
  const activeSignature = info.items[info.selectedItemIndex];
  if (activeSignature?.isVariadic) {
    return Math.min(info.argumentIndex, activeSignature.parameters.length - 1);
  }
  return info.argumentIndex;
}
function asSignatureInformation(item, filePathConverter) {
  const parameters = item.parameters.map((parameter) => asParameterInformation(parameter, filePathConverter));
  const signature = {
    label: plainWithLinks(item.prefixDisplayParts, filePathConverter),
    documentation: markdownDocumentation(item.documentation, item.tags.filter((x) => x.name !== "param"), filePathConverter),
    parameters
  };
  signature.label += parameters.map((parameter) => parameter.label).join(plainWithLinks(item.separatorDisplayParts, filePathConverter));
  signature.label += plainWithLinks(item.suffixDisplayParts, filePathConverter);
  return signature;
}
function asParameterInformation(parameter, filePathConverter) {
  const { displayParts, documentation } = parameter;
  return {
    label: plainWithLinks(displayParts, filePathConverter),
    documentation: markdownDocumentation(documentation, void 0, filePathConverter)
  };
}
function toTsTriggerReason(context) {
  switch (context.triggerKind) {
    case mainExports$2.SignatureHelpTriggerKind.TriggerCharacter:
      if (context.triggerCharacter) {
        if (context.isRetrigger) {
          return {
            kind: "retrigger",
            triggerCharacter: context.triggerCharacter
          };
        } else {
          return {
            kind: "characterTyped",
            triggerCharacter: context.triggerCharacter
          };
        }
      } else {
        return {
          kind: "invoked"
        };
      }
    case mainExports$2.SignatureHelpTriggerKind.ContentChange:
      return context.isRetrigger ? {
        kind: "retrigger"
      } : {
        kind: "invoked"
      };
    case mainExports$2.SignatureHelpTriggerKind.Invoked:
    default:
      return {
        kind: "invoked"
      };
  }
}
var TSServerRequestCommand = class _TSServerRequestCommand {
  tsClient;
  static ID = "typescript.tsserverRequest";
  id = _TSServerRequestCommand.ID;
  constructor(tsClient) {
    this.tsClient = tsClient;
  }
  async execute(command2, args, config) {
    if (args && typeof args === "object" && !Array.isArray(args)) {
      const requestArgs = args;
      const hasFile = typeof requestArgs.file === "string";
      if (hasFile) {
        const newArgs = {
          ...args
        };
        if (hasFile) {
          const document = this.tsClient.toOpenDocument(requestArgs.file);
          if (document) {
            newArgs.file = document.filepath;
          }
        }
        args = newArgs;
      }
    }
    return await this.tsClient.executeCustom(command2, args, config);
  }
};
var CodeActionKind$1;
(function(CodeActionKind2) {
  CodeActionKind2.RefactorMove = "refactor.move";
})(CodeActionKind$1 || (CodeActionKind$1 = {}));
function provideRefactors(refactors, args, features) {
  const actions = [];
  for (const refactor of refactors) {
    if (refactor.inlineable === false) {
      actions.push(asSelectRefactoring(refactor, args));
    } else {
      const relevantActions = refactor.actions.filter((action) => {
        if (action.notApplicableReason && !features.codeActionDisabledSupport) {
          return false;
        }
        if (action.isInteractive && (!features.moveToFileCodeActionSupport || action.name !== "Move to file")) {
          return false;
        }
        return true;
      });
      for (const action of relevantActions) {
        actions.push(asApplyRefactoring(action, refactor, args));
      }
    }
  }
  return actions;
}
function asSelectRefactoring(refactor, args) {
  return mainExports$2.CodeAction.create(refactor.description, mainExports$2.Command.create(refactor.description, Commands.SELECT_REFACTORING, refactor, args), mainExports$2.CodeActionKind.Refactor);
}
function asApplyRefactoring(action, refactor, args) {
  const codeAction = mainExports$2.CodeAction.create(action.description, asKind(action));
  if (action.notApplicableReason) {
    codeAction.disabled = {
      reason: action.notApplicableReason
    };
  } else {
    codeAction.command = mainExports$2.Command.create(action.description, Commands.APPLY_REFACTORING, {
      ...args,
      refactor: refactor.name,
      action: action.name
    });
  }
  return codeAction;
}
function asKind(action) {
  if (action.kind) {
    return action.kind;
  }
  if (action.name.startsWith("function_")) {
    return `${mainExports$2.CodeActionKind.RefactorExtract}.function`;
  }
  if (action.name.startsWith("constant_")) {
    return `${mainExports$2.CodeActionKind.RefactorExtract}.constant`;
  }
  if (action.name.startsWith("Extract to type alias")) {
    return `${mainExports$2.CodeActionKind.RefactorExtract}.type`;
  }
  if (action.name.startsWith("Extract to interface")) {
    return `${mainExports$2.CodeActionKind.RefactorExtract}.interface`;
  }
  if (action.name.startsWith("Move to file")) {
    return `${CodeActionKind$1.RefactorMove}.file`;
  }
  if (action.name.startsWith("Move to a new file")) {
    return `${CodeActionKind$1.RefactorMove}.newFile`;
  }
  if (action.name.startsWith("Convert namespace import") || action.name.startsWith("Convert named imports")) {
    return `${mainExports$2.CodeActionKind.RefactorRewrite}.import`;
  }
  if (action.name.startsWith("Convert default export") || action.name.startsWith("Convert named export")) {
    return `${mainExports$2.CodeActionKind.RefactorRewrite}.export`;
  }
  if (action.name.startsWith("Convert parameters to destructured object")) {
    return `${mainExports$2.CodeActionKind.RefactorRewrite}.parameters.toDestructured`;
  }
  if (action.name.startsWith("Generate 'get' and 'set' accessors")) {
    return `${mainExports$2.CodeActionKind.RefactorRewrite}.property.generateAccessors`;
  }
  return mainExports$2.CodeActionKind.Refactor;
}
var CodeActionKind = class _CodeActionKind {
  value;
  static sep = ".";
  static Empty = new _CodeActionKind(mainExports$2.CodeActionKind.Empty);
  static QuickFix = new _CodeActionKind(mainExports$2.CodeActionKind.QuickFix);
  static Refactor = new _CodeActionKind(mainExports$2.CodeActionKind.Refactor);
  static Source = new _CodeActionKind(mainExports$2.CodeActionKind.Source);
  static SourceAddMissingImportsTs = _CodeActionKind.Source.append("addMissingImports").append("ts");
  static SourceFixAll = new _CodeActionKind(mainExports$2.CodeActionKind.SourceFixAll);
  static SourceFixAllTs = _CodeActionKind.SourceFixAll.append("ts");
  static SourceOrganizeImports = new _CodeActionKind(mainExports$2.CodeActionKind.SourceOrganizeImports);
  static SourceOrganizeImportsTs = _CodeActionKind.SourceOrganizeImports.append("ts");
  static SourceRemoveUnusedImportsTs = _CodeActionKind.Source.append("removeUnusedImports").append("ts");
  static SourceRemoveUnusedTs = _CodeActionKind.Source.append("removeUnused").append("ts");
  static SourceSortImportsTs = _CodeActionKind.Source.append("sortImports").append("ts");
  constructor(value) {
    this.value = value;
  }
  equals(other) {
    return this.value === other.value;
  }
  contains(other) {
    return this.equals(other) || this.value === "" || other.value.startsWith(this.value + _CodeActionKind.sep);
  }
  intersects(other) {
    return this.contains(other) || other.contains(this);
  }
  append(part) {
    return new _CodeActionKind(this.value + _CodeActionKind.sep + part);
  }
};
var organizeImportsCommand = {
  title: "Organize Imports",
  kind: CodeActionKind.SourceOrganizeImportsTs,
  mode: OrganizeImportsMode.All
};
var sortImportsCommand = {
  minVersion: API.v430,
  title: "Sort Imports",
  kind: CodeActionKind.SourceSortImportsTs,
  mode: OrganizeImportsMode.SortAndCombine
};
var removeUnusedImportsCommand = {
  minVersion: API.v490,
  title: "Remove Unused Imports",
  kind: CodeActionKind.SourceRemoveUnusedImportsTs,
  mode: OrganizeImportsMode.RemoveUnused
};
var organizeImportsCommands = [organizeImportsCommand, sortImportsCommand, removeUnusedImportsCommand];
function provideOrganizeImports(command2, response, client) {
  if (!response || response.body.length === 0) {
    return [];
  }
  return [mainExports$2.CodeAction.create(command2.title, {
    documentChanges: response.body.map((edit) => toTextDocumentEdit(edit, client))
  }, command2.kind.value)];
}
function collectDocumentSymbols(parent, symbols) {
  return collectDocumentSymbolsInRange(parent, symbols, {
    start: Range.fromTextSpan(parent.spans[0]).start,
    end: Range.fromTextSpan(parent.spans[parent.spans.length - 1]).end
  });
}
function collectDocumentSymbolsInRange(parent, symbols, range2) {
  let shouldInclude = shouldIncludeEntry(parent);
  for (const span of parent.spans) {
    const spanRange = Range.fromTextSpan(span);
    if (!Range.intersection(range2, spanRange)) {
      continue;
    }
    const children = [];
    if (parent.childItems) {
      for (const child of parent.childItems) {
        if (child.spans.some((childSpan) => !!Range.intersection(spanRange, Range.fromTextSpan(childSpan)))) {
          const includedChild = collectDocumentSymbolsInRange(child, children, spanRange);
          shouldInclude = shouldInclude || includedChild;
        }
      }
    }
    let selectionRange = spanRange;
    if (parent.nameSpan) {
      const nameRange = Range.fromTextSpan(parent.nameSpan);
      if (Range.intersection(spanRange, nameRange)) {
        selectionRange = nameRange;
      }
    }
    if (shouldInclude) {
      symbols.push({
        name: parent.text,
        detail: "",
        kind: toSymbolKind(parent.kind),
        range: spanRange,
        selectionRange,
        children
      });
    }
  }
  return shouldInclude;
}
function collectSymbolInformation(uri, current, symbols, containerName) {
  let shouldInclude = shouldIncludeEntry(current);
  const name = current.text;
  for (const span of current.spans) {
    const range2 = Range.fromTextSpan(span);
    const children = [];
    if (current.childItems) {
      for (const child of current.childItems) {
        if (child.spans.some((span2) => !!Range.intersection(range2, Range.fromTextSpan(span2)))) {
          const includedChild = collectSymbolInformation(uri, child, children, name);
          shouldInclude = shouldInclude || includedChild;
        }
      }
    }
    if (shouldInclude) {
      symbols.push({
        name,
        kind: toSymbolKind(current.kind),
        location: {
          uri,
          range: range2
        },
        containerName
      });
      symbols.push(...children);
    }
  }
  return shouldInclude;
}
function shouldIncludeEntry(item) {
  if (item.kind === ScriptElementKind.alias) {
    return false;
  }
  return !!(item.text && item.text !== "<function>" && item.text !== "<class>");
}
function fromProtocolCallHierarchyItem(item, client, workspaceRoot) {
  const useFileName = isSourceFileItem(item);
  const name = useFileName ? path__default.basename(item.file) : item.name;
  const detail = useFileName ? workspaceRoot ? path__default.relative(workspaceRoot, path__default.dirname(item.file)) : path__default.dirname(item.file) : item.containerName ?? "";
  const result = {
    kind: fromProtocolScriptElementKind(item.kind),
    name,
    detail,
    uri: client.toResourceUri(item.file),
    range: Range.fromTextSpan(item.span),
    selectionRange: Range.fromTextSpan(item.selectionSpan)
  };
  const kindModifiers = item.kindModifiers ? parseKindModifier(item.kindModifiers) : void 0;
  if (kindModifiers?.has(ScriptElementKindModifier.deprecatedModifier)) {
    result.tags = [mainExports$2.SymbolTag.Deprecated];
  }
  return result;
}
function fromProtocolCallHierarchyIncomingCall(item, client, workspaceRoot) {
  return {
    from: fromProtocolCallHierarchyItem(item.from, client, workspaceRoot),
    fromRanges: item.fromSpans.map(Range.fromTextSpan)
  };
}
function fromProtocolCallHierarchyOutgoingCall(item, client, workspaceRoot) {
  return {
    to: fromProtocolCallHierarchyItem(item.to, client, workspaceRoot),
    fromRanges: item.fromSpans.map(Range.fromTextSpan)
  };
}
function isSourceFileItem(item) {
  return item.kind === ScriptElementKind.scriptElement || item.kind === ScriptElementKind.moduleElement && item.selectionSpan.start.line === 1 && item.selectionSpan.start.offset === 1;
}
function fromProtocolScriptElementKind(kind) {
  switch (kind) {
    case ScriptElementKind.moduleElement:
      return mainExports$2.SymbolKind.Module;
    case ScriptElementKind.classElement:
      return mainExports$2.SymbolKind.Class;
    case ScriptElementKind.enumElement:
      return mainExports$2.SymbolKind.Enum;
    case ScriptElementKind.enumMemberElement:
      return mainExports$2.SymbolKind.EnumMember;
    case ScriptElementKind.interfaceElement:
      return mainExports$2.SymbolKind.Interface;
    case ScriptElementKind.indexSignatureElement:
      return mainExports$2.SymbolKind.Method;
    case ScriptElementKind.callSignatureElement:
      return mainExports$2.SymbolKind.Method;
    case ScriptElementKind.memberFunctionElement:
      return mainExports$2.SymbolKind.Method;
    case ScriptElementKind.memberVariableElement:
      return mainExports$2.SymbolKind.Property;
    case ScriptElementKind.memberGetAccessorElement:
      return mainExports$2.SymbolKind.Property;
    case ScriptElementKind.memberSetAccessorElement:
      return mainExports$2.SymbolKind.Property;
    case ScriptElementKind.variableElement:
      return mainExports$2.SymbolKind.Variable;
    case ScriptElementKind.letElement:
      return mainExports$2.SymbolKind.Variable;
    case ScriptElementKind.constElement:
      return mainExports$2.SymbolKind.Variable;
    case ScriptElementKind.localVariableElement:
      return mainExports$2.SymbolKind.Variable;
    case ScriptElementKind.alias:
      return mainExports$2.SymbolKind.Variable;
    case ScriptElementKind.functionElement:
      return mainExports$2.SymbolKind.Function;
    case ScriptElementKind.localFunctionElement:
      return mainExports$2.SymbolKind.Function;
    case ScriptElementKind.constructSignatureElement:
      return mainExports$2.SymbolKind.Constructor;
    case ScriptElementKind.constructorImplementationElement:
      return mainExports$2.SymbolKind.Constructor;
    case ScriptElementKind.typeParameterElement:
      return mainExports$2.SymbolKind.TypeParameter;
    case ScriptElementKind.string:
      return mainExports$2.SymbolKind.String;
    default:
      return mainExports$2.SymbolKind.Variable;
  }
}
function parseKindModifier(kindModifiers) {
  return new Set(kindModifiers.split(/,|\s+/g));
}
var cjs;
var hasRequiredCjs;
function requireCjs() {
  if (hasRequiredCjs) return cjs;
  hasRequiredCjs = 1;
  var isMergeableObject = function isMergeableObject2(value) {
    return isNonNullObject(value) && !isSpecial(value);
  };
  function isNonNullObject(value) {
    return !!value && typeof value === "object";
  }
  function isSpecial(value) {
    var stringValue = Object.prototype.toString.call(value);
    return stringValue === "[object RegExp]" || stringValue === "[object Date]" || isReactElement(value);
  }
  var canUseSymbol = typeof Symbol === "function" && Symbol.for;
  var REACT_ELEMENT_TYPE = canUseSymbol ? /* @__PURE__ */ Symbol.for("react.element") : 60103;
  function isReactElement(value) {
    return value.$$typeof === REACT_ELEMENT_TYPE;
  }
  function emptyTarget(val) {
    return Array.isArray(val) ? [] : {};
  }
  function cloneUnlessOtherwiseSpecified(value, options2) {
    return options2.clone !== false && options2.isMergeableObject(value) ? deepmerge2(emptyTarget(value), value, options2) : value;
  }
  function defaultArrayMerge(target, source, options2) {
    return target.concat(source).map(function(element) {
      return cloneUnlessOtherwiseSpecified(element, options2);
    });
  }
  function getMergeFunction(key, options2) {
    if (!options2.customMerge) {
      return deepmerge2;
    }
    var customMerge = options2.customMerge(key);
    return typeof customMerge === "function" ? customMerge : deepmerge2;
  }
  function getEnumerableOwnPropertySymbols(target) {
    return Object.getOwnPropertySymbols ? Object.getOwnPropertySymbols(target).filter(function(symbol) {
      return Object.propertyIsEnumerable.call(target, symbol);
    }) : [];
  }
  function getKeys(target) {
    return Object.keys(target).concat(getEnumerableOwnPropertySymbols(target));
  }
  function propertyIsOnObject(object, property) {
    try {
      return property in object;
    } catch (_) {
      return false;
    }
  }
  function propertyIsUnsafe(target, key) {
    return propertyIsOnObject(target, key) && !(Object.hasOwnProperty.call(target, key) && Object.propertyIsEnumerable.call(target, key));
  }
  function mergeObject(target, source, options2) {
    var destination = {};
    if (options2.isMergeableObject(target)) {
      getKeys(target).forEach(function(key) {
        destination[key] = cloneUnlessOtherwiseSpecified(target[key], options2);
      });
    }
    getKeys(source).forEach(function(key) {
      if (propertyIsUnsafe(target, key)) {
        return;
      }
      if (propertyIsOnObject(target, key) && options2.isMergeableObject(source[key])) {
        destination[key] = getMergeFunction(key, options2)(target[key], source[key], options2);
      } else {
        destination[key] = cloneUnlessOtherwiseSpecified(source[key], options2);
      }
    });
    return destination;
  }
  function deepmerge2(target, source, options2) {
    options2 = options2 || {};
    options2.arrayMerge = options2.arrayMerge || defaultArrayMerge;
    options2.isMergeableObject = options2.isMergeableObject || isMergeableObject;
    options2.cloneUnlessOtherwiseSpecified = cloneUnlessOtherwiseSpecified;
    var sourceIsArray = Array.isArray(source);
    var targetIsArray = Array.isArray(target);
    var sourceAndTargetTypesMatch = sourceIsArray === targetIsArray;
    if (!sourceAndTargetTypesMatch) {
      return cloneUnlessOtherwiseSpecified(source, options2);
    } else if (sourceIsArray) {
      return options2.arrayMerge(target, source, options2);
    } else {
      return mergeObject(target, source, options2);
    }
  }
  deepmerge2.all = function deepmergeAll(array, options2) {
    if (!Array.isArray(array)) {
      throw new Error("first argument should be an array");
    }
    return array.reduce(function(prev, next) {
      return deepmerge2(prev, next, options2);
    }, {});
  };
  var deepmerge_1 = deepmerge2;
  cjs = deepmerge_1;
  return cjs;
}
var cjsExports = requireCjs();
var deepmerge = getDefaultExportFromCjs(cjsExports);
function equals(one, other) {
  if (one === other) {
    return true;
  }
  if (one === null || one === void 0 || other === null || other === void 0) {
    return false;
  }
  if (typeof one !== typeof other) {
    return false;
  }
  if (typeof one !== "object") {
    return false;
  }
  if (Array.isArray(one) !== Array.isArray(other)) {
    return false;
  }
  if (Array.isArray(one)) {
    if (!Array.isArray(other)) {
      return false;
    }
    return equals$1(one, other, equals);
  } else {
    const oneKeys = [];
    for (const key in one) {
      oneKeys.push(key);
    }
    oneKeys.sort();
    const otherKeys = [];
    for (const key in other) {
      otherKeys.push(key);
    }
    otherKeys.sort();
    if (!equals$1(oneKeys, otherKeys)) {
      return false;
    }
    return oneKeys.every((key) => equals(one[key], other[key]));
  }
}
function getInferredProjectCompilerOptions(version2, workspaceConfig) {
  const projectConfig = {
    module: version2.gte(API.v540) ? ModuleKind.Preserve : ModuleKind.ESNext,
    moduleResolution: version2.gte(API.v540) ? ModuleResolutionKind.Bundler : ModuleResolutionKind.Node,
    target: ScriptTarget.ES2022,
    jsx: JsxEmit.ReactJSX
  };
  if (version2.gte(API.v500)) {
    projectConfig.allowImportingTsExtensions = true;
  }
  if (workspaceConfig.checkJs) {
    projectConfig.checkJs = true;
    projectConfig.allowJs = true;
  }
  if (workspaceConfig.experimentalDecorators) {
    projectConfig.experimentalDecorators = true;
  }
  if (workspaceConfig.strictNullChecks) {
    projectConfig.strictNullChecks = true;
  }
  if (workspaceConfig.strictFunctionTypes) {
    projectConfig.strictFunctionTypes = true;
  }
  if (workspaceConfig.strict) {
    projectConfig.strict = true;
  }
  if (workspaceConfig.module) {
    projectConfig.module = workspaceConfig.module;
  }
  if (workspaceConfig.target) {
    projectConfig.target = workspaceConfig.target;
  }
  projectConfig.sourceMap = true;
  return projectConfig;
}
var DEFAULT_TSSERVER_PREFERENCES = {
  allowIncompleteCompletions: true,
  allowRenameOfImportPath: true,
  allowTextChangesInNewFiles: true,
  autoImportFileExcludePatterns: [],
  autoImportSpecifierExcludeRegexes: [],
  disableLineTextInReferences: true,
  disableSuggestions: false,
  displayPartsForJSDoc: true,
  excludeLibrarySymbolsInNavTo: true,
  generateReturnInDocTemplate: true,
  importModuleSpecifierEnding: "auto",
  importModuleSpecifierPreference: "shortest",
  includeAutomaticOptionalChainCompletions: true,
  includeCompletionsForImportStatements: true,
  includeCompletionsForModuleExports: true,
  includeCompletionsWithClassMemberSnippets: true,
  includeCompletionsWithInsertText: true,
  includeCompletionsWithObjectLiteralMethodSnippets: true,
  includeCompletionsWithSnippetText: true,
  includeInlayEnumMemberValueHints: false,
  includeInlayFunctionLikeReturnTypeHints: false,
  includeInlayFunctionParameterTypeHints: false,
  includeInlayParameterNameHints: "none",
  includeInlayParameterNameHintsWhenArgumentMatchesName: false,
  includeInlayPropertyDeclarationTypeHints: false,
  includeInlayVariableTypeHints: false,
  includeInlayVariableTypeHintsWhenTypeMatchesName: false,
  includePackageJsonAutoImports: "auto",
  interactiveInlayHints: true,
  jsxAttributeCompletionStyle: "auto",
  lazyConfiguredProjectsFromExternalProject: false,
  maximumHoverLength: 500,
  organizeImportsAccentCollation: true,
  organizeImportsCaseFirst: false,
  organizeImportsCollation: "ordinal",
  organizeImportsLocale: "en",
  organizeImportsIgnoreCase: "auto",
  organizeImportsNumericCollation: false,
  organizeImportsTypeOrder: "last",
  preferTypeOnlyAutoImports: false,
  providePrefixAndSuffixTextForRename: true,
  provideRefactorNotApplicableReason: true,
  quotePreference: "auto",
  useLabelDetailsInCompletionEntries: true
};
var DEFAULT_IMPLICIT_PROJECT_CONFIGURATION = {
  checkJs: false,
  experimentalDecorators: false,
  module: ModuleKind.ESNext,
  strict: true,
  strictFunctionTypes: true,
  strictNullChecks: true,
  target: ScriptTarget.ES2024
};
var DEFAULT_WORKSPACE_CONFIGURATION = {
  implicitProjectConfiguration: DEFAULT_IMPLICIT_PROJECT_CONFIGURATION
};
function areFileConfigurationsEqual(a, b) {
  return equals(a, b);
}
var FileConfigurationManager = class {
  client;
  lspClient;
  features;
  tsPreferences = deepmerge({}, DEFAULT_TSSERVER_PREFERENCES);
  workspaceConfiguration = deepmerge({}, DEFAULT_WORKSPACE_CONFIGURATION);
  fileOptionsCache;
  formatOptionsCache;
  initialConfigurationRequestsMap;
  constructor(client, lspClient, features, onCaseInsensitiveFileSystem2) {
    this.client = client;
    this.lspClient = lspClient;
    this.features = features;
    this.fileOptionsCache = new ResourceMap(void 0, {
      onCaseInsensitiveFileSystem: onCaseInsensitiveFileSystem2
    });
    this.formatOptionsCache = new ResourceMap(void 0, {
      onCaseInsensitiveFileSystem: onCaseInsensitiveFileSystem2
    });
    this.initialConfigurationRequestsMap = new ResourceMap(void 0, {
      onCaseInsensitiveFileSystem: onCaseInsensitiveFileSystem2
    });
  }
  onDidOpenTextDocument(document) {
    const cancellation2 = new lsp$1.CancellationTokenSource();
    this.initialConfigurationRequestsMap.set(document.uri, cancellation2);
    this.ensureConfigurationForDocument(document, cancellation2.token).then(() => {
      this.initialConfigurationRequestsMap.delete(document.uri);
    }).catch(() => {
    });
  }
  onDidCloseTextDocument(documentUri) {
    this.fileOptionsCache.delete(documentUri);
    this.initialConfigurationRequestsMap.get(documentUri)?.cancel();
  }
  mergeTsPreferences(preferences) {
    this.tsPreferences = deepmerge(this.tsPreferences, preferences);
  }
  setWorkspaceConfiguration(configuration2) {
    const updatedConfiguration = deepmerge(DEFAULT_WORKSPACE_CONFIGURATION, configuration2);
    if (this.features.codeLensRefreshSupport) {
      const settingKeys = ["javascript.implementationsCodeLens", "typescript.implementationsCodeLens", "javascript.referencesCodeLens", "typescript.referencesCodeLens"];
      const oldCodeLens = getValueForConfigurationKeys(settingKeys, this.workspaceConfiguration);
      const newCodeLens = getValueForConfigurationKeys(settingKeys, updatedConfiguration);
      if (!equals(oldCodeLens, newCodeLens)) {
        void this.lspClient.codeLensRefresh();
      }
    }
    if (this.features.inlayHintRefreshSupport) {
      const settingKeys = ["javascript.inlayHints", "typescript.inlayHints"];
      const oldInlayHints = getValueForConfigurationKeys(settingKeys, this.workspaceConfiguration);
      const newInlayHints = getValueForConfigurationKeys(settingKeys, updatedConfiguration);
      if (!equals(oldInlayHints, newInlayHints)) {
        void this.lspClient.inlayHintRefresh();
      }
    }
    this.workspaceConfiguration = updatedConfiguration;
    this.setCompilerOptionsForInferredProjects();
  }
  setGlobalConfiguration(workspaceFolder2, hostInfo) {
    const formatOptions = {
      newLineCharacter: "\n"
    };
    this.client.executeWithoutWaitingForResponse(CommandTypes.Configure, {
      ...hostInfo ? {
        hostInfo
      } : {},
      formatOptions,
      preferences: {
        ...this.tsPreferences,
        autoImportFileExcludePatterns: this.getAutoImportFileExcludePatternsPreference(workspaceFolder2)
      }
    });
    this.setCompilerOptionsForInferredProjects();
  }
  setCompilerOptionsForInferredProjects() {
    this.client.executeWithoutWaitingForResponse(CommandTypes.CompilerOptionsForInferredProjects, {
      options: {
        ...getInferredProjectCompilerOptions(this.client.apiVersion, this.workspaceConfiguration.implicitProjectConfiguration),
        allowJs: true,
        allowNonTsExtensions: true,
        allowSyntheticDefaultImports: true,
        resolveJsonModule: true
      }
    });
  }
  async ensureConfigurationForDocument(document, token) {
    const formattingOptions = await this.getFormattingOptions(document);
    return this.ensureConfigurationOptions(document, formattingOptions, token);
  }
  async getFormattingOptions(document) {
    const formatOptionsCached = this.formatOptionsCache.get(document.uri);
    if (formatOptionsCached) {
      return formatOptionsCached;
    }
    const formatConfiguration = this.features.workspaceConfigurationSuppport ? await this.lspClient.getWorkspaceConfiguration(document.uri.toString(), "formattingOptions") || {} : {};
    const options2 = {};
    if (typeof formatConfiguration.tabSize === "number") {
      options2.tabSize = formatConfiguration.tabSize;
    }
    if (typeof formatConfiguration.insertSpaces === "boolean") {
      options2.insertSpaces = formatConfiguration.insertSpaces;
    }
    this.formatOptionsCache.set(document.uri, options2);
    return options2;
  }
  async ensureConfigurationOptions(document, options2, token) {
    const currentOptions = this.getFileOptions(document, options2);
    const cachedOptions = this.fileOptionsCache.get(document.uri);
    if (cachedOptions) {
      const cachedOptionsValue = await cachedOptions;
      if (token?.isCancellationRequested) {
        return;
      }
      if (cachedOptionsValue && areFileConfigurationsEqual(cachedOptionsValue, currentOptions)) {
        return;
      }
    }
    const task = (async () => {
      try {
        const response = await this.client.execute(CommandTypes.Configure, {
          file: document.filepath,
          ...currentOptions
        }, token);
        return response.type === "response" ? currentOptions : void 0;
      } catch {
        return void 0;
      }
    })();
    this.fileOptionsCache.set(document.uri, task);
    await task;
  }
  async setGlobalConfigurationFromDocument(document, token) {
    const args = {
      file: void 0,
      ...this.getFileOptions(document)
    };
    await this.client.execute(CommandTypes.Configure, args, token);
  }
  reset() {
    this.fileOptionsCache.clear();
    this.formatOptionsCache.clear();
    this.initialConfigurationRequestsMap.clear();
  }
  getFileOptions(document, options2) {
    return {
      formatOptions: this.getFormatOptions(document, options2),
      preferences: this.getPreferences(document)
    };
  }
  getFormatOptions(document, formattingOptions) {
    const workspacePreferences = this.getWorkspacePreferencesForFile(document);
    const opts = {
      ...workspacePreferences?.format,
      ...formattingOptions
    };
    if (opts.convertTabsToSpaces === void 0) {
      opts.convertTabsToSpaces = formattingOptions?.insertSpaces;
    }
    if (opts.indentSize === void 0) {
      opts.indentSize = formattingOptions?.tabSize;
    }
    if (opts.newLineCharacter === void 0) {
      opts.newLineCharacter = "\n";
    }
    return opts;
  }
  getWorkspacePreferencesForFile(document) {
    return this.workspaceConfiguration[isTypeScriptDocument(document) ? "typescript" : "javascript"] || {};
  }
  getPreferences(document) {
    const workspacePreferences = this.getWorkspacePreferencesForFile(document);
    const preferences = Object.assign({}, this.tsPreferences, workspacePreferences?.inlayHints || {});
    return {
      ...preferences,
      quotePreference: this.getQuoteStylePreference(preferences)
    };
  }
  getQuoteStylePreference(preferences) {
    switch (preferences.quotePreference) {
      case "single":
        return "single";
      case "double":
        return "double";
      default:
        return this.client.apiVersion.gte(API.v333) ? "auto" : void 0;
    }
  }
  getAutoImportFileExcludePatternsPreference(workspaceFolder2) {
    if (!workspaceFolder2 || this.tsPreferences.autoImportFileExcludePatterns.length === 0) {
      return;
    }
    return this.tsPreferences.autoImportFileExcludePatterns.map((p) => {
      const slashNormalized = p.replace(/\\/g, "/");
      const isRelative = /^\.\.?($|\/)/.test(slashNormalized);
      return path__default.posix.isAbsolute(p) ? p : p.startsWith("*") ? `/${slashNormalized}` : isRelative ? path__default.posix.join(workspaceFolder2, p) : `/**/${slashNormalized}`;
    });
  }
};
function getValueForConfigurationKeys(keys, configuration2) {
  const result = [];
  for (const key of keys) {
    let resolvedValue = configuration2;
    for (const component of key.split(".")) {
      resolvedValue = resolvedValue[component];
      if (!isPlainObject(resolvedValue)) {
        break;
      }
    }
    result.push(resolvedValue);
  }
  return result;
}
function isPlainObject(val) {
  return Object.prototype.toString.call(val) === "[object Object]";
}
function escapeRegExp(text) {
  return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
}
var CodeLensType;
(function(CodeLensType2) {
  CodeLensType2[CodeLensType2["Reference"] = 0] = "Reference";
  CodeLensType2[CodeLensType2["Implementation"] = 1] = "Implementation";
})(CodeLensType || (CodeLensType = {}));
var TypeScriptBaseCodeLensProvider = class {
  client;
  cachedResponse;
  fileConfigurationManager;
  static cancelledCommand = {
    title: "",
    command: ""
  };
  static errorCommand = {
    title: "Could not determine references",
    command: ""
  };
  constructor(client, cachedResponse, fileConfigurationManager) {
    this.client = client;
    this.cachedResponse = cachedResponse;
    this.fileConfigurationManager = fileConfigurationManager;
  }
  async provideCodeLenses(document, token) {
    const configuration2 = this.fileConfigurationManager.getWorkspacePreferencesForFile(document);
    if (this.type === CodeLensType.Implementation && !configuration2.implementationsCodeLens?.enabled || this.type === CodeLensType.Reference && !configuration2.referencesCodeLens?.enabled) {
      return [];
    }
    const response = await this.cachedResponse.execute(document, () => this.client.execute(CommandTypes.NavTree, {
      file: document.filepath
    }, token));
    if (response.type !== "response") {
      return [];
    }
    const referenceableSpans = [];
    response.body?.childItems?.forEach((item) => this.walkNavTree(document, item, void 0, referenceableSpans));
    return referenceableSpans.map((span) => mainExports.CodeLens.create(span, {
      uri: document.uri.toString(),
      type: this.type
    }));
  }
  walkNavTree(document, item, parent, results) {
    const range2 = this.extractSymbol(document, item, parent);
    if (range2) {
      results.push(range2);
    }
    item.childItems?.forEach((child) => this.walkNavTree(document, child, item, results));
  }
};
function getSymbolRange(document, item) {
  if (item.nameSpan) {
    return Range.fromTextSpan(item.nameSpan);
  }
  const span = item.spans?.[0];
  if (!span) {
    return void 0;
  }
  const range2 = Range.fromTextSpan(span);
  const text = document.getText(range2);
  const identifierMatch = new RegExp(`^(.*?(\\b|\\W))${escapeRegExp(item.text || "")}(\\b|\\W)`, "gm");
  const match = identifierMatch.exec(text);
  const prefixLength = match ? match.index + match[1].length : 0;
  const startOffset = document.offsetAt(range2.start) + prefixLength;
  return mainExports.Range.create(document.positionAt(startOffset), document.positionAt(startOffset + item.text.length));
}
var TypeScriptImplementationsCodeLensProvider = class extends TypeScriptBaseCodeLensProvider {
  get type() {
    return CodeLensType.Implementation;
  }
  async resolveCodeLens(codeLens, token) {
    const document = this.client.toOpenDocument(codeLens.data.uri);
    if (!document) {
      return codeLens;
    }
    if (!this.fileConfigurationManager.getWorkspacePreferencesForFile(document).implementationsCodeLens?.enabled) {
      return codeLens;
    }
    const args = Position.toFileLocationRequestArgs(document.filepath, codeLens.range.start);
    const response = await this.client.execute(CommandTypes.Implementation, args, token, {
      lowPriority: true,
      executionTarget: ExecutionTarget.Semantic,
      cancelOnResourceChange: codeLens.data.uri
    });
    if (response.type !== "response" || !response.body) {
      codeLens.command = response.type === "cancelled" ? TypeScriptBaseCodeLensProvider.cancelledCommand : TypeScriptBaseCodeLensProvider.errorCommand;
      return codeLens;
    }
    const locations = response.body.map((reference) => mainExports.Location.create(this.client.toResourceUri(reference.file), reference.start.line === reference.end.line ? Range.fromTextSpan(reference) : mainExports.Range.create(Position.fromLocation(reference.start), mainExports.Position.create(reference.start.line, 0)))).filter((location) => !(location.uri.toString() === codeLens.data.uri && location.range.start.line === codeLens.range.start.line && location.range.start.character === codeLens.range.start.character));
    codeLens.command = this.getCommand(locations, codeLens);
    return codeLens;
  }
  getCommand(locations, codeLens) {
    return {
      title: this.getTitle(locations),
      command: locations.length ? "editor.action.showReferences" : "",
      arguments: [codeLens.data.uri, codeLens.range.start, locations]
    };
  }
  getTitle(locations) {
    return locations.length === 1 ? "1 implementation" : `${locations.length} implementations`;
  }
  extractSymbol(document, item, _parent) {
    switch (item.kind) {
      case ScriptElementKind.interfaceElement:
        return getSymbolRange(document, item);
      case ScriptElementKind.classElement:
      case ScriptElementKind.memberFunctionElement:
      case ScriptElementKind.memberVariableElement:
      case ScriptElementKind.memberGetAccessorElement:
      case ScriptElementKind.memberSetAccessorElement:
        if (item.kindModifiers.match(/\babstract\b/g)) {
          return getSymbolRange(document, item);
        }
        break;
    }
    return void 0;
  }
};
var TypeScriptReferencesCodeLensProvider = class extends TypeScriptBaseCodeLensProvider {
  get type() {
    return CodeLensType.Reference;
  }
  async resolveCodeLens(codeLens, token) {
    const document = this.client.toOpenDocument(codeLens.data.uri);
    if (!document) {
      return codeLens;
    }
    if (!this.fileConfigurationManager.getWorkspacePreferencesForFile(document).referencesCodeLens?.enabled) {
      return codeLens;
    }
    const args = Position.toFileLocationRequestArgs(document.filepath, codeLens.range.start);
    const response = await this.client.execute(CommandTypes.References, args, token, {
      lowPriority: true,
      executionTarget: ExecutionTarget.Semantic,
      cancelOnResourceChange: codeLens.data.uri
    });
    if (response.type !== "response" || !response.body) {
      codeLens.command = response.type === "cancelled" ? TypeScriptBaseCodeLensProvider.cancelledCommand : TypeScriptBaseCodeLensProvider.errorCommand;
      return codeLens;
    }
    const locations = response.body.refs.filter((reference) => !reference.isDefinition).map((reference) => Location.fromTextSpan(this.client.toResourceUri(reference.file), reference));
    codeLens.command = {
      title: this.getCodeLensLabel(locations),
      command: locations.length ? "editor.action.showReferences" : "",
      arguments: [codeLens.data.uri, codeLens.range.start, locations]
    };
    return codeLens;
  }
  getCodeLensLabel(locations) {
    return locations.length === 1 ? "1 reference" : `${locations.length} references`;
  }
  extractSymbol(document, item, parent) {
    if (parent && parent.kind === ScriptElementKind.enumElement) {
      return getSymbolRange(document, item);
    }
    switch (item.kind) {
      case ScriptElementKind.functionElement: {
        const showOnAllFunctions = this.fileConfigurationManager.getWorkspacePreferencesForFile(document).referencesCodeLens?.showOnAllFunctions;
        if (showOnAllFunctions) {
          return getSymbolRange(document, item);
        }
      }
      case ScriptElementKind.constElement:
      case ScriptElementKind.letElement:
      case ScriptElementKind.variableElement:
        if (/\bexport\b/.test(item.kindModifiers)) {
          return getSymbolRange(document, item);
        }
        break;
      case ScriptElementKind.classElement:
        if (item.text === "<class>") {
          break;
        }
        return getSymbolRange(document, item);
      case ScriptElementKind.interfaceElement:
      case ScriptElementKind.typeElement:
      case ScriptElementKind.enumElement:
        return getSymbolRange(document, item);
      case ScriptElementKind.memberFunctionElement:
      case ScriptElementKind.memberGetAccessorElement:
      case ScriptElementKind.memberSetAccessorElement:
      case ScriptElementKind.constructorImplementationElement:
      case ScriptElementKind.memberVariableElement:
        if (parent && Position.isEqual(Position.fromLocation(parent.spans[0].start), Position.fromLocation(item.spans[0].start))) {
          return void 0;
        }
        switch (parent?.kind) {
          case ScriptElementKind.classElement:
          case ScriptElementKind.interfaceElement:
          case ScriptElementKind.typeElement:
            return getSymbolRange(document, item);
        }
        break;
    }
    return void 0;
  }
};
var TypeScriptInlayHintsProvider = class _TypeScriptInlayHintsProvider {
  static minVersion = API.v440;
  static async provideInlayHints(textDocument, range2, client, lspClient, fileConfigurationManager, token) {
    if (client.apiVersion.lt(_TypeScriptInlayHintsProvider.minVersion)) {
      lspClient.showErrorMessage("Inlay Hints request failed. Requires TypeScript 4.4+.");
      return [];
    }
    const document = client.toOpenDocument(textDocument.uri);
    if (!document) {
      lspClient.showErrorMessage("Inlay Hints request failed. File not opened in the editor.");
      return [];
    }
    if (!areInlayHintsEnabledForFile(fileConfigurationManager, document)) {
      return [];
    }
    await fileConfigurationManager.ensureConfigurationForDocument(document, token);
    if (token?.isCancellationRequested) {
      return [];
    }
    const start = document.offsetAt(range2.start);
    const length = document.offsetAt(range2.end) - start;
    const response = await client.execute(CommandTypes.ProvideInlayHints, {
      file: document.filepath,
      start,
      length
    }, token);
    if (response.type !== "response" || !response.success || !response.body) {
      return [];
    }
    return response.body.map((hint) => {
      const inlayHint2 = mainExports$2.InlayHint.create(Position.fromLocation(hint.position), _TypeScriptInlayHintsProvider.convertInlayHintText(hint, client), fromProtocolInlayHintKind(hint.kind));
      if (hint.whitespaceBefore) {
        inlayHint2.paddingLeft = true;
      }
      if (hint.whitespaceAfter) {
        inlayHint2.paddingRight = true;
      }
      return inlayHint2;
    });
  }
  static convertInlayHintText(tsHint, filePathConverter) {
    if (tsHint.displayParts) {
      return tsHint.displayParts.map((part) => {
        const out = mainExports$2.InlayHintLabelPart.create(part.text);
        if (part.span) {
          out.location = Location.fromTextSpan(filePathConverter.toResource(part.span.file).toString(), part.span);
        }
        return out;
      });
    }
    return tsHint.text;
  }
};
function areInlayHintsEnabledForFile(fileConfigurationManager, document) {
  const preferences = fileConfigurationManager.getPreferences(document);
  return preferences.includeInlayParameterNameHints === "literals" || preferences.includeInlayParameterNameHints === "all" || preferences.includeInlayEnumMemberValueHints || preferences.includeInlayFunctionLikeReturnTypeHints || preferences.includeInlayFunctionParameterTypeHints || preferences.includeInlayPropertyDeclarationTypeHints || preferences.includeInlayVariableTypeHints;
}
function fromProtocolInlayHintKind(kind) {
  switch (kind) {
    case "Parameter":
      return mainExports$2.InlayHintKind.Parameter;
    case "Type":
      return mainExports$2.InlayHintKind.Type;
    case "Enum":
      return void 0;
    default:
      return void 0;
  }
}
var TokenEncodingConsts;
(function(TokenEncodingConsts2) {
  TokenEncodingConsts2[TokenEncodingConsts2["typeOffset"] = 8] = "typeOffset";
  TokenEncodingConsts2[TokenEncodingConsts2["modifierMask"] = 255] = "modifierMask";
})(TokenEncodingConsts || (TokenEncodingConsts = {}));
function transformSpans(doc, spans) {
  const lspSpans = [];
  let previousLine = 0;
  let previousTokenStart = 0;
  for (let i = 0; i < spans.length; i += 3) {
    const tokenStart = spans[i];
    const tokenLength = spans[i + 1];
    const tokenTypeBitSet = spans[i + 2];
    const tokenModifier = tokenTypeBitSet & TokenEncodingConsts.modifierMask;
    const tokenType = (tokenTypeBitSet >> TokenEncodingConsts.typeOffset) - 1;
    const { line, character } = doc.positionAt(tokenStart);
    const deltaLine = line - previousLine;
    const deltaStart = previousLine === line ? character - previousTokenStart : character;
    lspSpans.push(deltaLine, deltaStart, tokenLength, tokenType, tokenModifier);
    previousTokenStart = character;
    previousLine = line;
  }
  return lspSpans;
}
var CachedResponse = class {
  response;
  version = -1;
  document = "";
  execute(document, resolve2) {
    if (this.response && this.matches(document)) {
      return this.response = this.response.then((result) => result.type === "cancelled" ? resolve2() : result);
    }
    return this.reset(document, resolve2);
  }
  onDocumentClose(document) {
    if (this.document === document.uri.toString()) {
      this.response = void 0;
      this.version = -1;
      this.document = "";
    }
  }
  matches(document) {
    return this.version === document.version && this.document === document.uri.toString();
  }
  async reset(document, resolve2) {
    this.version = document.version;
    this.document = document.uri.toString();
    return this.response = resolve2();
  }
};
var LogDirectoryProvider = class {
  rootPath;
  constructor(rootPath) {
    this.rootPath = rootPath;
  }
  getNewLogDirectory() {
    const root = this.logDirectory();
    if (root) {
      try {
        return fs$2.mkdtempSync(path__default.join(root, "tsserver-log-"));
      } catch {
        return void 0;
      }
    }
    return void 0;
  }
  logDirectory() {
    if (!this.rootPath) {
      return void 0;
    }
    try {
      if (!fs$2.existsSync(this.rootPath)) {
        fs$2.mkdirSync(this.rootPath);
      }
      return this.rootPath;
    } catch {
      return void 0;
    }
  }
};
var CommandManager = class {
  commands = /* @__PURE__ */ new Map();
  dispose() {
    this.commands.clear();
  }
  register(command2) {
    const entry = this.commands.get(command2.id);
    if (!entry) {
      this.commands.set(command2.id, command2);
    }
  }
  get registeredIds() {
    return Array.from(this.commands.keys());
  }
  handlesCommand(commandId) {
    return this.commands.has(commandId);
  }
  async handle(commandId, ...args) {
    const entry = this.commands.get(commandId);
    if (entry) {
      return await entry.execute(...args);
    }
    return null;
  }
};
var variableDeclaredButNeverUsed = /* @__PURE__ */ new Set([6196, 6133]);
var unreachableCode$1 = /* @__PURE__ */ new Set([7027]);
var incorrectlyImplementsInterface = /* @__PURE__ */ new Set([2420]);
var cannotFindName = /* @__PURE__ */ new Set([2552, 2304]);
var asyncOnlyAllowedInAsyncFunctions = /* @__PURE__ */ new Set([1308]);
var addMissingAwait = "addMissingAwait";
var addMissingNewOperator = "addMissingNewOperator";
var addMissingOverride = "fixOverrideModifier";
var annotateWithTypeFromJSDoc = "annotateWithTypeFromJSDoc";
var awaitInSyncFunction = "fixAwaitInSyncFunction";
var classDoesntImplementInheritedAbstractMember = "fixClassDoesntImplementInheritedAbstractMember";
var classIncorrectlyImplementsInterface = "fixClassIncorrectlyImplementsInterface";
var constructorForDerivedNeedSuperCall = "constructorForDerivedNeedSuperCall";
var extendsInterfaceBecomesImplements = "extendsInterfaceBecomesImplements";
var fixImport = "import";
var forgottenThisPropertyAccess = "forgottenThisPropertyAccess";
var removeUnnecessaryAwait = "removeUnnecessaryAwait";
var spelling = "spelling";
var unreachableCode = "fixUnreachableCode";
var unusedIdentifier = "unusedIdentifier";
var TsCodeAction = class {
  title;
  kind;
  command;
  diagnostics;
  disabled;
  edit;
  isPreferred;
  constructor(title, kind) {
    this.title = title;
    this.kind = kind;
  }
  toLspCodeAction() {
    const codeAction = mainExports$2.CodeAction.create(this.title, this.kind);
    if (this.command !== void 0) {
      codeAction.command = this.command;
    }
    if (this.diagnostics !== void 0) {
      codeAction.diagnostics = this.diagnostics;
    }
    if (this.disabled !== void 0) {
      codeAction.disabled = this.disabled;
    }
    if (this.edit !== void 0) {
      codeAction.edit = this.edit;
    }
    if (this.isPreferred !== void 0) {
      codeAction.isPreferred = this.isPreferred;
    }
    return codeAction;
  }
};
async function buildIndividualFixes(fixes, client, file2, diagnostics, token) {
  const documentChanges = [];
  for (const diagnostic2 of diagnostics) {
    for (const { codes, fixName } of fixes) {
      if (token.isCancellationRequested) {
        return;
      }
      if (!codes.has(diagnostic2.code)) {
        continue;
      }
      const args = {
        ...Range.toFileRangeRequestArgs(file2, diagnostic2.range),
        errorCodes: [+diagnostic2.code]
      };
      const response = await client.execute(CommandTypes.GetCodeFixes, args, token);
      if (response.type !== "response") {
        continue;
      }
      const fix = response.body?.find((fix2) => fix2.fixName === fixName);
      if (fix) {
        documentChanges.push(...fix.changes.map((change) => toTextDocumentEdit(change, client)));
        break;
      }
    }
  }
  return {
    documentChanges
  };
}
async function buildCombinedFix(fixes, client, file2, diagnostics, token) {
  for (const diagnostic2 of diagnostics) {
    for (const { codes, fixName } of fixes) {
      if (token.isCancellationRequested) {
        return;
      }
      if (!codes.has(diagnostic2.code)) {
        continue;
      }
      const args = {
        ...Range.toFileRangeRequestArgs(file2, diagnostic2.range),
        errorCodes: [+diagnostic2.code]
      };
      const response = await client.execute(CommandTypes.GetCodeFixes, args, token);
      if (response.type !== "response" || !response.body?.length) {
        continue;
      }
      const fix = response.body?.find((fix2) => fix2.fixName === fixName);
      if (!fix) {
        continue;
      }
      if (!fix.fixId) {
        return {
          documentChanges: fix.changes.map((change) => toTextDocumentEdit(change, client))
        };
      }
      const combinedArgs = {
        scope: {
          type: "file",
          args: {
            file: file2
          }
        },
        fixId: fix.fixId
      };
      const combinedResponse = await client.execute(CommandTypes.GetCombinedCodeFix, combinedArgs, token);
      if (combinedResponse.type !== "response" || !combinedResponse.body) {
        return;
      }
      return {
        documentChanges: combinedResponse.body.changes.map((change) => toTextDocumentEdit(change, client))
      };
    }
  }
}
var SourceAction = class extends TsCodeAction {
};
var SourceFixAll = class _SourceFixAll extends SourceAction {
  static kind = CodeActionKind.SourceFixAllTs;
  constructor() {
    super("Fix all fixable JS/TS issues", _SourceFixAll.kind.value);
  }
  async build(client, file2, diagnostics, token) {
    this.edit = await buildIndividualFixes([{
      codes: incorrectlyImplementsInterface,
      fixName: classIncorrectlyImplementsInterface
    }, {
      codes: asyncOnlyAllowedInAsyncFunctions,
      fixName: awaitInSyncFunction
    }], client, file2, diagnostics, token);
    const edits = await buildCombinedFix([{
      codes: unreachableCode$1,
      fixName: unreachableCode
    }], client, file2, diagnostics, token);
    if (edits?.documentChanges) {
      this.edit?.documentChanges?.push(...edits.documentChanges);
    }
  }
};
var SourceRemoveUnused = class _SourceRemoveUnused extends SourceAction {
  static kind = CodeActionKind.SourceRemoveUnusedTs;
  constructor() {
    super("Remove all unused code", _SourceRemoveUnused.kind.value);
  }
  async build(client, file2, diagnostics, token) {
    this.edit = await buildCombinedFix([{
      codes: variableDeclaredButNeverUsed,
      fixName: unusedIdentifier
    }], client, file2, diagnostics, token);
  }
};
var SourceAddMissingImports = class _SourceAddMissingImports extends SourceAction {
  static kind = CodeActionKind.SourceAddMissingImportsTs;
  constructor() {
    super("Add all missing imports", _SourceAddMissingImports.kind.value);
  }
  async build(client, file2, diagnostics, token) {
    this.edit = await buildCombinedFix([{
      codes: cannotFindName,
      fixName: fixImport
    }], client, file2, diagnostics, token);
  }
};
var TypeScriptAutoFixProvider = class _TypeScriptAutoFixProvider {
  client;
  fileConfigurationManager;
  diagnosticsManager;
  static kindProviders = [SourceFixAll, SourceRemoveUnused, SourceAddMissingImports];
  constructor(client, fileConfigurationManager, diagnosticsManager) {
    this.client = client;
    this.fileConfigurationManager = fileConfigurationManager;
    this.diagnosticsManager = diagnosticsManager;
  }
  getMetadata() {
    return {
      providedCodeActionKinds: _TypeScriptAutoFixProvider.kindProviders.map((x) => x.kind.value)
    };
  }
  async provideCodeActions(document, _range, context, token) {
    if (!context.only?.length) {
      return void 0;
    }
    const sourceKinds = context.only.map((kind) => new CodeActionKind(kind)).filter((codeActionKind) => CodeActionKind.Source.intersects(codeActionKind));
    if (!sourceKinds.length) {
      return void 0;
    }
    if (this.client.hasPendingDiagnostics(document.uri)) {
      return void 0;
    }
    const actions = this.getFixAllActions(sourceKinds);
    const diagnostics = this.diagnosticsManager.getDiagnosticsForFile(document.filepath);
    if (!diagnostics.length) {
      return actions;
    }
    await this.fileConfigurationManager.ensureConfigurationForDocument(document, token);
    if (token.isCancellationRequested) {
      return void 0;
    }
    await Promise.all(actions.map((action) => action.build(this.client, document.filepath, diagnostics, token)));
    return actions;
  }
  isCodeActionResolvable(_codeAction) {
    return false;
  }
  getFixAllActions(kinds) {
    return _TypeScriptAutoFixProvider.kindProviders.filter((provider) => kinds.some((only) => only.intersects(provider.kind))).map((provider) => new provider());
  }
};
var Lazy = class {
  executor;
  _didRun = false;
  _value;
  _error;
  constructor(executor) {
    this.executor = executor;
  }
  get hasValue() {
    return this._didRun;
  }
  get value() {
    if (!this._didRun) {
      try {
        this._value = this.executor();
      } catch (err) {
        this._error = err;
      } finally {
        this._didRun = true;
      }
    }
    if (this._error) {
      throw this._error;
    }
    return this._value;
  }
  get rawValue() {
    return this._value;
  }
};
function getEditForCodeAction(client, action) {
  return action.changes?.length ? {
    documentChanges: action.changes.map((change) => toTextDocumentEdit(change, client))
  } : void 0;
}
async function applyCodeActionCommands(client, commands, token) {
  if (commands?.length) {
    for (const command2 of commands) {
      await client.execute(CommandTypes.ApplyCodeActionCommand, {
        command: command2
      }, token);
    }
  }
  return true;
}
var ApplyCodeActionCommand = class _ApplyCodeActionCommand {
  client;
  static ID = "_typescript.applyCodeActionCommand";
  id = _ApplyCodeActionCommand.ID;
  constructor(client) {
    this.client = client;
  }
  async execute({ action }) {
    const codeActionResult = await applyCodeActionCommands(this.client, action.commands);
    return codeActionResult;
  }
};
var ApplyFixAllCodeAction = class _ApplyFixAllCodeAction {
  client;
  tsCodeActionProvider;
  static ID = "_typescript.applyFixAllCodeAction";
  id = _ApplyFixAllCodeAction.ID;
  constructor(client, tsCodeActionProvider) {
    this.client = client;
    this.tsCodeActionProvider = tsCodeActionProvider;
  }
  async execute(args) {
    const tsAction = this.tsCodeActionProvider.getQuickFixAllTsCodeActionByFixName(args.tsActionId);
    if (tsAction instanceof TsQuickFixAllCodeAction && tsAction.combinedResponse) {
      await applyCodeActionCommands(this.client, tsAction.combinedResponse.body.commands);
    }
  }
};
var DiagnosticsSet = class _DiagnosticsSet {
  _values;
  static from(diagnostics) {
    const values = /* @__PURE__ */ new Map();
    for (const diagnostic2 of diagnostics) {
      values.set(_DiagnosticsSet.key(diagnostic2), diagnostic2);
    }
    return new _DiagnosticsSet(values);
  }
  static key(diagnostic2) {
    const { start, end } = diagnostic2.range;
    return `${diagnostic2.code}-${start.line},${start.character}-${end.line},${end.character}`;
  }
  constructor(_values) {
    this._values = _values;
  }
  get values() {
    return this._values.values();
  }
  get size() {
    return this._values.size;
  }
};
var TsQuickFixCodeAction = class extends TsCodeAction {
  tsAction;
  constructor(tsAction, title, kind) {
    super(title, kind);
    this.tsAction = tsAction;
  }
};
var TsQuickFixAllCodeAction = class extends TsQuickFixCodeAction {
  file;
  constructor(tsAction, file2, title, kind) {
    super(tsAction, title, kind);
    this.file = file2;
  }
  combinedResponse;
};
var CodeActionSet = class {
  _actions = /* @__PURE__ */ new Set();
  _fixAllActions = /* @__PURE__ */ new Map();
  _aiActions = /* @__PURE__ */ new Set();
  *values() {
    yield* this._actions;
    yield* this._aiActions;
  }
  addAction(action) {
    for (const existing of this._actions) {
      if (action.tsAction.fixName === existing.tsAction.fixName && equals(action.edit, existing.edit)) {
        this._actions.delete(existing);
      }
    }
    this._actions.add(action);
    if (action.tsAction.fixId) {
      const existingFixAll = this._fixAllActions.get(action.tsAction.fixId);
      if (existingFixAll) {
        this._actions.delete(existingFixAll);
        this._actions.add(existingFixAll);
      }
    }
  }
  addFixAllAction(fixId, action) {
    const existing = this._fixAllActions.get(fixId);
    if (existing) {
      this._actions.delete(existing);
    }
    this.addAction(action);
    this._fixAllActions.set(fixId, action);
  }
  hasFixAllAction(fixId) {
    return this._fixAllActions.has(fixId);
  }
};
var SupportedCodeActionProvider = class {
  client;
  constructor(client) {
    this.client = client;
  }
  async getFixableDiagnosticsForContext(diagnostics) {
    const fixableCodes = await this.fixableDiagnosticCodes.value;
    return DiagnosticsSet.from(diagnostics.filter((diagnostic2) => typeof diagnostic2.code !== "undefined" && fixableCodes.has(diagnostic2.code + "")));
  }
  fixableDiagnosticCodes = new Lazy(() => this.client.execute(CommandTypes.GetSupportedCodeFixes, null).then((response) => response.type === "response" ? response.body || [] : []).then((codes) => new Set(codes)));
};
var TypeScriptQuickFixProvider = class _TypeScriptQuickFixProvider {
  client;
  fileConfigurationManager;
  diagnosticsManager;
  features;
  static _maxCodeActionsPerFile = 1e3;
  _quickFixAllTsCodeActionMap = /* @__PURE__ */ new Map();
  supportedCodeActionProvider;
  constructor(client, fileConfigurationManager, commandManager, diagnosticsManager, features) {
    this.client = client;
    this.fileConfigurationManager = fileConfigurationManager;
    this.diagnosticsManager = diagnosticsManager;
    this.features = features;
    commandManager.register(new ApplyCodeActionCommand(client));
    commandManager.register(new ApplyFixAllCodeAction(client, this));
    this.supportedCodeActionProvider = new SupportedCodeActionProvider(client);
  }
  getMetadata() {
    return {
      providedCodeActionKinds: [CodeActionKind.QuickFix.value]
    };
  }
  async provideCodeActions(document, range2, context, token) {
    this._quickFixAllTsCodeActionMap.clear();
    let diagnostics = context.diagnostics;
    if (this.client.hasPendingDiagnostics(document.uri)) {
      await new Promise((resolve2) => {
        setTimeout(resolve2, 500);
      });
      if (token.isCancellationRequested) {
        return;
      }
      const allDiagnostics = [];
      for (const diagnostic2 of this.diagnosticsManager.getDiagnosticsForFile(document.filepath)) {
        if (Range.intersection(range2, diagnostic2.range)) {
          const newLen = allDiagnostics.push(diagnostic2);
          if (newLen > _TypeScriptQuickFixProvider._maxCodeActionsPerFile) {
            break;
          }
        }
      }
      diagnostics = allDiagnostics;
    }
    const fixableDiagnostics = await this.supportedCodeActionProvider.getFixableDiagnosticsForContext(diagnostics);
    if (!fixableDiagnostics.size || token.isCancellationRequested) {
      return;
    }
    await this.fileConfigurationManager.ensureConfigurationForDocument(document, token);
    if (token.isCancellationRequested) {
      return;
    }
    const results = new CodeActionSet();
    for (const diagnostic2 of fixableDiagnostics.values) {
      await this.getFixesForDiagnostic(document, diagnostic2, results, token);
      if (token.isCancellationRequested) {
        return;
      }
    }
    const allActions = Array.from(results.values());
    for (const action of allActions) {
      action.isPreferred = isPreferredFix(action, allActions);
    }
    return allActions;
  }
  isCodeActionResolvable(codeAction) {
    return codeAction instanceof TsQuickFixAllCodeAction;
  }
  async resolveCodeAction(codeAction, token) {
    if (!this.isCodeActionResolvable(codeAction) || !codeAction.tsAction.fixId) {
      return codeAction;
    }
    const arg = {
      scope: {
        type: "file",
        args: {
          file: codeAction.file
        }
      },
      fixId: codeAction.tsAction.fixId
    };
    const response = await this.client.execute(CommandTypes.GetCombinedCodeFix, arg, token);
    if (response.type === "response") {
      codeAction.combinedResponse = response;
      codeAction.edit = {
        documentChanges: response.body.changes.map((change) => toTextDocumentEdit(change, this.client))
      };
    }
    return codeAction;
  }
  getQuickFixAllTsCodeActionByFixName(fixName) {
    return this._quickFixAllTsCodeActionMap.get(fixName);
  }
  async getFixesForDiagnostic(document, diagnostic2, results, token) {
    const args = {
      ...Range.toFileRangeRequestArgs(document.filepath, diagnostic2.range),
      errorCodes: [+diagnostic2.code]
    };
    const response = await this.client.execute(CommandTypes.GetCodeFixes, args, token);
    if (response.type !== "response" || !response.body) {
      return results;
    }
    for (const tsCodeFix of response.body) {
      for (const action of this.getFixesForTsCodeAction(document, diagnostic2, tsCodeFix)) {
        results.addAction(action);
      }
      if (this.features.codeActionResolveSupport) {
        this.addFixAllForTsCodeAction(results, document.uri, document.filepath, diagnostic2, tsCodeFix);
      }
    }
    return results;
  }
  getFixesForTsCodeAction(document, diagnostic2, action) {
    const actions = [];
    const codeAction = new TsQuickFixCodeAction(action, action.description, mainExports$2.CodeActionKind.QuickFix);
    codeAction.edit = getEditForCodeAction(this.client, action);
    codeAction.diagnostics = [diagnostic2];
    codeAction.command = {
      command: ApplyCodeActionCommand.ID,
      arguments: [{
        action,
        diagnostic: diagnostic2,
        documentUri: document.uri.toString()
      }],
      title: ""
    };
    actions.push(codeAction);
    return actions;
  }
  addFixAllForTsCodeAction(results, _resource, file2, diagnostic2, tsAction) {
    if (!tsAction.fixId || results.hasFixAllAction(tsAction.fixId)) {
      return results;
    }
    if (!this.diagnosticsManager.getDiagnosticsForFile(file2).some((x) => {
      if (x === diagnostic2) {
        return false;
      }
      return x.code === diagnostic2.code || fixAllErrorCodes.has(x.code) && fixAllErrorCodes.get(x.code) === fixAllErrorCodes.get(diagnostic2.code);
    })) {
      return results;
    }
    const action = new TsQuickFixAllCodeAction(tsAction, file2, tsAction.fixAllDescription || `${tsAction.description} (Fix all in file)`, mainExports$2.CodeActionKind.QuickFix);
    action.diagnostics = [diagnostic2];
    action.command = {
      command: ApplyFixAllCodeAction.ID,
      arguments: [{
        tsActionId: tsAction.fixName
      }],
      title: ""
    };
    this._quickFixAllTsCodeActionMap.set(tsAction.fixName, action);
    results.addFixAllAction(tsAction.fixId, action);
    return results;
  }
};
var fixAllErrorCodes = /* @__PURE__ */ new Map([[2339, 2339], [2345, 2339]]);
var preferredFixes = /* @__PURE__ */ new Map([[annotateWithTypeFromJSDoc, {
  priority: 2
}], [constructorForDerivedNeedSuperCall, {
  priority: 2
}], [extendsInterfaceBecomesImplements, {
  priority: 2
}], [awaitInSyncFunction, {
  priority: 2
}], [removeUnnecessaryAwait, {
  priority: 2
}], [classIncorrectlyImplementsInterface, {
  priority: 3
}], [classDoesntImplementInheritedAbstractMember, {
  priority: 3
}], [unreachableCode, {
  priority: 2
}], [unusedIdentifier, {
  priority: 2
}], [forgottenThisPropertyAccess, {
  priority: 2
}], [spelling, {
  priority: 0
}], [addMissingAwait, {
  priority: 2
}], [addMissingOverride, {
  priority: 2
}], [addMissingNewOperator, {
  priority: 2
}], [fixImport, {
  priority: 1,
  thereCanOnlyBeOne: true
}]]);
function isPreferredFix(action, allActions) {
  if (action instanceof TsQuickFixAllCodeAction) {
    return false;
  }
  const fixPriority = preferredFixes.get(action.tsAction.fixName);
  if (!fixPriority) {
    return false;
  }
  return allActions.every((otherAction) => {
    if (otherAction === action) {
      return true;
    }
    if (otherAction instanceof TsQuickFixAllCodeAction) {
      return true;
    }
    const otherFixPriority = preferredFixes.get(otherAction.tsAction.fixName);
    if (!otherFixPriority || otherFixPriority.priority < fixPriority.priority) {
      return true;
    } else if (otherFixPriority.priority > fixPriority.priority) {
      return false;
    }
    if (fixPriority.thereCanOnlyBeOne && action.tsAction.fixName === otherAction.tsAction.fixName) {
      return false;
    }
    return true;
  });
}
var noopDisposable = mainExports$2.Disposable.create(() => {
});
var nulToken = {
  isCancellationRequested: false,
  onCancellationRequested: () => noopDisposable
};
var CodeActionManager = class {
  features;
  providerMap = /* @__PURE__ */ new Map();
  nextProviderId = 1;
  resolveCodeActionsMap = /* @__PURE__ */ new Map();
  nextGlobalCodeActionId = 1;
  constructor(client, fileConfigurationManager, commandManager, diagnosticsManager, features) {
    this.features = features;
    this.addProvider(new TypeScriptAutoFixProvider(client, fileConfigurationManager, diagnosticsManager));
    this.addProvider(new TypeScriptQuickFixProvider(client, fileConfigurationManager, commandManager, diagnosticsManager, features));
  }
  get kinds() {
    const allKinds = [];
    for (const [_, provider] of this.providerMap) {
      allKinds.push(...provider.getMetadata().providedCodeActionKinds || []);
    }
    return allKinds;
  }
  async provideCodeActions(document, range2, context, token) {
    this.resolveCodeActionsMap.clear();
    const allCodeActions = [];
    for (const [providerId, provider] of this.providerMap.entries()) {
      const codeActions = await provider.provideCodeActions(document, range2, context, token || nulToken);
      if (!codeActions) {
        continue;
      }
      for (const action of codeActions) {
        if (mainExports$2.Command.is(action)) {
          allCodeActions.push(action);
          continue;
        }
        const lspCodeAction = action.toLspCodeAction();
        if (provider.isCodeActionResolvable(action)) {
          const globalId = this.nextGlobalCodeActionId++;
          this.resolveCodeActionsMap.set(globalId, action);
          lspCodeAction.data = {
            globalId,
            providerId
          };
        }
        allCodeActions.push(lspCodeAction);
      }
    }
    return allCodeActions;
  }
  async resolveCodeAction(codeAction, token) {
    if (!this.features.codeActionResolveSupport) {
      return codeAction;
    }
    const { globalId, providerId } = codeAction.data || {};
    if (globalId === void 0 || providerId === void 0) {
      return codeAction;
    }
    const provider = this.providerMap.get(providerId);
    if (!provider || !provider.resolveCodeAction) {
      return codeAction;
    }
    const tsCodeAction = this.resolveCodeActionsMap.get(globalId);
    if (!tsCodeAction || !providerId) {
      return codeAction;
    }
    const resolvedTsCodeAction = await provider.resolveCodeAction(tsCodeAction, token || nulToken);
    if (!resolvedTsCodeAction) {
      return codeAction;
    }
    const lspCodeAction = resolvedTsCodeAction.toLspCodeAction();
    for (const property of this.features.codeActionResolveSupport.properties) {
      if (property in lspCodeAction) {
        codeAction[property] = lspCodeAction[property];
      }
    }
    return codeAction;
  }
  addProvider(provider) {
    this.providerMap.set(this.nextProviderId++, provider);
  }
};
var WatchEventManager = class {
  options;
  watchers = /* @__PURE__ */ new Map();
  coverage = /* @__PURE__ */ new Map();
  coverageUsage = /* @__PURE__ */ new Map();
  workspacePaths;
  registration;
  registrationHash;
  updateRegistrationQueue = Promise.resolve();
  readyForRegistration = false;
  disposed = false;
  constructor(options2) {
    this.options = options2;
    this.workspacePaths = options2.workspaceFolders.map((folder) => this.normalizePath(folder.fsPath));
    for (const folder of options2.workspaceFolders) {
      const key = this.coverageKey(folder.fsPath, "**/*");
      const kind = mainExports$2.WatchKind.Create | mainExports$2.WatchKind.Change | mainExports$2.WatchKind.Delete;
      const entry = {
        key,
        normalizedBase: this.normalizePath(folder.fsPath),
        watcher: {
          globPattern: {
            baseUri: folder.toString(),
            pattern: "**/*"
          },
          kind
        },
        watchKind: kind,
        permanent: true
      };
      this.coverage.set(key, entry);
    }
  }
  onInitialized() {
    this.readyForRegistration = true;
    this.updateRegistration();
  }
  dispose() {
    this.disposed = true;
    this.registration?.dispose();
    this.registration = void 0;
    this.watchers.clear();
    this.coverage.clear();
    this.coverageUsage.clear();
  }
  handleTsserverEvent(event) {
    switch (event.event) {
      case EventName.createFileWatcher:
        this.addFileWatcher(event.body);
        return true;
      case EventName.createDirectoryWatcher:
        this.addDirectoryWatcher(event.body);
        return true;
      case EventName.closeFileWatcher:
        this.closeWatcher(event.body);
        return true;
      default:
        return false;
    }
  }
  handleFileChanges(params) {
    if (!this.watchers.size || !params.changes.length) {
      return;
    }
    const collected = /* @__PURE__ */ new Map();
    for (const change of params.changes) {
      const uri = URI.parse(change.uri);
      const fsPath = uri.fsPath;
      const normalizedFsPath = this.normalizePath(fsPath);
      for (const watcher of this.watchers.values()) {
        if (!this.watcherMatchesPath(watcher, normalizedFsPath)) {
          continue;
        }
        if (change.type === mainExports$2.FileChangeType.Changed && watcher.ignoreUpdate) {
          continue;
        }
        const changes = this.ensureChangeBucket(collected, watcher.id);
        switch (change.type) {
          case mainExports$2.FileChangeType.Created:
            changes.created.push(normalizedFsPath);
            break;
          case mainExports$2.FileChangeType.Deleted:
            changes.deleted.push(normalizedFsPath);
            break;
          case mainExports$2.FileChangeType.Changed:
            changes.updated.push(normalizedFsPath);
            break;
        }
      }
    }
    if (!collected.size) {
      return;
    }
    const payload = [];
    for (const [id, changes] of collected.entries()) {
      payload.push({
        id,
        created: changes.created.length ? changes.created : void 0,
        deleted: changes.deleted.length ? changes.deleted : void 0,
        updated: changes.updated.length ? changes.updated : void 0
      });
    }
    this.options.sendWatchChanges(payload.length === 1 ? payload[0] : payload);
  }
  ensureChangeBucket(collected, id) {
    let bucket = collected.get(id);
    if (!bucket) {
      bucket = {
        created: [],
        deleted: [],
        updated: []
      };
      collected.set(id, bucket);
    }
    return bucket;
  }
  addFileWatcher(body) {
    const normalizedPath = this.normalizePath(body.path);
    const watcher = {
      id: body.id,
      path: body.path,
      normalizedPath,
      kind: "file",
      recursive: false,
      ignoreUpdate: false
    };
    watcher.coverageKey = this.ensureCoverageForWatcher(watcher);
    this.watchers.set(body.id, watcher);
  }
  addDirectoryWatcher(body) {
    const normalizedPath = this.normalizePath(body.path);
    const watcher = {
      id: body.id,
      path: body.path,
      normalizedPath,
      kind: "directory",
      recursive: !!body.recursive,
      ignoreUpdate: !!body.ignoreUpdate
    };
    watcher.coverageKey = this.ensureCoverageForWatcher(watcher);
    this.watchers.set(body.id, watcher);
  }
  closeWatcher(body) {
    const watcher = this.watchers.get(body.id);
    if (!watcher) {
      return;
    }
    this.watchers.delete(body.id);
    if (!watcher.coverageKey) {
      return;
    }
    const usage = (this.coverageUsage.get(watcher.coverageKey) ?? 1) - 1;
    if (usage <= 0) {
      this.coverageUsage.delete(watcher.coverageKey);
      const coverage = this.coverage.get(watcher.coverageKey);
      if (coverage && !coverage.permanent) {
        this.coverage.delete(watcher.coverageKey);
        this.registrationHash = void 0;
        this.updateRegistration();
      }
    } else {
      this.coverageUsage.set(watcher.coverageKey, usage);
    }
  }
  ensureCoverageForWatcher(watcher) {
    if (this.isCoveredByWorkspace(watcher.normalizedPath)) {
      return void 0;
    }
    const basePath = watcher.kind === "file" ? path__default.dirname(watcher.path) : watcher.path;
    const pattern = watcher.kind === "file" ? path__default.basename(watcher.path) : watcher.recursive ? "**/*" : "*";
    const coverageKey = this.coverageKey(basePath, pattern);
    const desiredWatchKind = watcher.ignoreUpdate ? mainExports$2.WatchKind.Create | mainExports$2.WatchKind.Delete : mainExports$2.WatchKind.Create | mainExports$2.WatchKind.Change | mainExports$2.WatchKind.Delete;
    const existing = this.coverage.get(coverageKey);
    let coverageChanged = false;
    if (existing) {
      const addedChangeWatch = desiredWatchKind !== existing.watchKind && (existing.watchKind & mainExports$2.WatchKind.Change) === 0 && (desiredWatchKind & mainExports$2.WatchKind.Change) !== 0;
      if (addedChangeWatch) {
        const updated = this.createCoverageEntry(basePath, pattern, desiredWatchKind, coverageKey, false);
        this.coverage.set(coverageKey, updated);
        coverageChanged = true;
      }
    } else {
      const entry = this.createCoverageEntry(basePath, pattern, desiredWatchKind, coverageKey, false);
      this.coverage.set(coverageKey, entry);
      coverageChanged = true;
    }
    this.coverageUsage.set(coverageKey, (this.coverageUsage.get(coverageKey) ?? 0) + 1);
    if (coverageChanged) {
      this.registrationHash = void 0;
      this.updateRegistration();
    }
    return coverageKey;
  }
  createCoverageEntry(basePath, pattern, watchKind, key, permanent) {
    return {
      key,
      watchKind,
      normalizedBase: this.normalizePath(basePath),
      watcher: {
        globPattern: {
          baseUri: URI.file(basePath).toString(),
          pattern
        },
        kind: watchKind
      },
      permanent
    };
  }
  updateRegistration() {
    this.updateRegistrationQueue = this.updateRegistrationQueue.then(() => this.doUpdateRegistration());
  }
  async doUpdateRegistration() {
    if (this.disposed || !this.readyForRegistration) {
      return;
    }
    const watchers = Array.from(this.coverage.values(), (entry) => entry.watcher);
    if (!watchers.length) {
      this.registration?.dispose();
      this.registration = void 0;
      this.registrationHash = void 0;
      return;
    }
    const hash = watchers.map((watcher) => {
      const { baseUri, pattern } = watcher.globPattern;
      const baseUriString = typeof baseUri === "string" ? baseUri : baseUri.uri;
      return `${baseUriString}|${pattern}|${watcher.kind}`;
    }).join("-");
    if (hash === this.registrationHash) {
      return;
    }
    this.registrationHash = hash;
    try {
      this.registration?.dispose();
      this.registration = await this.options.lspClient.registerDidChangeWatchedFilesCapability(watchers);
      if (this.disposed) {
        this.registration.dispose();
        this.registration = void 0;
      }
    } catch (err) {
      this.options.logger.warn("Failed to register file watchers for tsserver watch events", err);
    }
  }
  watcherMatchesPath(watcher, normalizedFsPath) {
    if (watcher.kind === "file") {
      return watcher.normalizedPath === normalizedFsPath;
    }
    const base = watcher.normalizedPath;
    if (watcher.recursive) {
      return normalizedFsPath === base || normalizedFsPath.startsWith(base + "/");
    }
    return this.dirname(normalizedFsPath) === base;
  }
  isCoveredByWorkspace(normalizedPath) {
    return this.workspacePaths.some((base) => normalizedPath === base || normalizedPath.startsWith(base + "/"));
  }
  normalizePath(filePath) {
    const normalized = path__default.normalize(filePath).replace(/\\/g, "/");
    const isDriveRoot = /^[a-zA-Z]:\/?$/.test(normalized);
    const isPosixRoot = normalized === "/";
    const trimmed = isDriveRoot || isPosixRoot ? normalized.replace(/\/+$/, "/") : normalized.replace(/\/+$/, "");
    return this.options.caseInsensitive ? trimmed.toLowerCase() : trimmed;
  }
  dirname(normalizedPath) {
    const dir = normalizedPath.substring(0, normalizedPath.lastIndexOf("/"));
    return dir || normalizedPath;
  }
  coverageKey(basePath, pattern) {
    return `${this.normalizePath(basePath)}|${pattern}`;
  }
};
var LspServer = class {
  options;
  tsClient;
  fileConfigurationManager;
  initializeParams = null;
  diagnosticsManager;
  completionDataCache = new CompletionDataCache();
  logger;
  codeActionsManager;
  commandManager;
  workspaceRoot;
  features = {};
  cachedNavTreeResponse = new CachedResponse();
  implementationsCodeLensProvider = null;
  referencesCodeLensProvider = null;
  watchEventManager = null;
  constructor(options2) {
    this.options = options2;
    this.logger = new PrefixingLogger(options2.logger, "[lspserver]");
    this.tsClient = new TsClient(onCaseInsensitiveFileSystem(), this.logger, options2.lspClient);
    this.fileConfigurationManager = new FileConfigurationManager(this.tsClient, this.options.lspClient, this.features, onCaseInsensitiveFileSystem());
    this.commandManager = new CommandManager();
    this.diagnosticsManager = new DiagnosticsManager((diagnostics) => this.options.lspClient.publishDiagnostics(diagnostics), this.tsClient, this.features, this.logger);
    this.codeActionsManager = new CodeActionManager(this.tsClient, this.fileConfigurationManager, this.commandManager, this.diagnosticsManager, this.features);
    this.commandManager.register(new TSServerRequestCommand(this.tsClient));
  }
  closeAllForTesting() {
    for (const document of this.tsClient.documentsForTesting.values()) {
      this.closeDocument(document.uri.toString());
    }
  }
  async waitForDiagnosticsForFile(uri) {
    const document = this.tsClient.toOpenDocument(uri);
    if (!document) {
      throw new Error(`Document not open: ${uri}`);
    }
    await this.diagnosticsManager.waitForDiagnosticsForTesting(document.filepath);
  }
  shutdown() {
    this.watchEventManager?.dispose();
    this.watchEventManager = null;
    this.tsClient.shutdown();
  }
  initialize(params) {
    this.initializeParams = params;
    const clientCapabilities = this.initializeParams.capabilities;
    this.workspaceRoot = this.initializeParams.rootUri ? URI.parse(this.initializeParams.rootUri).fsPath : this.initializeParams.rootPath || void 0;
    const userInitializationOptions = this.initializeParams.initializationOptions || {};
    const { disableAutomaticTypingAcquisition, hostInfo, maxTsServerMemory, npmLocation, locale, plugins, tsserver } = userInitializationOptions;
    const typescriptVersion = this.findTypescriptVersion(tsserver?.path, tsserver?.fallbackPath);
    if (typescriptVersion) {
      this.options.lspClient.logMessage({
        type: mainExports$2.MessageType.Info,
        message: `Using Typescript version (${typescriptVersion.source}) ${typescriptVersion.versionString} from path "${typescriptVersion.tsServerPath}"`
      });
    } else {
      throw Error('Could not find a valid TypeScript installation. Please ensure that the "typescript" dependency is installed in the workspace or that a valid `tsserver.path` is specified. Exiting.');
    }
    this.fileConfigurationManager.mergeTsPreferences(userInitializationOptions.preferences || {});
    this.features.completionDisableFilterText = userInitializationOptions.completionDisableFilterText ?? false;
    this.features.moveToFileCodeActionSupport = userInitializationOptions.supportsMoveToFileCodeAction && typescriptVersion.version?.gte(API.v520);
    this.features.hoverVerbositySupport = userInitializationOptions.supportsHoverVerbosity && typescriptVersion.version?.gte(API.v590);
    const { textDocument, workspace } = clientCapabilities;
    if (textDocument) {
      const { codeAction, completion, definition, publishDiagnostics } = textDocument;
      if (codeAction) {
        this.features.codeActionDisabledSupport = codeAction.disabledSupport;
        this.features.codeActionResolveSupport = codeAction.resolveSupport;
      }
      if (completion) {
        const { completionItem } = completion;
        if (completionItem) {
          const { commitCharactersSupport, insertReplaceSupport, labelDetailsSupport, snippetSupport } = completionItem;
          this.features.completionCommitCharactersSupport = commitCharactersSupport;
          this.features.completionInsertReplaceSupport = insertReplaceSupport;
          this.features.completionSnippets = snippetSupport;
          this.features.completionLabelDetails = this.fileConfigurationManager.tsPreferences.useLabelDetailsInCompletionEntries && labelDetailsSupport && typescriptVersion.version?.gte(API.v470);
        }
      }
      if (definition) {
        this.features.definitionLinkSupport = definition.linkSupport;
      }
      this.features.diagnosticsSupport = Boolean(publishDiagnostics);
      this.features.diagnosticsTagSupport = Boolean(publishDiagnostics?.tagSupport);
    }
    if (workspace?.codeLens?.refreshSupport) {
      this.features.codeLensRefreshSupport = true;
    }
    if (workspace?.inlayHint?.refreshSupport) {
      this.features.inlayHintRefreshSupport = true;
    }
    if (workspace?.configuration) {
      this.features.workspaceConfigurationSuppport = true;
    }
    this.fileConfigurationManager.mergeTsPreferences({
      useLabelDetailsInCompletionEntries: this.features.completionLabelDetails
    });
    const requestedWatchEvents = tsserver?.useClientFileWatcher ?? false;
    let canUseWatchEvents = false;
    if (requestedWatchEvents) {
      const supportsFileWatcherRegistration = Boolean(workspace?.didChangeWatchedFiles?.dynamicRegistration);
      const supportsRelativePatterns = workspace?.didChangeWatchedFiles?.relativePatternSupport === true;
      const typescriptSupportsWatchEvents = typescriptVersion.version?.gte(API.v544);
      if (!supportsFileWatcherRegistration) {
        this.logger.logIgnoringVerbosity(LogLevel.Warning, "Client does not support dynamic file watcher registration; falling back to tsserver file watching.");
      } else if (!supportsRelativePatterns) {
        this.logger.logIgnoringVerbosity(LogLevel.Warning, "Client does not support relative file watcher patterns; falling back to tsserver file watching.");
      } else if (!typescriptSupportsWatchEvents) {
        this.logger.logIgnoringVerbosity(LogLevel.Warning, "Client-side file watching requires TypeScript 5.4.4 or newer; disabling useClientFileWatcher.");
      } else {
        canUseWatchEvents = true;
      }
    }
    const tsserverLogVerbosity = tsserver?.logVerbosity && TsServerLogLevel.fromString(tsserver.logVerbosity);
    const started = this.tsClient.start(this.workspaceRoot, {
      trace: Trace.fromString(tsserver?.trace || "off"),
      typescriptVersion,
      logDirectoryProvider: new LogDirectoryProvider(this.getLogDirectoryPath(userInitializationOptions)),
      logVerbosity: tsserverLogVerbosity ?? TsServerLogLevel.Off,
      disableAutomaticTypingAcquisition,
      maxTsServerMemory,
      npmLocation,
      hostInfo,
      locale,
      plugins: plugins || [],
      onEvent: this.onTsEvent.bind(this),
      onExit: (exitCode, signal) => {
        this.shutdown();
        if (exitCode) {
          throw new Error(`tsserver process has exited (exit code: ${exitCode}, signal: ${signal}). Stopping the server.`);
        }
      },
      useClientFileWatcher: tsserver?.useClientFileWatcher ?? false,
      useSyntaxServer: toSyntaxServerConfiguration(tsserver?.useSyntaxServer)
    });
    if (!started) {
      throw new Error("tsserver process has failed to start.");
    }
    process.on("exit", () => {
      this.shutdown();
    });
    process.on("SIGINT", () => {
      process.exit();
    });
    if (canUseWatchEvents) {
      this.watchEventManager = new WatchEventManager({
        lspClient: this.options.lspClient,
        logger: this.logger,
        workspaceFolders: this.getWorkspaceFolders(),
        sendWatchChanges: (changes) => this.tsClient.sendWatchChanges(changes),
        caseInsensitive: onCaseInsensitiveFileSystem()
      });
    }
    this.fileConfigurationManager.setGlobalConfiguration(this.workspaceRoot, hostInfo);
    this.registerHandlers();
    const prepareSupport = textDocument?.rename?.prepareSupport && this.tsClient.apiVersion.gte(API.v310);
    const { codeActionLiteralSupport, resolveSupport: codeActionResolveSupport } = textDocument?.codeAction || {};
    const initializeResult = {
      capabilities: {
        textDocumentSync: mainExports$2.TextDocumentSyncKind.Incremental,
        completionProvider: {
          triggerCharacters: [".", '"', "'", "/", "@", "<"],
          resolveProvider: true
        },
        codeActionProvider: codeActionLiteralSupport || codeActionResolveSupport ? {
          ...codeActionLiteralSupport ? {
            codeActionKinds: [...this.codeActionsManager.kinds, CodeActionKind.SourceOrganizeImportsTs.value, CodeActionKind.SourceRemoveUnusedImportsTs.value, CodeActionKind.SourceSortImportsTs.value, CodeActionKind.Refactor.value]
          } : {},
          ...codeActionResolveSupport ? {
            resolveProvider: true
          } : {}
        } : true,
        codeLensProvider: {
          resolveProvider: true
        },
        definitionProvider: true,
        documentFormattingProvider: true,
        documentRangeFormattingProvider: true,
        documentHighlightProvider: true,
        documentSymbolProvider: true,
        executeCommandProvider: {
          commands: [Commands.APPLY_REFACTORING, Commands.CONFIGURE_PLUGIN, Commands.ORGANIZE_IMPORTS, Commands.APPLY_RENAME_FILE, Commands.SOURCE_DEFINITION, ...this.commandManager.registeredIds]
        },
        hoverProvider: true,
        inlayHintProvider: true,
        linkedEditingRangeProvider: false,
        renameProvider: prepareSupport ? {
          prepareProvider: true
        } : true,
        referencesProvider: true,
        selectionRangeProvider: true,
        signatureHelpProvider: {
          triggerCharacters: ["(", ",", "<"],
          retriggerCharacters: [")"]
        },
        workspaceSymbolProvider: true,
        implementationProvider: true,
        typeDefinitionProvider: true,
        foldingRangeProvider: true,
        semanticTokensProvider: {
          documentSelector: null,
          legend: {
            tokenTypes: ["class", "enum", "interface", "namespace", "typeParameter", "type", "parameter", "variable", "enumMember", "property", "function", "member"],
            tokenModifiers: ["declaration", "static", "async", "readonly", "defaultLibrary", "local"]
          },
          full: true,
          range: true
        },
        workspace: {
          fileOperations: {
            willRename: {
              filters: [{
                scheme: "file",
                pattern: {
                  glob: "**/*.{ts,js,jsx,tsx,mjs,mts,cjs,cts}",
                  matches: "file"
                }
              }, {
                scheme: "file",
                pattern: {
                  glob: "**",
                  matches: "folder"
                }
              }]
            }
          }
        }
      }
    };
    if (textDocument?.callHierarchy && typescriptVersion.version?.gte(API.v380)) {
      initializeResult.capabilities.callHierarchyProvider = true;
    }
    if (textDocument?.linkedEditingRange && typescriptVersion.version?.gte(API.v510)) {
      initializeResult.capabilities.linkedEditingRangeProvider = true;
    }
    this.logger.log("onInitialize result", initializeResult);
    return initializeResult;
  }
  registerHandlers() {
    if (this.initializeParams?.capabilities.textDocument?.codeLens) {
      this.implementationsCodeLensProvider = new TypeScriptImplementationsCodeLensProvider(this.tsClient, this.cachedNavTreeResponse, this.fileConfigurationManager);
      this.referencesCodeLensProvider = new TypeScriptReferencesCodeLensProvider(this.tsClient, this.cachedNavTreeResponse, this.fileConfigurationManager);
    }
  }
  initialized(_) {
    const { apiVersion, typescriptVersionSource } = this.tsClient;
    this.options.lspClient.sendNotification(TypescriptVersionNotification, {
      version: apiVersion.displayName,
      source: typescriptVersionSource
    });
    this.watchEventManager?.onInitialized();
  }
  findTypescriptVersion(userTsserverPath, fallbackTsserverPath) {
    const typescriptVersionProvider = new TypeScriptVersionProvider(userTsserverPath, this.logger);
    const userSettingVersion = typescriptVersionProvider.getUserSettingVersion();
    if (userSettingVersion) {
      if (userSettingVersion.isValid) {
        return userSettingVersion;
      }
      this.logger.logIgnoringVerbosity(LogLevel.Warning, `Typescript specified through user setting ignored due to invalid path "${userSettingVersion.path}"`);
    }
    if (this.workspaceRoot) {
      const workspaceVersion = typescriptVersionProvider.getWorkspaceVersion([this.workspaceRoot]);
      if (workspaceVersion) {
        return workspaceVersion;
      }
    }
    const fallbackVersionProvider = new TypeScriptVersionProvider(fallbackTsserverPath, this.logger);
    const fallbackSettingVersion = fallbackVersionProvider.getUserSettingVersion();
    if (fallbackSettingVersion) {
      if (fallbackSettingVersion.isValid) {
        return fallbackSettingVersion;
      }
      this.logger.logIgnoringVerbosity(LogLevel.Warning, `Typescript specified through fallback setting ignored due to invalid path "${fallbackSettingVersion.path}"`);
    }
    const bundledVersion = typescriptVersionProvider.bundledVersion();
    if (bundledVersion?.isValid) {
      return bundledVersion;
    }
    return null;
  }
  getLogDirectoryPath(initializationOptions) {
    if (initializationOptions.tsserver?.logDirectory) {
      return initializationOptions.tsserver.logDirectory;
    }
    if (this.workspaceRoot) {
      return path.join(this.workspaceRoot, ".log");
    }
    return void 0;
  }
  getWorkspaceFolders() {
    if (this.workspaceRoot) {
      return [URI.file(this.workspaceRoot)];
    }
    return [];
  }
  didChangeConfiguration(params) {
    this.fileConfigurationManager.setWorkspaceConfiguration(params.settings || {});
    const ignoredDiagnosticCodes = this.fileConfigurationManager.workspaceConfiguration.diagnostics?.ignoredCodes || [];
    this.tsClient.interruptGetErr(() => this.diagnosticsManager.updateIgnoredDiagnosticCodes(ignoredDiagnosticCodes));
  }
  didOpenTextDocument(params) {
    const { uri, languageId } = params.textDocument;
    if (this.tsClient.toOpenDocument(uri, {
      suppressAlertOnFailure: true
    })) {
      throw new Error(`Can't open already open document: ${uri}`);
    }
    if (!this.tsClient.openTextDocument(params.textDocument)) {
      throw new Error(`Cannot open document '${uri}' (languageId: ${languageId}).`);
    }
    const document = this.tsClient.toOpenDocument(uri);
    if (document) {
      this.fileConfigurationManager.onDidOpenTextDocument(document);
    }
  }
  didCloseTextDocument(params) {
    this.closeDocument(params.textDocument.uri);
  }
  closeDocument(uri) {
    const document = this.tsClient.toOpenDocument(uri);
    if (!document) {
      throw new Error(`Trying to close not opened document: ${uri}`);
    }
    this.cachedNavTreeResponse.onDocumentClose(document);
    this.tsClient.onDidCloseTextDocument(uri);
    this.diagnosticsManager.onDidCloseFile(document.filepath);
    this.fileConfigurationManager.onDidCloseTextDocument(document.uri);
  }
  didChangeTextDocument(params) {
    if (this.fileConfigurationManager.workspaceConfiguration.diagnostics?.eagerClear) {
      const document = this.tsClient.toOpenDocument(params.textDocument.uri);
      if (document) {
        this.diagnosticsManager.clearDiagnosticsForFile(document.filepath);
      }
    }
    this.tsClient.onDidChangeTextDocument(params);
  }
  didSaveTextDocument(_params) {
  }
  didChangeWatchedFiles(params) {
    this.watchEventManager?.handleFileChanges(params);
  }
  async definition(params, token) {
    return this.getDefinition({
      type: this.features.definitionLinkSupport ? CommandTypes.DefinitionAndBoundSpan : CommandTypes.Definition,
      params
    }, token);
  }
  async implementation(params, token) {
    return this.getSymbolLocations({
      type: CommandTypes.Implementation,
      params
    }, token);
  }
  async typeDefinition(params, token) {
    return this.getSymbolLocations({
      type: CommandTypes.TypeDefinition,
      params
    }, token);
  }
  async getDefinition({ type, params }, token) {
    const document = this.tsClient.toOpenDocument(params.textDocument.uri);
    if (!document) {
      return;
    }
    if (type === CommandTypes.DefinitionAndBoundSpan) {
      const args = Position.toFileLocationRequestArgs(document.filepath, params.position);
      const response = await this.tsClient.execute(type, args, token);
      if (response.type !== "response" || !response.body) {
        return void 0;
      }
      const span = response.body.textSpan ? Range.fromTextSpan(response.body.textSpan) : void 0;
      return response.body.definitions.map((location) => {
        const target = toLocation(location, this.tsClient);
        const targetRange = location.contextStart && location.contextEnd ? Range.fromLocations(location.contextStart, location.contextEnd) : target.range;
        return {
          originSelectionRange: span,
          targetRange,
          targetUri: target.uri,
          targetSelectionRange: target.range
        };
      });
    }
    return this.getSymbolLocations({
      type: CommandTypes.Definition,
      params
    });
  }
  async getSymbolLocations({ type, params }, token) {
    const document = this.tsClient.toOpenDocument(params.textDocument.uri);
    if (!document) {
      return [];
    }
    const args = Position.toFileLocationRequestArgs(document.filepath, params.position);
    const response = await this.tsClient.execute(type, args, token);
    if (response.type !== "response" || !response.body) {
      return void 0;
    }
    return response.body.map((fileSpan) => toLocation(fileSpan, this.tsClient));
  }
  async documentSymbol(params, token) {
    const document = this.tsClient.toOpenDocument(params.textDocument.uri);
    if (!document) {
      return [];
    }
    const response = await this.cachedNavTreeResponse.execute(document, () => this.tsClient.execute(CommandTypes.NavTree, {
      file: document.filepath
    }, token));
    if (response.type !== "response" || !response.body?.childItems) {
      return [];
    }
    if (this.supportHierarchicalDocumentSymbol) {
      const symbols2 = [];
      for (const item of response.body.childItems) {
        collectDocumentSymbols(item, symbols2);
      }
      return symbols2;
    }
    const symbols = [];
    for (const item of response.body.childItems) {
      collectSymbolInformation(params.textDocument.uri, item, symbols);
    }
    return symbols;
  }
  get supportHierarchicalDocumentSymbol() {
    const textDocument = this.initializeParams?.capabilities.textDocument;
    const documentSymbol = textDocument?.documentSymbol;
    return !!documentSymbol && !!documentSymbol.hierarchicalDocumentSymbolSupport;
  }
  async completion(params, token) {
    const document = this.tsClient.toOpenDocument(params.textDocument.uri);
    if (!document) {
      return mainExports$2.CompletionList.create([]);
    }
    const { filepath } = document;
    this.completionDataCache.reset();
    const completionOptions = this.fileConfigurationManager.workspaceConfiguration.completions || {};
    const result = await this.tsClient.interruptGetErr(async () => {
      await this.fileConfigurationManager.ensureConfigurationForDocument(document, token);
      const response = await this.tsClient.execute(CommandTypes.CompletionInfo, {
        file: filepath,
        line: params.position.line + 1,
        offset: params.position.character + 1,
        triggerCharacter: getCompletionTriggerCharacter(params.context?.triggerCharacter),
        triggerKind: params.context?.triggerKind
      }, token);
      if (response.type !== "response") {
        return void 0;
      }
      return response.body;
    });
    if (!result) {
      return mainExports$2.CompletionList.create();
    }
    const { entries, isIncomplete, optionalReplacementSpan, isMemberCompletion, isNewIdentifierLocation } = result;
    const defaultCommitCharacters = Object.freeze(result.defaultCommitCharacters);
    const line = document.getLine(params.position.line);
    let dotAccessorContext;
    if (isMemberCompletion) {
      const dotMatch = line.slice(0, params.position.character).match(/\??\.\s*$/) || void 0;
      if (dotMatch) {
        const startPosition = mainExports$2.Position.create(params.position.line, params.position.character - dotMatch[0].length);
        const range2 = mainExports$2.Range.create(startPosition, params.position);
        const text = document.getText(range2);
        dotAccessorContext = {
          range: range2,
          text
        };
      }
    }
    const completionContext = {
      enableCallCompletions: !completionOptions.completeFunctionCalls,
      isMemberCompletion,
      isNewIdentifierLocation,
      dotAccessorContext,
      line,
      optionalReplacementRange: optionalReplacementSpan ? Range.fromTextSpan(optionalReplacementSpan) : void 0
    };
    const completions = asCompletionItems(entries, this.completionDataCache, filepath, params.position, document, this.tsClient, completionOptions, this.features, completionContext, defaultCommitCharacters);
    return mainExports$2.CompletionList.create(completions, isIncomplete);
  }
  async completionResolve(item, token) {
    const data = item.data;
    if (data?.cacheId !== void 0) {
      const cachedData = this.completionDataCache.get(data.cacheId);
      item.data = cachedData;
      if (cachedData?.file) {
        const uri = this.tsClient.toResourceUri(cachedData.file);
        const document = this.tsClient.toOpenDocument(uri);
        if (document) {
          const response = await this.tsClient.interruptGetErr(() => this.tsClient.execute(CommandTypes.CompletionDetails, cachedData, token));
          if (response.type !== "response" || !response.body?.length) {
            return item;
          }
          return asResolvedCompletionItem(item, response.body[0], document, this.tsClient, this.fileConfigurationManager.workspaceConfiguration.completions || {}, this.features);
        }
      }
    }
    return item;
  }
  async hover(params, token) {
    const document = this.tsClient.toOpenDocument(params.textDocument.uri);
    if (!document) {
      return {
        contents: []
      };
    }
    const supportsVerbosity = this.features.hoverVerbositySupport;
    const verbosityLevel = supportsVerbosity ? Math.max(0, params.verbosityLevel ?? 0) : void 0;
    const result = await this.tsClient.interruptGetErr(async () => {
      await this.fileConfigurationManager.ensureConfigurationForDocument(document, token);
      const response = await this.tsClient.execute(CommandTypes.Quickinfo, {
        ...Position.toFileLocationRequestArgs(document.filepath, params.position),
        verbosityLevel
      }, token);
      if (response.type === "response" && response.body) {
        return response.body;
      }
    });
    if (!result) {
      return null;
    }
    const contents = new MarkdownString();
    const { displayString, documentation, tags } = result;
    if (displayString) {
      contents.appendCodeblock("typescript", displayString);
    }
    addMarkdownDocumentation(contents, documentation, tags, this.tsClient);
    return {
      contents: contents.toMarkupContent(),
      range: Range.fromTextSpan(result),
      ...supportsVerbosity && {
        canIncreaseVerbosityLevel: result.canIncreaseVerbosityLevel
      }
    };
  }
  async prepareRename(params, token) {
    const document = this.tsClient.toOpenDocument(params.textDocument.uri);
    if (!document) {
      return null;
    }
    const response = await this.tsClient.execute(CommandTypes.Rename, Position.toFileLocationRequestArgs(document.filepath, params.position), token);
    if (response.type !== "response" || !response.body?.info) {
      return null;
    }
    const renameInfo = response.body.info;
    if (!renameInfo.canRename) {
      throw new Error(renameInfo.localizedErrorMessage);
    }
    return Range.fromTextSpan(renameInfo.triggerSpan);
  }
  async rename(params, token) {
    const document = this.tsClient.toOpenDocument(params.textDocument.uri);
    if (!document) {
      return null;
    }
    const result = await this.tsClient.interruptGetErr(async () => {
      await this.fileConfigurationManager.ensureConfigurationForDocument(document);
      const response = await this.tsClient.execute(CommandTypes.Rename, Position.toFileLocationRequestArgs(document.filepath, params.position), token);
      if (response.type !== "response" || !response.body?.info.canRename || !response.body?.locs.length) {
        return null;
      }
      return response.body;
    });
    if (!result) {
      return null;
    }
    const changes = {};
    result.locs.forEach((spanGroup) => {
      const uri = this.tsClient.toResourceUri(spanGroup.file);
      const textEdits = changes[uri] || (changes[uri] = []);
      spanGroup.locs.forEach((textSpan) => {
        textEdits.push({
          newText: `${textSpan.prefixText || ""}${params.newName}${textSpan.suffixText || ""}`,
          range: {
            start: Position.fromLocation(textSpan.start),
            end: Position.fromLocation(textSpan.end)
          }
        });
      });
    });
    return {
      changes
    };
  }
  async references(params, token) {
    const document = this.tsClient.toOpenDocument(params.textDocument.uri);
    if (!document) {
      return [];
    }
    const response = await this.tsClient.execute(CommandTypes.References, Position.toFileLocationRequestArgs(document.filepath, params.position), token);
    if (response.type !== "response" || !response.body) {
      return [];
    }
    return response.body.refs.filter((fileSpan) => params.context.includeDeclaration || !fileSpan.isDefinition).map((fileSpan) => toLocation(fileSpan, this.tsClient));
  }
  async documentFormatting(params, token) {
    const document = this.tsClient.toOpenDocument(params.textDocument.uri);
    if (!document) {
      throw new Error(`The document should be opened for formatting', file: ${params.textDocument.uri}`);
    }
    const formatOptions = params.options;
    await this.fileConfigurationManager.ensureConfigurationOptions(document, formatOptions);
    const response = await this.tsClient.execute(CommandTypes.Format, {
      ...Range.toFormattingRequestArgs(document.filepath, document.getFullRange()),
      options: formatOptions
    }, token);
    if (response.type !== "response" || !response.body) {
      return [];
    }
    return response.body.map((e) => toTextEdit(e));
  }
  async documentRangeFormatting(params, token) {
    const document = this.tsClient.toOpenDocument(params.textDocument.uri);
    if (!document) {
      return [];
    }
    const formatOptions = params.options;
    await this.fileConfigurationManager.ensureConfigurationOptions(document, formatOptions);
    const response = await this.tsClient.execute(CommandTypes.Format, {
      ...Range.toFormattingRequestArgs(document.filepath, params.range),
      options: formatOptions
    }, token);
    if (response.type !== "response" || !response.body) {
      return [];
    }
    return response.body.map((e) => toTextEdit(e));
  }
  async selectionRanges(params, token) {
    const document = this.tsClient.toOpenDocument(params.textDocument.uri);
    if (!document) {
      return null;
    }
    const response = await this.tsClient.execute(CommandTypes.SelectionRange, {
      file: document.filepath,
      locations: params.positions.map(Position.toLocation)
    }, token);
    if (response.type !== "response" || !response.body) {
      return null;
    }
    return response.body.map(toSelectionRange);
  }
  async signatureHelp(params, token) {
    const document = this.tsClient.toOpenDocument(params.textDocument.uri);
    if (!document) {
      return void 0;
    }
    const { position, context } = params;
    const args = {
      file: document.filepath,
      line: position.line + 1,
      offset: position.character + 1,
      triggerReason: context ? toTsTriggerReason(context) : void 0
    };
    const response = await this.tsClient.interruptGetErr(() => this.tsClient.execute(CommandTypes.SignatureHelp, args, token));
    if (response.type !== "response" || !response.body) {
      return void 0;
    }
    return asSignatureHelp(response.body, params.context, this.tsClient);
  }
  async codeAction(params, token) {
    const document = this.tsClient.toOpenDocument(params.textDocument.uri);
    if (!document) {
      return [];
    }
    const actions = await this.codeActionsManager.provideCodeActions(document, params.range, params.context, token);
    const fileRangeArgs = Range.toFileRangeRequestArgs(document.filepath, params.range);
    const kinds = params.context.only?.map((kind) => new CodeActionKind(kind));
    if (!kinds || kinds.some((kind) => CodeActionKind.Refactor.contains(kind))) {
      actions.push(...provideRefactors(await this.getRefactors(fileRangeArgs, params.context, this.features, token), fileRangeArgs, this.features));
    }
    for (const kind of kinds || []) {
      for (const command2 of organizeImportsCommands) {
        if (!kind.contains(command2.kind) || command2.minVersion && this.tsClient.apiVersion.lt(command2.minVersion)) {
          continue;
        }
        let skipDestructiveCodeActions = command2.mode === OrganizeImportsMode.SortAndCombine;
        let mode = command2.mode;
        const isOrganizeImports = command2.kind.equals(CodeActionKind.SourceOrganizeImportsTs);
        if (isOrganizeImports) {
          const documentHasErrors = params.context.diagnostics.some((d) => (d.severity ?? 0) <= 2);
          skipDestructiveCodeActions = documentHasErrors;
          mode = OrganizeImportsMode.SortAndCombine;
        }
        const response = await this.tsClient.interruptGetErr(async () => {
          await this.fileConfigurationManager.ensureConfigurationForDocument(document, token);
          return this.tsClient.execute(CommandTypes.OrganizeImports, {
            scope: {
              type: "file",
              args: fileRangeArgs
            },
            skipDestructiveCodeActions,
            mode
          }, token);
        });
        if (response.type === "response" && response.body) {
          actions.push(...provideOrganizeImports(command2, response, this.tsClient));
        }
      }
    }
    return actions;
  }
  async getRefactors(fileRangeArgs, context, features, token) {
    const kinds = (context.only || [void 0]).filter((kind) => kind === void 0 || CodeActionKind.Refactor.contains(new CodeActionKind(kind)));
    const responses = await Promise.all(kinds.map(async (kind) => {
      const args = {
        ...fileRangeArgs,
        triggerReason: context.triggerKind === mainExports$2.CodeActionTriggerKind.Invoked ? "invoked" : void 0,
        kind,
        includeInteractiveActions: features.moveToFileCodeActionSupport
      };
      const response = await this.tsClient.execute(CommandTypes.GetApplicableRefactors, args, token);
      return response.type === "response" && response.body ? response.body : [];
    }));
    return responses.flat();
  }
  async codeActionResolve(params, _token) {
    return this.codeActionsManager.resolveCodeAction(params);
  }
  async executeCommand(params, token, workDoneProgress) {
    if (this.commandManager.handlesCommand(params.command)) {
      return await this.commandManager.handle(params.command, ...params.arguments || []);
    } else if (params.command === Commands.APPLY_REFACTORING && params.arguments) {
      const args = params.arguments[0];
      const response = await this.tsClient.execute(CommandTypes.GetEditsForRefactor, args, token);
      if (response.type !== "response" || !response.body) {
        return;
      }
      const { body } = response;
      if (body?.notApplicableReason) {
        throw new Error(body.notApplicableReason);
      }
      if (!body?.edits.length) {
        return;
      }
      for (const edit of body.edits) {
        await fs.ensureFile(edit.fileName);
      }
      if (!await this.applyFileCodeEdits(body.edits)) {
        return;
      }
      const renameLocation = body.renameLocation;
      if (renameLocation) {
        await this.options.lspClient.rename({
          textDocument: {
            uri: this.tsClient.toResourceUri(args.file)
          },
          position: Position.fromLocation(renameLocation)
        });
      }
    } else if (params.command === Commands.CONFIGURE_PLUGIN && params.arguments) {
      const [pluginName, configuration2] = params.arguments;
      this.tsClient.configurePlugin(pluginName, configuration2);
    } else if (params.command === Commands.ORGANIZE_IMPORTS && params.arguments) {
      const file2 = params.arguments[0];
      const uri = this.tsClient.toResourceUri(file2);
      const document = this.tsClient.toOpenDocument(uri);
      if (!document) {
        return;
      }
      const additionalArguments = params.arguments[1] || {};
      const body = await this.tsClient.interruptGetErr(async () => {
        await this.fileConfigurationManager.ensureConfigurationForDocument(document);
        const mode = additionalArguments.mode ?? (additionalArguments.skipDestructiveCodeActions ? OrganizeImportsMode.SortAndCombine : OrganizeImportsMode.All);
        const response = await this.tsClient.execute(CommandTypes.OrganizeImports, {
          scope: {
            type: "file",
            args: {
              file: file2
            }
          },
          skipDestructiveCodeActions: additionalArguments.skipDestructiveCodeActions,
          mode
        }, token);
        if (response.type !== "response") {
          return;
        }
        return response.body;
      });
      if (!body) {
        return;
      }
      await this.applyFileCodeEdits(body);
    } else if (params.command === Commands.APPLY_RENAME_FILE && params.arguments) {
      const { sourceUri, targetUri } = params.arguments[0];
      this.applyRenameFile(sourceUri, targetUri, token);
    } else if (params.command === Commands.APPLY_COMPLETION_CODE_ACTION && params.arguments) {
      const [_, codeActions] = params.arguments;
      for (const codeAction of codeActions) {
        await this.applyFileCodeEdits(codeAction.changes);
        if (codeAction.commands?.length) {
          for (const command2 of codeAction.commands) {
            await this.tsClient.execute(CommandTypes.ApplyCodeActionCommand, {
              command: command2
            }, token);
          }
        }
        break;
      }
    } else if (params.command === Commands.SOURCE_DEFINITION) {
      const [uri, position] = params.arguments || [];
      const reporter = await this.options.lspClient.createProgressReporter(token, workDoneProgress);
      return SourceDefinitionCommand.execute(uri, position, this.tsClient, this.options.lspClient, reporter, token);
    } else {
      this.logger.error(`Unknown command ${params.command}.`);
    }
  }
  async applyFileCodeEdits(edits) {
    if (!edits.length) {
      return false;
    }
    const changes = {};
    for (const edit of edits) {
      changes[this.tsClient.toResourceUri(edit.fileName)] = edit.textChanges.map(toTextEdit);
    }
    const { applied } = await this.options.lspClient.applyWorkspaceEdit({
      edit: {
        changes
      }
    });
    return applied;
  }
  async willRenameFiles(params, token) {
    const changes = {};
    for (const rename of params.files) {
      const codeEdits = await this.getEditsForFileRename(rename.oldUri, rename.newUri, token);
      for (const codeEdit of codeEdits) {
        const uri = this.tsClient.toResourceUri(codeEdit.fileName);
        const textEdits = changes[uri] || (changes[uri] = []);
        textEdits.push(...codeEdit.textChanges.map(toTextEdit));
      }
    }
    return {
      changes
    };
  }
  async applyRenameFile(sourceUri, targetUri, token) {
    const edits = await this.getEditsForFileRename(sourceUri, targetUri, token);
    this.applyFileCodeEdits(edits);
  }
  async getEditsForFileRename(sourceUri, targetUri, token) {
    const newFilePath = this.tsClient.toTsFilePath(targetUri);
    const oldFilePath = this.tsClient.toTsFilePath(sourceUri);
    if (!newFilePath || !oldFilePath) {
      return [];
    }
    const response = await this.tsClient.interruptGetErr(() => this.tsClient.execute(CommandTypes.GetEditsForFileRename, {
      oldFilePath,
      newFilePath
    }, token));
    if (response.type !== "response" || !response.body) {
      return [];
    }
    return response.body;
  }
  async codeLens(params, token) {
    if (!this.implementationsCodeLensProvider || !this.referencesCodeLensProvider) {
      return [];
    }
    const doc = this.tsClient.toOpenDocument(params.textDocument.uri);
    if (!doc) {
      return [];
    }
    return [...await this.implementationsCodeLensProvider.provideCodeLenses(doc, token), ...await this.referencesCodeLensProvider.provideCodeLenses(doc, token)];
  }
  async codeLensResolve(codeLens, token) {
    if (!this.implementationsCodeLensProvider || !this.referencesCodeLensProvider) {
      return codeLens;
    }
    if (codeLens.data?.type === CodeLensType.Implementation) {
      return await this.implementationsCodeLensProvider.resolveCodeLens(codeLens, token);
    }
    if (codeLens.data?.type === CodeLensType.Reference) {
      return await this.referencesCodeLensProvider.resolveCodeLens(codeLens, token);
    }
    throw new Error("Unexpected CodeLens!");
  }
  async documentHighlight(params, token) {
    const doc = this.tsClient.toOpenDocument(params.textDocument.uri);
    if (!doc) {
      throw new Error(`The document should be opened first: ${params.textDocument.uri}`);
    }
    const response = await this.tsClient.execute(CommandTypes.DocumentHighlights, {
      file: doc.filepath,
      line: params.position.line + 1,
      offset: params.position.character + 1,
      filesToSearch: [doc.filepath]
    }, token);
    if (response.type !== "response" || !response.body) {
      return [];
    }
    return response.body.flatMap((item) => toDocumentHighlight(item));
  }
  async workspaceSymbol(params, token) {
    const response = await this.tsClient.execute(CommandTypes.Navto, {
      file: this.tsClient.lastFileOrDummy(),
      searchValue: params.query
    }, token);
    if (response.type !== "response" || !response.body) {
      return [];
    }
    return response.body.map((item) => ({
      location: {
        uri: this.tsClient.toResourceUri(item.file),
        range: {
          start: Position.fromLocation(item.start),
          end: Position.fromLocation(item.end)
        }
      },
      kind: toSymbolKind(item.kind),
      name: item.name
    }));
  }
  async foldingRanges(params, token) {
    const document = this.tsClient.toOpenDocument(params.textDocument.uri);
    if (!document) {
      throw new Error(`The document should be opened for foldingRanges', file: ${params.textDocument.uri}`);
    }
    const response = await this.tsClient.execute(CommandTypes.GetOutliningSpans, {
      file: document.filepath
    }, token);
    if (response.type !== "response" || !response.body) {
      return void 0;
    }
    const foldingRanges = [];
    for (const span of response.body) {
      const foldingRange2 = this.asFoldingRange(span, document);
      if (foldingRange2) {
        foldingRanges.push(foldingRange2);
      }
    }
    return foldingRanges;
  }
  asFoldingRange(span, document) {
    const range2 = Range.fromTextSpan(span.textSpan);
    const kind = this.asFoldingRangeKind(span);
    if (span.kind === "comment") {
      const line = document.getLine(range2.start.line);
      if (line.match(/\/\/\s*#endregion/gi)) {
        return void 0;
      }
    }
    const startLine = range2.start.line;
    const endLine = range2.end.character > 0 && document.getText(mainExports$2.Range.create(mainExports$2.Position.create(range2.end.line, range2.end.character - 1), range2.end)) === "}" ? Math.max(range2.end.line - 1, range2.start.line) : range2.end.line;
    return {
      startLine,
      endLine,
      kind
    };
  }
  asFoldingRangeKind(span) {
    switch (span.kind) {
      case "comment":
        return mainExports$2.FoldingRangeKind.Comment;
      case "region":
        return mainExports$2.FoldingRangeKind.Region;
      case "imports":
        return mainExports$2.FoldingRangeKind.Imports;
      case "code":
      default:
        return void 0;
    }
  }
  onTsEvent(event) {
    if (this.watchEventManager?.handleTsserverEvent(event)) {
      return;
    }
    const eventName = event.event;
    if (eventName === EventName.semanticDiag || eventName === EventName.syntaxDiag || eventName === EventName.suggestionDiag) {
      const diagnosticEvent = event;
      if (diagnosticEvent.body?.diagnostics) {
        const { file: file2, diagnostics } = diagnosticEvent.body;
        this.diagnosticsManager.updateDiagnostics(getDignosticsKind(event), file2, diagnostics);
      }
    }
  }
  async prepareCallHierarchy(params, token) {
    const document = this.tsClient.toOpenDocument(params.textDocument.uri);
    if (!document) {
      return null;
    }
    const args = Position.toFileLocationRequestArgs(document.filepath, params.position);
    const response = await this.tsClient.execute(CommandTypes.PrepareCallHierarchy, args, token);
    if (response.type !== "response" || !response.body) {
      return null;
    }
    const items = Array.isArray(response.body) ? response.body : [response.body];
    return items.map((item) => fromProtocolCallHierarchyItem(item, this.tsClient, this.workspaceRoot));
  }
  async callHierarchyIncomingCalls(params, token) {
    const file2 = this.tsClient.toTsFilePath(params.item.uri);
    if (!file2) {
      return null;
    }
    const args = Position.toFileLocationRequestArgs(file2, params.item.selectionRange.start);
    const response = await this.tsClient.execute(CommandTypes.ProvideCallHierarchyIncomingCalls, args, token);
    if (response.type !== "response" || !response.body) {
      return null;
    }
    return response.body.map((item) => fromProtocolCallHierarchyIncomingCall(item, this.tsClient, this.workspaceRoot));
  }
  async callHierarchyOutgoingCalls(params, token) {
    const file2 = this.tsClient.toTsFilePath(params.item.uri);
    if (!file2) {
      return null;
    }
    const args = Position.toFileLocationRequestArgs(file2, params.item.selectionRange.start);
    const response = await this.tsClient.execute(CommandTypes.ProvideCallHierarchyOutgoingCalls, args, token);
    if (response.type !== "response" || !response.body) {
      return null;
    }
    return response.body.map((item) => fromProtocolCallHierarchyOutgoingCall(item, this.tsClient, this.workspaceRoot));
  }
  async inlayHints(params, token) {
    return await TypeScriptInlayHintsProvider.provideInlayHints(params.textDocument, params.range, this.tsClient, this.options.lspClient, this.fileConfigurationManager, token);
  }
  async linkedEditingRange(params, token) {
    const doc = this.tsClient.toOpenDocument(params.textDocument.uri);
    if (!doc) {
      return null;
    }
    const args = Position.toFileLocationRequestArgs(doc.filepath, params.position);
    const response = await this.tsClient.execute(CommandTypes.LinkedEditingRange, args, token);
    if (response.type !== "response" || !response.body) {
      return null;
    }
    return {
      ranges: response.body.ranges.map(Range.fromTextSpan),
      wordPattern: response.body.wordPattern
    };
  }
  async semanticTokensFull(params, token) {
    const doc = this.tsClient.toOpenDocument(params.textDocument.uri);
    if (!doc) {
      return {
        data: []
      };
    }
    const start = doc.offsetAt({
      line: 0,
      character: 0
    });
    const end = doc.offsetAt({
      line: doc.lineCount,
      character: 0
    });
    return this.getSemanticTokens(doc, doc.filepath, start, end, token);
  }
  async semanticTokensRange(params, token) {
    const doc = this.tsClient.toOpenDocument(params.textDocument.uri);
    if (!doc) {
      return {
        data: []
      };
    }
    const start = doc.offsetAt(params.range.start);
    const end = doc.offsetAt(params.range.end);
    return this.getSemanticTokens(doc, doc.filepath, start, end, token);
  }
  async getSemanticTokens(doc, file2, startOffset, endOffset, token) {
    const response = await this.tsClient.execute(CommandTypes.EncodedSemanticClassificationsFull, {
      file: file2,
      start: startOffset,
      length: endOffset - startOffset,
      format: "2020"
    }, token, {
      cancelOnResourceChange: doc.uri.toString()
    });
    if (response.type !== "response" || !response.body?.spans) {
      return {
        data: []
      };
    }
    return {
      data: transformSpans(doc, response.body.spans)
    };
  }
};
var progressExports = requireProgress();
var nullProgressReporter = progressExports.attachWorkDone(void 0, void 0);
var LspClientImpl = class {
  connection;
  constructor(connection2) {
    this.connection = connection2;
  }
  async createProgressReporter(_, workDoneProgress) {
    let reporter;
    if (workDoneProgress && workDoneProgress.constructor !== nullProgressReporter.constructor) {
      reporter = workDoneProgress;
    } else {
      reporter = workDoneProgress || await this.connection.window.createWorkDoneProgress();
    }
    return reporter;
  }
  async withProgress(options2, task) {
    const { message, reporter } = options2;
    reporter.begin(message);
    return task(reporter).then((result) => {
      reporter.done();
      return result;
    });
  }
  publishDiagnostics(params) {
    this.connection.sendDiagnostics(params);
  }
  showErrorMessage(message) {
    this.connection.sendNotification(mainExports$2.ShowMessageNotification.type, {
      type: mainExports$2.MessageType.Error,
      message
    });
  }
  logMessage(args) {
    this.connection.sendNotification(mainExports$2.LogMessageNotification.type, args);
  }
  async getWorkspaceConfiguration(scopeUri, section) {
    return await this.connection.workspace.getConfiguration({
      scopeUri,
      section
    });
  }
  async applyWorkspaceEdit(params) {
    return this.connection.workspace.applyEdit(params);
  }
  async rename(args) {
    return this.connection.sendRequest(TypeScriptRenameRequest.type, args);
  }
  async codeLensRefresh() {
    await this.connection.sendRequest(mainExports$2.CodeLensRefreshRequest.type);
  }
  async inlayHintRefresh() {
    await this.connection.sendRequest(mainExports$2.InlayHintRefreshRequest.type);
  }
  async sendNotification(type, params) {
    await this.connection.sendNotification(type, params);
  }
  async registerDidChangeWatchedFilesCapability(watchers) {
    return await this.connection.client.register(mainExports$2.DidChangeWatchedFilesNotification.type, {
      watchers
    });
  }
};
function createLspConnection(options2) {
  const connection2 = lsp.createConnection(lsp.ProposedFeatures.all);
  const lspClient = new LspClientImpl(connection2);
  const logger = new LspClientLogger(lspClient, options2.showMessageLevel);
  const server2 = new LspServer({
    logger,
    lspClient
  });
  connection2.onInitialize(server2.initialize.bind(server2));
  connection2.onInitialized(server2.initialized.bind(server2));
  connection2.onDidChangeConfiguration(server2.didChangeConfiguration.bind(server2));
  connection2.onDidOpenTextDocument(server2.didOpenTextDocument.bind(server2));
  connection2.onDidSaveTextDocument(server2.didSaveTextDocument.bind(server2));
  connection2.onDidCloseTextDocument(server2.didCloseTextDocument.bind(server2));
  connection2.onDidChangeTextDocument(server2.didChangeTextDocument.bind(server2));
  connection2.onDidChangeWatchedFiles(server2.didChangeWatchedFiles.bind(server2));
  connection2.onCodeAction(server2.codeAction.bind(server2));
  connection2.onCodeActionResolve(server2.codeActionResolve.bind(server2));
  connection2.onCodeLens(server2.codeLens.bind(server2));
  connection2.onCodeLensResolve(server2.codeLensResolve.bind(server2));
  connection2.onCompletion(server2.completion.bind(server2));
  connection2.onCompletionResolve(server2.completionResolve.bind(server2));
  connection2.onDefinition(server2.definition.bind(server2));
  connection2.onImplementation(server2.implementation.bind(server2));
  connection2.onTypeDefinition(server2.typeDefinition.bind(server2));
  connection2.onDocumentFormatting(server2.documentFormatting.bind(server2));
  connection2.onDocumentRangeFormatting(server2.documentRangeFormatting.bind(server2));
  connection2.onDocumentHighlight(server2.documentHighlight.bind(server2));
  connection2.onDocumentSymbol(server2.documentSymbol.bind(server2));
  connection2.onExecuteCommand(server2.executeCommand.bind(server2));
  connection2.onHover(server2.hover.bind(server2));
  connection2.onReferences(server2.references.bind(server2));
  connection2.onRenameRequest(server2.rename.bind(server2));
  connection2.onPrepareRename(server2.prepareRename.bind(server2));
  connection2.onSelectionRanges(server2.selectionRanges.bind(server2));
  connection2.onSignatureHelp(server2.signatureHelp.bind(server2));
  connection2.onWorkspaceSymbol(server2.workspaceSymbol.bind(server2));
  connection2.onFoldingRanges(server2.foldingRanges.bind(server2));
  connection2.languages.onLinkedEditingRange(server2.linkedEditingRange.bind(server2));
  connection2.languages.callHierarchy.onPrepare(server2.prepareCallHierarchy.bind(server2));
  connection2.languages.callHierarchy.onIncomingCalls(server2.callHierarchyIncomingCalls.bind(server2));
  connection2.languages.callHierarchy.onOutgoingCalls(server2.callHierarchyOutgoingCalls.bind(server2));
  connection2.languages.inlayHint.on(server2.inlayHints.bind(server2));
  connection2.languages.semanticTokens.on(server2.semanticTokensFull.bind(server2));
  connection2.languages.semanticTokens.onRange(server2.semanticTokensRange.bind(server2));
  connection2.workspace.onWillRenameFiles(server2.willRenameFiles.bind(server2));
  return connection2;
}
var DEFAULT_LOG_LEVEL = lsp$1.MessageType.Info;
var { version } = { version: "5.3.0" };
var program = new Command("typescript-language-server").version(version).requiredOption("--stdio", "use stdio").option("--log-level <logLevel>", "A number indicating the log level (4 = log, 3 = info, 2 = warn, 1 = error). Defaults to `2`.", (value) => parseInt(value, 10), 2).parse(process.argv);
var options = program.opts();
var logLevel = DEFAULT_LOG_LEVEL;
if (options.logLevel && (options.logLevel < 1 || options.logLevel > 4)) {
  console.error(`Invalid '--log-level ${logLevel}'. Falling back to 'info' level.`);
  logLevel = DEFAULT_LOG_LEVEL;
}
createLspConnection({
  showMessageLevel: logLevel
}).listen();
